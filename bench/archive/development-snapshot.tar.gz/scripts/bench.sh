#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
scripts/fetch-data.sh
cargo build --release --features baseline --bin compare
mkdir -p bench/local
export TRIALS_CSV="${TRIALS_CSV:-bench/local/trials.csv}"
target/release/compare "${THREADS:-4}" "${ROUNDS:-11}" both bench/data/enwik8 bench/data/x-ray bench/data/mozilla | tee bench/local/summary.csv
scripts/check-results.py "$TRIALS_CSV"
