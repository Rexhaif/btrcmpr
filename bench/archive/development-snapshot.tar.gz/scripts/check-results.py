#!/usr/bin/env python3
"""Check all three conditions, separately on each full input, from paired samples."""
import csv
import statistics
import sys
from pathlib import Path

sizes = {"enwik8": 100_000_000, "x-ray": 8_474_240, "mozilla": 51_220_480}
samples = {name: {} for name in sizes}
with open(sys.argv[1], newline="") as f:
    for r in csv.DictReader(f):
        name, codec = Path(r["file"]).name, r["codec"]
        key = (int(r["round"]), codec)
        if int(r["raw_bytes"]) != sizes[name] or codec not in ("btrcmpr", "zstd") or key in samples[name]:
            sys.exit(f"Invalid or duplicate trial for {name}: {key}")
        samples[name][key] = (int(r["compressed_bytes"]), float(r["compress_seconds"]), float(r["decompress_seconds"]))
ok = True
for name, data in samples.items():
    rounds = sorted({r for r, _ in data})
    if not rounds or rounds != list(range(1, 1 + len(rounds))):
        sys.exit(f"Missing rounds for {name}")
    series = [[data[(r, c)] for r in rounds] for c in ("btrcmpr", "zstd")]
    if any(len({s[0] for s in v}) != 1 or any(min(s) <= 0 for s in v) for v in series):
        sys.exit(f"Inconsistent sizes or times for {name}")
    a, b = [[statistics.median(x) for x in zip(*v)] for v in series]
    passed = all(x < y for x, y in zip(a, b))
    paired = [sum(x[i] < y[i] for x, y in zip(*series)) for i in (1, 2)]
    print(f"{name:7} {'PASS' if passed else 'FAIL'}  {100*(1-a[0]/b[0]):.2f}% fewer bytes; "
          f"encode {b[1]/a[1]:.3f}x; decode {b[2]/a[2]:.3f}x; "
          f"paired speed wins {paired[0]}/{len(rounds)}, {paired[1]}/{len(rounds)}")
    ok &= passed
sys.exit(0 if ok else 1)
