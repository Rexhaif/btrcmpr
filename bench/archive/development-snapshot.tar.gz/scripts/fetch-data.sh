#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p bench/data
tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
fetch() {
  local f=$1 hash=$2 url=$3
  if [[ -f "bench/data/$f" ]] && echo "$hash  bench/data/$f" | sha256sum --check --status; then return; fi
  curl -fLsS --retry 3 "$url" -o "$tmp/archive"
  case "$f" in enwik8) unzip -p "$tmp/archive" enwik8 > "$tmp/$f";; *) bzip2 -dc "$tmp/archive" > "$tmp/$f";; esac
  echo "$hash  $tmp/$f" | sha256sum -c
  mv "$tmp/$f" "bench/data/$f"
}
fetch enwik8 2b49720ec4d78c3c9fabaee6e4179a5e997302b3a70029f30f2d582218c024a8 https://mattmahoney.net/dc/enwik8.zip
fetch x-ray 7de9fce1405dc44ae5e6813ed21cd5751e761bd4265655a005d39b9685d1c9ad https://sun.aei.polsl.pl/~sdeor/corpus/x-ray.bz2
fetch mozilla 657fc3764b0c75ac9de9623125705831ebbfbe08fed248df73bc2dc66e2a963b https://sun.aei.polsl.pl/~sdeor/corpus/mozilla.bz2
