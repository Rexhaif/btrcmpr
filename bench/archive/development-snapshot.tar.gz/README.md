# btrcmpr

A lossless Rust compression experiment for the four Cortex-A76 cores in a Raspberry Pi 5. The codec has no crate dependencies and links no compression library. The encoder accepts levels 1 through 22 (default 3) and selects its representation from the input bytes. Compressed files contain everything needed to decode them, including any reordering information. No corpus-trained dictionary or input hashes are built into the codec.

```sh
python3 scripts/build-profiled.py --selected --profile-data bench/results/presets/native-combined-1/compiler.profdata
target/profiled/release/btrcmpr c input.bin archive.btr 4
target/profiled/release/btrcmpr c -18 input.bin smaller.btr 4
target/profiled/release/btrcmpr d archive.btr restored.bin 4
cmp input.bin restored.bin
```

The optional last argument is the worker count; the default is the available parallelism. The CLI currently works on whole files in memory. The [preset guide](PRESETS.md) explains what each level changes on text, signals and object archives. Run `python3 scripts/frame_info.py archive.btr` to see what was actually stored. The build uses `target-cpu=native`; build on the machine where you will run it. The command above uses the distributed compiler profile. To repeat compiler training locally, install `rustup component add llvm-tools-preview` and omit `--profile-data`. For a quick build without compiler training or the comparison tools, run `cargo build --release --locked --bin btrcmpr`. That build uses the original level-one scanner.

The [verified standalone ARM codec](target/verified/all-22-f8d320e7b5b2/btrcmpr) passed all 22 presets on enwik8, x-ray and Mozilla. The [release comparison](bench/results/presets/native-combined-1/release.md) gives the tightest margins and representative speeds. The [full 66-cell table](bench/results/presets/integrated/f8d320e7b5b2449a2586eccc6af365eafb306215e6c6b403a91de57e03078464/rates.md) shows both codecs’ compression ratios and encode/decode throughput at every level. The [individual rounds](bench/results/presets/integrated/f8d320e7b5b2449a2586eccc6af365eafb306215e6c6b403a91de57e03078464/paired-rounds.md) show timing variation, and the [candidate table](bench/results/presets/level-one-candidates.md) compares the alternatives. The [release manifest](bench/results/presets/native-combined-1/release.json) records the executable, compiler profile, raw trials and independently restored archives.

**Selected executable: 66 of 66 comparisons verified; 66 meet the 5% decode rule, 63 also decode faster than zstd.**

The [selected build](scripts/build-profiled.py) trains the compiler on separate documentation, executables, source code and synthetic data, then uses thin link-time optimization. The comparison tools need system libzstd; the standalone codec does not link it. A [rebuild from this checkout](bench/results/presets/research/combined-rebuild/README.md) reproduced all three level-1 archives and all machine instructions in the original CLI and comparator. The [exact compiler profile](bench/results/presets/native-combined-1/compiler.profdata) is included for reproducing that build without repeating training. A [15-pair repeat on the exact selected executable](bench/results/presets/research/selected-stability-15/README.md) passed level 1 on enwik8 and Mozilla. A [five-pair source rebuild replay](bench/results/presets/research/combined-rebuild/README.md) missed Mozilla encode by 0.37%; the longer rebuild replay passed.

<details>
<summary>Earlier executables, repeats and cross-build coverage</summary>

On this Pi the [paired compiler study](bench/results/presets/research/release-codegen/README.md) improved level-1 enwik8 throughput and passed Mozilla twice. In a [fresh production comparison on all three inputs](bench/results/presets/native-profiled-1/README.md), Mozilla and x-ray passed outright. Enwik8 compressed smaller and decoded 2.21% faster, but encoded 3.69% slower than matched zstd.

At level 1 the combined build uses the [regional scanner](bench/results/presets/research/native-regional-scan-1/README.md). The [earlier scanner executable](target/verified/regional-scan-7/btrcmpr) passed the [independent 15-pair check](bench/results/presets/research/native-regional-scan-1/long-repeat/README.md) on all three files. Enwik8 encoded at 640.60 vs 612.65 MB/s and decoded at 1568.04 vs 1601.16 MB/s. One earlier five-pair repeat missed on encode by 1.18%; each run produced the same 40,513,113-byte archive.

The current source also has two newer preset changes. [16-bit signals](bench/results/presets/research/signal-grid/README.md) can learn the spacing between rows: levels 2, 3–4, 5–11 and 12–22 use progressively larger jobs or search budgets. At level 22 the tested policy compressed x-ray to 3,681,518 bytes; zstd used 5,253,226. For [object archives at level 20](bench/results/presets/research/object-step/README.md), instruction sections keep the level-19 match window, bringing Mozilla below both its level-19 size and matched zstd. These changes are tracked on a fresh combined source snapshot, separately from the earlier scanner executable.

[All 22 presets, by file](bench/results/presets/preset-ladder.md) gives the measured ratios and relative throughput; its [CSV](bench/results/presets/preset-ladder.csv) includes absolute MB/s.

**Preset comparison verified on one executable.** [66 of 66 latest file/level comparisons meet the 5% decode allowance](bench/results/presets/decode-tolerance.md) while also producing a smaller archive and encoding faster than matched zstd. This ledger selects the latest result per cell across builds. Across versions, [66 of 66 file/level combinations have passed all three tests at least once](bench/results/presets/coverage.csv): x-ray 1–22; Mozilla 1–22; enwik8 1–22. The full matrix has passed on one executable. [Levels 13–15](bench/results/presets/phrase-levels-13-15/README.md) and levels 18, [20](bench/results/presets/dictionary-20-22/level-20.md), and [22](bench/results/presets/dictionary-20-22/level-22.md) passed on all three inputs. The acceptance rule allows up to 5% lower decode throughput on each file at the same level and worker count. The [preset results](bench/results/presets/README.md) use four workers in both directions and give zstd a full quarter-file frame per worker.

[Mozilla levels 6 and 17](bench/results/presets/native-object-6-17/README.md) now beat zstd on all three measures on the revised build. Level 6 restores the same archive in groups of 128 machine instructions; level 17 uses separate job sizes for plain data, records and code. On this build, levels 2, 3, 6 and 17 have been independently verified on all three files. On that earlier executable, level-1 encoding on enwik8 and Mozilla missed zstd. The [audit of the revised executable](bench/results/presets/integrated/620e00021252d9310e5e3e00ace74908c4336f2bd5a0309dd5ec618d0964a5c1/README.md) is separate from later measurements of older executables.

The [level-1 candidate table](bench/results/presets/level-one-candidates.md) compares the previous and current presets with matched zstd. The [new native level-1 comparison](bench/results/presets/native-fastest-1/README.md) uses six-byte match keys and batches 32 distances on ordinary blocks; on recognized object archives it uses seven-byte keys for ordinary sections and computes exact record-width prices from cumulative counts. Every archive is smaller than zstd’s and every decoder clears the 95% throughput threshold. On the first production run, encoding reached 555.55 vs 590.13 MB/s on enwik8 and 762.57 vs 768.29 MB/s on Mozilla. X-ray won on all three measures. A [predeclared 15-pair repeat](bench/results/presets/research/native-stability-1/README.md) passed all three measures on Mozilla (745.93 vs 739.77 MB/s encode) and still missed encode on enwik8 (551.00 vs 611.46 MB/s). On the same executable, levels 2, 3, and 6 pass on every file under the 5% rule. The [new hardware counters](bench/results/profiles/enwik8-general/native-fastest-1/README.md) show 28.55 vs 29.42 encode instructions per byte on enwik8 and 23.84 vs 23.86 on Mozilla. Results for this executable are tracked [independently](bench/results/presets/integrated/f9783e666aaaa49101ffa877053e5b04a1d88972d520134eb3e7d10db83fa705/README.md).

</details>

## Result on the requested corpus

On enwik8, [level 22](bench/results/presets/dictionary-20-22/enwik8-22.md) compressed to **26,790,565 vs 26,810,527 bytes** for four-worker zstd, compressed **2.475× faster**, and decompressed **1.155× faster** in five warmed pairs. A [different dictionary representation](bench/results/presets/research/dictionary-storage/README.md) preserves the four token streams and saves 460,048 bytes relative to the native level-19 archive. [Levels 18 and 19](bench/results/presets/pooled-18-19/README.md) also pass all three comparisons on enwik8.

On this Pi the original level-3 codec beat four-worker zstd level 3 in compressed size, compression speed, and decompression speed on every input. These are the historical median speeds of the thirteen-round confirmation run; a factor above one means btrcmpr was faster. The current preset encoder uses an improved representation for x-ray; the new level matrix has a different baseline framing policy as well.

| File | Fewer compressed bytes | Compression speedup | Decompression speedup |
|---|---:|---:|---:|
| enwik8 | 1.75% | 1.21× | 1.09× |
| x-ray | 4.51% | 20.89× | 1.43× |
| mozilla | 1.26% | 1.37× | 1.04× |

[Full measurements, standard CLI file sizes and profiling evidence](bench/results/README.md).

## How it works

* **General data.** Independent blocks use a lazy LZ parser with fingerprinted short- and long-prefix hash tables. It separates the literal bytes, run lengths, and distances. For a common entropy representation, the encoder ranks byte values and selects power-of-two groups by dynamic programming. Group selectors and payload bits go into separate streams; ARM NEON can reconstruct sixteen symbols at once. The encoder also has its own length-limited Huffman and four-state rANS coders, constant streams, and raw storage. Short copies, overlap handling, and validation of match bounds are implemented in Rust.
* **16-bit signals.** A sample tests whether neighboring little-endian samples are usually close. The encoder predicts sixteen samples from the previous group, writes the low residual bytes together, and uses a bit mask for high-byte exceptions. The predictor is selected from statistics, without knowing a file name, image width, or header.
* **Object archives.** For a checksummed tar archive containing several Alpha COFF objects, the planner groups like sections and preserves all headers, padding, unknown sections, and other members. Long contiguous spans can decode directly to their original addresses. Structured sections such as relocation and symbol tables use groups of 128 records: each integer field chooses a base or row difference, a bit width, and a list of exceptions. The decoder interleaves fields directly into the original spans. The archive includes a validated permutation of byte ranges; the decoder does not need a tar or COFF parser.

The archive path is a deliberate specialization for this class of binary, which is why the result on mozilla should not be generalized to arbitrary executables. The remaining data uses the general block codec. See [the candidate comparison](bench/results/candidates.md) for the measured tradeoffs during development and [encoder instruction counts by preset](bench/results/profiles/enwik8-general/encoder-comparison.md) for the ARM profiles on enwik8.

The text presets at levels 13–22 split bytes into short word, number and punctuation tokens, then repeatedly merge frequent adjacent tokens. The archive stores phrases as spellings or pairs of shorter phrases. At levels 13–15 each worker has its own dictionary. Starting at 16, groups of two or four workers combine identical spellings and transmit their dictionary once. At 18–22 they also [learn phrases across those workers](bench/results/presets/research/pooled-phrases/README.md). Levels 20–22 try compact representations for the dictionary fields themselves. The decoder rebuilds the dictionary once per group, then expands each worker's stream independently. [Level-17 hardware counters](bench/results/profiles/enwik8-general/shared-preset/README.md) measured **186.01 vs 931.33 encode instructions per input byte** for this shared-dictionary approach against zstd's tree search and optimal parser.

For the general codec on enwik8, [ARM hardware counters](bench/results/profiles/enwik8-general/current-presets/README.md) explain two different speedups. At level 3 the encoder executed **61.58 vs 36.57 instructions per input byte** but spent fewer cycles waiting for match candidates. The decoder executed **5.43 vs 12.36 instructions per output byte** by unpacking symbols and preparing commands in groups of 16. The [controlled experiments](bench/results/profiles/enwik8-general/README.md) change each component independently and keep the compressed file identical. At [level 10 on the selected build](bench/results/profiles/enwik8-general/combined-10/c/per-byte.csv), the encoder itself retires **93.26 vs 295.96 instructions per byte** and uses **533.72 vs 693.36 CPU cycles per byte**. The [instruction samples from this build](bench/results/profiles/enwik8-general/combined-10/interpretation.md) locate most of the gap in match search. [Direct counts and a search-depth experiment](bench/results/profiles/enwik8-general/middle-preset/search-depth/README.md) found 573.73 million buffered candidate checks in zstd's row matcher versus 57.95 million candidate-text comparisons in the Rust matcher.

On [Mozilla at level 1](bench/results/profiles/combined-01-mozilla/interpretation.md), both encoders use a short search: Rust retired 23.07 instructions per byte and zstd 23.86. The twofold instruction saving there is on decode (4.14 vs 8.71).

## Reproduce the comparison

```sh
scripts/fetch-data.sh
python3 scripts/preset-matrix.py --selected --out bench/local/my-selected-run
# After an interruption, continue with the exact same binaries and settings:
python3 scripts/preset-matrix.py --resume --out bench/local/my-selected-run
```

This compares all 22 levels on all three [Squash benchmark inputs](https://quixdb.github.io/squash-benchmark/). The script checks their SHA-256 values, reuses the selected profiled build (or builds it if absent), and pins both the comparator and standalone CLI. To try one setting, add `--levels 8 --files enwik8` and choose a fresh output directory. Fetching needs curl, unzip and bzip2; building the comparison tools needs the system zstd library and LLVM tools as described above.

Both codecs use four workers in both directions. At each matching numeric level, zstd encodes a quarter of the file per worker as independent standard frames, so it can also decode on four cores. Both sides include outer framing and all model metadata in their sizes. This differs from running a single zstd stream with the standard CLI. Each cell uses a warmup plus five alternating pairs, with seven full decodes per observation. Worker startup, data-dependent planning and restoration to the original order are timed. Disk I/O, outer serialization and the byte comparison are outside the timed region. Both decoders must reproduce the input.

`rates.csv` gives ratios and median MB/s; `matrix-decode-tolerance.csv` applies the 5% per-file decode allowance while requiring strictly smaller size and faster encode. All raw pairs are retained. The benchmark command locks the output directory and times only one active matrix comparator across checkouts sharing the binary cache. `cli.csv` identifies the production CLI and each archive and records the independent round trip. `cli.blocks.json` identifies the representations it actually stored. The command exits nonzero if any requested file and level misses a threshold. For the original level-3 comparison with smaller zstd frames, run `scripts/bench.sh`.

## Profile and test

```sh
BTR_LEVEL=1 scripts/perf-stat.sh --selected c ours bench/data/mozilla 4 8
BTR_LEVEL=1 scripts/perf-stat.sh --selected c zstd bench/data/mozilla 4 8
cargo build --release --example decode_loop
perf record -e cycles:u -- target/release/examples/decode_loop archive.btr 30 4
perf report --stdio
cargo test --all-features
cargo test --release --all-features
```

The counter script uses perf control FIFOs to exclude file I/O, initial frame construction, and warmup from hardware counters. With `--selected`, it uses the profiled build and the same zstd framing and timing lock as the matrix; use `d` to count decode instead. Pass `PERF=/path/to/perf` if needed.
