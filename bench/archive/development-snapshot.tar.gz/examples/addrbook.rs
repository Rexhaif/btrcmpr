use btrcmpr::{Frame, Result, decompress, research_address_book};
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let bytes = std::fs::read(&args[1])?;
    let raw = std::fs::read(&args[2])?;
    let frame = Frame::read(&bytes)?;
    let dst = research_address_book(
        &frame,
        &raw,
        4,
        args[3].parse().unwrap(),
        args[4].parse().unwrap(),
        args[5].parse().unwrap(),
    )?;
    let mut out = vec![0; raw.len()];
    decompress(&dst, 4, &mut out)?;
    assert_eq!(raw, out);
    if let Some(path) = args.get(6) {
        dst.write(std::io::BufWriter::new(std::fs::File::create(path)?))?
    }
    println!("{}", dst.encoded_size());
    Ok(())
}
