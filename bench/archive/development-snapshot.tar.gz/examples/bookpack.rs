use btrcmpr::{Frame, Result, decompress, research_repack_dictionary};
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    assert!(
        matches!(args.len(), 5 | 7),
        "bookpack ARCHIVE RAW METHODS OUTPUT or ARCHIVE RAW PAGE_LOG OUTPUT CAP CONDITIONAL"
    );
    let src = std::fs::read(&args[1])?;
    let reference = std::fs::read(&args[2])?;
    let f = Frame::read(&src)?;
    let packed = if args.len() == 5 {
        research_repack_dictionary(&f, args[3].parse().unwrap())?
    } else {
        btrcmpr::research_page_aliases(
            &f,
            args[3].parse().unwrap(),
            args[5].parse().unwrap(),
            args[6] == "1",
        )?
    };
    let mut wire = vec![];
    packed.write(&mut wire)?;
    let g = Frame::read(&wire)?;
    let mut restored = vec![0; g.size()];
    decompress(&g, 3, &mut restored)?;
    assert_eq!(restored, reference);
    std::fs::write(&args[4], wire)?;
    Ok(())
}
