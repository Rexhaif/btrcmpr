use btrcmpr::{Preset, Result, compress_with, decompress, research_encode};
use std::time::Instant;
fn main() -> Result<()> {
    let a: Vec<_> = std::env::args().collect();
    assert!(a.len() >= 5, "candidate THREADS LEVEL FILE METHOD...");
    let threads = a[1].parse().unwrap();
    let level = Preset::new(a[2].parse().unwrap())?;
    let s = std::fs::read(&a[3])?;
    let mut out = vec![0; s.len()];
    let block_limit = std::env::var("BLOCK_KIB")
        .map(|v| v.parse::<usize>().unwrap() * 1024)
        .or_else(|_| std::env::var("BLOCK_MIB").map(|v| v.parse::<usize>().unwrap() * (1 << 20)))
        .ok();
    let preset_alignment = std::env::var("PRESET_ALIGN").as_deref() == Ok("1");
    println!("candidate,bytes,encode_MBps,decode_MBps");
    for method in &a[4..] {
        let now = Instant::now();
        let f = if method == "native" {
            btrcmpr::compress_preset(&s, threads, level)?
        } else if method == "shared-dag" {
            btrcmpr::research_shared(&s, threads)?
        } else if let Some(max) = block_limit {
            let jobs = s.len().div_ceil(max).next_multiple_of(threads).max(1);
            let block = s.len().div_ceil(jobs).max(1);
            let block = if preset_alignment {
                block.next_multiple_of(64).min(max)
            } else {
                block
            };
            btrcmpr::compress_with_block(&s, threads, block, |b| research_encode(b, level, method))?
        } else {
            compress_with(&s, threads, |b| research_encode(b, level, method))?
        };
        let enc = now.elapsed().as_secs_f64();
        let now = Instant::now();
        for _ in 0..4 {
            decompress(&f, threads, &mut out)?;
        }
        let dec = now.elapsed().as_secs_f64() / 4.;
        assert_eq!(&s[..], &out[..], "round trip: {method}");
        if let Some(path) = std::env::var_os("BTR_CANDIDATE_FRAME") {
            assert_eq!(a.len(), 5, "one candidate per saved frame");
            f.write(std::io::BufWriter::new(std::fs::File::create(path)?))?;
        }
        println!(
            "{method},{},{:.2},{:.2}",
            f.encoded_size(),
            s.len() as f64 / 1e6 / enc,
            s.len() as f64 / 1e6 / dec
        );
    }
    Ok(())
}
