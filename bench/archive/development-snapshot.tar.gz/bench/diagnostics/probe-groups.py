#!/usr/bin/env python3
"""Test unconditional insertion of neighboring prefixes in level-1 LZ search."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import random
import re
from statistics import median
import subprocess
import sys
import tempfile
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

p=argparse.ArgumentParser(description=__doc__)
for key in ('workspace','bin-dir','out'):p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();exe=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
base=root/'bench/results/presets/research';env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    with path.open() as f:return list(csv.DictReader(f))
def run(cmd,env):return subprocess.run(cmd,cwd=snap,env=env,text=True,capture_output=True,check=True)
def writer(name,fields):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(fields.split());return f,w
def costs(rows,codec):
    rr=[r for r in rows if r['codec']==codec]
    if len(rr)!=5 or {int(r['round']) for r in rr}!=set(range(1,6)) or len({r['compressed_bytes'] for r in rr})!=1:raise ValueError('bad paired trials')
    return (int(rr[0]['compressed_bytes']),*(median(Decimal(r[k]) for r in rr) for k in ('compress_seconds','decompress_seconds')))
old=json.loads((base/'prefix-probes/manifest.json').read_text())
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',exe/'compare'],env).stdout)[1])
if sha(lib)!=old['zstd_library_sha256']:raise ValueError('wrong baseline')
spec=dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,input_sha256=old['input_sha256'],zstd_library_sha256=sha(lib),
          pmu_full_encodes=8,source_sha256={str(q.relative_to(snap)):sha(q) for q in sorted((snap/'src').rglob('*.rs'))},binaries={k:sha(exe/k) for k in old['binaries']})
(out/'manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
sc,sw=writer('screen','file mode batch_mode KiB bytes encode_MBps decode_MBps')
pp,pw=writer('paired','file mode batch_mode KiB archive_sha256 codec bytes encode_MBps decode_MBps all_pass_at_5pct')
cc,cw=writer('counters','file mode batch_mode KiB bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
known={r['file']:r['verified_sha256'] for r in read(base/'palette-write/checks.csv') if r['mode']=='0'}
events=['instructions:u','cycles:u','branches:u','branch-misses:u','r03:u'];doc=[]
with sc,pp,cc,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    arc=Path(tmp)/'frame'
    for name,width in [('enwik8',256),('mozilla',128)]:
        src=root/'bench/data'/name;size=src.stat().st_size
        if sha(src)!=spec['input_sha256'][name]:raise ValueError('wrong input')
        ref=costs(read(base/'group-key'/f'{name}-1.csv'),'zstd')
        def config(case):
            m,b,k=case
            return dict(env,BTR_LEVEL='1',BTR_PROBE_GROUP=str(m),BTR_GROUP_OFFSETS=str(b),**{'BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB':str(k)})
        def trial(case,save):
            e=config(case)
            if save:e['BTR_CANDIDATE_FRAME']=str(arc)
            row=next(csv.DictReader(run([exe/'examples/candidate','4','1',src,'native'],e).stdout.splitlines()))
            return int(row['bytes']),float(row['encode_MBps']),float(row['decode_MBps'])
        control=(0,0,width)
        trial(control,True)
        if sha(arc)!=known[name]:raise ValueError('changed control bytes')
        modes=range(1,8) if name=='enwik8' else [1,*range(5,13)]
        cases=[(m,b,k) for m in modes for b in (0,2) for k in (width,2*width)];cases.append(control)
        random.Random(614+len(name)).shuffle(cases);pool=[]
        for case in cases:
            n,c,d=trial(case,False);sw.writerow((name,*case,n,c,d))
            if case!=control:
                pool.append((n<ref[0] and d>=.95*float(Decimal(size)/ref[2]/1_000_000),n<ref[0],c,d,-n,case))
        # If no candidate meets both thresholds, show the fastest smaller one.
        # If none is smaller at all, report the smallest one instead of ignoring that failure.
        best=max(pool) if any(r[1] for r in pool) else max(pool,key=lambda r:r[4])
        for case in [control,best[-1]]:
            n,_,_=trial(case,True);digest=sha(arc)
            run([exe/'examples/decode_loop',arc,'1','3',src],env)
            run([sys.executable,root/'bench/diagnostics/fast-wire.py','--single',arc,'--name',name,'--out',out/f'{name}-{case[0]}-fields'],env)
            stat=out/f'{name}-{case[0]}-perf.txt'
            with tempfile.TemporaryDirectory() as t:
                ctl,ack=(Path(t)/f for f in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                pr=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe/'examples/profile','c','ours',src,'4','8'],dict(config(case),PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            stat.write_text(pr.stderr)
            if f'archive_bytes={n}\n' not in pr.stderr:raise ValueError('PMU archive changed')
            counts={v[2]:float(v[0])/(size*8) for l in pr.stderr.splitlines() if len(v:=l.split(';'))>2 and v[2] in events}
            cw.writerow((name,*case,n,*(round(counts[k],5) for k in events)))
            raw=out/f'{name}-{case[0]}.partial'
            run([exe/'compare','4','5','both',src],dict(config(case),ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            values=[costs(read(raw),codec) for codec in ('btrcmpr','zstd')]
            if values[0][0]!=n or values[1][0]!=ref[0]:raise ValueError('paired archive changed')
            ok=qualifies(values,DEFAULT_DECODE_LOSS_PCT); rates=[]
            for codec,(n,c,d) in zip(('btrcmpr','zstd'),values,strict=True):
                rates.append((n,float(Decimal(size)/c/1_000_000),float(Decimal(size)/d/1_000_000)))
                pw.writerow((name,*case,digest if codec=='btrcmpr' else '',codec,n,round(rates[-1][1],3),round(rates[-1][2],3),int(ok)))
            raw.replace(raw.with_suffix('.csv'));(nb,cb,db),(nz,cz,dz)=rates
            doc.append(f'| [{name}]({name}-{case[0]}.csv) | {case[0]} | {nb:,} / {nz:,} | {cb:.2f} / {cz:.2f} | {db:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
(out/'README.md').write_text('\n'.join(['# Testing several match starts at once','',
    'The encoder reads two to four existing hash slots, then updates every slot before choosing the first valid copy. Even a four-byte copy consumes every speculative start. This keeps consecutive hash lookups independent. Sparse versions check every second or third position; a backwards extension can recover skipped literals. All variants use the existing decoder.','',
    '| File | Mode (0 = native control) | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
    'Each finalist and native control used four workers per codec and five alternating pairs after warmup with seven decodes per measurement. The exact compressed archive was also reopened and restored on three workers. Each full input was screened for size and decode throughput before ranking by encode speed. [All cases](screen.csv), [paired medians](paired.csv), [eight-encode ARM hardware counters](counters.csv), [build and data identities](manifest.json), [driver](../../../../diagnostics/probe-groups.py). The accompanying file and mode field directories account for the bytes occupied by commands, distances, and literals.','']))
