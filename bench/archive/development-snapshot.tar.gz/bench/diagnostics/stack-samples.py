#!/usr/bin/env python3
"""Resolve the sampled record instructions and parser branch misses on their frozen executable."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path);p.add_argument('--exe',required=True,type=Path);p.add_argument('--results',required=True,type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[2];perf=root/'bench/local/perf';spec=json.loads((a.results/'manifest.json').read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
if sha(a.exe)!=spec['binaries']['examples/profile']:raise ValueError('wrong executable')
for src in ('record.rs','groupprobe.rs','emitoffset.rs','lz.rs'):
    if sha(a.workspace/'src'/src)!=spec['source_sha256']['src/'+src]:raise ValueError('wrong source')
build=re.search(r'Build ID: ([a-f0-9]+)',subprocess.check_output(['readelf','-n',a.exe],text=True))[1]
out=a.results/'sample-lines';out.mkdir(exist_ok=True);ident={}
for data,tag,funcs in [(a.workspace/'mozilla-profile/ours.data','mozilla-record',{'btrcmpr::record::encode'}),(a.workspace/'enwik8-branch-profile/ours.data','enwik8-branches',{'btrcmpr::lz::emitoffset::grouped','btrcmpr::lz::emitoffset::grouped::{{closure}}'})]:
    ids=subprocess.check_output([perf,'buildid-list','-i',data],text=True).splitlines()
    if not any(x.startswith(build+' ') for x in ids):raise ValueError('different sampled binary')
    raw=subprocess.check_output([perf,'script','-i',data,'-F','ip,sym,dsoff'],text=True)
    h=Counter();total=0
    for line in raw.splitlines():
        m=re.fullmatch(r'\s*[a-f0-9]+ (.*?) \((.*?)(?:\+0x([a-f0-9]+))?\)',line);total+=1
        if not m:raise ValueError(line)
        if m[1] in funcs and m[3]:h[int(m[3],16)]+=1
    if not h:raise ValueError('no samples in selected functions')
    stacks={};addr=None
    result=subprocess.run(['addr2line','-a','-f','-C','-i','-e',a.exe],input=''.join(f'0x{x:x}\n' for x in h),text=True,capture_output=True,check=True)
    for s in result.stdout.splitlines():
        if re.fullmatch(r'0x[a-f0-9]+',s):addr=int(s,16);stacks[addr]=[]
        else:stacks[addr].append(s)
    groups=Counter();positions=Counter()
    with (out/(tag+'-addresses.csv')).open('w') as f:
        wr=csv.writer(f,lineterminator='\n');wr.writerow(('elf_offset','count','first_resolved_source','group','inline_stack'))
        for ip,n in h.most_common():
            locs=[(m[1],int(m[2])) for frame in stacks[ip][1::2] if (m:=re.search(r'/src/(record|groupprobe|emitoffset|lz)\.rs:(\d+)',frame)) and int(m[2])]
            loc='unassigned';g='other or unassigned'
            if locs:
                file,i=locs[0];loc=f'{file}.rs:{i}'
                if file=='record':
                    if 12<=i<=16:g='count bit lengths'
                    elif 17<=i<=29:g='price widths'
                    elif 31<=i<=42:g='base and delta residuals'
                    elif 43<=i<=56:g='choose mode or write header'
                    elif 57<=i<=74:g='pack low bits'
                    elif 75<=i<=86:g='write exceptions'
                    elif 97<=i<=103:g='load record columns'
                elif file=='groupprobe':
                    if i in range(12,32) or i in range(60,68):g='verify and select match'
                    elif 68<=i<=73:g='extend backwards'
                    elif 75<=i<=83:g='index accepted match'
                    elif 35<=i<=59 or 84<=i<=90:g='index or advance candidate group'
                elif file=='emitoffset':g='emit lengths, literals and batched distances'
                elif file=='lz':g='generic match or stream operations'
            groups[g]+=n;positions[loc]+=n;wr.writerow((hex(ip),n,loc,g,' | '.join(stacks[ip])))
    for what,counts in [('groups',groups),('locations',positions)]:
        with (out/(tag+'-'+what+'.csv')).open('w') as f:
            w=csv.writer(f,lineterminator='\n');w.writerow((what,'samples','pct_whole_encoder','pct_selected_functions'))
            for key,n in counts.most_common():w.writerow((key,n,round(100*n/total,2),round(100*n/h.total(),2)))
    ident[tag]=dict(data_sha256=sha(data),total_samples=total,selected_samples=h.total())
(out/'manifest.json').write_text(json.dumps(dict(profile_build_id=build,profile_sha256=sha(a.exe),samples=ident),indent=2)+'\n')
