#!/usr/bin/env python3
"""Check whether sampling predictor residuals is worth the archive bytes it can cost."""
import argparse
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);name='mozilla'
if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('changed corpus')
ref=costs(read(l.base/'group-key/mozilla-1.csv'),'zstd')[0]
def cfg(x):
    mode,k,rec=x
    return dict(l.env,BTR_RECORD_COST=str(mode),BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='10',BTR_FAST_COUNTS='2',BTR_FAST_PLAN='0',BTR_ARCH_KIB=str(k),BTR_RECORD_KIB=str(rec))
sc,sw=l.report('screen','predictor job_KiB record_KiB bytes encode_MBps decode_MBps')
pa,pw=l.report('paired','predictor job_KiB record_KiB tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
ct,cw=l.report('counters','predictor job_KiB record_KiB codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
cases=[(m,k,128) for m in (2,*range(4,12)) for k in (128,192,256,384)]
random.Random(4275).shuffle(cases);pool={};doc=[];control=(2,192,128)
with sc,pa,ct,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'record-pick.btr'
    def one(x):
        if x in pool:return
        n,c,d=l.trial(name,cfg(x));pool[x]=(n,c,d);sw.writerow((*x,n,c,d))
    for x in cases:one(x)
    def order():
        return sorted((x for x in pool if x[0]!=2 and pool[x][0]<ref),key=lambda x:(pool[x][2]>=1530,pool[x][1]),reverse=True)
    for m,k,_ in order()[:4]:
        for r in (64,192,256):one((m,k,r))
    picks=[control]
    for x in order():
        if len(picks)>=4:break
        if all(x[0]!=q[0] for q in picks):picks.append(x)
    if len(picks)==1:picks.append(min((x for x in pool if x[0]!=2),key=lambda x:pool[x][0]))
    def pair(x,tag):
        n,_,_=l.trial(name,cfg(x),arc)
        if n!=pool[x][0]:raise ValueError('size changed')
        digest=sha(arc);l.restore(name,arc,l.env)
        if x==control and digest!='f54ae7dea0b95b63833b429e83ed914fc3d6634771d539f8559afa8aacc4ef89':raise ValueError('native control changed')
        rates,ok=l.pair(name,cfg(x),n,ref,tag)
        for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*x,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
        (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} / {x[2]} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
        return ok,c/cz
    scored=[]
    for i,x in enumerate(picks):
        tag=f'mozilla-{i}';cw.writerow((*x,'btrcmpr',pool[x][0],*l.perf(name,cfg(x),pool[x][0],tag)))
        score=pair(x,tag)
        if x[0]!=2:scored.append((score,x))
    if scored:pair(max(scored)[1],'mozilla-repeat')
    cw.writerow((*control,'zstd',ref,*l.perf(name,l.env,ref,'zstd',codec='zstd')))
(l.out/'README.md').write_text('\n'.join(['# Sampling base and delta predictions before exact width pricing','',
'Each integer record column can use one of two predictors. The experiment samples 8 or 16 rows of each tile: when one predictor clearly uses fewer residual bits, only that predictor receives a full bit-width search. Ambiguous tiles keep the exhaustive choice. The decoder still reconstructs every integer exactly. This trades a possible size increase for fewer histogram passes. Mode 2 is the exhaustive production control.','',
'| Raw trials | Predictor / generic KiB / record KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
'Five alternating four-worker pairs after warmup; seven decodes per measurement. Every finalist was independently restored with three workers and the best new configuration received a separate five-pair repeat. [Hardware counters](counters.csv), [screens](screen.csv), [paired archive hashes](paired.csv), [manifest](manifest.json).','']))
