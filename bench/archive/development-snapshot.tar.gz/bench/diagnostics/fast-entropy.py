#!/usr/bin/env python3
"""Screen level-1 histogram and ranked-palette work on otherwise fixed parsers."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--bin-dir', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
out = a.out.resolve()
out.mkdir(exist_ok=True, parents=True)
exe = a.bin_dir.resolve()
env = {k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
(out/'manifest.json').write_text(json.dumps(dict(workers=4,source={p:sha(root/'src'/p) for p in
    ['ans.rs','palette.rs','rankgroups.rs','quickstride.rs']},binaries={p:sha(exe/p) for p in
    ['examples/candidate','examples/decode_loop','compare']}),indent=2)+'\n')
with (out/'screen.csv').open('w',buffering=1) as screen, (out/'paired.csv').open('w',buffering=1) as confirm, tempfile.TemporaryDirectory(dir=root/'bench/local') as space:
    wr=csv.writer(screen,lineterminator='\n'); pr=csv.writer(confirm,lineterminator='\n')
    wr.writerow(('file','parser','counts','plan','bytes','encode_MBps','decode_MBps'))
    pr.writerow(('file','parser','counts','plan','codec','bytes','encode_MBps','decode_MBps'))
    for name,limit in [('enwik8',40669611),('mozilla',19963738)]:
        src=root/'bench/data'/name
        engines=[0,8] if name=='mozilla' else [0,1]
        cases=[(m,h,k) for m in engines for h,k in ((0,0),(1,0),(2,0),(0,1),(0,2),(2,1),(2,2),(2,3))]
        random.Random(3107).shuffle(cases)
        ranked=[]
        for m,h,k in cases:
            conf=dict(env,BTR_FAST1=str(m),BTR_FAST_COUNTS=str(h),BTR_FAST_PLAN=str(k))
            r=subprocess.run([exe/'examples/candidate','4','1',src,'native'],env=conf,capture_output=True,text=True,check=True)
            row=next(csv.DictReader(r.stdout.splitlines()))
            n=int(row['bytes']);c=float(row['encode_MBps']);d=float(row['decode_MBps'])
            wr.writerow((name,m,h,k,n,c,d))
            if (h or k) and n<limit:ranked.append((c,d,n,m,h,k))
        if not ranked: continue
        c,d,n,m,h,k=max(ranked)
        arc=Path(space)/'candidate.btr'
        knobs=dict(env,BTR_FAST1=str(m),BTR_FAST_COUNTS=str(h),BTR_FAST_PLAN=str(k))
        subprocess.run([exe/'examples/candidate','4','1',src,'native'],env=dict(knobs,BTR_CANDIDATE_FRAME=str(arc)),check=True,stdout=subprocess.DEVNULL)
        if arc.stat().st_size!=n:raise ValueError('screen and standalone disagree')
        subprocess.run([exe/'examples/decode_loop',arc,'1','3',src],env=env,check=True)
        trials=out/f'{name}.partial'
        subprocess.run([exe/'compare','4','5','both',src],env=dict(knobs,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(trials)),check=True)
        with trials.open() as f:data=list(csv.DictReader(f))
        for codec,size in [('btrcmpr',n),('zstd',limit)]:
            part=[r for r in data if r['codec']==codec]
            if len(part)!=5 or {int(r['round']) for r in part}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=size for r in part):raise ValueError('unpaired or inconsistent frames')
            pr.writerow((name,m,h,k,codec,size,*(round(src.stat().st_size/1e6/statistics.median(float(r[j]) for r in part),3) for j in ('compress_seconds','decompress_seconds'))))
        trials.replace(out/f'{name}.csv')
