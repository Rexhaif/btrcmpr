#!/usr/bin/env python3
"""Compare scalar and NEON entropy packing at level 1 on identical full archives."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
binroot=a.bin_dir.resolve();candidate=binroot/'examples/candidate';compare=binroot/'compare';env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
with (root/'bench/results/presets/research/quick-emitter/native-cli.csv').open() as f:expected={r['input']:r['archive_sha256'] for r in csv.DictReader(f)}
with (root/'bench/results/presets/palette/palette-packed-summary.csv').open() as f:zstd={Path(r['file']).name:r for r in csv.DictReader(f) if r['codec']=='zstd'}
(out/'manifest.json').write_text(json.dumps(dict(workers=4,rounds=5,candidate_sha256=digest(candidate),compare_sha256=digest(compare)),indent=2)+'\n')
with (out/'checks.csv').open('w',buffering=1) as cf,(out/'trials.csv').open('w',buffering=1) as tf,(out/'summary.csv').open('w',buffering=1) as sf:
    checks=csv.writer(cf,lineterminator='\n');checks.writerow(('file','mode','archive_bytes','verified_sha256'))
    trials=csv.writer(tf,lineterminator='\n');trials.writerow(('file','mode','round','encode_MBps','decode_MBps'))
    summary=csv.writer(sf,lineterminator='\n');summary.writerow(('file','mode','encode_MBps','decode_MBps'))
    for name in ('enwik8','mozilla'):
        src=root/'bench/data'/name;arc=root/'bench/local/levels/lanes'/f'palette-write-{name}.btr';rates={0:[],1:[]};sizes={}
        for mode in rates:
            r=subprocess.run([candidate,'4','1',src,'native'],env=dict(env,BTR_CANDIDATE_FRAME=str(arc),BTR_PALETTE_NEON_WRITE=str(mode)),capture_output=True,text=True,check=True)
            h=digest(arc);n=arc.stat().st_size
            if h!=expected[name]:raise ValueError(f'changed archive on {name} mode {mode}')
            checks.writerow((name,mode,n,h));sizes[mode]=n
        rng=random.Random(7251)
        for repeat in range(1,6):
            modes=[0,1];rng.shuffle(modes)
            for mode in modes:
                r=subprocess.run([compare,'4','1','ours',src],env=dict(env,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='5',BTR_PALETTE_NEON_WRITE=str(mode)),capture_output=True,text=True,check=True)
                row=next(csv.DictReader(r.stdout.splitlines()))
                if int(row['compressed_bytes'])!=sizes[mode]:raise ValueError('unexpected wire size')
                pair=(float(row['compress_MBps']),float(row['decompress_MBps']));rates[mode].append(pair);trials.writerow((name,mode,repeat,*pair))
        for mode,v in rates.items():
            c,d=map(statistics.median,zip(*v,strict=True));summary.writerow((name,mode,c,d))
            if mode and c>float(zstd[name]['compress_MBps'])*.98 and d>float(zstd[name]['decompress_MBps'])*.98:
                target=out/(name+'-pairs.csv')
                subprocess.run([compare,'4','5','both',src],env=dict(env,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(target),BTR_PALETTE_NEON_WRITE=str(mode)),check=True)
