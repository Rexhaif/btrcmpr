#!/usr/bin/env python3
"""Serialize promoted-preset validation and independent research on the four-core benchmark host."""
import csv, os, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];local=root/'bench/local/levels/lanes';base=root/'bench/results/presets'
target=local/'production-target';env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};env['CARGO_TARGET_DIR']=str(target)
def run(name,args):
    with (local/(name+'.log')).open('w') as log:
        subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
def native(status):
    rows=list(csv.DictReader((base/status/'matrix.csv').open()))
    if len(rows)!={'native-eighth':3,'shared-16-17':6}[status]:raise ValueError('incomplete frozen matrix')
    return rows
one=native('native-eighth');two=native('shared-16-17')
run('native-eighth-resume',[sys.executable,'scripts/preset-matrix.py','--levels','8','--files','enwik8','x-ray','mozilla','--rounds','5','--decodes','7','--resume','--out',base/'native-eighth'])
run('pool-native-tests',['cargo','test','--offline','--locked','--all-features'])
run('pool-native-clippy',['cargo','clippy','--offline','--locked','--all-features','--all-targets','--','-D','warnings'])
run('pool-default-clippy',['cargo','clippy','--offline','--locked','--no-default-features','--all-targets','--','-D','warnings'])
quick=base/'research/quick-emitter'
with (quick/'checks.csv').open() as f:
    quick_checks=[r for r in csv.DictReader(f) if r['variant']=='0']
quick_matrix=local/'native-quick-matrix.csv'
with quick_matrix.open('w') as f:
    wr=csv.writer(f);wr.writerow(('level','file','threads','btr_bytes'))
    for r in quick_checks:wr.writerow((1,r['input'],4,r['bytes']))
quick_out=quick/'native-cli.csv'
run('quick-production',[sys.executable,'bench/diagnostics/preset-cli.py',quick_matrix,'--out',quick_out])
with quick_out.open() as f:
    if sorted((r['input'],r['archive_sha256']) for r in csv.DictReader(f))!=sorted((r['input'],r['archive_sha256']) for r in quick_checks):
        raise ValueError('native quick parser produced a different archive')
run('pool-release',['cargo','build','--offline','--locked','--release','--features','baseline,research','--bin','compare','--example','candidate','--example','decode_loop'])
profile_dir=root/'bench/results/profiles/enwik8-general/shared-preset'
run('shared-decode-phases',[sys.executable,'bench/diagnostics/shared-phases.py','--bin-dir',target/'release','--out',profile_dir])
env['PERF']=str(root/'bench/local/perf')
run('shared-preset-counters',[sys.executable,'bench/diagnostics/phrase-pmu.py','--level','17','--out',profile_dir])
run('mozilla17',[sys.executable,'bench/diagnostics/mozilla17.py','--out',base/'research/mozilla17','--bin-dir',target/'release'])
threshold=18 if all(r['all_pass']=='1' for r in two if r['file']=='enwik8') else 16
run('pool-screen',[sys.executable,'bench/diagnostics/piece-screen.py','--workspace',root,'--bin-dir',target/'release',
       '--pool-only','--min-level',str(threshold),'--out',base/'research/pooled-phrases'])
run('middle-pages',[sys.executable,'bench/diagnostics/middle-pages.py','--out',base/'research/middle-pages'])
shared=[sys.executable,'bench/diagnostics/shared-phrases.py','--min-level',str(threshold),'--out',base/'research/shared-phrases']
run('shared-setup',[*shared,'--prepare'])
run('shared-series',shared)
