#!/usr/bin/env python3
"""Test per-worker scratch and palette padding separately on the same regional archive."""
import argparse
import json
import os
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab, read, sha

p=argparse.ArgumentParser(description=__doc__)
for key in ('workspace','out','bin-dir'):
    p.add_argument('--'+key,required=True,type=Path)
p.add_argument('--if-close',type=Path,help='run only if the completed enwik8 series has under 3% encode headroom or 97% decode throughput')
a=p.parse_args()
if a.if_close:
    from level_one_lab import costs
    from decimal import Decimal
    obs=read(a.if_close)
    if {Path(r['file']).name for r in obs}!={'enwik8'}:raise ValueError('wrong conditional input')
    bz,bt,bd=costs(obs,'btrcmpr');zz,zt,zd=costs(obs,'zstd')
    if bz<zz and zt>=Decimal('1.03')*bt and zd>=Decimal('.97')*bd:
        print('Buffer study deferred: the frozen encoder cleared the predeclared margins.');raise SystemExit()
l=Lab(a.workspace,a.bin_dir,a.out)
name='enwik8';source=l.data/name
if sha(source)!=l.spec['input_sha256'][name]:raise ValueError('changed input')
expected=json.loads((l.base/'native-regional-1/manifest.json').read_text())['expected_archives'][name]
steps=read(l.root/'bench/results/presets/native-profiled-1/rates.csv')
ref=int(next(r['zstd_bytes'] for r in steps if r['file']==name))
env=dict(l.env,BTR_SHARED_FIELDS='6',BTR_SHARED_PERIOD='128',BTR_SHARED_PAIRS='0',BTR_JOB_KIB='384',
         BTR_PAIR_HEAD='4',BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='5',BTR_FAST_COUNTS='2',BTR_FAST_PLAN='1')
hardware,hw=l.report('counters','worker_scratch padding codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
memory,mw=l.report('memory','worker_scratch padding minor_faults_per_encode major_faults_per_encode l1d_tlb_refills_per_byte')
paired,pw=l.report('paired','worker_scratch padding tag codec bytes encode_MBps decode_MBps pass_at_5pct')
doc=[];scores={}
with hardware,memory,paired,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'candidate'
    def trial(b,q,tag,pmu):
        e=dict(env,BTR_JOB_BUFFERS=str(b),BTR_PALETTE_PADDING=str(q))
        n,_,_=l.trial(name,e,arc)
        if [n,sha(arc)]!=expected:raise ValueError('allocator policy changed archive')
        l.restore(name,arc,e)
        if pmu:
            c=l.perf(name,e,n,tag)
            hw.writerow((b,q,'btrcmpr',n,*c));scores[b,q]=c[1]
            ctl,ack=(Path(td)/(k+tag) for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
            events=('minor-faults','major-faults','r05:u')
            result=l.run([l.root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',l.exe/'examples/profile','c','ours',source,'4','8'],dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack))).stderr
            if f'archive_bytes={n}\n' not in result:raise ValueError('memory profile changed stream')
            (l.out/(tag+'-memory.txt')).write_text(result)
            ev={}
            for line in result.splitlines():
                t=line.split(';')
                if len(t)<3:continue
                event=t[2] if t[2] in events else t[2].removesuffix(':u')
                if event in events:ev[event]=int(t[0])
            mw.writerow((b,q,ev[events[0]]/8,ev[events[1]]/8,round(ev[events[2]]/(source.stat().st_size*8),6)))
        vals,ok=l.pair(name,e,n,ref,tag)
        for codec,(n,c,d) in zip(('btrcmpr','zstd'),vals,strict=True):
            pw.writerow((b,q,tag,codec,n,round(c,3),round(d,3),int(ok)))
        (_,c,d),(_,cz,dz)=vals
        doc.append(f'| [{tag}]({tag}.csv) | {b} / {q} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
    for b,q in [(0,0),(1,1),(0,1),(1,0)]:trial(b,q,f'b{b}-p{q}',True)
    chosen=min((k for k in scores if k!=(0,0)),key=lambda k:scores[k])
    trial(*chosen,'repeat',False)
(l.out/'README.md').write_text('\n'.join(['# Worker buffers and palette padding','',
    'The parser, alphabets, block boundaries and archive bytes are held fixed. One change retains the seven temporary match streams across jobs on a worker. The other writes palette heads and rank bits directly into spare capacity and zeros the transmitted padding. The candidate using the fewest cycles gets an independent repeat. Every arm must reproduce the full independent regional archive hash and restore every byte on three workers.', '',
    '| Trial | Reuse buffers / only clear padding | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---|',*doc,'',
    '[CPU counters](counters.csv), [page faults and data TLB refills](memory.csv), [archive and binary provenance](manifest.json). Four workers per codec, five warm pairs, seven decodes per measurement.','']))

# Check whether the measured decode allowance buys a less expensive match
# history. The qualifying test still uses a new paired reference for each row.
prior=read(l.base/'native-regional-scan-1/paired.csv')
target=.95*max(float(v['decode_MBps']) for v in prior if v['codec']=='zstd' and v['tag'] in ('regional-enwik8','regional-enwik8-repeat'))
sf,sw=l.report('jobs-screen','job_KiB region_jobs bytes encode_MBps decode_MBps')
jf,jw=l.report('jobs-paired','job_KiB region_jobs tag codec bytes archive_sha256 encode_MBps decode_MBps pass_at_5pct')
cases=[(k,p) for k in (304,320,336,352,368,384,400,416,432,448) for p in (32,64,128,256)]
random.Random(5879).shuffle(cases);pool={};doc=[]
with sf,jf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'candidate'
    def config(k,p):
        return dict(env,BTR_JOB_BUFFERS=str(chosen[0]),BTR_PALETTE_PADDING=str(chosen[1]),BTR_JOB_KIB=str(k),BTR_SHARED_PERIOD=str(p))
    for k,p in cases:
        n,c,d=l.trial(name,config(k,p))
        pool[k,p]=(n,c,d);sw.writerow((k,p,n,c,d))
    eligible=[k for k,(n,_,d) in pool.items() if n<ref and d>=target and k!=(384,128)]
    finalists=sorted(eligible,key=lambda k:pool[k][1],reverse=True)[:2]
    for j,(k,p) in enumerate([(384,128),*finalists]):
        e=config(k,p);n,_,_=l.trial(name,e,arc);digest=sha(arc)
        if n!=pool[k,p][0] or (k,p)==(384,128) and [n,digest]!=expected:raise ValueError('unstable archive')
        l.restore(name,arc,e);tag='job-'+str(j)
        vals,ok=l.pair(name,e,n,ref,tag)
        for codec,(size,c,d) in zip(('btrcmpr','zstd'),vals,strict=True):
            jw.writerow((k,p,tag,codec,size,digest if codec=='btrcmpr' else '',round(c,3),round(d,3),int(ok)))
        (_,c,d),(_,cz,dz)=vals
        doc.append(f'| [{tag}]({tag}.csv) | {k} / {p} | {n:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
with (l.out/'README.md').open('a') as f:
    f.write('\nChanging the job size changes the match history and archive bytes. Of 40 combinations, the two fastest size-qualified screens reaching 95% of the faster prior zstd decode median received new independent pairs as well as the unchanged 384 KiB control. [Full screens](jobs-screen.csv), [paired archives](jobs-paired.csv).\n\n'
            '| Trial | Job KiB / jobs per region | Rust archive bytes | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |\n|---|---:|---:|---:|---:|---|\n'+'\n'.join(doc)+'\n')
