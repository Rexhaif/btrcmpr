#!/usr/bin/env python3
"""Attribute elapsed time and sample CPU cycles in the production level-17 wire decoder."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--bin-dir',type=Path,required=True)
opts=p.parse_args()
root=Path(__file__).resolve().parents[2];w=root/'bench/local/levels/lanes'
out=opts.out.resolve();out.mkdir(exist_ok=True,parents=True)
with (root/'bench/results/presets/shared-16-17/cli.csv').open() as f:
    expected=next(r for r in csv.DictReader(f) if r['level']=='17' and r['input']=='enwik8')
def digest(f):
    with f.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
arc=w/'shared-phrase/rare.btr';source=root/'bench/data/enwik8';binroot=opts.bin_dir.resolve()
if not arc.exists() or digest(arc)!=expected['archive_sha256']:
    arc=w/'profile-17.btr'
    subprocess.run([binroot/'btrcmpr','c','-17',source,arc,'4'],check=True)
if digest(arc)!=expected['archive_sha256'] or digest(source)!=expected['source_sha256']:raise ValueError('changed frame/input')
exe=binroot/'examples/decode_loop';n=15
args=[exe,arc,str(n),'4',source];env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
r=subprocess.run(args,env=dict(env,BTR_SHARED_TRACE='1'),text=True,capture_output=True,check=True)
rows=[tuple(map(int,line.split(',')[1:])) for line in r.stderr.splitlines() if line.startswith('shared-phase,')]
if len(rows)!=n+1 or any(x[:2]!=(source.stat().st_size,1) for x in rows):raise ValueError('unexpected phase or shared dictionary count')
with (out/'decode-wall.csv').open('w') as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('iteration','dictionary_ns','expansion_ns'))
    for i,(_,_,book,expansion) in enumerate(rows[1:],1):wr.writerow((i,book,expansion))
perf=env.get('PERF',str(root/'bench/local/perf'));data=w/'shared17-cycles.data'
subprocess.run([perf,'record','-q','-e','cycles:u','-c','450009','-o',data,'--',*args],env=env,check=True)
with (out/'decode-cycles.txt').open('w') as dst:
    subprocess.run([perf,'report','-i',data,'--stdio','--no-children','--sort','symbol','--percent-limit','1'],env=env,check=True,stdout=dst)
(out/'decode-manifest.json').write_text(json.dumps(dict(archive_sha256=digest(arc),input_sha256=digest(source),
    decoder_sha256=digest(exe),workers=4,phase_iterations=n,cycle_sample_period=450009,
    median_dictionary_ms=statistics.median(x[2] for x in rows[1:])/1e6,
    median_expansion_ms=statistics.median(x[3] for x in rows[1:])/1e6),indent=2)+'\n')
