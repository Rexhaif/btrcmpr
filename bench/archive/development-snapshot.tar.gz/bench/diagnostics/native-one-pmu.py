#!/usr/bin/env python3
"""Profile the actual level-one release in both directions, and resolve its encoder samples by source line."""
import argparse
from collections import Counter
import csv
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
base=root/'bench/results/presets/native-fastest-1';scripts=root/'bench/diagnostics';exe=snap/'target/release/examples/profile';perf=root/'bench/local/perf'
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','PROFILE_'))};env['PERF']=str(perf)
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
raw_table=[];hot=[]
for name in ('enwik8','mozilla'):
    for op in ('c','d'):
        loc=out/name/op;loc.mkdir(exist_ok=True,parents=True)
        subprocess.run([sys.executable,scripts/'frozen-encoder-pmu.py','--level','1','--file',name,'--workspace',snap,'--matrix',base,'--out',loc,'--operation',op,'--target-dir',snap/'target','--repetitions','8' if op=='c' else '24'],env=env,check=True)
        b,z=read(loc/'per-byte.csv')
        raw_table.append(f"| [{name}, {'encode' if op=='c' else 'decode'}]({name}/{op}/per-byte.csv) | {float(b['instructions_per_byte']):.2f} / {float(z['instructions_per_byte']):.2f} | {float(b['cycles_per_byte']):.2f} / {float(z['cycles_per_byte']):.2f} | {float(b['branch_misses_per_byte']):.3f} / {float(z['branch_misses_per_byte']):.3f} |")
    cache=root/'bench/local/levels/lanes'/('native-fastest-samples-'+name)
    subprocess.run([sys.executable,scripts/'sample-search.py','--file',name,'--level','1','--repetitions','8','--period','800009','--event','instructions','--exe',exe,'--out',cache,'--zstd-debug',root/'bench/local/zstd.debug'],cwd=root,env=env,check=True)
    shutil.copy2(cache/'encode-samples.txt',out/name/'encode-samples.txt')
    data=cache/'ours.data';samples=subprocess.check_output([perf,'script','-i',data,'-F','ip,sym,dsoff'],text=True).splitlines()
    offsets=Counter()
    for row in samples:
        m=re.fullmatch(r'\s*[0-9a-f]+ .*? \((.*)\+0x([0-9a-f]+)\)',row)
        if m and Path(m[1])==exe:offsets[int(m[2],16)]+=1
    if not offsets:raise ValueError('no samples in expected profile executable')
    addrs=list(offsets);raw=subprocess.check_output(['addr2line','-a','-i','-e',exe],input=''.join(f'{k:x}\n' for k in addrs),text=True)
    leaves={};current=None
    for row in raw.splitlines():
        if row.startswith('0x'):current=int(row,16)
        elif current is not None and current not in leaves:
            m=re.search(r'/src/([^/:]+\.rs):(\d+)(?:\s|$)',row)
            if m and (snap/'src'/m[1]).is_file() and int(m[2])>0:leaves[current]=(m[1],int(m[2]))
    files=Counter();sites=Counter()
    for k,total in offsets.items():
        f,i=leaves.get(k,('other',0));files[f]+=total;sites[(f,i)]+=total
    count=sum(1 for row in samples if row.strip());inside=sum(offsets.values())
    with (out/name/'encode-lines.csv').open('w') as fh:
        w=csv.writer(fh,lineterminator='\n');w.writerow(('source','line','instruction_samples','pct_whole_encoder','statement'))
        for (f,i),n in sites.most_common():w.writerow((f,i,n,round(100*n/count,3),(snap/'src'/f).read_text().splitlines()[i-1].strip() if i else ''))
    with (out/name/'encode-files.csv').open('w') as fh:
        w=csv.writer(fh,lineterminator='\n');w.writerow(('source','instruction_samples','pct_whole_encoder'))
        for f,n in files.most_common():w.writerow((f,n,round(100*n/count,3)))
    top=[(f,n) for f,n in files.most_common() if f!='other'][:3]
    hot.append(f"On {name}, "+', '.join(f'{100*n/count:.1f}% of samples in `{f}`' for f,n in top)+f". The denominator is all {count:,} recorded samples; {inside:,} were in the Rust executable. [Source lines]({name}/encode-lines.csv), [function samples for both encoders]({name}/encode-samples.txt).")
subprocess.run([sys.executable,scripts/'palette-loads.py','--workspace',snap,'--profile-dir',out],cwd=root,check=True)
(out/'README.md').write_text('\n'.join(['# Native level-one hardware counters','',
'Four Cortex-A76 workers compressed and decompressed the entire input with the release representation. Each counter run recreated the archive sizes of the warmed paired experiment, restored the input, enabled the hardware counters only for the measured operation, then disabled them. Compression counted eight full inputs and decompression 24. CPU cycles are summed across workers.','',
'| Input / operation | Instructions per original byte, Rust / zstd | CPU cycles per byte, Rust / zstd | Branch misses per byte, Rust / zstd |','|---|---:|---:|---:|',*raw_table,'',*hot,'',
'[Annotated ARM instructions for enwik8](enwik8/palette-disassembly.txt) and [Mozilla](mozilla/palette-disassembly.txt) show the separate byte loads from each symbol’s code entry.', '',
'The samples use the release sources without research settings, and the debug file for the matched zstd build. Source attribution uses the first project source line in each address’s inline stack. Instruction sampling identifies where work occurs; it does not measure the time of an individual source statement. [Paired wall-time results](../../../presets/native-fastest-1/README.md).','']))
