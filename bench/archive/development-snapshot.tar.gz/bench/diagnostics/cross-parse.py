#!/usr/bin/env python3
"""Compile a separate research encoder that reparses the group's shared phrase vocabulary."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--prepare',action='store_true')
p.add_argument('--min-level',type=int,choices=range(16,23),default=18);a=p.parse_args()
root=Path(__file__).resolve().parents[2];w=root/'bench/local/levels/lanes/cross-phrase'
if a.prepare:
    w.mkdir(exist_ok=True,parents=True)
    for folder in ('src','examples','.cargo','bench/support'):shutil.copytree(root/folder,w/folder,dirs_exist_ok=True)
    for name in ('Cargo.toml','Cargo.lock'):shutil.copy2(root/name,w/name)
    with (w/'src/wordreparse.rs').open('a') as f:f.write((root/'bench/diagnostics/phrase-cross.rs').read_text())
    patch=w/'src/wordshared.rs';s=patch.read_text()
    key='    drop(intern);'
    if s.count(key)!=1:raise ValueError('unrecognized dictionary builder')
    s=s.replace(key,key+'''
    #[cfg(feature = "research")]
    {
        let rounds = crate::tuning("BTR_CROSS_ROUNDS", 0, 0, 4);
        if rounds > 0 {
            super::wordreparse::across(&terms, &rules, &mut roots, rounds, group_workers)?;
            uses.fill(0);
            for part in &roots { for &id in part {uses[id as usize] += 1} }
        }
    }
''')
    for before,after in [
        ('jobs: Vec<Training>, plan: Plan) ->','jobs: Vec<Training>, plan: Plan, group_workers: usize) ->'),
        ('let mut books: Vec<_> = groups.iter().map(|_| None).collect();\n    parallel(\n        workers.min(books.len()),',
         'let mut books: Vec<_> = groups.iter().map(|_| None).collect();\n    let group_workers=(workers / books.len()).max(1);\n    parallel(\n        workers.min(books.len()),'),
        ('union(bytes, shard, g.take().unwrap(), plan)','union(bytes, shard, g.take().unwrap(), plan, group_workers)')]:
        if s.count(before)!=1:raise ValueError('unrecognized worker grouping')
        s=s.replace(before,after)
    patch.write_text(s);raise SystemExit(0)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_') and k!='CARGO_TARGET_DIR'}
subprocess.run(['cargo','test','--locked','--offline','--all-features','--lib'],cwd=w,env=env,check=True)
subprocess.run(['cargo','build','--release','--locked','--offline','--features','baseline,research','--bin','compare',
                '--example','candidate','--example','decode_loop'],cwd=w,env=env,check=True)
subprocess.run([sys.executable,root/'bench/diagnostics/piece-screen.py','--workspace',w,'--cross-only','--min-level',
                str(a.min_level),'--out',a.out.resolve()],cwd=root,env=env,check=True)
