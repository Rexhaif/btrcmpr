// Isolated level-one experiment: preserve the original greedy match decisions,
// batch the command metadata, and optionally probe two consecutive positions.
use super::{Streams, probe, word, lenout};
#[inline(always)]
fn keys(w:u64)->(usize,u32){
    (((w<<24).wrapping_mul(0x9e3779b97f4a7c15)>>49)as usize,
       (w as u32).wrapping_mul(0x9e3779b1)<<21)
}
fn parse<const TWO:bool>(s:&[u8],mut emit:impl FnMut(usize,usize,usize,usize))->usize{
    let mut table=vec![0u32;1<<15];let(mut i,mut anchor)=(0,0);
    while i+8<=s.len(){
        let w=word(s,i);let(k,sig)=keys(w);let here=sig|i as u32;
        let (mut len,mut q)=if TWO && i+9<=s.len(){
            let w1=word(s,i+1);let(k1,sig1)=keys(w1);
            let old=table[k];let old1=if k==k1{here}else{table[k1]};
            table[k]=here;
            let (a,b)=probe(s,i,w,old,sig);
            if a>4 || (a==4 && i-b<=12000){(a,b)}else{
                i+=1;table[k1]=sig1|i as u32;probe(s,i,w1,old1,sig1)
            }
        }else{let old=std::mem::replace(&mut table[k],here);probe(s,i,w,old,sig)};
        if len<4 || (len==4 && i-q>12000){i+=1;continue;}
        let off=i-q;
        while i>anchor && q>0 && s[i-1]==s[q-1]{i-=1;q-=1;len+=1;}
        emit(anchor,i,len,off);i+=len;anchor=i;
        for j in i-2..i{if j+8<=s.len(){let(k,sig)=keys(word(s,j));table[k]=sig|j as u32;}}
    }
    anchor
}
const fn compact()->[[u8;8];256]{
    let mut t=[[255;8];256];let mut i=0;while i<256{let mut n=0;let mut j=0;
        while j<8{if (i>>j)&1!=0{t[i][n]=j as u8;n+=1;}j+=1;}i+=1;}t
}
const SHUFFLE:[[u8;8];256]=compact();
struct Batch{ ll:Vec<u32>, ml:Vec<u32>, offsets:Vec<u32> }
impl Batch{
    fn new(n:usize)->Self{let mut offsets=Vec::with_capacity(n/8+3);offsets.extend([8,4,1]);Self{ll:Vec::with_capacity(n/8),ml:Vec::with_capacity(n/8),offsets}}
    #[inline(always)] fn put(&mut self,ll:usize,ml:usize,off:usize){self.ll.push(ll as u32);self.ml.push((ml-4)as u32);self.offsets.push(off as u32);}
    fn replay(self,s:&[u8],vector:bool,archive:bool)->Vec<u8>{
        let n=self.ll.len();let mut st=Streams::sized(s.len());let mut i=0;let mut at=0;
        if vector{
            for storage in [&mut st.tag,&mut st.offs,&mut st.low,&mut st.mid]{storage.reserve(n+8);}
            st.lits.reserve(s.len()+8);
            while i+8<=n{
                unsafe{self.eight(i,&mut st)}
                for j in i..i+8{let l=self.ll[j]as usize;let m=self.ml[j]as usize;
                    if l>=15{lenout(l-15,&mut st.lens);}if m>=15{lenout(m-15,&mut st.lens);}
                    if l>0{
                        if l<=8 && at+8<=s.len(){unsafe{
                            let k=st.lits.len();std::ptr::copy_nonoverlapping(s.as_ptr().add(at),st.lits.as_mut_ptr().add(k),8);st.lits.set_len(k+l);
                        }}else{st.lits.extend_from_slice(&s[at..at+l]);}
                    }
                    at+=l+m+4;
                }
                i+=8;
            }
            st.rep=[self.offsets[i+2]as usize,self.offsets[i+1]as usize,self.offsets[i]as usize];
        }
        for j in i..n{let l=self.ll[j]as usize;let m=self.ml[j]as usize+4;st.emit(s,at,at+l,m,self.offsets[j+3]as usize);at+=l+m;}
        st.finish(s,at,archive)
    }
    unsafe fn eight(&self,i:usize,st:&mut Streams){
        use std::arch::aarch64::*;
        unsafe{
            #[inline(always)] unsafe fn select(o:uint32x4_t,a:uint32x4_t,b:uint32x4_t,c:uint32x4_t)->uint32x4_t{
                unsafe{
                    let v=vaddq_u32(o,vdupq_n_u32(19));let d=vaddq_u32(vsubq_u32(o,a),vdupq_n_u32(8));
                    let mut k=vbslq_u32(vcltq_u32(v,vdupq_n_u32(32768)),
                        vaddq_u32(vshrq_n_u32::<8>(v),vdupq_n_u32(84)),vaddq_u32(vshrq_n_u32::<16>(v),vdupq_n_u32(212)));
                    k=vbslq_u32(vcleq_u32(o,vdupq_n_u32(64)),v,k);
                    k=vbslq_u32(vcleq_u32(d,vdupq_n_u32(16)),vaddq_u32(d,vdupq_n_u32(3)),k);
                    k=vbslq_u32(vceqq_u32(o,c),vdupq_n_u32(2),k);k=vbslq_u32(vceqq_u32(o,b),vdupq_n_u32(1),k);
                    vbicq_u32(k,vceqq_u32(o,a))
                }
            }
            #[inline(always)] unsafe fn narrow(x:uint32x4_t,y:uint32x4_t)->uint8x8_t{unsafe{vmovn_u16(vcombine_u16(vmovn_u32(x),vmovn_u32(y)))}}
            let p=self.offsets.as_ptr().add(i+3);let a=vld1q_u32(p);let b=vld1q_u32(p.add(4));
            let head=narrow(select(a,vld1q_u32(p.sub(1)),vld1q_u32(p.sub(2)),vld1q_u32(p.sub(3))),
                            select(b,vld1q_u32(p.add(3)),vld1q_u32(p.add(2)),vld1q_u32(p.add(1))));
            let mut tags=[vdupq_n_u32(0);2];
            for(j,d) in tags.iter_mut().enumerate(){let t=i+4*j;let cap=vdupq_n_u32(15);
                *d=vorrq_u32(vshlq_n_u32::<4>(vminq_u32(vld1q_u32(self.ll.as_ptr().add(t)),cap)),
                             vminq_u32(vld1q_u32(self.ml.as_ptr().add(t)),cap));}
            vst1_u8(st.tag.as_mut_ptr().add(i),narrow(tags[0],tags[1]));st.tag.set_len(i+8);
            vst1_u8(st.offs.as_mut_ptr().add(i),head);st.offs.set_len(i+8);
            let lo=vaddq_u32(a,vdupq_n_u32(19));let hi=vaddq_u32(b,vdupq_n_u32(19));
            let flags=vld1_u8([1,2,4,8,16,32,64,128].as_ptr());
            for (stream,min,v) in [(&mut st.low,84,narrow(lo,hi)),(&mut st.mid,212,narrow(vshrq_n_u32::<8>(lo),vshrq_n_u32::<8>(hi)))]{
                let mask=vaddv_u8(vand_u8(vcge_u8(head,vdup_n_u8(min)),flags));
                let selected=vtbl1_u8(v,vld1_u8(SHUFFLE[mask as usize].as_ptr()));
                let k=stream.len();vst1_u8(stream.as_mut_ptr().add(k),selected);stream.set_len(k+mask.count_ones() as usize);
            }
        }
    }
}
pub(super) fn encode(s:&[u8],archive:bool,mode:usize)->Vec<u8>{
    if mode==1 {let mut st=Streams::sized(s.len());let at=parse::<true>(s,|a,i,n,o|st.emit(s,a,i,n,o));return st.finish(s,at,archive);}
    let mut b=Batch::new(s.len());let emit=|a:usize,i:usize,n:usize,o:usize|b.put(i-a,n,o);
    if mode==4 {parse::<true>(s,emit);}else{parse::<false>(s,emit);}
    b.replay(s,mode>=3,archive)
}
