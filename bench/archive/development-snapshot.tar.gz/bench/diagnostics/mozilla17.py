#!/usr/bin/env python3
"""Compare the object path's job size and instruction field transform at level 17."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--bin-dir',type=Path,required=True)
a=p.parse_args();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
root=Path(__file__).resolve().parents[2];src=root/'bench/data/mozilla';exe=a.bin_dir.resolve()/'compare'
def digest(f):
    with f.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
def read(f):
    with f.open() as data:return list(csv.DictReader(data))
control=next(r for r in read(root/'bench/results/presets/shared-16-17/rates.csv') if r['file']=='mozilla' and r['level']=='17')
size=int(control['zstd_bytes']);mb=src.stat().st_size/1e6
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
env.update(BTR_LEVEL='17',ZSTD_LEVEL='17',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='9')
(out/'manifest.json').write_text(json.dumps(dict(threads=4,level=17,input_sha256=digest(src),compare_sha256=digest(exe),baseline_bytes=size,
    parameters='KiB per object job and per .text job; 0 always differences low instruction halfwords, 2 decides separately per bank.'),indent=2)+'\n')
cases=[(448,448,0),(448,448,2),(448,288,2),(384,256,2),(352,224,2),(320,192,2),(272,192,2),(224,224,2),(224,160,2)]
random.Random(7512).shuffle(cases)
headers=['job_KiB','text_KiB','bank_policy','archive_bytes','encode_MBps','decode_MBps']
eligible=[]
with (out/'screen.csv').open('w',buffering=1) as f,tempfile.TemporaryDirectory(dir=root/'bench/local') as temp:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(headers)
    for kib,text,policy in cases:
        key=dict(BTR_ARCH_KIB=str(kib),BTR_TEXT_KIB=str(text),BTR_BANK_MODE=str(policy));trial=Path(temp)/'one.csv'
        subprocess.run([exe,'4','1','ours',src],env=dict(env,**key,TRIALS_CSV=str(trial)),check=True,stdout=subprocess.DEVNULL)
        r,=read(trial);n=int(r['compressed_bytes']);c=mb/float(r['compress_seconds']);d=mb/float(r['decompress_seconds'])
        if (kib,text,policy)==(448,448,0) and n!=int(control['btr_bytes']):raise ValueError('control did not reproduce native archive')
        wr.writerow([kib,text,policy,n,round(c,3),round(d,3)])
        # Demand some margin above the previously measured zstd speed before spending five full pairs.
        if policy and n<size and c>float(control['zstd_encode_MBps'])*1.05 and d>float(control['zstd_decode_MBps'])*1.02:
            eligible.append((d,n,key))
if not eligible:raise SystemExit(0)
_,n,settings=max(eligible,key=lambda x:x[0]);tmp=out/'rounds.partial'
(out/'chosen.json').write_text(json.dumps(settings,indent=2)+'\n')
subprocess.run([exe,'4','5','both',src],env=dict(env,**settings,TRIALS_CSV=str(tmp)),check=True)
rows=read(tmp);result=[]
for codec,expected in [('btrcmpr',n),('zstd',size)]:
    group=[r for r in rows if r['codec']==codec]
    if len(group)!=5 or {int(r['round']) for r in group}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=expected for r in group):raise ValueError('unexpected paired data')
    result.append([codec,expected,*(round(mb/statistics.median(float(r[k]) for r in group),3) for k in ('compress_seconds','decompress_seconds'))])
tmp.replace(out/'rounds.csv')
with (out/'summary.csv').open('w') as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(['codec',*headers[3:]]);wr.writerows(result)
