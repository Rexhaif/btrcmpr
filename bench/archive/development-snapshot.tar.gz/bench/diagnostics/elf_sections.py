"""Compare the loaded sections of the two ARM64 builds, including bytes and layout."""
import hashlib
import struct


def allocated(path):
    data = path.read_bytes()
    h = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
    if h[0][:6] != b'\x7fELF\x02\x01' or h[2] != 183 or h[11] != 64:
        raise ValueError('expected little-endian ELF64 for AArch64')
    table = [struct.unpack_from('<IIQQQQIIQQ', data, h[6] + i * h[11]) for i in range(h[12])]
    names = table[h[13]]
    names = data[names[4]:names[4]+names[5]]
    result = {}
    for s in table:
        if s[2] & 2:  # SHF_ALLOC
            name = names[s[0]:names.index(0, s[0])].decode()
            # A NOBITS section such as .bss is specified by its size but has no file payload.
            digest = None if s[1] == 8 else hashlib.sha256(data[s[4]:s[4]+s[5]]).hexdigest()
            result[name] = (s[1:4], s[5:], digest)
    return result


def compare(a, b):
    x, y = allocated(a), allocated(b)
    differences = sorted(k for k in x.keys() | y.keys() if x.get(k) != y.get(k))
    return dict(frozen_count=len(x), rebuilt_count=len(y), differences=differences)
