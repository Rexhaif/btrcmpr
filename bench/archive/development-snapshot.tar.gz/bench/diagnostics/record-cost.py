#!/usr/bin/env python3
"""Test exact record bit-width prices, constant fields and ARM four-lane packing at level 1."""
import argparse
from decimal import Decimal
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);name='mozilla';src=l.data/name;raw=src.stat().st_size
if sha(src)!=l.spec['input_sha256'][name]:raise ValueError('wrong input')
ref=costs(read(l.base/'group-key/mozilla-1.csv'),'zstd')
def cfg(case,policy):
    search,k,h,batch=case
    return dict(l.env,BTR_RECORD_COST=str(policy),BTR_QUICK_KEY=str(search if search in (5,10) else 0),BTR_GROUP_KEY=str(search if search in (5,10) else 0),
                BTR_GROUP_OFFSETS=str(batch),BTR_PROBE_GROUP='8' if search==8 else '0',BTR_FAST1='8' if search==18 else '0',
                BTR_ARCH_KIB=str(k),BTR_FAST_PLAN=str(h),BTR_FAST_COUNTS='2' if h else '0')
sc,sw=l.report('screen','parser KiB planner batch record_policy bytes encode_MBps decode_MBps')
pf,pw=l.report('paired','parser KiB planner batch record_policy archive_sha256 codec bytes encode_MBps decode_MBps pass_at_5pct')
cf,cw=l.report('counters','parser KiB planner batch record_policy codec archive_sha256 bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
initial=(10,128,0,0);native=(0,128,0,0);doc=[]
with sc,pf,cf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as temp:
    arc=Path(temp)/'cost.btr'
    original=next(r['archive_sha256'] for r in read(l.base/'group-key/paired.csv') if r['file']==name and r['key']=='10' and r['KiB']=='128' and r['codec']=='btrcmpr')
    counts={}
    for policy in (0,1,2,3):
        z=l.trial(name,cfg(initial,policy),arc);digest=sha(arc)
        if digest!=original:raise ValueError('record optimization changed bytes')
        l.restore(name,arc,l.env)
        cs=l.perf(name,cfg(initial,policy),z[0],f'first-{policy}');counts[policy]=cs[1];cw.writerow((*initial,policy,'ours',digest,z[0],*cs))
    chosen=min(range(1,4),key=counts.get)
    cases=list({(s,k,h,b) for s in (0,5,10,8,18) for k,h in ((64,0),(96,0),(128,0),(192,0),(256,0),(128,1),(192,1),(256,3)) for b in ((0,2) if s in (5,10) else (2,) if s==8 else (0,))})
    random.Random(745).shuffle(cases);pool=[]
    for case in cases:
        n,c,d=l.trial(name,cfg(case,chosen))
        sw.writerow((*case,chosen,n,c,d))
        pool.append((n<ref[0] and d>=.95*float(Decimal(raw)/ref[2]/1_000_000),n<ref[0],c,-n,case))
    # Always pair the native parser and the earlier speed finalist; include
    # the two best additional size-qualified screen results on different archives.
    picks=[native,initial];sizes=set()
    for ok,small,_,nn,case in sorted(pool,reverse=True):
        if not small or case in picks or nn in sizes:continue
        if len(picks)>=4:break
        picks.append(case);sizes.add(nn)
    for rank,case in enumerate(picks):
        n,_,_=l.trial(name,cfg(case,0),arc);digest=sha(arc)
        l.trial(name,cfg(case,chosen),arc)
        if sha(arc)!=digest:raise ValueError('paired finalist changed bytes')
        l.restore(name,arc,l.env)
        for policy in ([0,chosen] if rank<=1 else [chosen]):
            tag=f'mozilla-{rank}-{policy}'
            rates,ok=l.pair(name,cfg(case,policy),n,ref[0],tag)
            for codec,(num,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*case,policy,digest if codec=='btrcmpr' else '',codec,num,round(c,3),round(d,3),int(ok)))
            (nr,c,d),(nz,cz,dz)=rates;doc.append(f'| [{case[0]}, {case[1]} KiB]({tag}.csv) | {case[2]} / {case[3]} | {policy} | {nr:,} / {nz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
    (l.out/'selection.txt').write_text(str(chosen)+'\n')
(l.out/'README.md').write_text('\n'.join(['# Exact record-width prices on the full Mozilla archive','',
    'For a candidate width, every exception needs one position and at least one high-byte digit. A cumulative histogram gives the exception count and the number of extra digits crossing each successive seven-bit boundary. This computes the identical byte cost without a nested scan of all histogram bins. Policy 2 also handles constant runs directly; policy 3 adds a four-lane ARM bit writer. The match parser and archive format are unchanged by these policies.','',
    '| Parser and job | Planner / distance batch mode | Record policy | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---:|---|',*doc,'',
    f'Policy {chosen} used the fewest measured cycles among the three new implementations on the same archived bytes. The scalar control and all three implementations reproduced the full archive hash. Each finalist was separately checked against its unchanged control archive and restored with three workers. Timing used five alternating four-worker pairs after warmup, with seven decodes per measurement. [Counters](counters.csv), [all screens](screen.csv), [paired medians](paired.csv), [source and build hashes](manifest.json).','']))
