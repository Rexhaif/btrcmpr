"""Shared checks for full-file four-worker level-one candidate experiments."""
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
from statistics import median
import subprocess
import tempfile
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    with path.open() as f:return list(csv.DictReader(f))
def costs(rows,codec):
    seq=[r for r in rows if r['codec']==codec]
    if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or len({int(r['compressed_bytes']) for r in seq})!=1:raise ValueError('invalid paired trials')
    return (int(seq[0]['compressed_bytes']),*(median(Decimal(r[k]) for r in seq) for k in ('compress_seconds','decompress_seconds')))
class Lab:
    def __init__(self,snapshot,bin_dir,out,extra_inputs=()):
        self.root=Path(__file__).resolve().parents[2];self.snap=snapshot.resolve();self.exe=bin_dir.resolve();self.out=out.resolve();self.out.mkdir(parents=True,exist_ok=True)
        self.base=self.root/'bench/results/presets/research';self.data=self.root/'bench/data';self.env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))}
        self.env.update(LC_ALL='C',BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1')
        old=json.loads((self.base/'prefix-probes/manifest.json').read_text())
        if extra_inputs:
            source=json.loads((self.root/'bench/results/presets/native-profiled-1/manifest.json').read_text())
            if old['zstd_library_sha256']!=source['zstd_library_sha256']:raise ValueError('different reference for additional inputs')
            for name in extra_inputs:
                expected=source['input_sha256'][name]
                if sha(self.data/name)!=expected:raise ValueError('additional input differs: '+name)
                old['input_sha256'][name]=expected
        lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',self.run(['ldd',self.exe/'compare'],self.env).stdout)[1])
        if sha(lib)!=old['zstd_library_sha256']:raise ValueError('different reference')
        self.spec=dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,input_sha256=old['input_sha256'],zstd_library_sha256=sha(lib),
          pmu_full_encodes=8,source_sha256={str(p.relative_to(self.snap)):sha(p) for p in sorted((self.snap/'src').rglob('*.rs'))},binaries={k:sha(self.exe/k) for k in old['binaries']})
        self.spec['events']=['instructions:u','cycles:u','branches:u','branch-misses:u','r03:u']
        (self.out/'manifest.json').write_text(json.dumps(self.spec,indent=2)+'\n')
    def run(self,cmd,e):
        p=subprocess.run(cmd,cwd=self.snap,env=e,text=True,capture_output=True)
        if p.returncode:raise RuntimeError(str(cmd[0])+': '+p.stderr[-2000:])
        return p
    def trial(self,name,e,save=None):
        if save:e=dict(e,BTR_CANDIDATE_FRAME=str(save))
        p=self.run([self.exe/'examples/candidate','4','1',self.data/name,'native'],e)
        row=next(csv.DictReader(p.stdout.splitlines()))
        return int(row['bytes']),float(row['encode_MBps']),float(row['decode_MBps'])
    def restore(self,name,arc,e):
        self.run([self.exe/'examples/decode_loop',arc,'1','3',self.data/name],e)
    def report(self,name,fields):
        f=(self.out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(fields.split());return f,w
    def perf(self,name,e,n,tag,codec='ours'):
        with tempfile.TemporaryDirectory() as tmp:
            ctl,ack=(Path(tmp)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
            r=self.run([self.root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(self.spec['events']),'--',
                        self.exe/'examples/profile','c',codec,self.data/name,'4','8'],dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack)))
        (self.out/(tag+'-perf.txt')).write_text(r.stderr)
        if f'archive_bytes={n}\n' not in r.stderr:raise ValueError('PMU size mismatch')
        size=(self.data/name).stat().st_size;counts={a[2]:float(a[0])/(8*size) for l in r.stderr.splitlines() if len(a:=l.split(';'))>2 and a[2] in self.spec['events']}
        return [round(counts[k],5) for k in self.spec['events']]
    def pair(self,name,e,n,ref,tag):
        partial=self.out/(tag+'.partial');self.run([self.exe/'compare','4','5','both',self.data/name],dict(e,WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(partial)))
        v=[costs(read(partial),codec) for codec in ('btrcmpr','zstd')]
        if v[0][0]!=n or v[1][0]!=ref:raise ValueError('archive size changed')
        partial.replace(partial.with_suffix('.csv'));size=Decimal((self.data/name).stat().st_size)
        return [(b,float(size/c/1_000_000),float(size/d/1_000_000)) for b,c,d in v],qualifies(v,DEFAULT_DECODE_LOSS_PCT)
