#!/usr/bin/env python3
"""Freeze the source and independently recorded archive identities for a level-one release."""
import argparse
import csv
import json
from pathlib import Path
import re
import shutil
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path);p.add_argument('--choices',required=True,type=Path,help='JSON mapping each corpus name to a results CSV and its identifying column values')
a=p.parse_args();root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';snap=a.workspace.resolve()
if not snap.is_relative_to(root/'bench/local/levels/lanes') or snap.exists():raise ValueError('snapshot must be a new local lane')
choices=json.loads(a.choices.read_text());known={}
if set(choices)!={'enwik8','mozilla','x-ray'}:raise ValueError('three independent archive references required')
for name,choice in choices.items():
    src=(base/choice['csv']).resolve()
    if not src.is_relative_to(base):raise ValueError('outside result tree')
    with src.open() as f:matches=[r for r in csv.DictReader(f) if all(r.get(k)==str(v) for k,v in choice['match'].items())]
    if len(matches)!=1:raise ValueError(f'ambiguous archive reference for {name}')
    r=matches[0];digest=r['archive_sha256'];n=int(r.get('bytes',r.get('cli_bytes')))
    if not re.fullmatch('[a-f0-9]{64}',digest) or n<=0:raise ValueError('missing reference archive')
    if r.get('file',r.get('input',name))!=name or r.get('codec','btrcmpr')!='btrcmpr' or r.get('restored_identical','1')!='1':raise ValueError('wrong corpus, codec or restoration')
    known[name]=[n,digest]
snap.mkdir()
for name in ('src','examples','tests','.cargo','bench/support','scripts'):shutil.copytree(root/name,snap/name)
for name in ('Cargo.toml','Cargo.lock'):shutil.copy2(root/name,snap/name)
(snap/'bench/data').symlink_to(root/'bench/data',target_is_directory=True);(snap/'bench/local').mkdir()
(snap/'bench/local/preset-binaries').symlink_to(root/'bench/local/preset-binaries',target_is_directory=True)
(snap/'bench/diagnostics').mkdir()
for name in ('decode_gate.py','preset-cli.py','preset-rates.py'):shutil.copy2(root/'bench/diagnostics'/name,snap/'bench/diagnostics'/name)
(snap/'expected.json').write_text(json.dumps(known,indent=2)+'\n');(snap/'choices.json').write_text(json.dumps(choices,indent=2)+'\n');(snap/'ready').touch()
