            // For each index exactly one 64-byte bank is in range. TBL returns
            // zero for the other banks, so the partial lookup results compose
            // with OR. Two shorter TBX chains can execute independently.
            let r1 = vsubq_u8(rank, vdupq_n_u8(64));
            let r2 = vsubq_u8(rank, vdupq_n_u8(128));
            let r3 = vsubq_u8(rank, vdupq_n_u8(192));
            let a = vqtbl4q_u8(t0, rank);
            let sym = if BANKS == 1 {
                let lo = vqtbx4q_u8(a, t1, r1);
                let hi = vqtbx4q_u8(vqtbl4q_u8(t2, r2), t3, r3);
                vorrq_u8(lo, hi)
            } else if BANKS == 2 {
                let b = vqtbl4q_u8(t1, r1);
                let c = vqtbl4q_u8(t2, r2);
                let d = vqtbl4q_u8(t3, r3);
                vorrq_u8(vorrq_u8(a, b), vorrq_u8(c, d))
            } else {
                let abc = vqtbx4q_u8(vqtbx4q_u8(a, t1, r1), t2, r2);
                vorrq_u8(abc, vqtbl4q_u8(t3, r3))
            };
