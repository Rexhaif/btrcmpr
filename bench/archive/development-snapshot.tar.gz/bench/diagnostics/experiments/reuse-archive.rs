// The scoped worker handles several independent object sections. Only capacities
// cross the block boundary. The parser overwrites the entropy policy on entry.
thread_local! {
    static OBJECT_COMMANDS: std::cell::RefCell<Streams> = std::cell::RefCell::new(Streams::new());
}

pub(super) fn archive(s: &[u8]) -> Vec<u8> {
    OBJECT_COMMANDS.with_borrow_mut(|st| {
        for field in [&mut st.tag, &mut st.offs, &mut st.lits, &mut st.lens,
                      &mut st.low, &mut st.mid, &mut st.far] {
            field.clear();
        }
        st.rep = [1, 4, 8];
        let end = parsed_into::<35, 0>(s, 10, (2, 0), st);
        st.finish_coded::<0>(s, end, true, false, None)
    })
}

#[cfg(test)]
#[test]
fn independent_object_blocks_can_share_a_worker() {
    let mut state = 19u32;
    let data: Vec<_> = (0..218103).map(|i| {
        state ^= state << 13; state ^= state >> 17; state ^= state << 5;
        if (i / 97) % 8 < 5 { (i % 7) as u8 } else { state as u8 }
    }).collect();
    for bytes in [&data[..], &data[..4], &data[301..65537], &[9; 2048][..],
                  &data[9..10], &data[101..], &[][..], &data[..]] {
        let fresh = std::thread::scope(|scope| {
            scope.spawn(|| grouped::<35, 0>(bytes, true, 10, (2, 0))).join().unwrap()
        });
        assert_eq!(archive(bytes), fresh);
    }
}
