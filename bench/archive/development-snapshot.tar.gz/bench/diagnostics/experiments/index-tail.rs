        // Lab only. Prepare the addresses of up to six independent history
        // insertions before reading their old heads. Commit in the original
        // order: coincident bucket addresses must still observe earlier writes.
        if lab_tail != 0 {
            let mut keys = [(Key { a: 0, b: 0, sig: 0 }, 0u32, usize::MAX); 6];
            let mut used = 0;
            for (t, j) in [i + 1, i + 2, i + 3, end - 3, end - 2, end - 1].into_iter().enumerate() {
                if (t >= 3 && j <= i + 3) || j + 8 > s.len() { continue; }
                let w = word(s, j);
                let k = hash::<SHORT, LONG, PB>(w);
                let x = if k.a & 3 == 0 && j + 12 <= s.len() {
                    superkey::<EXTRA>(s, j, w)
                } else { usize::MAX };
                #[cfg(target_arch="aarch64")]
                unsafe {
                    if lab_tail >= 2 {
                        std::arch::asm!("prfm pstl1keep, [{0}]", in(reg) h7.as_ptr().add(k.b), options(nostack, preserves_flags, readonly));
                    }
                    if lab_tail >= 3 {
                        std::arch::asm!("prfm pstl1keep, [{0}]", in(reg) h4.as_ptr().add(k.a), options(nostack, preserves_flags, readonly));
                    }
                }
                keys[used] = (k, j as u32 | k.sig, x);
                used += 1;
            }
            for &(k, slot, x) in &keys[..used] {
                if x != usize::MAX { ext[x] = slot; }
                h4[k.a] = slot;
                h7[k.b] = (h7[k.b] << 32) | u64::from(slot);
            }
            anchor = end;
            i = end;
            continue;
        }
