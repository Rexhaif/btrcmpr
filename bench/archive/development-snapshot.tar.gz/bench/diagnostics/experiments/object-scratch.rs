// A worker owns its scratch between independent jobs. Each logical stream starts
// empty, including padding inserted during finalization of the preceding job.
thread_local! { static OBJECT_STREAMS: std::cell::RefCell<Streams> = std::cell::RefCell::new(Streams::new()); }
pub(super) fn archive(s: &[u8]) -> Vec<u8> {
    if crate::object_scratch_mode() & 1 == 0 { return grouped::<35, 0>(s, true, 10, (2, 0)); }
    OBJECT_STREAMS.with_borrow_mut(|st| {
        for stream in [&mut st.tag, &mut st.offs, &mut st.lits, &mut st.lens, &mut st.low, &mut st.mid, &mut st.far] { stream.clear(); }
        st.rep = [1, 4, 8];
        let end = parsed_into::<35, 0>(s, 10, (2, 0), st);
        st.finish_scratch::<0>(s, end, true, false, None)
    })
}
