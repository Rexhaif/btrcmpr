#!/usr/bin/env python3
"""Validate the fastest size-qualified mixed design with fresh warmed pairs at each level."""
import csv
import os
from pathlib import Path
import shutil
import subprocess
import sys

source, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=True)
rows = list(csv.DictReader(source.open()))
extra=source.with_name('intermediate.csv')
subprocess.run([sys.executable,'bench/diagnostics/mix-balance.py','--intermediate','--out',extra],check=True)
shutil.copyfile(extra,out/'intermediate.csv')
layout=source.with_name('phrase-layout.csv')
if layout.exists():
    shutil.copyfile(layout,out/'phrase-layout.csv')
rows.extend(csv.DictReader(extra.open()))
# Full-file reference sizes; timing cutoffs only avoid testing clearly slow
# candidates. The actual pass/fail comparisons use the fresh paired trials.
for level, ceiling, minimum in [(15,29594686,610), (14,29917280,620), (13,30087699,630)]:
    eligible = [r for r in rows if int(r['bytes']) < ceiling and float(r['decode_MBps']) > minimum]
    if not eligible:
        continue
    best = max(eligible,key=lambda r:float(r['decode_MBps']))
    args = [best[k] for k in ('grammar_workers','grammar_permille','byte_preset','byte_chunk_KiB')]
    subprocess.run([sys.executable,'bench/diagnostics/grammar-pairs.py','--level',str(level),
                    '--rounds','5','--mix',*args,'--out',out/f'paired-mix-{level}'],
                   env=dict(os.environ,BTR_MIX_FLAT=best['flat'],BTR_MIX_PARTIAL=best.get('split_byte_jobs','0'),
                            BTR_GRAM_PIPE='2'),check=True)
