#!/usr/bin/env python3
"""Recheck the two close level-one files on the exact comparator from the 22-level run."""
import csv,json,os,subprocess,sys
from decimal import Decimal
from pathlib import Path
from statistics import median
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';origin=base/'native-combined-1';out=base/'research/selected-stability-15';out.mkdir(parents=True,exist_ok=True)
stamp=json.loads((origin/'codegen.json').read_text());meta=json.loads((origin/'manifest.json').read_text())
if stamp['comparator']!=meta['benchmark_sha256']:raise ValueError('wrong release')
decl=dict(level=1,files=['enwik8','mozilla'],rounds=15,decodes_per_observation=7,workers_per_codec=4,target_comparator=stamp['comparator'],reason='closest low-level encode and decode margins; short replay of an instruction-identical rebuild missed Mozilla encode',rule='same size, strict encode and 95% decode gate; retain either verdict; do not overwrite the five-pair matrix')
spec=out/'plan.json'
if spec.is_file() and json.loads(spec.read_text())!=decl:raise ValueError('stability plan changed')
spec.write_text(json.dumps(decl,indent=2)+'\n')
if '--prepare' in sys.argv:raise SystemExit()
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','PROFILE_','ZSTD_'))}
with (out/'run.log').open('a',buffering=1) as log:
    args=['--resume'] if (out/'manifest.json').exists() else ['--from-manifest',origin/'manifest.json']
    z=subprocess.run([sys.executable,root/'scripts/preset-matrix.py',*args,'--levels','1','--files',*decl['files'],'--rounds','15','--decodes','7','--threads','4','--out',out],env=e,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if z.returncode not in (0,1) or not (out/'matrix-decode-tolerance.csv').is_file():raise ValueError('incomplete repeat')
    for cmd in ([sys.executable,root/'bench/diagnostics/preset-rates.py',out/'matrix.csv','--out',out/'rates.csv'],[sys.executable,root/'bench/diagnostics/preset-cli.py',out/'matrix.csv','--binary',root/'bench/local/preset-binaries'/('cli-'+stamp['cli']),'--sha256',stamp['cli'],'--out',out/'cli.csv']):
        subprocess.run(cmd,cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
got=json.loads((out/'manifest.json').read_text());assert got['benchmark_sha256']==meta['benchmark_sha256'] and got['zstd_library_sha256']==meta['zstd_library_sha256']
gold={r['input']:r['archive_sha256'] for r in read(origin/'cli.csv')}
for r in read(out/'cli.csv'):
    assert r['archive_sha256']==gold[r['input']] and r['restored_identical']=='1' and r['cli_sha256']==stamp['cli']
passed={r['file']:r['all_pass_with_allowance']=='1' for r in read(out/'matrix-decode-tolerance.csv')}
doc=['# Longer check of the selected executable','','The [plan](plan.json) chose the two level-one files with narrow margins before running this check. Both use the very same comparator, standalone CLI, system libzstd, inputs and worker count as the full preset ladder. The [five-pair original](../../native-combined-1/rates.csv) and [source rebuild](../combined-rebuild/README.md) remain separate. Each of the fifteen alternating pairs includes seven decodes per timing.','','| File | Encode MB/s, Rust / zstd | Encode pairs won | Decode MB/s, Rust / zstd | Pairs within 5% on decode | Gate on medians |','|---|---:|---:|---:|---:|---|']
for r in read(out/'rates.csv'):
    f=r['file'];rs=read(out/f'level-01-{f}.csv');pairs=[{x['codec']:x for x in rs if int(x['round'])==i} for i in range(1,16)]
    win=sum(Decimal(v['btrcmpr']['compress_seconds'])<Decimal(v['zstd']['compress_seconds']) for v in pairs)
    dec=sum(Decimal(v['btrcmpr']['decompress_seconds'])*Decimal('.95')<=Decimal(v['zstd']['decompress_seconds']) for v in pairs)
    doc.append(f"| [{f}](level-01-{f}.csv) | {r['btr_encode_MBps']} / {r['zstd_encode_MBps']} | {win}/15 | {r['btr_decode_MBps']} / {r['zstd_decode_MBps']} | {dec}/15 | {'Pass' if passed[f] else 'Miss'} |")
doc+=['','[Raw median verdicts](matrix-decode-tolerance.csv), [archive hashes and independent byte-identical restoration](cli.csv).','']
(out/'README.md').write_text('\n'.join(doc))
