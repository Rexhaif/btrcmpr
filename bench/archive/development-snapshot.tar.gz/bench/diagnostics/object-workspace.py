#!/usr/bin/env python3
"""Build a native candidate with worker scratch, and give it fresh paired trials."""
import argparse, json, os, re, shutil, subprocess, sys
from pathlib import Path
from statistics import median
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';prior=base/'native-combined-1'
gold=json.loads((prior/'manifest.json').read_text());snap=root/'bench/local/levels/lanes/native-object-workspace';dest=base/'native-object-workspace-1'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepare',action='store_true');a=p.parse_args()
dest.mkdir(parents=True,exist_ok=True);choices={n:dict(csv='native-combined-1/cli.csv',match=dict(input=n,level='1')) for n in gold['files']}
if not snap.exists():
    path=dest/'archive-references.json';path.write_text(json.dumps(choices,indent=2)+'\n')
    subprocess.run([sys.executable,root/'bench/diagnostics/freeze-low.py','--workspace',snap,'--choices',path],check=True)
def once(s,old,new):
    if s.count(old)!=1:raise ValueError('unexpected original: '+old)
    return s.replace(old,new)
if not (snap/'scratch-ready').is_file():
    if any(sha(snap/k)!=v for k,v in gold['source_sha256'].items()):raise ValueError('wrong baseline source')
    path=snap/'src/lz.rs';s=path.read_text();s=once(s,'pub(crate) fn finish_literals(\n        self,','pub(crate) fn finish_literals(\n        mut self,')
    lo=s.index('    fn finish_coded<const PACK: u8>');hi=s.index('\n}\npub fn encode',lo)
    body=once(s[lo:hi],'        mut self,','        &mut self,');body=re.sub(r'&self(?=\s*[,\)])','self',body);path.write_text(s[:lo]+body+s[hi:])
    path=snap/'src/emitoffset.rs';path.write_text(once(path.read_text(),'pub(super) fn archive(s: &[u8]) -> Vec<u8> {\n    grouped::<35, 0>(s, true, 10, (2, 0))\n}',(root/'bench/diagnostics/experiments/reuse-archive.rs').read_text().rstrip()))
    path=snap/'src/pairhead.rs';s=once(path.read_text(),'fn parse<','''// The native object scanner uses exactly 16,384 entries. Taking the table
// temporarily also keeps its mutable storage private during parsing.
thread_local! {
    static OBJECT_TABLE: std::cell::Cell<Vec<u32>> = const { std::cell::Cell::new(Vec::new()) };
}
fn parse<''');s=once(s,'    let mut t = vec![0u32; 1 << B];','''    let reuse = P == 7 && B == 14 && MIN == 4 && POLICY == 0 && EXT == 1;
    let mut t = if reuse {
        let mut v = OBJECT_TABLE.with(std::cell::Cell::take);
        v.clear();
        // A zero slot refers to byte zero of this block. Retaining earlier
        // positions would change matches and could read outside short blocks.
        v.resize(1 << B, 0);
        v
    } else {
        vec![0u32; 1 << B]
    };''');path.write_text(once(s,'    anchor\n}', '    if reuse { OBJECT_TABLE.with(|buf| buf.set(t)); }\n    anchor\n}'))
    subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',snap/'src/emitoffset.rs',snap/'src/pairhead.rs'],check=True)
    patch=''
    for name in ('src/lz.rs','src/emitoffset.rs','src/pairhead.rs'):
        r=subprocess.run(['diff','-u','--label','a/'+name,'--label','b/'+name,root/name,snap/name],text=True,capture_output=True)
        if r.returncode!=1:raise ValueError('missing source change for '+name)
        patch+=r.stdout
    (dest/'worker-scratch.patch').write_text(patch);(snap/'scratch-ready').touch()
if a.prepare:raise SystemExit()
if not (base/'research/object-scratch/long-mode-3.csv').exists():raise ValueError('missing independent crossover')
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PERF_','PROFILE_','CARGO_PROFILE_')) and k not in ('CARGO_TARGET_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','BTRCMPR_NATIVE_SCAN')}
with (dest/'run.log').open('a',buffering=1) as log:
    def run(cmd,allowed=(0,),env=e):
        print(' '.join(map(str,cmd)),file=log,flush=True);res=subprocess.run(cmd,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT)
        if res.returncode not in allowed:raise RuntimeError('see '+str(dest/'run.log'))
    model=snap/'target/profiled/build-profiled.json'
    if not model.exists():
        run(['cargo','test','--locked','--offline','--lib','--features','regional-models'],env=dict(e,BTRCMPR_NATIVE_SCAN='7'))
        run(['cargo','clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings'])
        run([sys.executable,root/'scripts/build-profiled.py','--workspace',snap,'--selected'])
    for out,rounds,names in ((dest,5,gold['files']),(dest/'long-mozilla',15,['mozilla'])):
        run([sys.executable,snap/'scripts/preset-matrix.py',*(['--resume'] if (out/'manifest.json').exists() else ['--selected']),'--levels','1','--rounds',str(rounds),'--files',*names,'--out',out],(0,1))
        if not (out/'cli.csv').is_file() or not (out/'matrix-decode-tolerance.csv').is_file():raise ValueError('incomplete comparison')
build=json.loads(model.read_text());ids={t:build[k] for t,k in [('cli','cli_sha256'),('comparator','comparator_sha256'),('profile','profile_runner_sha256'),('profile_data_sha256','profile_data_sha256'),('settings','settings'),('regional_scan','regional_scan')]}
if {r['input']:r['archive_sha256'] for r in read(dest/'cli.csv')}!={r['input']:r['archive_sha256'] for r in read(prior/'cli.csv')}:raise ValueError('native archive changed')
(dest/'codegen.json').write_text(json.dumps(ids,indent=2)+'\n')
(dest/'training.json').write_text(json.dumps(build['training'],indent=2)+'\n')
for tag in (dest,dest/'long-mozilla'):
    m=json.loads((tag/'manifest.json').read_text())
    if m['benchmark_sha256']!=ids['comparator'] or m['zstd_library_sha256']!=gold['zstd_library_sha256']:raise ValueError('wrong candidate or reference')
rates=read(dest/'rates.csv');long,=read(dest/'long-mozilla/rates.csv')
rows=[(r,5) for r in rates]+[(long,15)]
trials=read(dest/'long-mozilla/level-01-mozilla.csv');pairs={i:{r['codec']:float(r['compress_seconds']) for r in trials if int(r['round'])==i} for i in range(1,16)}
wins=sum(x['btrcmpr']<x['zstd'] for x in pairs.values());ratio=float(long['btr_encode_MBps'])/float(long['zstd_encode_MBps'])
ready=all(r['all_pass_with_allowance']=='1' for r in read(dest/'matrix-decode-tolerance.csv')+read(dest/'long-mozilla/matrix-decode-tolerance.csv')) and ratio>=1.04 and wins>=10
(dest/'decision.json').write_text(json.dumps(dict(ready_for_ladder=ready,required_initial_cells=3,min_long_encode_ratio=1.04,min_long_encode_pairs_won=10,measured_wins=wins,measured_encode_ratio=ratio),indent=2)+'\n')
lines=['# Native level-one object worker workspace','','This standalone candidate retains its command stream buffers and its zeroed match table between independent object blocks. Its [three-file Rust patch](worker-scratch.patch) includes a regression test comparing a reused worker against a fresh thread after unrelated shorter and longer inputs. The [compiler training data](training.json) exclude the benchmark files. All three output archives reproduced the original release SHA-256.','','| Input | Pairs | Ratio, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |','|---|---:|---:|---:|---:|']
for r,n in rows:lines.append(f"| {r['file']} | {n} | "+' | '.join(r['btr_'+k]+' / '+r['zstd_'+k] for k in ('ratio','encode_MBps','decode_MBps'))+' |')
lines+=['',f'The longer Mozilla comparison won {wins}/15 individual encode pairs. The [screening rule](decision.json) requires every median to pass the user’s gate, at least 4% encode headroom on long Mozilla, and at least ten paired encode wins there. Eligible for a separate preset ladder: **{ready}**. Results from the earlier executable are not counted for this build.','']
(dest/'README.md').write_text('\n'.join(lines))
