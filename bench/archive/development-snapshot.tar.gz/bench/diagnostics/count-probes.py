"""Count match-finder outcomes without adding instrumentation to the shipped codec."""
import csv
import filecmp
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[2]
raw = (root / "bench/data/enwik8") if len(sys.argv) == 1 else Path(sys.argv[1]).resolve()
scratch = root / "bench/local"
scratch.mkdir(exist_ok=True, parents=True)


def inject(source, original, replacement):
    if source.count(original) != 1:
        raise ValueError("probe instrumentation no longer matches this revision: " + original)
    return source.replace(original, replacement)


with tempfile.TemporaryDirectory(prefix="count-probes-", dir=scratch) as tmp:
    work = Path(tmp)
    for name in ("Cargo.toml", "Cargo.lock"):
        shutil.copy2(root / name, work / name)
    for name in ("src", ".cargo", "examples"):
        shutil.copytree(root / name, work / name)

    cli = work / "target/release/btrcmpr"
    build = ["cargo", "build", "--quiet", "--locked", "--release", "--bin", "btrcmpr"]
    subprocess.run(build, cwd=work, check=True)
    ref, logged, decoded = (work / name for name in ("ref.btr", "logged.btr", "decoded.bin"))
    subprocess.run([cli, "c", "-3", raw, ref, "4"], check=True)

    lz = work / "src/lz.rs"
    src = lz.read_text()
    src = inject(src, "const MASK: usize", """
std::thread_local! {
    static PROBE_COUNTS: std::cell::Cell<[u64; 4]> = const { std::cell::Cell::new([0; 4]) };
}
fn probe_event(k: usize) {
    PROBE_COUNTS.with(|c| { let mut x = c.get(); x[k] += 1; c.set(x); });
}
const MASK: usize""")
    src = inject(src, "if (slot ^ sig) > MASK as u32 || pos >= i {", """
    if pos >= i {
        probe_event(0);
        return (0, 0);
    }
    if (slot ^ sig) > MASK as u32 {
        probe_event(1);""")
    src = inject(src, "    if d != 0 {\n        return ((d.trailing_zeros()",
                 "    probe_event(if d as u32 == 0 { 3 } else { 2 });\n"
                 "    if d != 0 {\n        return ((d.trailing_zeros()")
    finish = "    streams.finish(s, anchor, ARCHIVE)"
    src = inject(src, finish, """    let c = PROBE_COUNTS.with(|x| x.replace([0; 4]));
    eprintln!("probes,{},{},{},{},{}", s.len(), c[0], c[1], c[2], c[3]);
""" + finish)
    lz.write_text(src)
    subprocess.run(build, cwd=work, check=True)
    log = subprocess.run([cli, "c", "-3", raw, logged, "4"], check=True,
                         capture_output=True, text=True).stderr
    subprocess.run([cli, "d", logged, decoded, "4"], check=True)
    if not (filecmp.cmp(ref, logged, shallow=False) and filecmp.cmp(raw, decoded, shallow=False)):
        raise ValueError("instrumentation changed the archive or output")
    rows = [list(map(int, line.split(",")[1:])) for line in log.splitlines() if line.startswith("probes,")]
    n, invalid, rejected, short, matched = map(sum, zip(*rows, strict=True))
    if n != raw.stat().st_size:
        raise ValueError("input did not exclusively select the general level-3 parser")
    w = csv.writer(sys.stdout, lineterminator="\n")
    w.writerow(("input", "bytes", "blocks", "probe_calls", "not_earlier", "fingerprint_rejected",
                "history_load_under_4_equal_bytes", "history_load_at_least_4_equal_bytes", "archive_bytes"))
    w.writerow((raw.name, n, len(rows), invalid + rejected + short + matched, invalid, rejected,
                short, matched, ref.stat().st_size))
