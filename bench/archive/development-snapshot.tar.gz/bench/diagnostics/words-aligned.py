#!/usr/bin/env python3
"""Fully account and test two representations using a frozen research build."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import struct
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
controls={r['file']:r for r in read(root/'bench/results/presets/research/palette-write/checks.csv') if r['mode']=='0'}
def portions(arc):
    buf=memoryview(arc.read_bytes());assert buf[:8]==b'BTRCMP01';size,block=struct.unpack_from('<QI',buf,8);pos=20
    def u32(): 
        nonlocal pos
        v=struct.unpack_from('<I',buf,pos)[0];pos+=4;return v
    def var():
        nonlocal pos
        v=0
        for bits in range(0,64,7):
            x=buf[pos];pos+=1;v|=(x&127)<<bits
            if x<128:return v
        raise ValueError('oversized varint')
    if block>>31:
        jobs=[var() for _ in range(u32())]
        for _ in range(u32()):var();var()
    else:jobs=[min(block,size-i) for i in range(0,size,block)]
    totals=Counter()
    def one(data,n):
        tag=data[0]
        if tag==5:
            j=1;done=0
            while j<len(data):
                raw,nb=struct.unpack_from('<II',data,j);j+=8;one(data[j:j+nb],raw);j+=nb;done+=raw
            if j!=len(data) or done!=n:raise ValueError('bad split')
        else:totals[tag]+=n
    for n in jobs:
        nb=u32();one(buf[pos:pos+nb],n);pos+=nb
    if sum(totals.values())!=size or pos!=len(buf):raise ValueError('unaccounted frame')
    return totals
reference=read(root/'bench/results/presets/zstd-sizes.csv')
sources={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}
(out/'manifest.json').write_text(json.dumps(dict(workers=4,source_sha256=sources,binaries={b:sha(ex/b) for b in ('compare','examples/candidate','examples/decode_loop')},
    corpus={n:sha(root/'bench/data'/n) for n in controls}),indent=2)+'\n')
def run(cmd,e):return subprocess.run(cmd,env=e,text=True,capture_output=True,check=True)
with (out/'screen.csv').open('w',buffering=1) as sf,(out/'paired.csv').open('w',buffering=1) as pf,(out/'checks.csv').open('w',buffering=1) as cf,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    sw=csv.writer(sf,lineterminator='\n');sw.writerow(('file','phase','parse','model','KiB','fast_generic','archive_bytes','encode_MBps','decode_MBps'))
    pw=csv.writer(pf,lineterminator='\n');pw.writerow(('file','parse','model','KiB','fast_generic','codec','archive_bytes','encode_MBps','decode_MBps','all_three_pass'))
    cw=csv.writer(cf,lineterminator='\n');cw.writerow(('file','case','archive_bytes','archive_sha256','specialized_input_bytes','verified_decoder_workers'))
    for name,tag,refc,refd in [('mozilla',60,740,1650),('enwik8',61,630,1640)]:
        src=root/'bench/data'/name;arc=Path(tmp)/'test.btr';limit=int(next(r['zstd_bytes'] for r in reference if r['file']==name and r['level']=='1'))
        def conf(case):
            code,model,k,h=case
            if name=='enwik8':return dict(env,BTR_JOB_KIB=str(k),BTR_RUNBOOK=str(code),BTR_RUNBOOK_MODEL=str(model),BTR_FAST_COUNTS=str(2*h),BTR_FAST_PLAN=str(2*h))
            return dict(env,BTR_ARCH_KIB=str(k),BTR_WORD_COPY=str(code),BTR_WORD_MODEL=str(model),BTR_FAST1='8' if h else '0',BTR_FAST_COUNTS=str(2*h),BTR_FAST_PLAN=str(2*h))
        def screen(c,phase,save=False):
            e=conf(c)
            if save:e['BTR_CANDIDATE_FRAME']=str(arc)
            r=next(csv.DictReader(run([ex/'examples/candidate','4','1',src,'native'],e).stdout.splitlines()))
            n=int(r['bytes']);v=float(r['encode_MBps']);d=float(r['decode_MBps'])
            sw.writerow((name,phase,*c,n,v,d));return (n,v,d,c)
        control=(0,0,128 if name=='mozilla' else 256,0)
        def check(n,case):
            if arc.stat().st_size!=n:raise ValueError('nonreproducible archive size')
            run([ex/'examples/decode_loop',arc,'1','3',src],env)
            v=portions(arc);digest=sha(arc);cw.writerow((name,case,n,digest,v[tag],3));return digest,v[tag]
        ctrl=screen(control,'control',True)
        if check(ctrl[0],'native')[0]!=controls[name]['verified_sha256']:raise ValueError('native archive changed')
        if name=='mozilla':
            first=[(mode,mdl,128,0) for mode in (1,2,3,4,5,7,9,11,17,19,23,31) for mdl in (0,1,6)]
            sizes=[64,192,256,512];models=[0,1,2,6]
        else:
            first=[(mode,mdl,512,0) for mode in (1,2,3,4,5,6,9,13) for mdl in (1,5,13,29)]
            sizes=[256,1024,2048];models=[0,2,4,6,12,28]
        rng=random.Random(241+tag);rng.shuffle(first)
        options=[screen(c,'first') for c in first]
        def score(row):return min(row[1]/refc,row[2]/refd,limit/row[0])
        shallow=sorted(options,key=lambda r:r[0])[:1]+sorted(options,key=score,reverse=True)[:2]
        modes={r[3][0] for r in shallow}
        second=list({(mode,m,k,1) for mode in modes for k in sizes for m in models});rng.shuffle(second)
        options.extend(screen(c,'jobs') for c in second)
        eligible=[r for r in options if r[0]<limit]
        winners=[max(eligible,key=lambda r:min(r[1]/refc,r[2]/refd))] if eligible else [min(options,key=lambda r:r[0])]
        if not eligible and max(options,key=score)[0]<1.1*limit:winners.append(max(options,key=score))
        for n,c,d,case in dict.fromkeys(winners):
            screen(case,'selected',True);digest,active=check(n,case)
            if not active:raise ValueError('research representation unused by finalist')
            path=out/f'{name}-{"-".join(map(str,case))}.partial'
            run([ex/'compare','4','5','both',src],dict(conf(case),BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(path)))
            data=read(path);stats=[]
            for codec,wanted in [('btrcmpr',n),('zstd',limit)]:
                g=[r for r in data if r['codec']==codec];assert len(g)==5 and {int(r['round']) for r in g}==set(range(1,6)) and all(int(r['compressed_bytes'])==wanted for r in g)
                stats.append((wanted,*(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in g) for k in ('compress_seconds','decompress_seconds'))))
            x,y=stats;passed=int(x[0]<y[0] and x[1]>y[1] and x[2]>y[2])
            for nm,values in zip(('btrcmpr','zstd'),stats,strict=True):pw.writerow((name,*case,nm,values[0],round(values[1],3),round(values[2],3),passed))
            path.replace(path.with_suffix('.csv'))
