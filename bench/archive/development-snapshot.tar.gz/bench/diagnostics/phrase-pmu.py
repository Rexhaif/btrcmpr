#!/usr/bin/env python3
"""Gate ARM hardware counters around one production preset on enwik8."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--level',type=int,choices=range(1,23),default=13)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--zstd-debug',type=Path,help='also sample retired instructions with matching zstd symbols')
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
d=a.out.resolve();d.mkdir(exist_ok=True,parents=True)
perf=os.getenv('PERF') or shutil.which('perf') or str(root/'bench/local/perf')
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PROFILE_'))}
env.update(LC_ALL='C',PERF=perf,BTR_LEVEL=str(a.level),ZSTD_WIDE='1')
cr=8 if a.level<=2 else 2
for phase,codec,reps in [('c','ours',cr),('c','zstd',cr),('d','zstd',12),('d','ours',12)]:
    path=d/f'l{a.level}-{phase}-{codec}.txt'
    with path.with_suffix('.partial').open('w') as log:
        subprocess.run(['scripts/perf-stat.sh',phase,codec,'bench/data/enwik8','4',str(reps)],
                       cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    path.with_suffix('.partial').replace(path)
with (d/'per-byte.csv').open('w') as out:
    subprocess.run([sys.executable,'bench/diagnostics/preset-counters.py',d],cwd=root,stdout=out,check=True)
src=root/'bench/data/enwik8'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
profile=root/env.get('CARGO_TARGET_DIR','target')/'release/examples/profile'
rows=list(csv.DictReader((d/'per-byte.csv').open()))
if len(rows)!=4 or any(float(r['instructions_per_byte'])<=0 for r in rows):raise ValueError('incomplete PMU evidence')
(d/'manifest.json').write_text(json.dumps(dict(level=a.level,workers=4,input_sha256=digest(src),
    profile_sha256=digest(profile),perf_version=subprocess.check_output([perf,'version'],text=True).strip(),
    source={str(p.relative_to(root)):digest(p) for p in sorted((root/'src').rglob('*.rs'))}),indent=2)+'\n')
debug=a.zstd_debug or Path(os.getenv('ZSTD_DEBUG',root/'bench/local/zstd.debug'))
if debug.is_file():
    scratch=root/'bench/local/levels/lanes'/f'instruction-samples-l{a.level}'
    subprocess.run([sys.executable,'bench/diagnostics/sample-search.py','--out',scratch,'--level',str(a.level),
                    '--zstd-debug',debug.resolve(),'--repetitions',str(6 if a.level<=2 else 1)],cwd=root,env=env,check=True)
    shutil.copy2(scratch/'encode-samples.txt',d/'encode-samples.txt')
