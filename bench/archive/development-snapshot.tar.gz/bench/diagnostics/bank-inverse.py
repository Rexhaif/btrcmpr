#!/usr/bin/env python3
"""Compare instruction-bank restoration on fixed Mozilla archives, then pair the finalists."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
for arg in ('workspace','out','bin-dir'):p.add_argument('--'+arg,required=True,type=Path)
p.add_argument('--levels',nargs='+',type=int,choices=[6,17,19,21],default=[6],help='default: the Mozilla decode miss outside a 5% allowance')
a=p.parse_args();root=Path(__file__).resolve().parents[2];ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True);snap=a.workspace.resolve()
src=root/'bench/data/mozilla';base=root/'bench/results/presets';frames=root/'bench/local/levels/lanes/ahead-frames';perf=root/'bench/local/perf'
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,e):return subprocess.run(cmd,env=e,text=True,capture_output=True,check=True)
def rate(r):return float(re.search(r'([\d.]+) MB/s',r.stderr)[1])
def cfg(m,h):return dict(env,BTR_BANK_INVERSE=str(m),BTR_BANK_HINT=str(h))
def log(name,columns):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(columns.split());return f,w
reference={int(r['level']):int(r['zstd_bytes']) for r in read(base/'zstd-sizes.csv') if r['file']=='mozilla'}
checks=[r for r in read(base/'research/decode-ahead/checks.csv') if r['file']=='mozilla' and int(r['level']) in (6,17,19)]
assert len(checks)==3 and {r['source_sha256'] for r in checks}=={digest(src)}
# Level 21 subsequently missed on native decode. Recreate its exact CLI
# archive and require the independent production hash before adding it.
if 21 in a.levels:
    high=next(r for r in read(base/'dictionary-20-22/cli.csv') if r['input']=='mozilla' and r['level']=='21')
    extra=out/'mozilla-21.btr'
    subprocess.run(['cargo','build','--offline','--locked','--release','--all-features','--example','candidate'],cwd=snap,env=dict(env,CARGO_TARGET_DIR=str(ex.parent)),check=True)
    run([ex/'examples/candidate','4','21',src,'native'],dict(env,BTR_CANDIDATE_FRAME=str(extra)))
    if extra.stat().st_size!=int(high['cli_bytes']) or digest(extra)!=high['archive_sha256'] or high['source_sha256']!=digest(src):raise ValueError('native level-21 archive changed')
    extra.replace(frames/'mozilla-21.btr')
    checks.append(dict(file='mozilla',level='21',archive_bytes=high['cli_bytes'],archive_sha256=high['archive_sha256'],source_sha256=high['source_sha256']))
checks=[r for r in checks if int(r['level']) in a.levels]
(out/'manifest.json').write_text(json.dumps(dict(corpus=checks,workers=4,executable={s:digest(ex/s) for s in ('compare','examples/decode_loop')},
    sources={str(p.relative_to(snap)):digest(p) for p in (snap/'src').rglob('*.rs')}),indent=2)+'\n')
tf,tw=log('trials','level mode hint round decode_MBps');sf,sw=log('screen','level mode hint native_MBps best_MBps relative');cf,cw=log('counters','level mode hint instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte counter_MBps')
pf,pw=log('paired','level mode hint codec archive_bytes encode_MBps decode_MBps')
with tf,sf,cf,pf:
    finalists=[]
    for r in checks:
        lv=int(r['level']);arc=frames/f'mozilla-{lv}.btr'
        if digest(arc)!=r['archive_sha256']:raise ValueError('wrong archive')
        cases=[(m,1) for m in range(16)]+[(m,0) for m in (0,10,11,12,13,14)]
        timings={case:[] for case in cases};rng=random.Random(56+lv)
        for trial in range(3):
            rng.shuffle(cases)
            for m,h in cases:
                d=rate(run([ex/'examples/decode_loop',arc,'8','4',src],cfg(m,h)))
                tw.writerow((lv,m,h,trial+1,d));timings[m,h].append(d)
        med={case:statistics.median(v) for case,v in timings.items()};selected=max(med,key=med.get);control=med[0,1]
        sw.writerow((lv,*selected,control,med[selected],round(med[selected]/control,5)))
        events=['instructions:u','cycles:u','branches:u','branch-misses:u']
        for m,h in dict.fromkeys([(0,1),selected]):
            with tempfile.TemporaryDirectory() as t:
                ctl,ack=(Path(t)/x for x in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                z=run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',ex/'examples/decode_loop',arc,'20','4',src],dict(cfg(m,h),PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            (out/f'l{lv}-{m}-{h}-perf.txt').write_text(z.stderr)
            count={v[2]:float(v[0])/(20*src.stat().st_size) for s in z.stderr.splitlines() if len(v:=s.split(';'))>2 and v[2] in events}
            cw.writerow((lv,m,h,*(round(count[k],5) for k in events),rate(z)))
        if selected!=(0,1) and med[selected]>control*1.01:finalists.append((lv,*selected,int(r['archive_bytes'])))
    for lv,m,h,nb in finalists:
        t=out/f'level-{lv}-mozilla.partial'
        run([ex/'compare','4','5','both',src],dict(cfg(m,h),BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(t)))
        data=read(t)
        for codec,size in [('btrcmpr',nb),('zstd',reference[lv])]:
            seq=[r for r in data if r['codec']==codec]
            if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=size for r in seq):raise ValueError('invalid pair')
            pw.writerow((lv,m,h,codec,size,*(round(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in seq),3) for k in ('compress_seconds','decompress_seconds'))))
        t.replace(t.with_suffix('.csv'))
