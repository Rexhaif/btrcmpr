#!/usr/bin/env python3
"""Compare both native decoders on level-1 enwik8; the canonical archives must be identical."""
import csv,json,os,re,subprocess,sys,tempfile
from pathlib import Path
from statistics import median
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';lanes=root/'bench/local/levels/lanes';out=root/'bench/results/profiles/object-workspace-enwik8-decode';out.mkdir(parents=True,exist_ok=True)
origins=[base/'native-combined-1',base/'native-object-workspace-1'];snaps=[lanes/'combined-presets',lanes/'native-object-workspace'];src=root/'bench/data/enwik8';perf=root/'bench/local/perf'
exes=[s/'target/profiled/release/examples/profile' for s in snaps];names=['Original','Object buffers'];gold={};ident=[]
for i,(origin,snap,exe) in enumerate(zip(origins,snaps,exes,strict=True)):
    stamp=json.loads((origin/'codegen.json').read_text());meta=json.loads((origin/'manifest.json').read_text())
    cell,=[r for r in read(origin/'cli.csv') if r['input']=='enwik8'];rate,=[r for r in read(origin/'rates.csv') if r['file']=='enwik8']
    if sha(exe)!=stamp['profile'] or meta['benchmark_sha256']!=stamp['comparator'] or cell['cli_sha256']!=stamp['cli'] or cell['source_sha256']!=sha(src):raise ValueError('wrong profiled build or input')
    if i==0:gold=dict(sha=cell['archive_sha256'],ours=rate['btr_bytes'],zstd=rate['zstd_bytes'])
    elif (cell['archive_sha256'],rate['btr_bytes'],rate['zstd_bytes'])!=(gold['sha'],gold['ours'],gold['zstd']):raise ValueError('archives changed')
    lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',subprocess.check_output(['ldd',exe],text=True))[1])
    if sha(lib)!=meta['zstd_library_sha256']:raise ValueError('wrong reference library')
    ident.append(dict(name=names[i],profile=sha(exe),comparator=meta['benchmark_sha256'],archive=cell['archive_sha256'],input=sha(src),libzstd=sha(lib)))
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PROFILE_','PERF_'))};e.update(BTR_LEVEL='1',ZSTD_WIDE='1',LC_ALL='C',PERF=str(perf))
# Rotate all four cases through all four execution positions; reverse the middle groups.
orders=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]]
events=('instructions:u','cycles:u','branches:u','branch-misses:u','r03:u','r17:u');reps=8;raw=src.stat().st_size;results=[]
for block,order in enumerate(orders):
    for sequence,case in enumerate(order):
        idx,ref=divmod(case,2);codec='zstd' if ref else 'ours';exe=exes[idx]
        with tempfile.TemporaryDirectory() as t:
            ctl,ack=(Path(t)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
            proc=subprocess.run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe,'d',codec,src,'4',str(reps)],env=dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack)),text=True,capture_output=True,check=True)
        log=proc.stderr;(out/f'block-{block}-case-{case}.txt').write_text(log)
        if 'archive_bytes='+gold[codec]+'\n' not in log:raise ValueError('counter archive differs')
        counts={r[2]:int(r[0])/(reps*raw) for l in log.splitlines() if len(r:=l.split(';'))>2 and r[2] in events}
        results.append([block+1,sequence+1,case,names[idx],codec,*[counts[k] for k in events],float(re.search(r'([\d.]+) MB/s',log)[1])])
with (out/'counter-runs.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['block','sequence','case','build','codec','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','l1d_refills_per_byte','l2d_refills_per_byte','MBps']);w.writerows(results)
table=[]
for case in range(4):
    runs=[r for r in results if r[2]==case];r=runs[0];vals=[median(z[i] for z in runs) for i in [5,6,9,10,11]];table.append('| '+r[3]+' | '+r[4]+' | '+' | '.join(f'{v:.3f}' for v in vals)+' |')
subprocess.run([sys.executable,root/'bench/diagnostics/frozen-encoder-pmu.py','--workspace',snaps[1],'--matrix',origins[1],'--out',out/'candidate','--operation','d','--file','enwik8','--level','1','--repetitions','8','--frozen-profile',exes[1],'--codegen',origins[1]/'codegen.json','--arm-cache'],env=e,check=True)
subprocess.run([sys.executable,root/'bench/diagnostics/sample-search.py','--level','1','--file','enwik8','--operation','d','--event','cycles','--period','120011','--repetitions','8','--out',snaps[1]/'decode-samples','--zstd-debug',root/'bench/local/zstd.debug','--exe',exes[1],'--verified-cell',out/'candidate','--summary',out/'decode-cycles.txt'],env=e,check=True)
(out/'manifest.json').write_text(json.dumps(dict(builds=ident,orders=orders,repetitions=reps,workers=4),indent=2)+'\n')
(out/'README.md').write_text('\n'.join(['# Level-one enwik8 decoder comparison','','The [native object-buffer candidate](../../presets/native-object-workspace-1/README.md) missed the 5% decode gate on enwik8. This crossover compares the original and the candidate on byte-identical Rust archives, and also runs the same libzstd decoder in each executable. Each of the four cases occupied each position once. Each perf interval followed a verified warmup and covers eight four-worker decodes of the full input. Table entries are medians of the four runs per case.','','| Build | Decoder | Instructions/B | Cycles/B | L1D refills/B | L2D refills/B | Decode MB/s |','|---|---|---:|---:|---:|---:|---:|',*table,'','[All counters and timing observations](counter-runs.csv), [identities](manifest.json), [candidate and zstd cycle samples](decode-cycles.txt). These are fixed-archive diagnostic measurements. The original five-pair acceptance result is unchanged.','']))
