#!/usr/bin/env python3
"""Screen the phrase vocabulary and token parsers on a slice, then the full enwik8."""
import argparse
import csv
import os
import subprocess
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
exe = root / "target/release/examples/candidate"
source = root / "bench/data/enwik8"
def run(w, data, cap, width, methods):
    env = dict(os.environ, BLOCK_KIB="24576", PRESET_ALIGN="1", BTR_GRAM_CAP=str(cap),
               BTR_GRAM_WIDTH=str(width))
    p = subprocess.run([exe, "4", "16", data, *methods], env=env, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"{p.stderr} {p.stdout}")
    for r in csv.DictReader(p.stdout.splitlines()):
        w.writerow([data.stat().st_size, cap, width, r["candidate"], r["bytes"], r["encode_MBps"], r["decode_MBps"]])
args.out.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory() as tmp, args.out.open("w", buffering=1) as out:
    small = Path(tmp) / "slice"
    with source.open("rb") as src:
        small.write_bytes(src.read(4 << 20))
    w = csv.writer(out, lineterminator="\n")
    w.writerow(["raw_bytes","phrase_cap","max_spelling","candidate","bytes","encode_MBps","decode_MBps"])
    kinds = ["lex-grammar-flat", "lex-grammar", "lex-grammar-bytes"]
    run(w, small, 4096, 32, kinds)
    for cap, width in [(0,32), (4096,32), (16384,48), (65536,64)]:
        run(w, source, cap, width, kinds)
