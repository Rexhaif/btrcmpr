#!/usr/bin/env python3
"""Measure the self-contained child-reference dictionaries with exact decoding."""
import argparse
import csv
import os
import subprocess
import tempfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
a.out.parent.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as tmp,a.out.open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n')
    w.writerow(('input_bytes','min_uses','word_cap','max_width','chunk_KiB','archive_bytes','encode_MBps','decode_MBps'))
    full=Path('bench/data/enwik8');slice_=Path(tmp)/'small'
    with full.open('rb') as src:slice_.write_bytes(src.read(4<<20))
    for data,cap,width,minimum,kib in [
        (slice_,8192,48,3,24576),(full,16384,48,3,24576),
        (full,65536,64,3,24576),(full,131072,64,3,24576),
        (full,262144,64,2,24576),(full,65536,48,3,12288)]:
        env=dict(os.environ,BLOCK_KIB=str(kib),PRESET_ALIGN='1',BTR_DAG_CAP=str(cap),
                 BTR_DAG_MIN=str(minimum),BTR_DAG_WIDTH=str(width))
        r=subprocess.run(['target/release/examples/candidate','4','22',data,'lex-dag'],
                         env=env,capture_output=True,text=True)
        if r.returncode:raise RuntimeError(r.stderr+r.stdout)
        row=next(csv.DictReader(r.stdout.splitlines()))
        w.writerow((data.stat().st_size,minimum,cap,width,kib,row['bytes'],row['encode_MBps'],row['decode_MBps']))
