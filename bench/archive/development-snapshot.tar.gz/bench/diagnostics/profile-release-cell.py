#!/usr/bin/env python3
"""Compare both directions using the profile executable from the timed native build."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','origin','out'):p.add_argument('--'+k,required=True,type=Path)
p.add_argument('--level',required=True,type=int,choices=range(1,23))
p.add_argument('--file',required=True,choices=('enwik8','x-ray','mozilla'))
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();origin=a.origin.resolve();out=a.out.resolve()
stamp=json.loads((origin/'codegen.json').read_text())
series=origin.parent/'integrated'/stamp['comparator']
trials=f'level-{a.level:02}-{a.file}.csv'
locations=[d for d in (origin,series/f'l{a.level:02}',series/'tracks'/a.file) if (d/trials).is_file()]
if len(locations)!=1:raise ValueError(f'expected exactly one paired trial: {locations}')
loc=locations[0]
def rows(path):
    with path.open() as f:return list(csv.DictReader(f))
table=[]
for op,reps in (('c',3),('d',12)):
    subprocess.run([sys.executable,root/'bench/diagnostics/frozen-encoder-pmu.py','--workspace',snap,'--matrix',loc,
        '--out',out/op,'--operation',op,'--file',a.file,'--level',str(a.level),'--repetitions',str(reps),
        '--frozen-profile',snap/'target/profiled/release/examples/profile','--codegen',origin/'codegen.json','--arm-cache'],check=True)
    b,z=rows(out/op/'per-byte.csv')
    for key,label in (('instructions_per_byte','Instructions'),('cycles_per_byte','CPU cycles'),('branch_misses_per_byte','Branch misses'),
                      ('l1d_refills_per_byte','L1 data cache refills'),('l2d_refills_per_byte','L2 data cache refills')):
        bv,zv=map(float,(b[key],z[key]))
        table.append(f"| {'Encode' if op=='c' else 'Decode'} | {label} | {bv:.3f} | {zv:.3f} | {zv/bv:.2f}× |")
(out/'README.md').write_text('\n'.join([f'# Level {a.level}, {a.file}: hardware counters on the combined build','',
    f'Four Cortex-A76 workers on each side. The [paired wall-time trials]({os.path.relpath(loc/trials,out)}) used a separate comparator from the same [native build]({os.path.relpath(origin/"codegen.json",out)}). Each counter run checked the paired archive size and original contents. Counters cover the measured operation only; each value is summed over all workers and divided by the number of uncompressed bytes processed.','',
    '| Operation | Event per input byte | Rust | zstd | zstd / Rust |','|---|---|---:|---:|---:|',*table,'',
    'Raw perf output and executable identities: [encode](c/manifest.json), [decode](d/manifest.json).','']))
