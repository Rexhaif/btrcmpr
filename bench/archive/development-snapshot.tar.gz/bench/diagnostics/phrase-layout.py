#!/usr/bin/env python3
"""Screen equal-size grammar jobs and compact length-specific spelling groups on the full input."""
import argparse
import csv
import os
from pathlib import Path
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
configs=[
    (24576,4096,32,1),(24576,4096,32,0),
    (12288,4096,32,1),(12288,4096,32,0),
    (6144,4096,32,1),(6144,4096,32,0),
    (3072,2048,32,0),(1536,1024,32,0),
    (6144,16384,48,0),(3072,8192,48,1),
]
with a.out.open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n')
    w.writerow(('job_KiB','phrase_cap','phrase_width','length_groups','bytes','encode_MBps','decode_MBps'))
    for kib,cap,width,groups in configs:
        env=dict(os.environ,BTR_GRAM_JOB_KIB=str(kib),BTR_GRAM_CAP=str(cap),
                 BTR_GRAM_WIDTH=str(width),BTR_GRAM_GROUPS=str(groups),BTR_LEVEL='22',
                 BTR_TRIAL_METHOD='lex-grammar',ZSTD_LEVEL='22',ZSTD_WIDE='1',WARMUP='0',DEC_ITERS='7')
        r=subprocess.run(['target/release/compare','4','1','ours','bench/data/enwik8'],
                         env=env,capture_output=True,text=True,check=True)
        result=next(csv.DictReader(r.stdout.splitlines()))
        if 'research method=lex-grammar' not in r.stderr:
            raise ValueError('research comparator required')
        w.writerow((kib,cap,width,groups,result['compressed_bytes'],result['compress_MBps'],result['decompress_MBps']))
