#!/usr/bin/env python3
"""Combine the measured offset writer with faster prefix and entropy settings at level one."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
from statistics import median
import subprocess
import tempfile
from decimal import Decimal
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

p=argparse.ArgumentParser(description=__doc__)
for key in ('workspace','bin-dir','out'):p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
base=root/'bench/results/presets/research';env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def run(cmd,e):return subprocess.run(cmd,cwd=snap,env=e,capture_output=True,text=True,check=True)
def writer(name,fields):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(fields.split());return f,w
def costs(rows,codec):
    seq=[r for r in rows if r['codec']==codec]
    if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or len({r['compressed_bytes'] for r in seq})!=1:raise ValueError('invalid trials')
    return (int(seq[0]['compressed_bytes']),*(median(Decimal(r[t]) for r in seq) for t in ['compress_seconds','decompress_seconds']))
spec=json.loads((base/'group-offsets/manifest.json').read_text())
(out/'manifest.json').write_text(json.dumps(dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,
    input_sha256=spec['input_sha256'],binaries={k:sha(ex/k) for k in ['compare','examples/candidate','examples/decode_loop']},
    source_sha256={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}),indent=2)+'\n')
sf,sw=writer('screen','file key batch_mode KiB fast_plan bytes encode_MBps decode_MBps')
pf,pw=writer('paired','file key batch_mode KiB fast_plan archive_sha256 codec bytes encode_MBps decode_MBps passes_at_5pct')
with sf,pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as t:
    arc=Path(t)/'sample.btr'
    for name,key,window in [('enwik8',5,256),('mozilla',10,128)]:
        src=root/'bench/data'/name;size=src.stat().st_size
        if sha(src)!=spec['input_sha256'][name]:raise ValueError('input changed')
        cc=[r for r in read(base/'group-offsets/counters.csv') if r['file']==name and r['commands_per_batch']!='0']
        pick={8:1,32:2,64:3}[int(min(cc,key=lambda r:float(r['cycles_per_byte']))['commands_per_batch'])]
        ref=costs(read(base/'group-offsets'/f'{name}-0.csv'),'zstd')
        choices=[(q,b,k,h) for q in (0,key) for b in (0,pick) for k in (window//2,window,window*2) for h in (0,1,3)]
        random.Random(120+key).shuffle(choices);pool=[]
        def cfg(case):
            q,b,k,h=case;job='BTR_ARCH_KIB' if name=='mozilla' else 'BTR_JOB_KIB'
            return dict(env,**{job:str(k)},BTR_GROUP_KEY=str(q),BTR_QUICK_KEY=str(q),BTR_GROUP_OFFSETS=str(b),BTR_FAST_COUNTS='2' if h else '0',BTR_FAST_PLAN=str(h))
        def trial(case,save=False):
            e=cfg(case)
            if save:e['BTR_CANDIDATE_FRAME']=str(arc)
            row=next(csv.DictReader(run([ex/'examples/candidate','4','1',src,'native'],e).stdout.splitlines()))
            return int(row['bytes']),float(row['encode_MBps']),float(row['decode_MBps'])
        # Use the unbatched alternate parser itself as the control.
        for q in [0,key]:
            for b in [0,pick]:
                trial((q,b,window,0),True)
                digest=sha(arc)
                if b==0:expected=digest
                elif digest!=expected:raise ValueError('batch changed prefix-selected archive')
        for case in choices:
            n,c,d=trial(case);sw.writerow((name,*case,n,c,d))
            if n<ref[0]:pool.append((d>=float(Decimal(size)/ref[2]/1_000_000)*.95,c,d,n,case))
        for rank,(_,_,_,nb,case) in enumerate(sorted(pool,reverse=True)[:2],1):
            trial(case,True);digest=sha(arc)
            run([ex/'examples/decode_loop',arc,'1','3',src],env)
            raw=out/f'{name}-{rank}.partial'
            run([ex/'compare','4','5','both',src],dict(cfg(case),BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            values=[costs(read(raw),k) for k in ['btrcmpr','zstd']]
            if arc.stat().st_size!=nb or values[0][0]!=nb or values[1][0]!=ref[0]:raise ValueError('archive changed')
            for k,(n,c,d) in zip(['btrcmpr','zstd'],values,strict=True):
                pw.writerow((name,*case,digest if k=='btrcmpr' else '',k,n,round(Decimal(size)/c/1_000_000,3),round(Decimal(size)/d/1_000_000,3),int(qualifies(values,DEFAULT_DECODE_LOSS_PCT))))
            raw.replace(raw.with_suffix('.csv'))
