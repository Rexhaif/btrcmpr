#!/usr/bin/env python3
"""Test lower-cost prefix tables and packing four bounded Huffman codes together."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--controls-only',action='store_true',help='only verify identical match choices and measure their instruction counts');a=p.parse_args()
root=Path(__file__).resolve().parents[2];ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True);env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
known={r['file']:r['verified_sha256'] for r in rows(root/'bench/results/presets/research/palette-write/checks.csv') if r['mode']=='0'}
subprocess.run(['cargo','build','--offline','--locked','--release','--all-features','--example','profile'],cwd=root,env=dict(env,CARGO_TARGET_DIR=str(ex.parent)),check=True)
(out/'manifest.json').write_text(json.dumps(dict(workers=4,binaries={b:sha(ex/b) for b in ('examples/candidate','examples/decode_loop','compare')},
    profile_sha256=sha(ex/'examples/profile'),implementation={b:sha(root/'src'/b) for b in ('quicktwo.rs','huff.rs','lz.rs','cachematch.rs')}),indent=2)+'\n')
def pmu(src,env,nb,out):
    events=['instructions:u','cycles:u','branches:u','branch-misses:u'];n=10
    with tempfile.TemporaryDirectory() as tmp:
        ctl,ack=(Path(tmp)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
        z=subprocess.run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',ex/'examples/profile','c','ours',src,'4',str(n)],
            env=dict(env,PERF_CTL=str(ctl),PERF_ACK=str(ack),BTR_LEVEL='1',LC_ALL='C'),text=True,capture_output=True,check=True)
    out.write_text(z.stderr)
    if f'archive_bytes={nb}\n' not in z.stderr:raise ValueError('PMU archive wrong')
    count={v[2]:float(v[0])/(src.stat().st_size*n) for line in z.stderr.splitlines() if len(v:=line.split(';'))>2 and v[2] in events}
    return [*(round(count[k],4) for k in events),float(re.search(r'([\d.]+) MB/s',z.stderr)[1])]
with (out/'cache-counters.csv').open('w') as f:csv.writer(f,lineterminator='\n').writerow(('file','prefix','archive_bytes','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','counter_MBps'))
with (out/'screen.csv').open('w',buffering=1) as sf,(out/'paired.csv').open('w',buffering=1) as rf,(out/'wire-checks.csv').open('w',buffering=1) as wf,tempfile.TemporaryDirectory(dir=root/'bench/local') as work:
    sw=csv.writer(sf,lineterminator='\n');sw.writerow(('file','phase','prefix','KiB','huff_fields','packed','single','bytes','encode_MBps','decode_MBps'))
    rw=csv.writer(rf,lineterminator='\n');rw.writerow(('file','prefix','KiB','huff_fields','packed','single','codec','bytes','encode_MBps','decode_MBps'))
    ww=csv.writer(wf,lineterminator='\n');ww.writerow(('file','check','bytes','archive_sha256'))
    for name,base,limit,rc,rd in [('enwik8',256,40669611,630,1640),('mozilla',128,19963738,740,1650)]:
        src=root/'bench/data'/name;arc=Path(work)/'sample.btr';job='BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB'
        def cfg(q,k,f,h,d):return dict(env,**{job:str(k)},BTR_QUICK_KEY=str(q if q<12 else 0),BTR_CACHE_MATCH=str(max(0,q-11)),BTR_HUFF_FIELDS=str(f),BTR_HUFF_PACK=str(h),BTR_HUFF_SINGLE=str(d),BTR_FAST_COUNTS='2' if f else '0')
        def trial(case,phase,write=False):
            key=cfg(*case)
            if write:key['BTR_CANDIDATE_FRAME']=str(arc)
            z=subprocess.run([ex/'examples/candidate','4','1',src,'native'],env=key,capture_output=True,text=True,check=True)
            r=next(csv.DictReader(z.stdout.splitlines()));n=int(r['bytes']);c=float(r['encode_MBps']);d=float(r['decode_MBps'])
            sw.writerow((name,phase,*case,n,c,d));return (min(c/rc,d/rd),c,d,n,case)
        for case in [(q,base,0,0,0) for q in (0,1,12,20,28)]:
            row=trial(case,'identity',True);digest=sha(arc);ww.writerow((name,f'prefix {case[0]}',row[3],digest))
            if digest!=known[name]:raise ValueError('control match table changed native archive')
            if case[0] in (0,12,20,28):
                ctr=pmu(src,cfg(*case),row[3],out/f'{name}-prefix-{case[0]}-perf.txt')
                with (out/'cache-counters.csv').open('a') as f:csv.writer(f,lineterminator='\n').writerow((name,case[0],row[3],*ctr))
        if a.controls_only:continue
        hashes=[]
        for fast in (0,1):
            row=trial((1,base,7,fast,fast),'identity',True);hashes.append(sha(arc));ww.writerow((name,f'Huffman pack {fast}',row[3],hashes[-1]))
            subprocess.run([ex/'examples/decode_loop',arc,'1','3',src],env=dict(env,BTR_HUFF_SINGLE=str(1-fast)),check=True)
        if hashes[0]!=hashes[1]:raise ValueError('new Huffman writer changed archive')
        cases=[(q,kib,0,0,0) for q in range(1,36) for kib in (base//2,base,base*2)];random.Random(1142).shuffle(cases)
        options=[trial(case,'prefix') for case in cases]
        near=[r for r in options if r[3]<1.04*limit];chosen={(1,base)}
        for row in sorted(near,reverse=True)[:2]+sorted(options,key=lambda r:r[3])[:1]:chosen.add(row[4][:2])
        more=[(q,kib,f,1,d) for q,kib in sorted(chosen) for f in (1,2,3,4,5,6,7) for d in (0,1)]
        random.Random(983).shuffle(more);options.extend(trial(c,'fields') for c in more)
        eligible=[r for r in options if r[3]<limit]
        if not eligible:continue
        _,c,d,n,case=max(eligible);trial(case,'selected',True)
        if arc.stat().st_size!=n:raise ValueError('changed selected archive')
        subprocess.run([ex/'examples/decode_loop',arc,'1','3',src],env=cfg(*case),check=True)
        t=out/f'{name}.partial'
        subprocess.run([ex/'compare','4','5','both',src],env=dict(cfg(*case),BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(t)),check=True)
        data=rows(t)
        for codec,b in [('btrcmpr',n),('zstd',limit)]:
            seq=[r for r in data if r['codec']==codec]
            if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=b for r in seq):raise ValueError('wrong paired data')
            rw.writerow((name,*case,codec,b,*(round(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in seq),3) for k in ('compress_seconds','decompress_seconds'))))
        t.replace(t.with_suffix('.csv'))
