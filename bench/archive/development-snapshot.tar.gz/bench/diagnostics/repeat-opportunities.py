#!/usr/bin/env python3
"""Replay the native enwik8 level-1 parser to count repeats available before its next match."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parents[2];a.out.mkdir(parents=True,exist_ok=True)
base=root/'bench/results/presets/research';src=root/'bench/data/enwik8';arc=root/'bench/local/levels/lanes/palette-write-enwik8.btr'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
with (base/'palette-write/checks.csv').open() as f:want=next(x['verified_sha256'] for x in csv.DictReader(f) if x['file']=='enwik8' and x['mode']=='0')
if sha(arc)!=want or sha(src)!=json.loads((base/'prefix-probes/manifest.json').read_text())['input_sha256']['enwik8']:raise ValueError('input identities changed')
with arc.open('rb') as f:magic,size,block=struct.unpack('<8sQI',f.read(20))
if magic!=b'BTRCMP01' or size!=src.stat().st_size or block>>31:raise ValueError('expected native linear enwik8 frame')
lz=(root/'src/lz.rs').read_text();quick=(root/'src/quicktwo.rs').read_text()
# Compile the actual generic match walker, its exact hash functions, and the
# native prefix comparison; the callback gathers counts instead of emitting.
parts=[lz[lz.index('pub(crate) fn word'):lz.index('fn lenout(')],quick[quick.index('fn keys<'):quick.index('pub(super) fn encode(')],quick[quick.index('fn walk_key<'):quick.index('#[cfg(feature = "research")]\npub(super) fn alternate')]]
body=r'''
fn main(){
 let args:Vec<_>=std::env::args().collect();let data=std::fs::read(&args[1]).unwrap();let block:usize=args[2].parse().unwrap();
 let(mut commands,mut copied)=(0u64,0u64);let mut totals=[[[[0u64;5];3];3];3];
 for s in data.chunks(block){let mut rep=[1,4,8];
   walk_key::<5,15,2,false>(s,|a,i,n,off|{
     commands+=1;copied+=n as u64;
     // Precompute, once per position, the exact longest prefix for each
     // previous distance. 0..7 include early starts ending in a literal gap.
     let mut lengths=[[0usize;8];3];
     for (r,&dist) in rep.iter().enumerate(){for j in 0..8{let at=a+j;if at>i||at<dist||at+4>s.len(){continue}
       if s[at..at+4]==s[at-dist..at-dist+4]{lengths[r][j]=4+common(s,at+4-dist,at+4);}}}
     for (rr,&reach) in [1usize,2,3].iter().enumerate(){for (ww,&lags) in [2usize,4,8].iter().enumerate(){for (mm,&min) in [4usize,6,8].iter().enumerate(){
        let mut any=false;let mut dominate=false;let mut exact=false;let mut best_end=0usize;
        for (r,len) in lengths[..reach].iter().enumerate(){for (j,&k) in len[..lags].iter().enumerate(){if k>=min{any=true;let end=a+j+k;
           dominate|=end>=i+n;exact|=a+j==i && rep[r]==off;best_end=best_end.max(end);}}}
        let row=&mut totals[rr][ww][mm];row[0]+=any as u64;row[1]+=dominate as u64;row[2]+=exact as u64;
        if dominate{row[3]+=n as u64;row[4]+=(i-a+1)as u64;} let _=best_end;
     }}}
     rep=[off,rep[0],rep[1]];
   });
 }
 assert_eq!((commands,copied),(10557552,81785126));
 println!("prior_distances,lookahead_positions,min_match,commands,covered_bytes,any_early_match,reach_native_end,identical_start_and_distance,original_copy_bytes_if_reaching_end,literal_probes_if_reaching_end");
 for (r,rs) in totals.iter().enumerate(){for(w,ws) in rs.iter().enumerate(){for(m,t) in ws.iter().enumerate(){
   println!("{},{},{},{commands},{copied},{},{},{},{},{}",r+1,[2,4,8][w],[4,6,8][m],t[0],t[1],t[2],t[3],t[4]);
 }}}
}
'''
with tempfile.TemporaryDirectory() as t:
    t=Path(t);prog=t/'pilot.rs';prog.write_text('#![allow(dead_code)]\n'+'\n'.join(parts)+body);exe=t/'pilot'
    subprocess.run(['rustc','--edition','2024','-C','opt-level=3','-C','target-cpu=native',prog,'-o',exe],check=True)
    raw=a.out/'counts.partial'
    with raw.open('w') as f:subprocess.run([exe,src,str(block)],stdout=f,check=True)
    raw.replace(a.out/'counts.csv');spec=dict(input_sha256=sha(src),archive_sha256=want,job_bytes=block,quicktwo_sha256=sha(root/'src/quicktwo.rs'),lz_sha256=sha(root/'src/lz.rs'),diagnostic_source_sha256=sha(prog),jobs=(size+block-1)//block)
(a.out/'manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
with (a.out/'counts.csv').open() as f:counts=list(csv.DictReader(f))
def row(r,w,m):return next(x for x in counts if tuple(map(int,(x['prior_distances'],x['lookahead_positions'],x['min_match'])))==(r,w,m))
lines=['# Can recent copy distances bypass the level-one hash lookup?', '',
       'This diagnostic replays the recorded five-byte parser on every enwik8 block. For each native command it checks recent distances at the first few positions following the preceding match, stopping at the native match start. A hit is counted as a possible replacement only if it reaches at least the original match end. This is a replay of fixed commands, not an alternate encoder or a timing benchmark.', '',
       '| Distances checked | Positions checked | Minimum length | Commands reached or exceeded | Share of native commands |', '|---:|---:|---:|---:|---:|']
for r,w,m in [(1,2,4),(1,8,4),(3,8,4),(3,8,8)]:
    x=row(r,w,m);a1=int(x['reach_native_end']);total=int(x['commands']);lines.append(f'| {r} | {w} | {m} | {a1:,} / {total:,} | {100*a1/total:.2f}% |')
lines+=['','Even checking three distances at up to eight positions reached the old match end for fewer than two percent of commands. The pilot cannot price a different downstream parse; it rules out assuming that most of this parser’s hash lookups can be replaced with cheap recent-distance hits. [All 27 counts](counts.csv), [corpus, archive, and source hashes](manifest.json).','']
(a.out/'README.md').write_text('\n'.join(lines))
