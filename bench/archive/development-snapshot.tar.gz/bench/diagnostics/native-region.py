#!/usr/bin/env python3
"""Confirm the level-6 inverse and level-17 job sizes using one production source without flags."""
import argparse
import csv
from decimal import Decimal
import json
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();base=root/'bench/results/presets';out=base/'native-object-6-17'
if not snap.is_relative_to(root/'bench/local'):raise ValueError('requires a frozen source tree')
out.mkdir(exist_ok=True);env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};env['CARGO_TARGET_DIR']=str(snap/'target')
def read(path):
    with path.open() as f:return list(csv.DictReader(f))
def invoke(cmd,log):
    return subprocess.run(cmd,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT)
control=next(r for r in read(base/'research/object-windows/fixed.csv') if (r['level'],r['other_KiB'],r['records_KiB'],r['code_KiB'],r['bank_policy'])==('17','512','128','352','2'))
previous=next(r for r in read(base/'native-six-after-ahead/cli.csv') if r['input']=='mozilla' and r['level']=='6')
known={6:(previous['archive_sha256'],previous['cli_bytes']),17:(control['archive_sha256'],control['bytes'])}
with (out/'run.log').open('a') as log:
    for check in [['cargo','test','--locked','--offline','--all-features'],['cargo','clippy','--all-features','--all-targets','--locked','--offline','--','-D','warnings'],['cargo','clippy','--no-default-features','--lib','--locked','--offline','--','-D','warnings']]:
        invoke(check,log).check_returncode()
    cmd=[sys.executable,'scripts/preset-matrix.py','--levels','6,17','--files','mozilla','--threads','4','--rounds','5','--decodes','7','--out',out]
    if (out/'manifest.json').is_file():cmd.append('--resume')
    r=invoke(cmd,log)
    if r.returncode not in (0,1) or not (out/'matrix.csv').is_file():raise ValueError('incomplete paired benchmark')
    for tool,output in [('preset-cli','cli.csv'),('preset-rates','rates.csv')]:
        invoke([sys.executable,snap/'bench/diagnostics'/f'{tool}.py',out/'matrix.csv','--out',out/output],log).check_returncode()
clis={int(r['level']):r for r in read(out/'cli.csv')};allrates={int(r['level']):r for r in read(out/'rates.csv')};statuses={int(r['level']):r for r in read(out/'matrix-decode-tolerance.csv')}
if set(clis)!=set(allrates) or set(allrates)!=set(statuses) or set(clis)!={6,17}:raise ValueError('missing production comparison')
spec=json.loads((out/'manifest.json').read_text())
text=['# Native levels 6 and 17 on Mozilla','',
      '| Level | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---:|---:|---:|---:|---|']
for lv in (6,17):
    check=clis[lv];rates=allrates[lv];status=statuses[lv]
    if (check['archive_sha256'],check['cli_bytes'])!=known[lv] or check['restored_identical']!='1' or check['cli_bytes']!=rates['btr_bytes']:raise ValueError('production did not reproduce the selected archive')
    if Decimal(status['allow_decode_loss_pct'])!=5:raise ValueError('wrong decode limit')
    text.append(f"| [{lv}](level-{lv:02}-mozilla.csv) | {int(rates['btr_bytes']):,} / {int(rates['zstd_bytes']):,} | {rates['btr_encode_MBps']} / {rates['zstd_encode_MBps']} | {rates['btr_decode_MBps']} / {rates['zstd_decode_MBps']} | "+('Yes' if status['all_pass_with_allowance']=='1' else 'No')+' |')
text+=['','Level 6 still emits exactly its earlier native archive. Small instruction blocks with unconditional delta banks now restore up to 128 instructions together without software prefetch. Level 17 changes the encoder: plain sections use 512 KiB jobs, records 128 KiB and code 352 KiB. An instruction bank is delta-coded only when its estimated gain clears its cost threshold. These choices use section structure, not a filename or corpus identifier.','',
       f"The [standalone CLI](cli.csv), built without libzstd, restored every byte and reproduced both expected archive SHA-256 digests. The five alternating warmed pairs used four workers for each codec, seven decodes per round, and one independent quarter-file frame per zstd worker. The [manifest](manifest.json) identifies frozen comparator `{spec['benchmark_sha256']}`. With this executable only the results in the [single-build audit](../decode-tolerance-build-cells.csv) count.",'']
(out/'README.md').write_text('\n'.join(text))
for script,args in [('preset-audit',['--out',base]),('preset-coverage',['--out',base/'coverage.csv','--update-overview'])]:
    subprocess.run([sys.executable,root/'bench/diagnostics'/f'{script}.py',*args],cwd=root,check=True)
