#!/usr/bin/env python3
"""Screen grammar/byte worker splits on the full enwik8; never count a screening result as a pass."""
import argparse,csv,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
exe=root/'target/release/compare'
configs=[
    (1,170,10,32768),(1,180,11,32768),(1,180,12,32768),(1,165,9,32768),
    (2,365,8,12288),(2,360,7,12288),(2,385,9,16384),(2,370,8,32768),
    (2,375,10,32768),(3,665,8,16384),
]
with a.out.open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('grammar_workers','grammar_permille','byte_preset','byte_chunk_KiB','archive_bytes','encode_MBps','decode_MBps'))
    for jobs,share,level,kib in configs:
        env=dict(os.environ,BTR_LEVEL='14',ZSTD_LEVEL='14',ZSTD_WIDE='1',WARMUP='0',DEC_ITERS='6',BTR_TRIAL_METHOD='mix',
                 BTR_GRAM_CAP='4096',BTR_GRAM_WIDTH='32',BTR_MIX_JOBS=str(jobs),BTR_MIX_SHARE=str(share),
                 BTR_MIX_PLAIN=str(level),BTR_MIX_KIB=str(kib))
        r=subprocess.run([exe,'4','1','ours','bench/data/enwik8'],env=env,capture_output=True,text=True)
        if r.returncode:raise RuntimeError(r.stdout+r.stderr)
        row=next(csv.DictReader(r.stdout.splitlines()))
        w.writerow((jobs,share,level,kib,row['compressed_bytes'],row['compress_MBps'],row['decompress_MBps']))
