#!/usr/bin/env python3
"""Measure retaining streams, the 64 KiB match table, or both between Mozilla level-1 jobs."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import shutil
from statistics import median
import subprocess
import sys
import tempfile
from level_one_lab import read,sha

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepare',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2];origin=root/'bench/results/presets/native-combined-1'
stamp=json.loads((origin/'codegen.json').read_text());meta=json.loads((origin/'manifest.json').read_text())
frozen=root/'bench/local/levels/lanes/combined-presets';lab=frozen.parent/'object-scratch';out=origin.parent/'research/object-scratch'
series=origin.parent/'integrated'/stamp['comparator'];gold,=(r for r in read(series/'verified-cells.csv') if r['level']=='1' and r['file']=='mozilla')
source=root/'bench/data/mozilla';raw=source.stat().st_size;target=lab/'target';model=frozen/'target/profiled'/('native-'+stamp['profile_data_sha256']+'.profdata')
if sha(source)!=meta['input_sha256']['mozilla'] or any(sha(frozen/k)!=v for k,v in meta['source_sha256'].items()):raise ValueError('frozen sources or input differ')
lab.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
for f in ('Cargo.toml','Cargo.lock'):shutil.copy2(frozen/f,lab/f)
for d in ('src','examples','.cargo','bench/support'):shutil.copytree(frozen/d,lab/d,dirs_exist_ok=True)
def once(s,old,new):
    if s.count(old)!=1:raise ValueError('source anchor changed: '+old[:65])
    return s.replace(old,new)
r=lab/'src/lib.rs';r.write_text(r.read_text()+'''\npub(crate) fn object_scratch_mode() -> u8 {
    static MODE: std::sync::OnceLock<u8> = std::sync::OnceLock::new();
    *MODE.get_or_init(|| std::env::var("BTR_LAB_OBJECT_SCRATCH").unwrap_or_default().parse().unwrap_or(0))
}\n''')
r=lab/'src/lz.rs';s=r.read_text();lo=s.index('    fn finish_coded<const PACK: u8>(');hi=s.index('\n}\npub fn encode',lo)
borrowed=once(once(s[lo:hi],'fn finish_coded<','fn finish_scratch<'),'        mut self,','        &mut self,');r.write_text(s[:hi]+'\n'+borrowed+s[hi:])
r=lab/'src/emitoffset.rs';r.write_text(once(r.read_text(),'pub(super) fn archive(s: &[u8]) -> Vec<u8> {\n    grouped::<35, 0>(s, true, 10, (2, 0))\n}',(root/'bench/diagnostics/experiments/object-scratch.rs').read_text().rstrip()))
r=lab/'src/pairhead.rs';s=once(r.read_text(),'fn parse<','thread_local! { static OBJECT_TABLE: std::cell::RefCell<Vec<u32>> = const { std::cell::RefCell::new(Vec::new()) }; }\nfn parse<')
s=once(s,'    let mut t = vec![0u32; 1 << B];','''    let reuse = P == 7 && B == 14 && crate::object_scratch_mode() & 2 != 0;
    let mut t = if reuse {
        let mut buf = OBJECT_TABLE.with_borrow_mut(std::mem::take);
        if buf.len() == 1 << B { buf.fill(0); } else { buf.resize(1 << B, 0); }
        buf
    } else { vec![0u32; 1 << B] };''');r.write_text(once(s,'    anchor\n}', '    if reuse { OBJECT_TABLE.with_borrow_mut(|buf| *buf = t); }\n    anchor\n}'))
if a.prepare:raise SystemExit()
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','ZSTD_','PROFILE_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS','BTRCMPR_NATIVE_SCAN')};e.update(LC_ALL='C',BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',DEC_ITERS='7',WARMUP='1')
perf=root/'bench/local/perf';exe=target/'release';restore=root/'bench/local/preset-binaries'/('cli-'+stamp['cli'])
if sha(restore)!=stamp['cli']:raise ValueError('wrong production decoder')
for codec in ('ours','zstd'):
    z=subprocess.run([root/'scripts/perf-stat.sh','--selected','c',codec,source,'4','8'],env=dict(e,PERF=str(perf)),cwd=root,text=True,capture_output=True,check=True)
    (out/f'selected-{codec}-stat.txt').write_text(z.stdout+z.stderr)
    if 'archive_bytes='+gold['btr_bytes' if codec=='ours' else 'zstd_bytes']+'\n' not in z.stderr:raise ValueError('public counter command produced wrong size')
native_profile=root/'bench/results/profiles/combined-01-mozilla'
subprocess.run([sys.executable,root/'bench/diagnostics/profile-release-cell.py','--workspace',frozen,'--origin',origin,'--out',native_profile,'--level','1','--file','mozilla'],env=e,check=True)
subprocess.run([sys.executable,root/'bench/diagnostics/sample-search.py','--level','1','--file','mozilla','--event','cycles','--repetitions','8','--period','280001','--out',lab/'cycle-samples','--zstd-debug',root/'bench/local/zstd.debug','--exe',frozen/'target/profiled/release/examples/profile','--verified-cell',native_profile/'c','--summary',native_profile/'encode-cycles.txt'],env=dict(e,PERF=str(perf)),check=True)
with (out/'build.log').open('w') as f: subprocess.run([sys.executable,root/'scripts/build-profiled.py','--workspace',lab,'--target-dir',target,'--profile-data',model,'--profile-sha256',stamp['profile_data_sha256'],'--selected'],env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
lib=Path(re.search(r'libzstd\.so\.\d+ => (\S+)',subprocess.check_output(['ldd',exe/'compare'],text=True))[1]);assert sha(lib)==meta['zstd_library_sha256']
def write(name,columns,rows):
    with (out/name).open('w') as f:
        w=csv.writer(f,lineterminator='\n');w.writerow(columns);w.writerows(rows)
names=['Fresh allocations','Reuse command streams','Reuse match table','Reuse streams and table'];identity=[]
with tempfile.TemporaryDirectory(dir=lab) as td:
    archive,back=(Path(td)/n for n in ('archive','restore'))
    for mode in range(4):
        subprocess.run([exe/'btrcmpr','c','-1',source,archive,'4'],env=dict(e,BTR_LAB_OBJECT_SCRATCH=str(mode)),capture_output=True,check=True)
        if sha(archive)!=gold['archive_sha256'] or archive.stat().st_size!=int(gold['btr_bytes']):raise ValueError('storage reuse changed the archive')
        subprocess.run([restore,'d',archive,back,'3'],capture_output=True,check=True)
        if sha(back)!=sha(source):raise ValueError('wrong roundtrip')
        identity.append((mode,archive.stat().st_size,sha(archive),sha(back)))
write('wire.csv',['mode','archive_bytes','archive_sha256','restored_sha256'],identity)
events=('instructions:u','cycles:u','branches:u','branch-misses:u','r03:u','r17:u');pmu=[];order=[0,2,1,3,3,1,2,0];reps=6
for i,mode in enumerate(order):
    with tempfile.TemporaryDirectory() as td:
        ctl,ack=(Path(td)/n for n in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
        z=subprocess.run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe/'examples/profile','c','ours',source,'4',str(reps)],env=dict(e,BTR_LAB_OBJECT_SCRATCH=str(mode),PERF_CTL=str(ctl),PERF_ACK=str(ack)),text=True,capture_output=True,check=True)
    (out/f'counter-{i}.txt').write_text(z.stderr)
    if 'archive_bytes='+gold['btr_bytes']+'\n' not in z.stderr:raise ValueError('wrong PMU archive')
    counts={v[2]:int(v[0])/(raw*reps) for line in z.stderr.splitlines() if len(v:=line.split(';'))>2 and v[2] in events};pmu.append([i,mode,*(counts[k] for k in events)])
write('counters.csv',['order','mode','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','l1d_refills_per_byte','l2d_refills_per_byte'],pmu)
def pair(mode,rounds,label):
    path=out/f'{label}-mode-{mode}.csv';partial=path.with_suffix('.partial');env=dict(e,BTR_LAB_OBJECT_SCRATCH=str(mode),TRIALS_CSV=str(partial))
    z=subprocess.run([exe/'compare','4',str(rounds),'both',source],env=env,text=True,capture_output=True,check=True);(out/f'{label}-mode-{mode}.log').write_text(z.stdout+z.stderr)
    rs=read(partial);values=[]
    for codec,size in [('btrcmpr',gold['btr_bytes']),('zstd',gold['zstd_bytes'])]:
        sub=[r for r in rs if r['codec']==codec]
        if len(sub)!=rounds or {int(r['round']) for r in sub}!=set(range(1,rounds+1)) or any(r['compressed_bytes']!=size or int(r['raw_bytes'])!=raw for r in sub):raise ValueError('incomplete or changed paired result')
        if any(int(r['order'])!=(int(r['round'])%2 if codec=='btrcmpr' else (int(r['round'])+1)%2) for r in sub):raise ValueError('wrong sequence')
        values.extend(raw/1e6/median(float(r[k]) for r in sub) for k in ('compress_seconds','decompress_seconds'))
    partial.replace(path);return values
rates={mode:pair(mode,5,'screen') for mode in (0,2,1,3)};val=lambda m,j:median(r[j] for r in pmu if r[1]==m)
eligible=[m for m in (1,2,3) if val(m,3)<val(0,3)*.98 and rates[m][0]/rates[m][2]>rates[0][0]/rates[0][2]*1.02]
long={}
if eligible:
    m=max(eligible,key=lambda m:rates[m][0]/rates[m][2]);long={n:pair(n,15,'long') for n in (m,0)}
write('screen.csv',['mode','name','instructions_per_byte','cycles_per_byte','encode_MBps','decode_MBps','zstd_encode_MBps','zstd_decode_MBps'],[(m,names[m],val(m,2),val(m,3),*rates[m]) for m in range(4)])
rows=['| '+names[m]+' | '+' | '.join(f'{x:.2f}' for x in (val(m,2),val(m,3),*rates[m][:1],rates[m][2],100*(rates[m][0]/rates[m][2]-1)))+'% |' for m in range(4)]
(out/'README.md').write_text('\n'.join(['# Scratch buffer reuse on Mozilla at level 1','','The selected codec emits 215 ordinary LZ blocks and 76 fixed-record blocks on Mozilla. Only the ordinary LZ path changes here. A worker can keep seven command buffers, the zeroed 64 KiB match table, or both until its next block. The four variants used one experimental executable, and each [reproduced the frozen archive](wire.csv) and restored the input with the independent release decoder.','','| Candidate | Instructions/B | Cycles/B | Encode MB/s | Matched zstd MB/s | Encode vs zstd |','|---|---:|---:|---:|---:|---:|',*rows,'','[All rates, including decode](screen.csv). Four workers per side. Each screen used five alternating pairs after warmup, seven decodes per measurement. The perf medians use two runs per mode, six full-file encodes each, in forward then reverse order. Absolute timing and compiler layout can differ from the release.','','The prespecified follow-up requires at least 2% fewer cycles and 2% higher zstd-relative encode throughput than the experimental control. '+('Long runs (15 pairs; encode MB/s, Rust vs zstd): '+', '.join(f'{names[n]} {v[0]:.2f} vs {v[2]:.2f}' for n,v in long.items())+'.' if long else 'No candidate cleared both thresholds.'),'']))
if long:
    table=['', '| 15-pair confirmation | Ratio, Rust / zstd | Encode MB/s, Rust / zstd | Encode pairs won | Decode MB/s, Rust / zstd | Decode pairs within 5% |',
           '|---|---:|---:|---:|---:|---:|']
    for m in (0,*[k for k in long if k]):
        raw_pairs=read(out/f'long-mode-{m}.csv')
        pairs=[{r['codec']:r for r in raw_pairs if int(r['round'])==i} for i in range(1,16)]
        b,d,z,zd=long[m]; won=sum(float(x['zstd']['compress_seconds'])>float(x['btrcmpr']['compress_seconds']) for x in pairs)
        allowed=sum(float(x['zstd']['decompress_seconds'])>=.95*float(x['btrcmpr']['decompress_seconds']) for x in pairs)
        table.append(f"| [{names[m]}](long-mode-{m}.csv) | {gold['btr_ratio']} / {gold['zstd_ratio']} | {b:.2f} / {z:.2f} | {won}/15 | {d:.2f} / {zd:.2f} | {allowed}/15 |")
    with (out/'README.md').open('a') as f:f.write('\n'.join(table)+'\n')
(out/'manifest.json').write_text(json.dumps(dict(input=sha(source),original_comparator=stamp['comparator'],cli=sha(exe/'btrcmpr'),comparator=sha(exe/'compare'),profile=sha(exe/'examples/profile'),libzstd=sha(lib),decoder=sha(restore),training_profile=sha(model),counter_order=order,timing_order=list(rates),followup_modes=list(long),source_sha256={k:sha(lab/k) for k in ('src/lib.rs','src/lz.rs','src/emitoffset.rs','src/pairhead.rs')}),indent=2)+'\n')
