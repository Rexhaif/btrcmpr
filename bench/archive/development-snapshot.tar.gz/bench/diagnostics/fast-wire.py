#!/usr/bin/env python3
"""Count the separate command, distance and literal fields in the verified level-1 frames."""
import argparse
from collections import Counter
import csv
import hashlib
from pathlib import Path
import struct

p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--frames',type=Path);g.add_argument('--single',type=Path);p.add_argument('--name',default='candidate');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];a.out.mkdir(exist_ok=True,parents=True)
def word(buf,pos):return struct.unpack_from('<I',buf,pos)[0]
def skip(buf,start):
    n=word(buf,start);mode=buf[start+4];p=start+5
    if mode==0:p+=n
    elif mode==1:p+=1
    elif mode==2:
        freq=sum(b.bit_count() for b in buf[p:p+32]);p+=32+freq*2+16;p+=4+2*word(buf,p)
    elif mode==4:
        p+=128;step=(n+3)//4
        for _ in range(0,n,step):bits=word(buf,p);p+=4+(bits+7)//8+4
    elif mode==5:
        k=buf[p];syms=buf[p+1]+1;p+=2+(1<<k)+syms+(n*k+7)//8+16
        bits=word(buf,p);p+=4+(bits+7)//8+17
    elif mode==60:
        k=buf[p];syms=buf[p+1]+1;p+=2+(1<<k)+syms+(n*k+7)//8+16
        size=word(buf,p);p+=4+32+size+8
    elif mode in (22,23):
        classes=buf[p];width=buf[p+1];p+=2+classes+256+(classes+1)*width
        inner,_,p=skip(buf,p)
        if inner!=n:raise ValueError('incorrect rank stream length')
    else:raise ValueError(f'Unexpected field {mode}')
    if p>len(buf):raise ValueError('long field')
    return n,mode,p
if a.frames:
    with (root/'bench/results/presets/research/palette-write/checks.csv').open() as f:
        frames={r['file']:(a.frames/f"palette-write-{r['file']}.btr",r['verified_sha256']) for r in csv.DictReader(f) if r['mode']=='0'}
else:frames={a.name:(a.single,None)}
with (a.out/'wire.csv').open('w') as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('file','field','uncoded_bytes','wire_bytes','raw_blocks','constant_blocks','rans_blocks','huffman_blocks','palette_blocks','stack_palette_blocks'))
    for name,(archive,wanted) in frames.items():
        data=archive.read_bytes()
        if (wanted and hashlib.sha256(data).hexdigest()!=wanted) or data[:8]!=b'BTRCMP01':raise ValueError('unexpected archive')
        p=20
        def var():
            global p
            x=0
            for i in range(0,64,7):
                b=data[p];p+=1;x|=(b&127)<<i
                if b<128:return x
            raise ValueError('long integer')
        if word(data,16)>>31:
            jobs=word(data,p);p+=4;sizes=[var() for _ in range(jobs)]
            pieces=word(data,p);p+=4
            for _ in range(pieces*2):var()
        stat={};modes={}
        def add(tag,raw,wire,mode):
            r=stat.setdefault(tag,[0,0]);r[0]+=raw;r[1]+=wire;modes.setdefault(tag,Counter())[mode]+=1
        add('frame index',0,p,0)
        while p<len(data):
            n=word(data,p);start=p+4;p=start+n;tag=data[start]
            if tag not in (1,13,16,17,59):
                add(f'other block tag {tag}',0,n+4,tag);continue
            add('block headers',0,5+int(tag==59),0);q=start+1+int(tag==59)
            labels=['commands','length escapes','literals','distance low','distance middle','distance high'] if tag==59 else ['commands','distance selectors','length escapes','literals','distance low','distance middle']
            if tag in (13,17):labels.append('distance high')
            for label in labels:
                raw,kind,end=skip(data,q);add(label,raw,end-q,kind);q=end
            if q!=p:raise ValueError('incomplete block')
        if sum(r[1] for r in stat.values())!=len(data):raise ValueError('incomplete frame')
        for k,v in stat.items():wr.writerow((name,k,*v,*(modes[k][j] for j in (0,1,2,4,5,60))))
