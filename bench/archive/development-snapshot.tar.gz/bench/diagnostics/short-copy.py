#!/usr/bin/env python3
"""Compare copy kernels on fixed archives, then measure the finalists with ARM counters."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--bin-dir',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
a=p.parse_args();root=Path(__file__).resolve().parents[2];folder=a.out.resolve();folder.mkdir(exist_ok=True,parents=True)
exe=a.bin_dir.resolve();base=root/'bench/results/presets';frames=root/'bench/local/levels/lanes/ahead-frames'
perf=Path(os.getenv('PERF',root/'bench/local/perf')).resolve()
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,e):return subprocess.run(cmd,env=e,text=True,capture_output=True,check=True)
def rate(log):return float(re.search(r'([\d.]+) MB/s',log)[1])
checks=rows(base/'research/decode-ahead/checks.csv')
ids={str(p.relative_to(root)):sha(p) for p in [root/'src/copyshort.rs',root/'src/lz.rs',root/'examples/decode_loop.rs',root/'bench/support/perf.rs']}
ident={'inputs':checks,'implementation':ids,'executables':{b:sha(exe/b) for b in ('compare','examples/decode_loop')},
       'workers':4,'perf_version':run([perf,'version'],env).stdout.strip()}
(folder/'manifest.json').write_text(json.dumps(ident,indent=2)+'\n')
reference={(int(r['level']),r['file']):int(r['zstd_bytes']) for r in rows(base/'zstd-sizes.csv')}
selected=[]
with (folder/'trials.csv').open('w',buffering=1) as tf,(folder/'screen.csv').open('w',buffering=1) as sf,(folder/'counters.csv').open('w',buffering=1) as cf:
    tw=csv.writer(tf,lineterminator='\n');tw.writerow(('level','file','round','mode','decode_MBps'))
    sw=csv.writer(sf,lineterminator='\n');sw.writerow(('level','file','best_mode','native_MBps','best_MBps','relative'))
    cw=csv.writer(cf,lineterminator='\n');cw.writerow(('level','file','mode','repetitions','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','counter_MBps'))
    verified=set()
    for item in checks:
        lv=int(item['level']);name=item['file'];src=root/'bench/data'/name
        arc=frames/f'{name}-{lv}.btr';size=src.stat().st_size
        if name not in verified and sha(src)!=item['source_sha256']:raise ValueError('wrong reference input')
        verified.add(name)
        if arc.stat().st_size!=int(item['archive_bytes']) or sha(arc)!=item['archive_sha256']:raise ValueError('wrong native archive')
        decoder=[exe/'examples/decode_loop',arc]
        data={m:[] for m in range(9)};rng=random.Random(lv*13+44)
        for r in range(3):
            order=list(data);rng.shuffle(order)
            for mode in order:
                z=run([*decoder,'6','4',src],dict(env,BTR_SHORT_COPY=str(mode)))
                v=rate(z.stderr);data[mode].append(v);tw.writerow((lv,name,r+1,mode,v))
        med={m:statistics.median(v) for m,v in data.items()};best=max(med,key=med.get)
        sw.writerow((lv,name,best,med[0],med[best],round(med[best]/med[0],5)))
        events=['instructions:u','cycles:u','branches:u','branch-misses:u'];reps=16
        # A separate counter run for each implementation; enable only after
        # a verified warmup and disable before comparing the timed output.
        for mode in dict.fromkeys([0,best]):
            with tempfile.TemporaryDirectory() as tmp:
                ctl,ack=(Path(tmp)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                key=dict(env,PERF_CTL=str(ctl),PERF_ACK=str(ack),BTR_SHORT_COPY=str(mode))
                z=run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',*decoder,str(reps),'4',src],key)
            (folder/f'{name}-{lv}-mode{mode}.txt').write_text(z.stderr)
            counts={l[2]:float(l[0])/(size*reps) for line in z.stderr.splitlines() if len(l:=line.split(';'))>2 and l[2] in events}
            cw.writerow((lv,name,mode,reps,*(round(counts[k],5) for k in events),rate(z.stderr)))
        if lv!=1 and best and med[best]>1.015*med[0]:selected.append((lv,name,best,int(item['archive_bytes'])))
with (folder/'paired.csv').open('w',buffering=1) as rf:
    w=csv.writer(rf,lineterminator='\n');w.writerow(('level','file','mode','codec','archive_bytes','encode_MBps','decode_MBps'))
    for lv,name,mode,n in selected:
        src=root/'bench/data'/name;t=folder/f'{name}-{lv}.partial'
        run([exe/'compare','4','5','both',src],dict(env,BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),BTR_SHORT_COPY=str(mode),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(t)))
        data=rows(t)
        for codec,nb in [('btrcmpr',n),('zstd',reference[lv,name])]:
            s=[r for r in data if r['codec']==codec]
            if len(s)!=5 or {int(x['round']) for x in s}!=set(range(1,6)) or any(int(x['compressed_bytes'])!=nb for x in s):raise ValueError('wrong paired measurement or archive')
            w.writerow((lv,name,mode,codec,nb,*(round(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in s),3) for k in ('compress_seconds','decompress_seconds'))))
        t.replace(t.with_suffix('.csv'))
