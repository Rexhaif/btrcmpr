"""Keep wins in individual matched rounds separate from the predeclared median gate."""
from decimal import Decimal
import os
from pathlib import Path
from statistics import median
import tempfile
from decode_gate import write_csv
from level_one_lab import read


def write(series):
    output=[]
    for cell in read(series/'verified-cells.csv'):
        stem=cell['individual_trials'];name=cell['file'];n=int(cell['rounds'])
        trials=[r for r in read(series/stem) if Path(r['file']).name==name]
        data={(int(r['round']),r['codec']):r for r in trials}
        if len(trials)!=2*n or len(data)!=2*n:raise ValueError('invalid pairs in '+stem)
        per=[];order=None
        for i in range(1,n+1):
            b,z=(data[i,codec] for codec in ('btrcmpr','zstd'))
            if b['order']==order or {b['order'],z['order']}!={'0','1'} or b['compressed_bytes']!=cell['btr_bytes'] or z['compressed_bytes']!=cell['zstd_bytes']:raise ValueError('changed archives or pair order in '+stem)
            order=b['order'];per.append(tuple(Decimal(z[k])/Decimal(b[k]) for k in ('compress_seconds','decompress_seconds')))
        enc,dec=zip(*per);ew=sum(e>1 for e in enc);dw=sum(d>=Decimal('.95') for d in dec)
        both=sum(e>1 and d>=Decimal('.95') for e,d in per)
        output.append((int(cell['level']),name,n,ew,dw,both,*(f'{v:.5f}' for v in (min(enc),median(enc),max(enc),min(dec),median(dec),max(dec))),stem))
    write_csv(series/'paired-rounds.csv',('level','file','rounds','encode_wins','decodes_at_least_95pct','rounds_passing_both_speeds','min_paired_encode_ratio','median_paired_encode_ratio','max_paired_encode_ratio','min_paired_decode_ratio','median_paired_decode_ratio','max_paired_decode_ratio','raw_trials'),output)
    doc=['# Variation between paired rounds','',
         'The [preset acceptance table](preset-ladder.md) compares each codec’s median time. This table instead compares Rust and zstd within each alternating round: Rust must encode faster and decode at least 95% as fast. Counting individual wins helps identify comparisons that are sensitive to timing. Five pairs are too few to establish a guaranteed margin. No rows are discarded.','',
         f'In {sum(r[3]==r[2] for r in output)} of {len(output)} verified file/level comparisons, Rust encoded faster in every pair; in {sum(r[4]==r[2] for r in output)}, every pair met the decode allowance. [Full data, including minima, maxima and paired medians](paired-rounds.csv).','',
         'The six cells with the fewest rounds passing both speed thresholds, ordered by number passing, then paired encode median. Each speed is Rust throughput divided by zstd throughput within one round.','',
         '| File / level | Encode wins | Decodes within 5% | Both in same round | Median paired encode | Median paired decode |','|---|---:|---:|---:|---:|---:|']
    for lv,name,n,ew,dw,both,_,me,_,_,md,_,stem in sorted(output,key=lambda r:(r[5]/r[2],Decimal(r[7]),r[0],r[1]))[:6]:
        doc.append(f'| [{name} / {lv}]({stem}) | {ew}/{n} | {dw}/{n} | {both}/{n} | {float(me):.3f}× | {float(md):.3f}× |')
    with tempfile.NamedTemporaryFile(mode='w', dir=series, delete=False) as f:f.write('\n'.join(doc)+'\n')
    os.replace(f.name,series/'paired-rounds.md')
