#!/usr/bin/env python3
"""Repack only the transmitted dictionary of the same full enwik8 archives."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import statistics
import struct
import subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
w=root/'bench/local/levels/lanes';store=w/'book-storage';store.mkdir(exist_ok=True);binroot=a.bin_dir.resolve();repack=binroot/'examples/bookpack';decode=binroot/'examples/decode_loop'
raw=root/'bench/data/enwik8';env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def components(path):
    data=path.read_bytes();block,=struct.unpack_from('<I',data,20);d,=struct.unpack_from('<I',data,26)
    if data[24:26]!=bytes([50,4]) or d>block-6:raise ValueError('not the four-worker native dictionary')
    # All fields except the lengths and the dictionary itself must match byte for byte.
    return d,hashlib.sha256(data[:20]+data[24:26]+data[30+d:]).hexdigest()
with (root/'bench/results/presets/pooled-18-19/preflight.csv').open() as f:verified={int(r['level']):r for r in csv.DictReader(f)}
manifest=dict(repacker_sha256=digest(repack),decoder_sha256=digest(decode),source_sha256=digest(raw),encoder_code={k:digest(root/'src'/k) for k in ('worddag.rs','wordshared.rs','bookpack.rs','phrasepage.rs')})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (out/'sizes.csv').open('w',buffering=1) as sf,(out/'decode.csv').open('w',buffering=1) as df:
    sw=csv.writer(sf,lineterminator='\n');sw.writerow(('native_level','methods','archive_bytes','dictionary_bytes','archive_sha256','unchanged_roots_sha256'))
    dw=csv.writer(df,lineterminator='\n');dw.writerow(('native_level','methods','trial','decode_MBps'))
    for lv in (18,19):
        source=w/f'native-pooled-18-19/enwik8-{lv}.btr'
        if digest(source)!=verified[lv]['archive_sha256']:raise ValueError('different native archive')
        dic,root_sha=components(source);rows=[(source.stat().st_size,0,source)]
        sw.writerow((lv,0,rows[0][0],dic,digest(source),root_sha))
        for mode in (2,1,3,7):
            tgt=store/f'level-{lv}-{mode}.btr'
            subprocess.run([repack,source,raw,str(mode),tgt],check=True,env=env)
            size=tgt.stat().st_size;d,h=components(tgt)
            if h!=root_sha or size-rows[0][0]!=d-dic:raise ValueError('root token bytes changed')
            sw.writerow((lv,mode,size,d,digest(tgt),h));rows.append((size,mode,tgt))
        best=min(rows,key=lambda r:(r[0],r[1]));chosen=[rows[0],best] if best[1] else [rows[0]]
        data={r[1]:[] for r in chosen};rng=random.Random(9021+lv)
        for i in range(3):
            rng.shuffle(chosen)
            for _,mode,src in chosen:
                proc=subprocess.run([decode,src,'7','4',raw],env=env,capture_output=True,text=True,check=True)
                rate=float(re.search(r'([\d.]+) MB/s',proc.stderr)[1]);dw.writerow((lv,mode,i+1,rate));data[mode].append(rate)
        print(lv,'best bytes',best[0],'method',best[1],'median decode MB/s',{k:statistics.median(v) for k,v in data.items()},flush=True)

# Hold the winning dictionary fixed; rewrite only its four token streams.
# These are fixed-archive screens. Only a complete native encode can qualify
# the speed of the parser, dictionary training and transmission together.
source=best[2];base_bytes=best[0];dic,_=components(source)
with (out/'page-aliases.csv').open('w',buffering=1) as f:
    tw=csv.writer(f,lineterminator='\n');tw.writerow(('base_level','dictionary_methods','page_log','alias_cap','archive_bytes','delta_bytes','decode_MBps','archive_sha256'))
    for log,cap in [(8,16),(10,48),(11,96),(12,128),(13,192),(14,254)]:
        arc=store/f'page-{log}-{cap}.btr'
        subprocess.run([repack,source,raw,str(log),arc,str(cap),'1'],env=env,check=True)
        d,_=components(arc);n=arc.stat().st_size
        if d!=dic:raise ValueError('local aliasing changed the dictionary')
        proc=subprocess.run([decode,arc,'5','4',raw],env=env,capture_output=True,text=True,check=True)
        rate=float(re.search(r'([\d.]+) MB/s',proc.stderr)[1])
        tw.writerow((19,best[1],log,cap,n,n-base_bytes,rate,digest(arc)))
