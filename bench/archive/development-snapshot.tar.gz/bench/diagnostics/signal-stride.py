#!/usr/bin/env python3
"""Compare 16-bit predictors on a deterministic sample and a held-out sample."""
from array import array
import argparse
import csv
import hashlib
import json
from math import log2
from pathlib import Path
import random
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('input',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--max-stride',type=int,default=8192);a=p.parse_args()
raw=a.input.read_bytes();words=array('H');words.frombytes(raw[:len(raw)&~1])
if sys.byteorder!='little':words.byteswap()
maxd=min(a.max_stride,len(words)//4)
if maxd<32:raise SystemExit('need more samples')
def idx(n,seed):
    rng=random.Random(seed)
    return [rng.randrange(maxd+1,len(words)) for _ in range(n)]
def delta(i):return ((int(words[i])-words[i-1]+32768)&65535)-32768
def values(d,sample,kind):
    if kind=='adjacent':return [delta(i) for i in sample]
    if kind=='source':return [((int(words[i])-words[i-d]+32768)&65535)-32768 for i in sample]
    return [((delta(i)-delta(i-d)+32768)&65535)-32768 for i in sample]
def estimate(v):
    h={};n=len(v)
    for x in v:h[x]=h.get(x,0)+1
    return sum(c*log2(n/c) for c in h.values())/n
train=idx(96,124822);hold=idx(32768,77612);a.out.mkdir(exist_ok=True,parents=True)
full={kind:sorted((sum(abs(x).bit_length() for x in values(d,train,kind)),d) for d in range(16,maxd+1)) for kind in ('source','gradient')}
cases=[('adjacent',1)]
for kind,ranked in full.items():
    cases.extend((kind,d) for _,d in ranked[:12])
with (a.out/'held-out.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow('predictor stride mean_absolute_residual entropy_bits_per_sample fits_signed_byte_pct'.split())
    for kind,d in cases:
        v=values(d,hold,kind);w.writerow((kind,d,round(sum(map(abs,v))/len(v),3),round(estimate(v),4),round(100*sum(-128<=x<128 for x in v)/len(v),3)))
(a.out/'manifest.json').write_text(json.dumps(dict(input_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),max_stride=maxd,training_samples=96,holdout_samples=len(hold),threshold='top 12 strides per predictor by summed bit lengths on training sample; independent holdout'),indent=2)+'\n')
# Unlike a scalar left/above predictor, a group anchor is the same for
# several samples. All lanes can be decoded in parallel after knowing it.
def signed(v):return ((v+32768)&65535)-32768
def avg(a,b):return a+(signed(b-a)//2)
def blend(i,d,method):
    l=words[i-1];u=words[i-d];ul=words[i-d-1];ur=words[i-d+1]
    smooth=avg(u,avg(ul,ur))
    if method=='left-above':return avg(l,u)
    if method=='left-smoothed-above':return avg(l,smooth)
    if method=='above-smoothed':return smooth
    if method=='left-quarter-gradient':return l+signed(u-ul)//4
    if method=='left-double-average':return avg(l,avg(smooth,l))
    if method=='left-down-gradient':return max(min(l,u),min(max(l,u),l+signed(u-ul)))
    if method.startswith('row-bias'):
        width=int(method.split('-')[-1]);k=i//width*width-1
        return smooth+signed(words[k]-words[k-d])//2
    if method.startswith('recent-mean'):
        width=int(method.split('-')[-1])
        return l+sum(signed(words[i-j]-l) for j in range(1,width+1))//width
    if method=='local-linear':return l+signed(l-words[i-2])//2
    raise ValueError(method)
with (a.out/'blends.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow('predictor stride mean_absolute_residual entropy_bits_per_sample fits_signed_byte_pct'.split())
    d=full['source'][0][1]
    for method in ('left-above','left-smoothed-above','above-smoothed','left-quarter-gradient','left-double-average','left-down-gradient','row-bias-4','row-bias-8','row-bias-16','recent-mean-2','recent-mean-3','recent-mean-4','local-linear'):
        v=[signed(words[i]-blend(i,d,method)) for i in hold];w.writerow((method,d,round(sum(map(abs,v))/len(v),3),round(estimate(v),4),round(100*sum(-128<=x<128 for x in v)/len(v),3)))
