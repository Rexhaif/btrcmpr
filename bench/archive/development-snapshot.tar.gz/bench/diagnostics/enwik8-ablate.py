"""Isolate single codec changes using the original profile harness on enwik8."""
import os
import shutil
import subprocess as sp
import sys
from pathlib import Path

root, work = map(lambda p: Path(p).resolve(), sys.argv[1:3])
src = work / "copy"
src.mkdir(exist_ok=True)
for path in ("Cargo.toml", "Cargo.lock", ".cargo", "src", "examples", "bench/support"):
    dest = src / path
    if (root/path).is_dir():
        shutil.copytree(root/path, dest, dirs_exist_ok=True)
    else:
        shutil.copy2(root/path, dest)

def edit(s, a, b):
    assert s.count(a) == 1, a
    return s.replace(a, b)

def make(variant):
    pal = (root/"src/palette.rs").read_text()
    lz = (root/"src/lz.rs").read_text()
    if variant in ("scalar-palette", "all-three"):
        pal = edit(pal, '#[cfg(target_arch = "aarch64")]\n    let (at, mut bit)', '#[cfg(any())]\n    let (at, mut bit)')
        pal = edit(pal, '#[cfg(not(target_arch = "aarch64"))]\n    let (at, mut bit)', '    let (at, mut bit)')
    if variant in ("scalar-commands", "all-three"):
        for loop in ("while k + 16 <= os.len()", "while j + 16 <= ts.len()"):
            lz = edit(lz, '#[cfg(target_arch = "aarch64")]\n        '+loop, '#[cfg(any())]\n        '+loop)
    if variant in ("unfused-copy", "all-three"):
        lz = edit(lz, 'let copy_mode = crate::tuning("BTR_COPY_MODE", 0, 0, 5);',
                  'let copy_mode = 1usize;')
    if variant == "always-load":
        lz = edit(lz, 'if (slot ^ sig) > MASK as u32 || pos >= i', 'if pos >= i')
        lz = edit(lz, '    if d != 0 {\n        return ((d.trailing_zeros()', '''    if (slot ^ sig) > MASK as u32 {
        unsafe { core::arch::asm!("/* {d} */", d=in(reg) d, options(nomem, nostack, preserves_flags)) }
        return (0, 0);
    }
    if d != 0 {
        return ((d.trailing_zeros()''')
    for name, code in (("palette", pal), ("lz", lz)):
        p = src/"src"/(name+".rs")
        if p.read_text() != code:
            p.write_text(code)
    with (work/(variant+".build")).open("w") as log:
        sp.run(["cargo", "build", "--release", "--locked", "--features", "baseline", "--example", "profile", "--bin", "btrcmpr"], cwd=src, stdout=log, stderr=log, check=True)
    return src/"target/release"

def measure(name, direction, reps, binary):
    ctl, ack = (work/(name+ext) for ext in (".ctl", ".ack"))
    os.mkfifo(ctl)
    os.mkfifo(ack)
    env = dict(os.environ, PERF_CTL=str(ctl), PERF_ACK=str(ack), LC_ALL="C")
    with (work/("ablation-"+name+".txt")).open("w") as out:
        sp.run([env.get("PERF","perf"), "stat", "-D", "-1", "--control=fifo:"+str(ctl)+","+str(ack), "-e", "cycles:u,instructions:u,branches:u,branch-misses:u,cache-misses:u", "--", str(binary/"examples/profile"), direction, "ours", str(root/"bench/data/enwik8"), "4", str(reps)], env=env, stdout=out, stderr=out, check=True)

for variant in (sys.argv[3:] or ("reference", "scalar-palette", "scalar-commands", "unfused-copy", "all-three", "always-load")):
    binary = make(variant)
    if variant in ("reference","always-load"):
        archive = work/(variant+".btr")
        sp.run([str(binary/"btrcmpr"), "c", str(root/"bench/data/enwik8"), str(archive), "4"], check=True)
        if variant == "always-load":
            sp.run(["cmp", str(work/"reference.btr"), str(archive)], check=True)
        measure("enc-"+variant, "c", 5, binary)
    if variant != "always-load":
        measure(variant, "d", 30, binary)
