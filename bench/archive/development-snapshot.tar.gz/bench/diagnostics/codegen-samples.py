#!/usr/bin/env python3
"""Identify where the profiled release spends cycles and incurs branch misses."""
from collections import Counter
import csv
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];lanes=root/'bench/local/levels/lanes';snap=lanes/'native-fastest-1';lab=root/'bench/results/presets/research/release-codegen'
out=lab/'samples';out.mkdir(exist_ok=True);perf=root/'bench/local/perf';spec=json.loads((lab/'manifest.json').read_text());exe=lanes/'low-codegen/thin-pgo/target/release/examples/profile'
if sha(exe)!=spec['builds']['thin-pgo']['profile'] or {str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}!=spec['source_sha256']:raise ValueError('wrong program or source')
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',subprocess.check_output(['ldd',exe],text=True))[1])
if sha(lib)!=spec['reference_library_sha256']:raise ValueError('wrong library')
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PERF_','PROFILE_'))};env.update(LC_ALL='C',PERF=str(perf))
rows={r['file']:r for r in read(root/'bench/results/presets/native-fastest-1/rates.csv')};snapsh={};doc=[]
for name in ('enwik8','mozilla'):
    if sha(root/'bench/data'/name)!=spec['input_sha256'][name]:raise ValueError('wrong input')
    for event,period in [('cycles',490019),('branch-misses',4231)]:
        tag=name+'-'+event;cache=lanes/('thin-pgo-samples-'+tag)
        subprocess.run([sys.executable,root/'bench/diagnostics/sample-search.py','--file',name,'--level','1','--repetitions','8','--period',str(period),'--event',event,'--exe',exe,'--out',cache,'--zstd-debug',root/'bench/local/zstd.debug'],cwd=root,env=env,check=True)
        for codec,size in [('ours','btr_bytes'),('zstd','zstd_bytes')]:
            if 'archive_bytes='+rows[name][size]+'\n' not in (cache/(codec+'.log')).read_text():raise ValueError('profiled wrong archive')
        shutil.copy2(cache/'encode-samples.txt',out/(tag+'.txt'))
        raw=subprocess.check_output([perf,'script','-i',cache/'ours.data','-F','ip,sym,dsoff'],text=True).splitlines()
        hist=Counter();total=sum(bool(l.strip()) for l in raw)
        for l in raw:
            m=re.fullmatch(r'\s*[0-9a-f]+ .*? \((.*)\+0x([0-9a-f]+)\)',l)
            if m and Path(m[1])==exe:hist[int(m[2],16)]+=1
        if not hist or not total:raise ValueError('missing samples')
        symbols=subprocess.check_output(['addr2line','-a','-i','-e',exe],input=''.join(f'{k:x}\n' for k in hist),text=True)
        leaves={};ip=None
        for l in symbols.splitlines():
            if l.startswith('0x'):ip=int(l,16);continue
            m=re.search(r'/src/([^/:]+\.rs):(\d+)(?:\s|$)',l)
            if m and ip is not None and ip not in leaves and (snap/'src'/m[1]).is_file() and int(m[2])>0:leaves[ip]=(m[1],int(m[2]))
        sites=Counter();files=Counter()
        for ip,n in hist.items():
            pair=leaves.get(ip,('unassigned',0));sites[pair]+=n;files[pair[0]]+=n
        with (out/(tag+'-lines.csv')).open('w') as f:
            w=csv.writer(f,lineterminator='\n');w.writerow(['source','line','samples','pct_all','statement'])
            for (src,line),n in sites.most_common():
                stmt=(snap/'src'/src).read_text().splitlines()[line-1].strip() if line else ''
                w.writerow([src,line,n,round(100*n/total,3),stmt])
        snapsh[tag]=dict(event=event,period=period,all_samples=total,program_samples=sum(hist.values()),raw_data_sha256={k:sha(cache/(k+'.data')) for k in ('ours','zstd')})
        top=[f'{k} {100*n/total:.1f}%' for k,n in files.most_common() if k!='unassigned'][:3]
        doc.append(f"| {name} | [{event}]({tag}.txt) | {total:,} | "+', '.join(top)+f" | [Mapped lines]({tag}-lines.csv) |")
(out/'identity.json').write_text(json.dumps(dict(profile_binary_sha256=sha(exe),libzstd_sha256=sha(lib),samples=snapsh),indent=2)+'\n')
(out/'README.md').write_text('\n'.join(['# Where the compiled level-one encoder spends cycles','',
'Hardware samples over eight complete four-worker encodes. The counters run only during the codec operation. The column gives the share of all Rust encoder samples attributed to each project source file by the first matching line in the inline stack. Some samples fall outside the executable or cannot be mapped. ARM sampling can land after a branch; an individual line does not establish which branch mispredicted. The linked function samples include the matched installed zstd library and its verified debug symbols.','',
'| Input | Hardware event | All Rust samples | Three largest Rust source files | Detail |','|---|---|---:|---|---|',*doc,'','[Counter and build identities](identity.json), [cycles and misses per input byte](../counters.csv), [independent wall times](../README.md).','']))

subprocess.run([sys.executable,root/'bench/diagnostics/codegen-hot-pcs.py'],cwd=root,check=True)
with (out/'README.md').open('a') as doc:doc.write('\n[ARM instruction windows on enwik8](enwik8-arm.md) and [Mozilla](mozilla-arm.md) show the hottest sampled positions and the surrounding loads, compares and branches.\n')
