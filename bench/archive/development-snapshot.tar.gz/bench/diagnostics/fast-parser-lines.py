#!/usr/bin/env python3
"""Resolve the existing level-one ARM instruction samples to the original parser or entropy stages."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess

p=argparse.ArgumentParser(description=__doc__)
for key in ('exe','data','source','out'):p.add_argument('--'+key,type=Path,required=True)
p.add_argument('--entropy',action='store_true',help='resolve the palette and stream encoder instead; --source is the original src directory')
a=p.parse_args();root=Path(__file__).resolve().parents[2];perf=root/'bench/local/perf';out=a.out;out.mkdir(exist_ok=True,parents=True)
reference=root/'bench/results/profiles/enwik8-general/fastest-preset'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
spec=json.loads((reference/'manifest.json').read_text())
sources={k:a.source/k for k in ('palette.rs','ans.rs')} if a.entropy else {'quicktwo.rs':a.source}
if sha(a.exe)!=spec['profile_sha256'] or any(sha(path)!=spec['source']['src/'+k] for k,path in sources.items()):raise ValueError('wrong profiled executable or source')
build=re.search(r'Build ID: ([a-f0-9]+)',subprocess.check_output(['readelf','-n',a.exe],text=True))[1]
ids=subprocess.check_output([perf,'buildid-list','-i',a.data],text=True)
if not any(line.split()[0]==build and 'profile' in line for line in ids.splitlines() if line.split()):raise ValueError('perf data built by different binary')
raw=subprocess.check_output([perf,'script','-i',a.data,'-F','ip,sym,dsoff'],text=True)
hist=Counter();total=0
target={'btrcmpr::palette::put','btrcmpr::ans::put_inner'} if a.entropy else {'btrcmpr::lz::quicktwo::encode'}
for line in raw.splitlines():
    m=re.fullmatch(r'\s*[a-f0-9]+ (.*?) \((.*?)(?:\+0x([a-f0-9]+))?\)',line)
    if not m:raise ValueError(line)
    total+=1
    if m[1] in target and m[3]:hist[int(m[3],16)]+=1
if sum(hist.values())!=(4618+2083 if a.entropy else 16384) or total!=23949:raise ValueError('not the original gated instruction sample')
addr=list(hist)
z=subprocess.run(['addr2line','-a','-f','-C','-i','-e',a.exe],input=''.join(f'0x{x:x}\n' for x in addr),text=True,capture_output=True,check=True)
stacks={};ip=None
for line in z.stdout.splitlines():
    if re.fullmatch(r'0x[0-9a-f]+',line):ip=int(line,16);stacks[ip]=[]
    else:stacks[ip].append(line)
if set(stacks)!=set(addr):raise ValueError('incomplete DWARF address mapping')
counts=Counter();detail=Counter()
def classify(stack):
    frames=[(f,l.split(' (discriminator')[0]) for f,l in zip(stack[::2],stack[1::2],strict=True)]
    if a.entropy:
        for fun,line in frames:
            m=re.search(r'/(palette|ans)\.rs:(\d+)',line)
            if not m or not (n:=int(m[2])):continue
            if m[1]=='palette':
                if 8<=n<=76 or 156<=n<=189:return 'choose palette widths'
                if 81<=n<=129 or 234<=n<=238:return 'pack palette selectors and ranks'
                if 135<=n<=142:return 'rank alphabet and count prefixes'
                if 195<=n<=232:return 'write palette tables and allocate output'
            elif n in (47,48,49,50,51,53) or 173<=n<=185:return 'count symbols'
            elif 67<=n<=92 or 104<=n<=137:return 'estimate entropy or normalize counts'
            elif 55<=n<=66 or 93<=n<=97:return 'test or write raw and constant streams'
            elif 138<=n<=170:return 'encode rANS stream'
        return 'other or unassigned'
    lines=[int(m[1]) for _,l in reversed(frames) if (m:=re.search(r'/quicktwo\.rs:(\d+)',l))]
    if lines:
        n=lines[0]
        if n==48:return 'emit literals, lengths and distance'
        if n in (26,32,36):return 'verify candidate or extend match'
        if 51<=n<=55:return 'index inside accepted match'
        if 42<=n<=46:return 'extend match backwards or form distance'
        if n in (17,18,19,21,22,23,24,25,31,35):return 'form keys or access current index'
        if n in (16,20,27,30,38,39,49,50):return 'parse decisions and loop control'
        if n in (8,9):return 'index hash arithmetic'
    for f,_ in frames:
        if 'Streams::emit' in f or 'Streams::offset' in f:return 'emit literals, lengths and distance'
        if re.search(r'lz::(common|probe)(::|$)',f):return 'verify candidate or extend match'
    return 'other or unassigned'
with (out/'addresses.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('elf_offset','samples','group','inline_stack'))
    for x,ct in hist.most_common():
        stack=stacks[x];label=classify(stack);counts[label]+=ct;detail[tuple(stack)]+=ct
        w.writerow((hex(x),ct,label,' | '.join(stack)))
with (out/'groups.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('group','samples','pct_entropy_functions' if a.entropy else 'pct_parser','pct_entire_encoder','approx_instructions_per_input_byte'))
    for k,n in counts.most_common():w.writerow((k,n,round(100*n/sum(hist.values()),2),round(100*n/total,2),round(33.967*n/total,3)))
manifest=dict(elf_build_id=build,profile_sha256=sha(a.exe),perf_data_sha256=sha(a.data),total_samples=total)
if a.entropy:
    manifest.update(entropy_function_samples=sum(hist.values()),source_sha256={k:sha(path) for k,path in sources.items()})
else:
    (out/'profiled-quicktwo.rs').write_bytes(a.source.read_bytes())
    manifest.update(quicktwo_sha256=sha(a.source),parser_samples=sum(hist.values()))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
