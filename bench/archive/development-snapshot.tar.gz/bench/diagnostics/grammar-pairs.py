#!/usr/bin/env python3
"""Compare the experimental word grammar with ordinary zstd at a matching level."""
import argparse,csv,hashlib,json,os,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--level',type=int,default=22)
p.add_argument('--rounds',type=int,default=3)
p.add_argument('--out',required=True,type=Path)
p.add_argument('--decoder',type=int,default=0)
p.add_argument('--mix',nargs=4,type=int,metavar=('GRAMMAR_JOBS','PERMILLE','BYTE_PRESET','CHUNK_KIB'))
a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
root=Path(__file__).resolve().parents[2]
exe=root/'target/release/compare'
binary=exe.read_bytes();digest=hashlib.sha256(binary).hexdigest()
frozen=root/'bench/local/preset-binaries'/digest
frozen.parent.mkdir(parents=True,exist_ok=True)
if not frozen.exists():frozen.write_bytes(binary);frozen.chmod(0o755)
if hashlib.sha256(frozen.read_bytes()).hexdigest()!=digest:raise ValueError("binary digest mismatch")
raw=a.out/'rounds.partial';method='mix' if a.mix else 'lex-grammar'
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
env.update(BTR_LEVEL=str(a.level),ZSTD_LEVEL=str(a.level),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw),
         BTR_TRIAL_METHOD=method,BTR_GRAM_CAP='4096',BTR_GRAM_WIDTH='32',BTR_GRAM_DECODE=str(a.decoder))
for key in ('BTR_GRAM_NUMBERS','BTR_GRAM_PIPE','BTR_GRAM_GROUPS','BTR_MIX_FLAT','BTR_MIX_ROTATE','BTR_MIX_PARTIAL'):
    env[key]=os.environ.get(key,'0')
env['BTR_GRAM_JOB_KIB']=os.environ.get('BTR_GRAM_JOB_KIB','24576')
if a.mix:
    for key,v in zip(('JOBS','SHARE','PLAIN','KIB'),a.mix):env['BTR_MIX_'+key]=str(v)
manifest=dict(benchmark_sha256=digest,research=True,preset_level=a.level,method=method,merges=4096,phrase_limit=32,decoder=a.decoder,
              mix=a.mix,settings={k:v for k,v in env.items() if k.startswith('BTR_')},
              threads=4,rounds=a.rounds,warmup=1,decodes=7,input_bytes=100000000,
              input_sha256=hashlib.sha256((root/'bench/data/enwik8').read_bytes()).hexdigest())
(a.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run([frozen,'4',str(a.rounds),'both','bench/data/enwik8'],env=env,check=True)
data=list(csv.DictReader(raw.open()))
with (a.out/'summary.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('codec','bytes','encode_MBps','decode_MBps'))
    for label in ('btrcmpr','zstd'):
        series=[r for r in data if r['codec']==label];sizes={int(r['compressed_bytes'])for r in series}
        if len(series)!=a.rounds or len(sizes)!=1 or any(int(r['raw_bytes'])!=100_000_000 for r in series):raise ValueError("incomplete trials")
        w.writerow((method if label=='btrcmpr' else 'zstd',sizes.pop(),*(round(100/statistics.median(float(r[key]) for r in series),3) for key in ('compress_seconds','decompress_seconds'))))
raw.replace(a.out/'rounds.csv')
