#!/usr/bin/env python3
"""Measure two independent match cursors in one native block with an unchanged decoder."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import tempfile
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
base=root/'bench/results/presets/research';env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def run(cmd,e):return subprocess.run(cmd,cwd=snap,env=e,text=True,capture_output=True,check=True)
def writer(name,columns):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(columns.split());return f,w
def costs(data,k):
    seq=[r for r in data if r['codec']==k]
    if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or len({r['compressed_bytes'] for r in seq})!=1:raise ValueError('invalid paired measurements')
    return int(seq[0]['compressed_bytes']),*(statistics.median(Decimal(r[t]) for r in seq) for t in ['compress_seconds','decompress_seconds'])
known={r['file']:(r['verified_sha256'],int(r['archive_bytes'])) for r in read(base/'palette-write/checks.csv') if r['mode']=='0'}
spec=json.loads((base/'group-offsets/manifest.json').read_text())
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',ex/'compare'],env).stdout)[1])
if sha(lib)!=spec['zstd_library_sha256']:raise ValueError('reference library changed')
(out/'manifest.json').write_text(json.dumps(dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,
    zstd_frame_policy='one independent frame per worker',zstd_library_sha256=sha(lib),input_sha256=spec['input_sha256'],
    source_sha256={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))},
    binaries={n:sha(ex/n) for n in ('compare','examples/candidate','examples/decode_loop','examples/profile')}),indent=2)+'\n')
sf,sw=writer('screen','file phase mode key seed_stride reach_KiB bytes encode_MBps decode_MBps')
cf,cw=writer('counters','file mode key seed_stride reach_KiB bytes archive_sha256 instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte counter_MBps')
pf,pw=writer('paired','file mode key seed_stride reach_KiB codec bytes encode_MBps decode_MBps pass_at_5pct')
tf,tw=writer('wire','file mode key seed_stride reach_KiB bytes archive_sha256')
with sf,cf,pf,tf,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    arc=Path(tmp)/'test.btr'
    for name in ['enwik8','mozilla']:
        src=root/'bench/data'/name;nbytes=src.stat().st_size
        if sha(src)!=spec['input_sha256'][name]:raise ValueError('input changed')
        ref=costs(read(base/'group-offsets'/f'{name}-0.csv'),'zstd');target=float(Decimal(nbytes)/ref[2]/1_000_000)*.95
        def cfg(case):
            m,k,step,reach=case
            return dict(env,BTR_LANE_MODE=str(m),BTR_LANE_KEY=str(k),BTR_LANE_STEP=str(step),BTR_LANE_REACH=str(reach))
        def trial(case,phase,verify=False):
            e=cfg(case)
            if verify:e['BTR_CANDIDATE_FRAME']=str(arc)
            r=next(csv.DictReader(run([ex/'examples/candidate','4','1',src,'native'],e).stdout.splitlines()))
            size,c,d=int(r['bytes']),float(r['encode_MBps']),float(r['decode_MBps'])
            sw.writerow((name,phase,*case,size,c,d))
            if verify:
                run([ex/'examples/decode_loop',arc,'1','3',src],env)
                if arc.stat().st_size!=size:raise ValueError('size changed')
                tw.writerow((name,*case,size,sha(arc)))
            return (size<ref[0],d>=target,c,d,-size,case)
        native=(0,0,0,64)
        for case in [native,(1,0,0,64)]:
            z=trial(case,'identity',True)
            if (sha(arc),-z[4])!=known[name]:raise ValueError('the new unsplit cursor must match native')
        cases=[(3,k,step,reach) for k in range(4) for step,reach in [(0,64),(2,64),(4,16),(4,64),(4,256),(8,64),(16,128)]]
        random.Random(37).shuffle(cases);res=[trial(case,'shape') for case in cases]
        # Prioritize smaller-than-zstd configurations; when even the smallest
        # misses, measure the least oversized candidate instead of hiding it.
        eligible=sorted((r for r in res if r[0]),reverse=True)
        best=(eligible[0] if eligible else max(res,key=lambda r:r[4]))[-1]
        choices=[(m,*best[1:]) for m in [2,3,4,5]];seen=set();counts={}
        for case in [native,*choices]:
            row=trial(case,'schedule',True);size=-row[4];digest=sha(arc)
            if case!=native:seen.add(digest)
            events=['instructions:u','cycles:u','branches:u','branch-misses:u'];n=8
            with tempfile.TemporaryDirectory() as work:
                ctl,ack=(Path(work)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                z=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',ex/'examples/profile','c','ours',src,'4',str(n)],dict(cfg(case),BTR_LEVEL='1',PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            (out/f'{name}-{case[0]}-perf.txt').write_text(z.stderr)
            if f'archive_bytes={size}\n' not in z.stderr:raise ValueError('counter archive differs')
            vals={v[2]:float(v[0])/(nbytes*n) for s in z.stderr.splitlines() if len(v:=s.split(';'))>2 and v[2] in events}
            counts[case]=vals['cycles:u']
            cw.writerow((name,*case,size,digest,*(round(vals[k],4) for k in events),re.search(r'([\d.]+) MB/s',z.stderr)[1]))
        if len(seen)!=1:raise ValueError('changing cursor issue order changed the archive')
        for case in dict.fromkeys([choices[0],min(choices[1:],key=counts.get)]):
            size=-trial(case,'paired',True)[4];raw=out/f'{name}-{case[0]}.partial'
            run([ex/'compare','4','5','both',src],dict(cfg(case),BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            data=read(raw);ab=[costs(data,k) for k in ['btrcmpr','zstd']]
            if ab[0][0]!=size or ab[1][0]!=ref[0]:raise ValueError('paired archive different')
            for k,(b,c,d) in zip(['btrcmpr','zstd'],ab,strict=True):
                pw.writerow((name,*case,k,b,round(Decimal(nbytes)/c/1_000_000,3),round(Decimal(nbytes)/d/1_000_000,3),int(qualifies(ab,DEFAULT_DECODE_LOSS_PCT))))
            raw.replace(raw.with_suffix('.csv'))
