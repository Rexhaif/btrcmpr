"""Describe the representations actually stored, using only CLI-verified archive hashes."""
import csv
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import subprocess

from level_one_lab import read, sha

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'scripts'))
from frame_info import inspect


def save(path, text):
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, delete=False) as f:
        f.write(text)
    os.replace(f.name, path)


def write(series, scan=(), fill=None):
    cells = read(series/'verified-cells.csv')
    meta = next((p for p in sorted((ROOT/'bench/results/presets').glob('native-*/codegen.json'))
                 if json.loads(p.read_text())['comparator'] == series.name), None)
    if meta is None: return
    origin = meta.parent
    cli = json.loads(meta.read_text())['cli']
    evidence = {}
    cache = series/'cached-blocks.json'
    if cache.is_file(): evidence.update(json.loads(cache.read_text()))
    sizes = {int(r['btr_bytes']) for r in cells}
    hashes = {r['archive_sha256'] for r in cells}
    if scan:
        for path in map(Path, scan):
            if path.stat().st_size not in sizes:continue
            digest = sha(path)
            if digest in hashes and digest not in evidence:
                evidence[digest] = dict(source=os.path.relpath(path,series), **inspect(path))
        save(cache,json.dumps(evidence,indent=2)+'\n')
    dirs = {((series/r['individual_trials']).resolve()).parent for r in cells}
    for sidecar in sorted({d/'cli.blocks.json' for d in dirs} | {origin.parent/'research/combined-rebuild/cli.blocks.json'}):
        if not sidecar.is_file():continue
        for r in json.loads(sidecar.read_text()):
            digest=r['archive_sha256']
            if digest not in hashes:continue
            # A rebuilt executable can produce identical bytes. Trust that
            # observation only through the original standalone archive digest.
            if r['cli_sha256']!=cli and sidecar.parent.name!='combined-rebuild':raise ValueError('wrong native CLI')
            evidence[digest]=dict(r,source=os.path.relpath(sidecar,series))
    if fill is not None:
        if sha(fill)!=cli:raise ValueError('header backfill needs the original standalone CLI')
        newly={}
        with tempfile.TemporaryDirectory(dir=ROOT/'target') as tmp:
            path=Path(tmp)/'archive'
            for r in cells:
                digest=r['archive_sha256']
                if digest in evidence:continue
                subprocess.run([fill,'c','-'+r['level'],ROOT/'bench/data'/r['file'],path,'4'],check=True,capture_output=True)
                if sha(path)!=digest:raise ValueError('standalone archive changed during header capture')
                newly[digest]=dict(source='independently recaptured with frozen standalone CLI',cli_sha256=cli,**inspect(path))
                evidence[digest]=newly[digest]
        existing=json.loads(cache.read_text()) if cache.is_file() else {}
        save(cache,json.dumps({**existing,**newly},indent=2)+'\n')
    report=['# Stored representations on the selected build','',
            'Each row is based on the exact archive SHA-256 from the [standalone round trip](verified-cells.csv). '
            'The counts below describe the outermost blocks, not guesses from the file name or level. '
            'The [per-representation bytes](representation-bytes.csv) show how much input and compressed payload each kind accounts for. '
            'Header bytes plus all stored payload bytes equal the full archive. Shared dictionary bytes are already included in the payload.','',
            '| File and level | Stored blocks (tag: count) | Framing bytes | Shared dictionary bytes | Row strides (samples: jobs) |',
            '|---|---|---:|---:|---|']
    by_tag={}
    buf=io.StringIO();writer=csv.writer(buf,lineterminator='\n')
    writer.writerow(('file','level','archive_sha256','tag','representation','blocks','original_bytes','payload_bytes','evidence'))
    for r in cells:
        info=evidence.get(r['archive_sha256'])
        if info is None:continue
        reps=info['representations']
        if (int(r['btr_bytes'])!=info['archive_bytes'] or info['archive_bytes']!=info['framing_bytes']+sum(x['payload_bytes'] for x in reps)
                or sum(x['original_bytes'] for x in reps)!=info['original_bytes'] or sum(x['blocks'] for x in reps)!=info['blocks']):
            raise ValueError('representation accounting disagrees with the verified archive')
        for x in reps:
            by_tag[x['tag']]=x['name']
            writer.writerow([r['file'],r['level'],r['archive_sha256'],x['tag'],x['name'],x['blocks'],x['original_bytes'],x['payload_bytes'],info['source']])
        blocks=', '.join(f"{x['tag']}: {x['blocks']}" for x in reps)
        strides=', '.join(f'{k}: {v}' for k,v in info['row_strides_in_samples'].items()) or '—'
        report.append(f"| [{r['file']}, {r['level']}]({r['individual_trials']}) | {blocks} | {info['framing_bytes']:,} | {info['embedded_dictionary_bytes']:,} | {strides} |")
    count=sum(r['archive_sha256'] in evidence for r in cells)
    report.extend(['',f'Archive headers available for {count} of {len(cells)} measured cells. An omitted row has no header capture here.','',
                   '| Tag | Stored representation |','|---:|---|',*[f'| {k} | {v} |' for k,v in sorted(by_tag.items())],''])
    save(series/'representations.md','\n'.join(report))
    save(series/'representation-bytes.csv',buf.getvalue())


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('series',type=Path)
    p.add_argument('--archives-from-stdin',action='store_true',help='inspect any listed archive whose hash matches a verified cell')
    p.add_argument('--fill-with',type=Path,help='use the frozen CLI to reproduce any remaining verified archive header once')
    a=p.parse_args()
    write(a.series.resolve(),sys.stdin.read().splitlines() if a.archives_from_stdin else (),a.fill_with.resolve() if a.fill_with else None)
