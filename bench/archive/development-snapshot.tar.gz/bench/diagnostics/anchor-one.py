#!/usr/bin/env python3
"""Screen full inputs for low-preset match search at content-dependent landmarks."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tempfile

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[2];exe=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(method,src,env):
    x=subprocess.run([exe/'examples/candidate','4','1',src,method],env=env,capture_output=True,text=True,check=True)
    return next(csv.DictReader(x.stdout.splitlines()))
def getcsv(p):
    with p.open() as f:return list(csv.DictReader(f))
(out/'manifest.json').write_text(json.dumps(dict(workers=4,code={p:sha(root/'src'/p) for p in ['anchorfast.rs','quicktwo.rs','lz.rs']},binaries={b:sha(exe/b) for b in ['examples/candidate','examples/decode_loop','compare']}),indent=2)+'\n')
control={r['file']:r for r in getcsv(root/'bench/results/presets/research/palette-write/checks.csv') if r['mode']=='0'}
with (out/'screen.csv').open('w',buffering=1) as f,(out/'paired.csv').open('w',buffering=1) as pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as space:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('file','anchor','columns','job_KiB','bytes','encode_MBps','decode_MBps'))
    pw=csv.writer(pf,lineterminator='\n');pw.writerow(('file','anchor','columns','job_KiB','codec','bytes','encode_MBps','decode_MBps'))
    for name,limit,base in [('enwik8',40669611,256),('mozilla',19963738,128)]:
        src=root/'bench/data'/name;arc=Path(space)/'frame.btr'
        job='BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB'
        def cfg(m,h,kib):return dict(env,BTR_ANCHOR1=str(m),BTR_FAST_COUNTS=str(2*h),BTR_FAST_PLAN=str(2*h),**{job:str(kib)})
        cases=[(i,0,base) for i in range(26)]+[(i,h,2*base) for i in (1,2,3,4,5,6,8,10,13,16,17,19,23,25) for h in (0,1)]+[(1,1,base)]
        cases.extend((i,1,kib) for i in (1,2,3,8,9,14,21,25) for kib in (base//2,base*3//4))
        random.Random(2141).shuffle(cases);eligible=[]
        for m,h,kib in cases:
            key=cfg(m,h,kib);check=m in (0,1) and h==0 and kib==base
            row=run('native',src,dict(key,BTR_CANDIDATE_FRAME=str(arc)) if check else key)
            n=int(row['bytes']);c=float(row['encode_MBps']);d=float(row['decode_MBps'])
            if check and sha(arc)!=control[name]['verified_sha256']:raise ValueError('same parse changed the native archive')
            wr.writerow((name,m,h,kib,n,c,d))
            if m and n<limit:eligible.append((c,d,n,m,h,kib))
        for c,d,n,m,h,kib in sorted(eligible,reverse=True)[:2]:
            key=cfg(m,h,kib);run('native',src,dict(key,BTR_CANDIDATE_FRAME=str(arc)))
            if arc.stat().st_size!=n:raise ValueError('different selected frame')
            subprocess.run([exe/'examples/decode_loop',arc,'1','3',src],env=env,check=True)
            subprocess.run([sys.executable,root/'bench/diagnostics/fast-wire.py','--single',arc,'--name',name,'--out',out/f'{name}-{m}-{h}-{kib}-wire'],check=True)
            path=out/f'{name}-{m}-{h}-{kib}.partial'
            subprocess.run([exe/'compare','4','5','both',src],env=dict(key,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(path)),check=True)
            rows=getcsv(path)
            for codec,size in [('zstd',limit),('btrcmpr',n)]:
                part=[r for r in rows if r['codec']==codec]
                if len(part)!=5 or {int(r['round']) for r in part}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=size for r in part):raise ValueError('inconsistent pair')
                pw.writerow((name,m,h,kib,codec,size,*(round(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in part),3) for k in ('compress_seconds','decompress_seconds'))))
            path.replace(path.with_suffix('.csv'))
