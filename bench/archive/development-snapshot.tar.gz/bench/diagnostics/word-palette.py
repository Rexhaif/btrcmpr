#!/usr/bin/env python3
"""Compare single-word palette lookups on the exact native level-one archives."""
import argparse
from pathlib import Path
import random
import subprocess
import sys
import tempfile
from level_one_lab import Lab,costs,read,sha
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out)
native={r['input']:r for r in read(l.root/'bench/results/presets/native-fastest-1/cli.csv')};doc=[]
cf,cw=l.report('counters','file mode codec archive_bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
pa,pw=l.report('paired','file mode tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
with cf,pa,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as tmp:
    arc=Path(tmp)/'packed.btr'
    for name in ('enwik8','mozilla'):
        arch=name=='mozilla';ref=costs(read(l.base/'group-key'/f'{name}-1.csv'),'zstd')[0]
        def cfg(m):return dict(l.env,BTR_WORD_PALETTE=str(m),BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='10' if arch else '5',BTR_FAST_COUNTS='2',BTR_FAST_PLAN='0' if arch else '1',BTR_JOB_KIB='384',BTR_ARCH_KIB='192',BTR_RECORD_KIB='128',BTR_RECORD_COST='2')
        digest=native[name]['archive_sha256'];n=int(native[name]['cli_bytes']);cycles={}
        if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('wrong corpus')
        modes=list(range(5));random.Random(15701).shuffle(modes)
        for m in modes:
            num,_,_=l.trial(name,cfg(m),arc)
            if n!=num or sha(arc)!=digest:raise ValueError(f'changed native archive: {name} mode {m}')
            l.restore(name,arc,l.env);vals=l.perf(name,cfg(m),n,f'{name}-m{m}');cycles[m]=vals[1];cw.writerow((name,m,'btrcmpr',n,*vals))
        # Pair the best narrow and wide implementations, plus the original.
        def pair(m,tag):
            rates,ok=l.pair(name,cfg(m),n,ref,tag)
            for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((name,m,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
            (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {m} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |");return ok,c/cz
        picks=[0,min((1,2),key=cycles.get),min((3,4),key=cycles.get)];scores=[]
        for m in picks:
            score=pair(m,f'{name}-paired-{m}')
            if m:scores.append((score,m))
        best=max(scores)[1];pair(best,f'{name}-repeat')
(l.out/'README.md').write_text('\n'.join(['# One packed lookup per palette symbol','',
'On the release binary, ARM disassembly showed separate byte loads for the selector, residual and residual width of each symbol. This writer packs the three into one initialized table word; two entry words can be added to obtain the total width in the low bits. Modes 1/2 emit four residuals per store, modes 3/4 emit eight. Even modes force one aligned 32-bit load in ARM assembly. Mode zero is the shipped scalar writer.','',
'| Raw trials | Mode | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
'Every implementation reproduced both native level-one archive SHA-256 digests and restored the entire inputs. Hardware counters cover eight encodes; independent timings used four workers, five warmed alternating pairs, and seven decodes per trial. The fastest narrow and wide implementations by cycles both received paired comparisons; the best measured candidate received a second independent comparison. [Counters](counters.csv), [paired rates and archive hashes](paired.csv), [manifest](manifest.json).','']))
if all((l.base/k/'README.md').is_file() for k in ('record-pick','confirm-match')):
    subprocess.run([sys.executable,l.root/'bench/diagnostics/joint-one.py','--workspace',l.snap,'--bin-dir',l.exe,'--out',l.base/'joint-one'],check=True)
