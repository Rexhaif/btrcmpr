#!/usr/bin/env python3
"""Compare rare spelling splits with exact byte restoration; qualify one candidate in paired trials."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--workspace',type=Path,required=True,help='prepared shared-phrases build')
p.add_argument('--bin-dir',type=Path,help='directory containing compare and examples/ in a separate release target')
p.add_argument('--min-level',type=int,choices=range(16,23),default=16,help='lowest matching level eligible for paired promotion')
p.add_argument('--out',type=Path,required=True)
p.add_argument('--pilot',action='store_true',help='measure three full-input alternatives without paired promotion')
p.add_argument('--pool-only',action='store_true',help='test shared dictionaries with pooled merges and sparse long copies')
p.add_argument('--cross-only',action='store_true',help='reparse each worker with the whole group dictionary in the cross-parse build')
a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True)
root=Path(__file__).resolve().parents[2];w=a.workspace.resolve();binroot=a.bin_dir.resolve() if a.bin_dir else w/'target/release'
exe=binroot/'examples/candidate';compare=binroot/'compare';loop=binroot/'examples/decode_loop';src=root/'bench/data/enwik8'
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_') and k!='CARGO_TARGET_DIR'}
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    with path.open() as f:return list(csv.DictReader(f))
candidates=[]
shared=[] if a.pilot or a.pool_only or a.cross_only else read(a.out.parent/'shared-phrases/screen.csv')
for r in shared:
    candidates.append((int(r['archive_bytes']),float(r['encode_MBps']),float(r['decode_MBps']),'shared-dag',
        dict(BTR_DAG_CAP=r['cap'],BTR_DAG_WIDTH=r['max_width'],BTR_SHARED_JOBS=r['jobs_per_dictionary'])))
manifest=dict(input_sha256=digest(src),candidate_sha256=digest(exe),compare_sha256=digest(compare),threads=4,
              source={p.name:digest(p) for p in sorted((w/'src').glob('*')) if p.is_file()})
(a.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (a.out/'screen.csv').open('w',buffering=1) as out:
    wr=csv.writer(out,lineterminator='\n');wr.writerow(('method','merge_cap','rare_threshold','spelling_rent','reparse','jobs_per_dictionary','pooled_merges','minimum_count','minimum_copy_bytes','group_reparse_rounds','group_rent','archive_bytes','encode_MBps','decode_MBps','dictionary_bytes','token_count'))
    cases=[
          ('lex-dag',65536,0,64,0,1),('lex-dag',32768,2,64,0,1),('lex-dag',65536,2,64,0,1),
          ('lex-dag',65536,6,48,0,1),('lex-dag',65536,16,96,0,1),('lex-dag',65536,6,64,1,1),
          ('shared-dag',32768,2,64,0,2),('shared-dag',65536,6,64,0,2),('shared-dag',65536,6,64,0,4)]
    if a.pilot:
        cases=[('lex-dag',65536,2,64,0,1),('shared-dag',65536,0,64,0,2),('shared-dag',65536,0,64,0,4)]
    cases=[(*case,0,3,0) for case in cases]
    pooled=[('shared-dag',cap,0,64,0,4,extra,least,0) for cap,extra,least in
            [(4096,32768,3),(16384,32768,3),(32768,65536,3),(65536,16384,3),(65536,65536,3),(32768,131072,2)]]
    pooled.extend(('shared-dag',65536,0,64,0,4,extra,3,cutoff) for extra,cutoff in
                  [(0,96),(0,64),(0,32),(32768,48),(32768,24)])
    if a.pool_only:cases=pooled
    cases=[(*v,0,0) for v in cases]
    if a.cross_only:
        cases=[('shared-dag',cap,0,64,0,4,extra,3,0,rounds,fee) for cap,extra,rounds,fee in
               [(65536,0,0,0),(65536,0,1,0),(65536,0,2,0),(65536,0,2,256),(32768,32768,1,128),(65536,32768,1,128)]]
    for method,cap,rare,rent,reparse,share,extra,least,cutoff,cross,fee in cases:
        key=dict(BTR_DAG_CAP=str(cap),BTR_DAG_WIDTH='64',BTR_SUBWORD_RARE=str(rare),BTR_SUBWORD_RENT=str(rent),
                 BTR_DAG_REPARSE=str(reparse),BTR_SHARED_JOBS=str(share),
                 BTR_SHARED_EXTRA=str(extra),BTR_SHARED_MIN=str(least),BTR_SHARED_COPY=str(cutoff),
                 BTR_CROSS_ROUNDS=str(cross),BTR_CROSS_RENT=str(fee))
        arc=root/'bench/local/levels/lanes/piece-trial.btr'
        r=subprocess.run([exe,'4','22',src,method],env=dict(env,**key,BLOCK_KIB='24576',PRESET_ALIGN='1',BTR_DAG_TRACE='1',
                         BTR_CANDIDATE_FRAME=str(arc)),text=True,capture_output=True,check=True)
        row=next(csv.DictReader(r.stdout.splitlines()));size=int(row['bytes'])
        subprocess.run([loop,arc,'1','3',src],env=env,check=True)
        blocks=[list(map(int,x.split(',')[1:])) for x in r.stderr.splitlines() if x.startswith('dag,')]
        dic=tokens=''
        if method=='lex-dag':
            if len(blocks)!=4 or 20+sum(9+sum(x[3:]) for x in blocks)!=size:raise ValueError('incomplete archive accounting')
            dic=sum(x[4] for x in blocks);tokens=sum(x[1] for x in blocks)
        if a.cross_only and not cross and size!=27763104:raise ValueError('shared-preset control changed')
        wr.writerow((method,cap,rare,rent,reparse,share,extra,least,cutoff,cross,fee,size,row['encode_MBps'],row['decode_MBps'],dic,tokens))
        candidates.append((size,float(row['encode_MBps']),float(row['decode_MBps']),method,key))
if a.pilot:raise SystemExit(0)
qualified=[]
for level in range(22,a.min_level-1,-1):
    before=next(r for r in read(root/f'bench/results/presets/enwik8-screen-v1/level-{level}-enwik8.csv') if r['codec']=='zstd')
    baseline_size=int(before['compressed_bytes']);enc=100/float(before['compress_seconds']);dec=100/float(before['decompress_seconds'])
    # Avoid a slow candidate that merely clears a historical low zstd time.
    if level>=20:dec=max(dec,650)
    if level==16:dec=max(dec,757.2)
    eligible=[r for r in candidates if r[0]<baseline_size and r[1]>enc and r[2]>0.98*dec]
    if eligible:
        qualified.append((level,baseline_size,max(eligible,key=lambda r:min(r[1]/enc,r[2]/dec))))
(a.out/'eligibility.json').write_text(json.dumps(qualified,indent=2)+'\n')
if not qualified:raise SystemExit(0)
level,ceiling,winner=qualified[0];size,_,_,method,key=winner
paired=a.out/f'paired-{level}';paired.mkdir(exist_ok=True)
frozen=root/'bench/local/preset-binaries'/digest(compare)
if not frozen.exists():shutil.copy2(compare,frozen)
if digest(frozen)!=digest(compare):raise ValueError('binary mismatch')
trial=paired/'rounds.partial'
(paired/'manifest.json').write_text(json.dumps(dict(level=level,method=method,knobs=key,expected_bytes=size,reference_bytes=ceiling,
          threads=4,rounds=5,decodes=7,benchmark_sha256=digest(frozen),input_sha256=digest(src)),indent=2)+'\n')
subprocess.run([frozen,'4','5','both',src],env=dict(env,**key,BTR_TRIAL_METHOD=method,BTR_LEVEL=str(level),ZSTD_LEVEL=str(level),
               BTR_GRAM_JOB_KIB='24576',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(trial.resolve())),check=True)
rows=read(trial)
with (paired/'summary.csv').open('w') as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('codec','archive_bytes','encode_MBps','decode_MBps'))
    for c,want in [('btrcmpr',size),('zstd',ceiling)]:
        group=[r for r in rows if r['codec']==c]
        if len(group)!=5 or {int(r['round']) for r in group}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=want for r in group):raise ValueError('changed archive or missing round')
        wr.writerow((c,want,*(round(100/statistics.median(float(r[k]) for r in group),3) for k in ('compress_seconds','decompress_seconds'))))
trial.replace(paired/'rounds.csv')
