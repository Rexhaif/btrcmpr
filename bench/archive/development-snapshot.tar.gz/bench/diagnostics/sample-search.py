#!/usr/bin/env python3
"""Attribute retired-user-instruction samples to codec functions, after a verified warmup."""
import argparse
import bisect
from collections import Counter
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--zstd-debug", type=Path, required=True, help="debug ELF for the installed libzstd")
parser.add_argument("--level", type=int, default=10, choices=range(1, 23))
parser.add_argument("--repetitions", type=int, default=1, choices=range(1, 33))
parser.add_argument("--exe", type=Path, help="use an already built profile executable")
parser.add_argument("--operation", choices=("c", "d"), default="c", help="sample encode or decode; construction and verification are outside the interval")
parser.add_argument("--file", choices=("enwik8","mozilla","x-ray"), default="enwik8")
parser.add_argument("--event", choices=("instructions","branch-misses","cycles","r03","r17"), default="instructions")
parser.add_argument("--period", type=int, default=850009)
parser.add_argument("--verified-cell",type=Path,help="validate input, native profile driver, library and archive sizes against a counter run")
parser.add_argument("--summary",type=Path,help="also publish the text report outside the raw perf-data directory")
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
exe = args.exe.resolve() if args.exe else root / os.environ.get("CARGO_TARGET_DIR", "target") / "release/examples/profile"
debug = args.zstd_debug.resolve()
args.out.mkdir(parents=True, exist_ok=True)
if not args.exe:subprocess.run(["cargo", "build", "--release", "--offline", "--locked", "--features", "baseline",
                "--example", "profile"], cwd=root, check=True)
lib = re.search(r"libzstd\.so\.1 => (\S+)", subprocess.check_output(["ldd", exe], text=True))[1]
if args.verified_cell:
    check=json.loads((args.verified_cell/'manifest.json').read_text())
    def sha(path):
        with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
    if (check['operation']!=args.operation or check['level']!=args.level or check['workers']!=4 or
        sha(exe)!=check['profile_sha256'] or sha(lib)!=check['reference_library_sha256'] or
        sha(root/'bench/data'/args.file)!=check['input']):raise ValueError('profile, reference, workers or input changed')
    with (args.verified_cell/'per-byte.csv').open() as f:expected={r['codec']:r['archive_bytes'] for r in csv.DictReader(f)}
def build_id(path):
    return re.search(r"Build ID: ([0-9a-f]+)", subprocess.check_output(["readelf", "-n", path], text=True))[1]
if build_id(lib) != build_id(debug):
    raise SystemExit("different libzstd and debug ELF build IDs")
symbols = []
for line in subprocess.check_output(["nm", "-nS", debug], text=True).splitlines():
    m = re.fullmatch(r"([0-9a-f]+) ([0-9a-f]+) [tTi] (.+)", line)
    if m:
        symbols.append((int(m[1], 16), int(m[2], 16), m[3]))
symbols.sort()
starts = [s[0] for s in symbols]
perf = os.environ.get("PERF", "perf")
report = []
for codec in ("ours", "zstd"):
    data = args.out / (codec + ".data")
    with tempfile.TemporaryDirectory() as temp:
        ctl, ack = [Path(temp) / n for n in ("ctl", "ack")]
        os.mkfifo(ctl)
        os.mkfifo(ack)
        env = dict(os.environ, PERF_CTL=str(ctl), PERF_ACK=str(ack), BTR_LEVEL=str(args.level), ZSTD_WIDE="1")
        with (args.out / (codec + ".log")).open("w") as log:
            subprocess.run([perf, "record", "-q", "-e", args.event+":u", "-c", str(args.period), "-D", "-1",
                            "--control=fifo:" + str(ctl) + "," + str(ack), "-o", data.resolve(),
                            "--", exe, args.operation, codec, "bench/data/"+args.file, "4", str(args.repetitions)],
                           cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    if args.verified_cell and f'level={args.level} threads=4 archive_bytes={expected[codec]}\n' not in (args.out/(codec+'.log')).read_text():
        raise ValueError('sampler used a different archive from the native timing')
    samples = subprocess.check_output([perf, "script", "-i", data, "-F", "ip,sym,dsoff"], text=True)
    functions, addresses, rust = Counter(), Counter(), Counter()
    for line in samples.splitlines():
        m = re.fullmatch(r"\s*[0-9a-f]+ (.*?) \((.*?)(?:\+0x([0-9a-f]+))?\)", line)
        if not m:
            raise ValueError(f"unrecognized perf sample: {line}")
        name, dso, off = m.groups()
        if "libzstd.so" in dso and off:
            address = int(off, 16)
            i = bisect.bisect_right(starts, address) - 1
            if i >= 0:
                start, size, symbol = symbols[i]
                name = symbol if address < start + size else "other-libzstd"
            addresses[address] += 1
        elif codec=="ours" and off and Path(dso)==exe and args.verified_cell:
            rust[int(off,16)]+=1
        elif name == "[unknown]":
            name = Path(dso).name
        functions[name] += 1
    total = functions.total()
    event = "insn" if args.event=="instructions" else args.event
    report.append(f"{args.operation}-{codec} {event} samples {total}")
    def top(histogram, k):
        return [f"{100*v/total:6.2f}% {v:7d} {name}" for name, v in histogram.most_common(k)]
    report.extend(top(functions, 10))
    if rust:
        addr=list(rust);mapping=subprocess.run(["addr2line","-a","-i","-e",exe],
            input="".join(f"{a:x}\n" for a in addr),capture_output=True,check=True,text=True).stdout.splitlines()
        locations=Counter();current=None
        for row in mapping:
            if row.startswith('0x'):current=int(row,16)
            elif current is not None and (m:=re.search(r"/src/([^/:]+\.rs):(\d+)(?:\s|$)",row)) and (root/'src'/m[1]).is_file() and int(m[2]):
                locations[f'{m[1]}:{m[2]}']+=rust[current];current=None
        report.append("top Rust source positions (first project line in each inline stack)")
        report.extend(top(locations,12))
    if addresses:
        addr = list(addresses)
        lines = subprocess.run(["addr2line", "-e", debug], input="".join(f"{a:x}\n" for a in addr),
                               capture_output=True, check=True, text=True).stdout.splitlines()
        locations = Counter()
        for a, line in zip(addr, lines, strict=True):
            locations[Path(line.split(" ")[0]).name] += addresses[a]
        report.append("top source positions")
        report.extend(top(locations, 12))
    report.append("")
(args.out / ("encode-samples.txt" if args.operation=="c" else "decode-samples.txt")).write_text("\n".join(report) + "\n")
if args.summary:args.summary.write_text("\n".join(report)+"\n")
