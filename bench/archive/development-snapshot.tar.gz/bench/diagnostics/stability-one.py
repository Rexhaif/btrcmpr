#!/usr/bin/env python3
"""A predeclared 15-pair repeat on the same native level-one executable, independent of candidate selection."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
from statistics import median
import subprocess
from decode_gate import qualifies,DEFAULT_DECODE_LOSS_PCT
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--origin',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
r=Path(__file__).resolve().parents[2];orig=a.origin.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
if (out/'README.md').is_file():raise SystemExit('the predeclared repeat already completed')
spec=json.loads((orig/'manifest.json').read_text());exe=r/'bench/local/preset-binaries'/spec['benchmark_sha256'];clis={x['input']:x for x in rows(orig/'cli.csv')};rates={x['file']:x for x in rows(orig/'rates.csv')}
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',subprocess.check_output(['ldd',exe],text=True))[1])
if sha(exe)!=exe.name or sha(lib)!=spec['zstd_library_sha256'] or spec['threads']!=4 or spec['zstd_frame_policy']!='one independent frame per worker':raise ValueError('changed comparator or reference')
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','PROFILE_','ZSTD_'))};env.update(LC_ALL='C',BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7')
plan={'native_comparator_sha256':exe.name,'reference_sha256':sha(lib),'rounds':15,'decodes':7,'warmup':1,'workers':4,'inputs':['enwik8','mozilla'],'input_sha256':{n:spec['input_sha256'][n] for n in ('enwik8','mozilla')}}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');doc=[]
with (out/'summary.csv').open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('file','rounds','ours_bytes','zstd_bytes','ours_encode_MBps','zstd_encode_MBps','ours_decode_MBps','zstd_decode_MBps','encode_rounds_won','pass_at_5pct'))
    for name in plan['inputs']:
        src=r/'bench/data'/name;n=Decimal(src.stat().st_size);dst=out/(name+'.csv')
        if sha(src)!=spec['input_sha256'][name] or clis[name]['restored_identical']!='1':raise ValueError('changed corpus or missing independent restore')
        if not dst.exists():
            tmp=dst.with_suffix('.partial')
            with (out/(name+'.log')).open('w') as log:subprocess.run([exe,'4','15','both',src],cwd=r,env=dict(env,TRIALS_CSV=str(tmp)),stdout=log,stderr=subprocess.STDOUT,check=True)
            tmp.replace(dst)
        data=rows(dst)
        if len(data)!=30:raise ValueError('incomplete repeat')
        for initial,final in ((1,15),(1,5),(6,10),(11,15)):
            g=[];alltimes=[]
            for code,key in [('btrcmpr','btr_bytes'),('zstd','zstd_bytes')]:
                vals=sorted((x for x in data if x['codec']==code and initial<=int(x['round'])<=final),key=lambda x:int(x['round']))
                if [int(x['round']) for x in vals]!=list(range(initial,final+1)) or {int(v['compressed_bytes']) for v in vals}!={int(rates[name][key])}:raise ValueError('unexpected sizes or rounds')
                for v in vals:
                    if int(v['order'])!=((int(v['round'])%2) if code=='btrcmpr' else (1-int(v['round'])%2)):raise ValueError('not alternating')
                alltimes.append([Decimal(v['compress_seconds']) for v in vals]);g.append((int(vals[0]['compressed_bytes']),*(median(Decimal(v[k]) for v in vals) for k in ('compress_seconds','decompress_seconds'))))
            won=sum(x<z for x,z in zip(*alltimes,strict=True));(b,c,d),(bz,cz,dz)=g
            c,cz,d,dz=[n/x/1_000_000 for x in (c,cz,d,dz)];ok=qualifies(g,DEFAULT_DECODE_LOSS_PCT)
            w.writerow((name,f'{initial}-{final}',b,bz,*(round(v,3) for v in (c,cz,d,dz)),won,int(ok)))
            if initial==1 and final==15:doc.append(f"| [{name}]({name}.csv) | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {won} / 15 | {'Yes' if ok else 'No'} |")
(out/'README.md').write_text('\n'.join(['# Independent level-one repeat on the native executable','',
'One predeclared 15-pair run per input used the exact production comparator and zstd library. Both codecs ran on four workers in both directions, with one warmup and seven decodes per measurement. This study reports its own medians; it does not replace the original five-pair release audit.', '',
'| Input | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Corresponding encode rounds won | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
'The [summary](summary.csv) also shows the three consecutive groups of five, without rerunning or selecting a group. [Protocol and identities](plan.json), [original release results](../../native-fastest-1/README.md).','']))
