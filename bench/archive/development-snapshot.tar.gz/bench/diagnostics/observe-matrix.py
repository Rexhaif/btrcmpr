#!/usr/bin/env python3
"""Passively observe active codec programs in this repository during an existing matrix."""
import argparse,csv,datetime,json,os,re,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--scheduler',type=int,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];proc=Path('/proc');scheduler=proc/str(a.scheduler);dest=a.out.resolve();dest.mkdir(parents=True,exist_ok=True)
def state(p):return (p/'stat').read_text().rsplit(') ',1)[1].split()
def active():
 rows=[]
 for d in proc.glob('[0-9]*'):
    try:
        exe=(d/'exe').readlink()
        if not exe.is_relative_to(root) or not (exe.name in {'btrcmpr','compare','candidate','profile','decode_loop'} or re.fullmatch('(?:cli-|profile-)?[a-f0-9]{64}',exe.name)):continue
        av=(d/'cmdline').read_bytes().decode(errors='replace').rstrip('\0').split('\0')
        env=dict(x.split(b'=',1) for x in (d/'environ').read_bytes().split(b'\0') if b'=' in x)
        rows.append((int(d.name),exe.name,env.get(b'BTR_LEVEL',b'').decode(),Path(av[-1]).name))
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 return sorted(rows)
if b'/bench/diagnostics/integrated.py\0' not in (scheduler/'cmdline').read_bytes():raise SystemExit('not a native matrix scheduler')
birth=state(scheduler)[19];uniq=set();n=0;busy=0
with (dest/'remaining-host.csv').open('x',buffering=1) as f:
 writer=csv.writer(f,lineterminator='\n');writer.writerow(['utc','active_repository_codecs','pid','program','level','last_argument'])
 while True:
    try:s=state(scheduler)
    except FileNotFoundError:break
    if s[0]=='Z' or s[19]!=birth:break
    now=datetime.datetime.now(datetime.timezone.utc).isoformat();codecs=active();n+=1;busy+=bool(codecs)
    for row in codecs or [('','','','')]:writer.writerow((now,len(codecs),*row))
    if len(codecs)>1:
        uniq.update(x[0] for x in codecs)
        with (dest/'remaining-conflicts.jsonl').open('a') as w:w.write(json.dumps(dict(time=now,programs=codecs))+'\n')
    time.sleep(2)
(dest/'remaining-host.json').write_text(json.dumps(dict(samples=n,samples_with_active_codec=busy,observed_competing_pids=sorted(uniq),approximate_interval_seconds=2),indent=2)+'\n')
