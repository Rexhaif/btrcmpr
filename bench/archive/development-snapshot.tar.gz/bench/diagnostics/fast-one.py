#!/usr/bin/env python3
"""Screen sparse one-hash parsers and verify the best size-qualified level-1 candidates."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
binroot=a.bin_dir.resolve();candidate=binroot/'examples/candidate';compare=binroot/'compare';decode=binroot/'examples/decode_loop'
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};w=root/'bench/local/levels/lanes';rng=random.Random(9201)
def sha(f):
    with f.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
(out/'manifest.json').write_text(json.dumps(dict(workers=4,candidate_sha256=sha(candidate),compare_sha256=sha(compare),decode_sha256=sha(decode)),indent=2)+'\n')
with (out/'screen.csv').open('w',buffering=1) as sf,(out/'paired.csv').open('w',buffering=1) as pf:
    screen=csv.writer(sf,lineterminator='\n');screen.writerow(('file','parser','raw_policy','job_KiB','archive_bytes','encode_MBps','decode_MBps'))
    paired=csv.writer(pf,lineterminator='\n');paired.writerow(('file','parser','raw_policy','job_KiB','codec','bytes','encode_MBps','decode_MBps'))
    for name in ('enwik8','mozilla'):
        src=root/'bench/data'/name;smax={'enwik8':40669611,'mozilla':19963738}[name]
        default=256 if name=='enwik8' else 128;jobvar='BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB'
        def knobs(method,raw,job):return dict(BTR_FAST1=str(method),BTR_FAST_RAW=str(raw),**{jobvar:str(job)})
        cases=[(i,0,default) for i in range(11)]+[(0,1,default),(0,2,default)]
        for i in (2,3,4,5,6,7,8,9,10):
            cases.extend([(i,1,512 if name=='enwik8' else 192),(i,2,1024 if name=='enwik8' else 256)])
        rng.shuffle(cases);eligible=[]
        for m,raw,job in cases:
            r=subprocess.run([candidate,'4','1',src,'native'],env=dict(env,**knobs(m,raw,job)),capture_output=True,text=True,check=True)
            row=next(csv.DictReader(r.stdout.splitlines()));n=int(row['bytes']);c=float(row['encode_MBps']);d=float(row['decode_MBps'])
            screen.writerow((name,m,raw,job,n,c,d))
            if n<smax:eligible.append((c,d,n,m,raw,job))
        for c,d,n,m,raw,job in sorted(eligible,reverse=True)[:2]:
            key=knobs(m,raw,job);arc=w/'fast1.btr'
            r=subprocess.run([candidate,'4','1',src,'native'],env=dict(env,**key,BTR_CANDIDATE_FRAME=str(arc)),capture_output=True,text=True,check=True)
            subprocess.run([decode,arc,'1','3',src],env=env,check=True)
            if arc.stat().st_size!=n:raise ValueError('unstable archive')
            data=out/f'{name}-{m}-{raw}-{job}.csv'
            subprocess.run([compare,'4','5','both',src],env=dict(env,**key,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(data)),check=True)
            with data.open() as f:rows=list(csv.DictReader(f))
            for codec,size in [('btrcmpr',n),('zstd',smax)]:
                seq=[x for x in rows if x['codec']==codec]
                if len(seq)!=5 or {int(x['round']) for x in seq}!=set(range(1,6)) or any(int(x['compressed_bytes'])!=size for x in seq):raise ValueError('changed frame or incomplete measurement')
                paired.writerow((name,m,raw,job,codec,size,*(round(src.stat().st_size/1e6/statistics.median(float(x[k]) for x in seq),3) for k in ('compress_seconds','decompress_seconds'))))

# Collect the counters separately: timed comparisons above use the uninstrumented
# binaries. Inspect both the production matcher and the actual level-1 reference.
if (root/'bench/local/perf').exists():
    subprocess.run([sys.executable,root/'bench/diagnostics/phrase-pmu.py','--level','1','--out',
                    root/'bench/results/profiles/enwik8-general/fastest-preset'],
                   cwd=root,env=dict(env,PERF=str(root/'bench/local/perf')),check=True)
