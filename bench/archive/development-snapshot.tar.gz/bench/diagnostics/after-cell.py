#!/usr/bin/env python3
"""Reserve an idle slot after a live frozen trial, leaving its timing uninterrupted."""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--scheduler',type=int,help='matrix scheduler PID; omit to wait for this exact scheduled matrix');p.add_argument('--matrix',type=Path,required=True)
p.add_argument('--level',type=int,required=True);p.add_argument('--file',required=True);p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args();command=a.command[1:] if a.command[:1]==['--'] else a.command
if not command:raise SystemExit('missing command')
matrix=a.matrix.resolve()
def state(p):
    try:s=(p/'stat').read_text().rsplit(') ',1)[1].split()
    except FileNotFoundError:return None
    return s[0],int(s[19]) # kernel start time prevents signalling a reused PID
def args(p):return (p/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
pending=matrix/f'level-{a.level:02}-{a.file}.partial';done=pending.with_suffix('.csv')
if a.scheduler is None:
    while True:
        if done.exists():raise SystemExit('requested cell already finished; select another live slot')
        matches=[]
        if (matrix/'manifest.json').exists():
            for candidate in Path('/proc').glob('[0-9]*'):
                try:av=args(candidate)
                except (FileNotFoundError,ProcessLookupError,PermissionError):continue
                if len(av)>2 and av[1]==b'scripts/preset-matrix.py' and os.fsencode(matrix) in av:matches.append(int(candidate.name))
        if len(matches)>1:raise SystemExit('ambiguous matrix scheduler')
        if matches:a.scheduler=matches[0];break
        time.sleep(1)
proc=Path('/proc')/str(a.scheduler)
start=state(proc)
if not start or b'scripts/preset-matrix.py' not in args(proc) or os.fsencode(matrix) not in args(proc):raise SystemExit('not the expected matrix scheduler')
def same():
    s=state(proc);return s and s[0]!='Z' and start[1]==s[1]
while same():
    if done.exists():raise SystemExit('requested cell already finished; select another live slot')
    if pending.exists() and state(proc)[0]!='T':
        children=(proc/'task'/str(a.scheduler)/'children').read_text().split()
        if len(children)==1:
            child=Path('/proc')/children[0];cs=state(child)
            try:actual=args(child)
            except FileNotFoundError:continue
            if cs and actual[-2:]==[b'both',os.fsencode('bench/data/'+a.file)]:
                break
    time.sleep(.3)
else:raise SystemExit('matrix ended before selected cell')
os.kill(a.scheduler,signal.SIGSTOP)
try:
    # The measured process continues at full speed. A finished child may be
    # a zombie until the scheduler resumes and calls waitpid().
    while (s:=state(child)) and s[0]!='Z' and s[1]==cs[1]:time.sleep(.5)
    if not same() or state(proc)[0]!='T':raise SystemExit('scheduler identity or state changed')
    extra=(proc/'task'/str(a.scheduler)/'children').read_text().split()
    if any(b!=child.name and state(Path('/proc')/b) and state(Path('/proc')/b)[0]!='Z' for b in extra):raise SystemExit('another live trial appeared')
    subprocess.run(command,check=True)
finally:
    if same():os.kill(a.scheduler,signal.SIGCONT)
