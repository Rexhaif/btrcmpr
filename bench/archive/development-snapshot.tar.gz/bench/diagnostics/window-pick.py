#!/usr/bin/env python3
"""Screen bounded content-chosen match starts against the production six-byte matcher on enwik8."""
import argparse
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);name='enwik8'
if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('changed source')
ref=costs(read(l.base/'group-key/enwik8-1.csv'),'zstd')[0]
def cfg(x):
    mode,k=x
    return dict(l.env,BTR_WINDOW_PICK=str(mode),BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='5',BTR_FAST_COUNTS='2',BTR_FAST_PLAN='1',BTR_JOB_KIB=str(k))
sc,sw=l.report('screen','mode job_KiB bytes encode_MBps decode_MBps')
pa,pw=l.report('paired','mode job_KiB tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
pc,cw=l.report('counters','mode job_KiB codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
cases=[(m,k) for m in range(21) for k in (384,640)];random.Random(97351).shuffle(cases);pool={};doc=[]
with sc,pa,pc,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'test.btr'
    for case in cases:
        n,c,d=l.trial(name,cfg(case));pool[case]=(n,c,d);sw.writerow((*case,n,c,d))
    # Let cheaper indexes have a longer history before rejecting them on size.
    others=[x for x in cases if x[0] and x[1]==640]
    for x in sorted(others,key=lambda x:pool[x][0])[:4]+sorted(others,key=lambda x:pool[x][1] if pool[x][0]<ref*1.04 else 0,reverse=True)[:3]:
        case=(x[0],960)
        if case not in pool:
            n,c,d=l.trial(name,cfg(case));pool[case]=(n,c,d);sw.writerow((*case,n,c,d))
    pool_new=[x for x in pool if x[0]];small=[x for x in pool_new if pool[x][0]<ref]
    # Report a miss explicitly if none make size. Show both a fast match
    # finder and the cheapest archive when there is no eligible candidate.
    picks=[(0,384)]
    if small:picks.append(max(small,key=lambda x:(pool[x][2]>=1520,pool[x][1])))
    else:picks.append(min(pool_new,key=lambda x:pool[x][0]))
    near=[x for x in pool_new if pool[x][0]<ref*1.02] or pool_new
    picks.append(max(near,key=lambda x:pool[x][1]))
    def pair(x,tag):
        n,_,_=l.trial(name,cfg(x),arc)
        if n!=pool[x][0]:raise ValueError('archive changed')
        digest=sha(arc);l.restore(name,arc,l.env)
        if not x[0] and digest!='4990dab14148e8a9dd16622622d3208a9101dd67f9bc803dd013ec38ba2b2f37':raise ValueError('control changed')
        rates,ok=l.pair(name,cfg(x),n,ref,tag)
        for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*x,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
        (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
        return ok
    for idx,x in enumerate(dict.fromkeys(picks)):
        tag=f'enwik8-{idx}'
        cw.writerow((*x,'btrcmpr',pool[x][0],*l.perf(name,cfg(x),pool[x][0],tag)))
        if pair(x,tag) and x[0]:pair(x,tag+'-repeat')
    cw.writerow((0,384,'zstd',ref,*l.perf(name,l.env,ref,'zstd',codec='zstd')))
(l.out/'README.md').write_text('\n'.join(['# One match start chosen from two neighboring bytes','',
'The parser compares two nearby bytes and probes only the chosen start. It can extend a match backwards to recover the unprobed byte. A similar choice seeds the recent match tail so identical contents tend to propose the same starts. The decoder and command representation are unchanged. Mode zero is the six-byte production parser.','',
'| Raw trials | Mode / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'','Paired medians use five alternating full-file trials after warmup, four workers on either codec, and seven decodes per trial. Every finalist was separately restored and compared with the original. [PMU counters](counters.csv), [all screens](screen.csv), [archive identities](paired.csv), [manifest](manifest.json).','']))
