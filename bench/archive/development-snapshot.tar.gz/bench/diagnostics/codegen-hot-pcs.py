#!/usr/bin/env python3
"""Disassemble the hottest already-recorded ARM branch-miss sample addresses."""
from collections import Counter
import csv
import json
from pathlib import Path
import re
import subprocess
from level_one_lab import sha
root=Path(__file__).resolve().parents[2];lanes=root/'bench/local/levels/lanes';perf=root/'bench/local/perf';out=root/'bench/results/presets/research/release-codegen/samples';spec=json.loads((out/'identity.json').read_text())
exe=lanes/'low-codegen/thin-pgo/target/release/examples/profile'
if sha(exe)!=spec['profile_binary_sha256']:raise ValueError('wrong profiled program')
# perf dso offsets are usable as llvm/objdump PCs for this ELF only if its
# executable load segment has the same virtual address and file offset.
ph=subprocess.check_output(['readelf','-lW',exe],text=True)
if not any(re.match(r'\s*LOAD\s+',l) and 'R E' in l and int(l.split()[1],16)==int(l.split()[2],16) for l in ph.splitlines()):raise ValueError('different ELF address mapping')
for name in ('enwik8','mozilla'):
    tag=name+'-branch-misses';data=lanes/('thin-pgo-samples-'+tag)/'ours.data'
    if sha(data)!=spec['samples'][tag]['raw_data_sha256']['ours']:raise ValueError('recording changed')
    v=subprocess.check_output([perf,'script','-i',data,'-F','ip,sym,dsoff'],text=True)
    h=Counter();total=0;symbol='btrcmpr::lz::encode_level' if name=='enwik8' else 'btrcmpr::object::archive_lz'
    for l in v.splitlines():
        if l.strip():total+=1
        m=re.fullmatch(r'\s*[0-9a-f]+ '+re.escape(symbol)+r' \((.*)\+0x([0-9a-f]+)\)',l)
        if m and Path(m[1])==exe:h[int(m[2],16)]+=1
    if total!=spec['samples'][tag]['all_samples'] or not h:raise ValueError('inconsistent samples')
    doc=['# Hottest sampled ARM PCs: '+name,'',
        'The event is retired user branch misses. These are sampled PCs in the inlined native LZ encoder, not precise branch records. The surrounding instructions show what the machine was doing near the interrupt; the nearest conditional is not necessarily the cause. Percentages use all samples in the encoder run, including symbols outside this LZ function.','',
        '| Sampled PC | Samples | Share | ARM instruction at sampled PC |','|---|---:|---:|---|'];windows=[]
    for pc,n in h.most_common(10):
        raw=subprocess.check_output(['objdump','-d','--no-show-raw-insn',f'--start-address={pc-20}',f'--stop-address={pc+16}',exe],text=True)
        ins={}
        for line in raw.splitlines():
            m=re.match(r'^\s*([a-f0-9]+):\s*(.*)$',line)
            if m:ins[int(m[1],16)]=m[2].split('//')[0].strip()
        if pc not in ins:raise ValueError('instruction missing')
        doc.append(f'| 0x{pc:x} | {n:,} | {100*n/total:.2f}% | `{ins[pc]}` |')
        windows.extend(['',f'PC 0x{pc:x} ({n:,} samples):','','```asm',*(f'{"=>" if addr==pc else "  "} {addr:08x}  {op}' for addr,op in ins.items()),'```'])
    (out/(name+'-arm.md')).write_text('\n'.join(doc+windows+[''])+'\n')
