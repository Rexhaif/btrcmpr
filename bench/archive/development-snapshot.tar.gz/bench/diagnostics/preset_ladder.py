"""Publish the per-level reader view from the same paired trials used by the audit."""
from decimal import Decimal
import json
import os
from pathlib import Path
import tempfile

from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies, write_csv
from level_one_lab import costs, read


def write_native_rates(series):
    """Keep all three raw measures directly comparable on one executable."""
    from paired_variation import write as write_variation
    write_variation(series)
    rows = read(series / 'verified-cells.csv')
    text = ['# Matched zstd rates per file', '',
            f'Comparator `{series.name}`, four workers per codec in each direction. '
            'Every numeric pair is **Rust / zstd**. Ratio is original bytes divided by archive bytes. '
            'Speeds are original decimal MB per second. A dash means the paired run and standalone '
            'round trip have not both been verified yet. [Relative throughput and bytes saved](preset-ladder.md). [Variation between individual pairs](paired-rounds.md).']
    # The comparator wraps its four independent zstd frames in the same
    # 20-byte header and four four-byte lengths. Removing that directory
    # preserves the exact zstd payloads (the standard format allows concatenation).
    if rows:
        tight=min(rows,key=lambda r:int(r['zstd_bytes'])-int(r['btr_bytes']))
        margin=int(tight['zstd_bytes'])-int(tight['btr_bytes'])-36
        text.extend(['', 'The zstd size includes 36 bytes of outer framing (20-byte header and four lengths). '
                     'Concatenating the very same four zstd frames would omit those bytes. '
                     f'The smallest size margin against that concatenation is **{margin:+,} bytes** '
                     f'(zstd minus Rust, {tight["file"]} level {tight["level"]}). '
                     'This calculation does not estimate a different single-stream zstd compression.'])
    for name in ('enwik8', 'x-ray', 'mozilla'):
        text.extend(['', f'## {name}', '', '| Preset | Ratio | Encode MB/s | Decode MB/s |',
                     '|---:|---:|---:|---:|'])
        data = {int(r['level']): r for r in rows if r['file'] == name}
        for lv in range(1, 23):
            r = data.get(lv)
            if r is None:
                text.append(f'| {lv} | — | — | — |')
                continue
            cells = [r['btr_' + k] + ' / ' + r['zstd_' + k] for k in ('ratio', 'encode_MBps', 'decode_MBps')]
            text.append(f'| [{lv}]({r["individual_trials"]}) | ' + ' | '.join(cells) + ' |')
    with tempfile.NamedTemporaryFile(mode='w', dir=series, delete=False) as tmp:
        tmp.write('\n'.join(text) + '\n')
    os.replace(tmp.name, series / 'rates.md')


def write(base):
    names = ('enwik8', 'x-ray', 'mozilla')
    cells = {}
    output = []
    for row in read(base / 'decode-tolerance-cells.csv'):
        lv, name = int(row['level']), row['file']
        relative = row['latest_trials']
        path = base / relative
        trials = [r for r in read(path) if Path(r['file']).name == name]
        raw, = {int(r['raw_bytes']) for r in trials}
        b, z = (costs(trials, c) for c in ('btrcmpr', 'zstd'))
        passed = qualifies((b, z), DEFAULT_DECODE_LOSS_PCT)
        if ((b[0], z[0], int(passed)) !=
            tuple(int(row[k]) for k in ('btr_bytes', 'zstd_bytes', 'pass_at_5pct'))):
            raise ValueError(f'ledger disagrees with {relative}')
        model = path.parent / 'manifest.json'
        digest = json.loads(model.read_text()).get('benchmark_sha256', '') if model.exists() else ''
        mb = Decimal(raw) / 1000000
        ratios = (Decimal(raw) / b[0], Decimal(raw) / z[0])
        rates = (mb / b[1], mb / z[1], mb / b[2], mb / z[2])
        factors = (z[1] / b[1], z[2] / b[2])
        key = (lv, name)
        if key in cells:
            raise ValueError(f'duplicate cell: {key}')
        cells[key] = (ratios, factors, passed, b[0])
        output.append((lv, name, raw, b[0], z[0], *(f'{r:.8f}' for r in (*ratios, *rates, *factors)),
                       int(passed), digest, relative))
    if set(cells) != {(lv, name) for lv in range(1, 23) for name in names}:
        raise ValueError('the complete ladder needs all 66 paired comparisons')
    write_csv(base / 'preset-ladder.csv',
              ('level', 'file', 'raw_bytes', 'rust_bytes', 'zstd_bytes', 'rust_ratio', 'zstd_ratio',
               'rust_encode_MBps', 'zstd_encode_MBps', 'rust_decode_MBps', 'zstd_decode_MBps',
               'encode_speedup', 'decode_speedup', 'pass_at_5pct', 'comparator_sha256', 'raw_trials'),
              sorted(output))
    lines = ['# All 22 compression presets', '',
             'Each cell uses the latest complete comparison on that file and numeric level: four workers for each codec in both directions, with one independent zstd frame per worker. '
             'These measurements span executables. The [single-executable audit](decode-tolerance-builds.csv) separately tracks release coverage. '
             'The [downloadable table](preset-ladder.csv) gives both archive sizes, absolute speeds in decimal MB/s, trial paths, and the comparator hash where recorded.', '',
             '**Compression ratio (original bytes / archive bytes), Rust / zstd.** Higher is better. '
             'A file passes if the Rust archive is strictly smaller, encoding strictly faster, and decoding reaches at least 95% of zstd throughput on the same file.', '',
             '| Preset | enwik8 | x-ray | Mozilla | Files passing |', '|---:|---:|---:|---:|---:|']
    for lv in range(1, 23):
        group = [cells[lv, n] for n in names]
        pairs = [f'{a:.4f} / {b:.4f}' for (a, b), _, _, _ in group]
        lines.append('| ' + ' | '.join([str(lv), *pairs, f'{sum(c[2] for c in group)} / 3']) + ' |')
    lines.extend(['', '**Throughput relative to zstd on the same run, encode / decode.** '
                  '1.000 means equal throughput; 2.000 means twice as many original bytes per second. '
                  'Verdicts use unrounded medians.', '',
                  '| Preset | enwik8 | x-ray | Mozilla |', '|---:|---:|---:|---:|'])
    for lv in range(1, 23):
        pairs = [f'{a:.3f} / {b:.3f}' for _, (a, b), _, _ in (cells[lv, n] for n in names)]
        lines.append('| ' + ' | '.join([str(lv), *pairs]) + ' |')
    lines.extend(['', '**How the archive sizes change as the level increases:**', ''])
    for n in names:
        sizes = [cells[lv, n][3] for lv in range(1, 23)]
        increases = [f'{i} → {i+1}: {a:,} → {b:,} bytes' for i, (a, b) in
                     enumerate(zip(sizes, sizes[1:]), 1) if b > a]
        note = '; increases at ' + '; '.join(increases) if increases else '; no increases'
        lines.append(f'- {n}: {len(set(sizes))} distinct archive sizes{note}.')
    with tempfile.NamedTemporaryFile(mode='w', dir=base, delete=False) as tmp:
        tmp.write('\n'.join(lines) + '\n')
    os.replace(tmp.name, base / 'preset-ladder.md')
