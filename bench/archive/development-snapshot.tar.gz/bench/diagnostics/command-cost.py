#!/usr/bin/env python3
"""Run the record-cost and match-command experiments serially on one frozen executable."""
import argparse
import random
import subprocess
import sys
import tempfile
from pathlib import Path
from level_one_lab import Lab,costs,read,sha

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();r=Path(__file__).resolve().parents[2]
record=a.out.resolve().with_name('record-cost')
if not (record/'README.md').exists():
    subprocess.run([sys.executable,r/'bench/diagnostics/record-cost.py','--workspace',a.workspace,'--bin-dir',a.bin_dir,'--out',record],cwd=r,check=True)
l=Lab(a.workspace,a.bin_dir,a.out);name='enwik8';raw=(l.data/name).stat().st_size
if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('wrong input')
ref,_,refdec=costs(read(l.base/'group-key/enwik8-1.csv'),'zstd');floor=.95*raw/float(refdec)/1_000_000
def cfg(case):
    search,k,h,w=case;key=5 if search=='prefix' else 0
    return dict(l.env,BTR_GROUP_OFFSETS='2',BTR_QUICK_KEY=str(key),BTR_GROUP_KEY=str(key),BTR_PROBE_GROUP='2' if search=='group' else '0',BTR_JOB_KIB=str(k),
                BTR_FAST_COUNTS='2' if h else '0',BTR_FAST_PLAN=str(h),BTR_COMMAND_WRITER=str(w))
sf,sw=l.report('screen','parser KiB planner writer bytes encode_MBps decode_MBps')
cf,cw=l.report('counters','parser KiB planner writer bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
pf,pw=l.report('paired','parser KiB planner writer archive_sha256 codec bytes encode_MBps decode_MBps pass_at_5pct');doc=[]
with sf,cf,pf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as t:
    arc=Path(t)/'full.btr'
    original=next(r for r in read(l.base/'group-key/paired.csv') if r['file']==name and r['key']=='5' and r['KiB']=='256' and r['codec']=='btrcmpr' and r['batch_mode']=='2')
    for w in [0,1,2,3]:
        case=('prefix',256,0,w);n,_,_=l.trial(name,cfg(case),arc)
        if sha(arc)!=original['archive_sha256']:raise ValueError('command writer changed archive')
        l.restore(name,arc,l.env)
        cw.writerow((*case,n,*l.perf(name,cfg(case),n,f'prefix-{w}')))
    cases=[(q,k,h,w) for q in ('prefix','group') for k,h in ((256,0),(320,0),(384,1),(384,3),(448,1),(512,3)) for w in range(4)]
    random.Random(1517).shuffle(cases);seen={}
    for case in cases:
        z=l.trial(name,cfg(case));sw.writerow((*case,*z));seen[case]=z
    pool=[]
    for (q,k,h,w),(n,c,d) in seen.items():
        if n!=seen[q,k,h,0][0]:raise ValueError('changed candidate size')
        if w and n<ref:pool.append((d>=floor,c,-n,(q,k,h,w)))
    if not pool:raise ValueError('no smaller configuration')
    pick=max(pool)[-1];fixed=('prefix',256,0,pick[-1])
    for rank,cap in enumerate(dict.fromkeys([fixed,pick])):
        q,k,h,w=cap;expected=None
        for policy in [0,w]:
            case=(q,k,h,policy);e=cfg(case);n,_,_=l.trial(name,e,arc);digest=sha(arc)
            if expected is None:expected=digest
            elif digest!=expected:raise ValueError('finalist bytes differ')
            l.restore(name,arc,l.env);tag=f'enwik8-{rank}-{policy}';rates,ok=l.pair(name,e,n,ref,tag)
            for codec,(nb,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*case,digest if codec=='btrcmpr' else '',codec,nb,round(c,3),round(d,3),int(ok)))
            (nr,c,d),(nz,cz,dz)=rates;doc.append(f'| [{q}, {k} KiB]({tag}.csv) | {h} / {policy} | {nr:,} / {nz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
(l.out/'README.md').write_text('\n'.join(['# Writing short level-one commands without a branch for every empty run','',
    'Every accepted match has eight readable source bytes at the literal anchor. The writer can copy those bytes even for an empty literal run, while revealing only the actual initialized run in the stream. It can also write both one-byte overflow lengths into reserved space and advance by the number that the command needs. Longer lengths use the original variable-length encoding.','',
    '| enwik8 parser | Planner / writer | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
    'All writers reproduced the original full archive for a given parser and restored it with three workers. Each paired comparison used four workers per codec, five alternating warmed pairs and seven decodes per measurement. [Counters](counters.csv), [screen](screen.csv), [paired rates](paired.csv), [manifest](manifest.json).','']))
