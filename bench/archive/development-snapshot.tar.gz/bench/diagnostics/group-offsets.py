#!/usr/bin/env python3
"""Measure batching the unchanged native offsets: exact wire checks, gated PMU, paired zstd."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
for name in ('workspace','bin-dir','out'):p.add_argument('--'+name,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];src=a.workspace.resolve();ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def run(cmd,e):return subprocess.run(cmd,cwd=src,env=e,text=True,capture_output=True,check=True)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def output(name,columns):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(columns.split());return f,w
known={r['file']:(r['verified_sha256'],int(r['archive_bytes'])) for r in read(root/'bench/results/presets/research/palette-write/checks.csv') if r['mode']=='0'}
spec=dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,zstd_frame_policy='one independent frame per worker',
    binaries={b:sha(ex/b) for b in ('examples/profile','examples/candidate','examples/decode_loop','compare')},
    input_sha256={name:sha(root/'bench/data'/name) for name in known},
    source_sha256={str(f.relative_to(src)):sha(f) for f in sorted((src/'src').rglob('*.rs'))})
lib=re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',ex/'compare'],env).stdout)
if not lib:raise ValueError('reference library not found')
spec['zstd_library_sha256']=sha(Path(lib[1]))
(out/'manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
events=['instructions:u','cycles:u','branches:u','branch-misses:u']
cf,cw=output('counters','file commands_per_batch archive_bytes archive_sha256 instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte counter_MBps')
pf,pw=output('paired','file commands_per_batch codec bytes encode_MBps decode_MBps')
with cf,pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as work:
    arc=Path(work)/'sample.btr'
    for name,reference in [('enwik8',40669611),('mozilla',19963738)]:
        corpus=root/'bench/data'/name;digest,nb=known[name];cycles={}
        if name=='mozilla':order=[3,1,0,2]
        else:order=[2,0,3,1]
        for mode in order:
            batch=(0,8,32,64)[mode];e=dict(env,BTR_GROUP_OFFSETS=str(mode),BTR_LEVEL='1')
            sample=next(csv.DictReader(run([ex/'examples/candidate','4','1',corpus,'native'],dict(e,BTR_CANDIDATE_FRAME=str(arc))).stdout.splitlines()))
            if int(sample['bytes'])!=nb or arc.stat().st_size!=nb or sha(arc)!=digest:raise ValueError('native archive differs')
            run([ex/'examples/decode_loop',arc,'1','3',corpus],env)
            n=10
            with tempfile.TemporaryDirectory() as t:
                ctl,ack=(Path(t)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                r=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',ex/'examples/profile','c','ours',corpus,'4',str(n)],dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            (out/f'{name}-{batch}-perf.txt').write_text(r.stderr)
            if f'archive_bytes={nb}\n' not in r.stderr:raise ValueError('profiled different archive')
            counts={v[2]:float(v[0])/(corpus.stat().st_size*n) for line in r.stderr.splitlines() if len(v:=line.split(';'))>2 and v[2] in events}
            cw.writerow((name,batch,nb,digest,*(round(counts[k],4) for k in events),re.search(r'([\d.]+) MB/s',r.stderr)[1]))
            cycles[mode]=counts['cycles:u']
        best=min((1,2,3),key=cycles.get)
        # Paired comparisons of both baseline and fastest experimental batch,
        # even if every batch is worse. Frozen archive size is identical.
        for mode in (0,best):
            batch=(0,8,32,64)[mode];raw=out/f'{name}-{batch}.partial'
            run([ex/'compare','4','5','both',corpus],dict(env,BTR_GROUP_OFFSETS=str(mode),BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            data=read(raw)
            for codec,target in [('btrcmpr',nb),('zstd',reference)]:
                seq=[r for r in data if r['codec']==codec]
                if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=target for r in seq):raise ValueError('invalid paired measurement')
                pw.writerow((name,batch,codec,target,*(round(corpus.stat().st_size/1e6/statistics.median(float(r[k]) for r in seq),3) for k in ('compress_seconds','decompress_seconds'))))
            raw.replace(raw.with_suffix('.csv'))
counts=read(out/'counters.csv');pairs=read(out/'paired.csv')
doc=['# Writing identical level-1 distances in small batches','',
     'The match finder, literal and length format, block boundaries and decoder stay the same. The encoder collects 8, 32 or 64 distances locally; ARM NEON compares each against the preceding three absolute distances, then packs the extra bytes. Every setting reproduced the native full-file SHA-256 and independently restored the input on three decoder workers.','',
     '| File | Distances per batch | Instructions/input byte | Aggregate CPU cycles/input byte | Branch misses/input byte |','|---|---:|---:|---:|---:|']
for r in sorted(counts,key=lambda v:(v['file'],int(v['commands_per_batch']))):
    doc.append('| '+' | '.join([r['file'],r['commands_per_batch'] if r['commands_per_batch']!='0' else 'Native',*(r[k] for k in ['instructions_per_byte','cycles_per_byte','branch_misses_per_byte'])])+' |')
doc+=['','The [gated perf totals](counters.csv) cover ten full encodes per setting. The table below compares both native and the best experimental batch by CPU cycles against a fresh zstd level-1 measurement: five alternating pairs after warmup, four workers, seven decodes per measurement. A factor above 1 means Rust was faster.','',
      '| File | Distances per batch | Bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Encode vs zstd | Decode vs zstd |','|---|---:|---:|---:|---:|---:|---:|']
for i in range(0,len(pairs),2):
    rust,zstd=pairs[i:i+2]
    if rust['codec']!='btrcmpr' or zstd['codec']!='zstd' or rust['file']!=zstd['file']:raise ValueError('unexpected paired summary')
    batch=rust['commands_per_batch'];name=rust['file'];fields=['bytes','encode_MBps','decode_MBps']
    datum=[f"{float(rust[k]):,.0f} / {float(zstd[k]):,.0f}" if k=='bytes' else f"{float(rust[k]):,.2f} / {float(zstd[k]):,.2f}" for k in fields]
    doc.append('| '+' | '.join([f'[{name}]({name}-{batch}.csv)',batch if batch!='0' else 'Native',*datum,*(f'{float(rust[k])/float(zstd[k]):.3f}×' for k in fields[1:])])+' |')
doc+=['','The [manifest](manifest.json) identifies the two inputs, Rust sources, executables and reference library. This research report does not count as production preset verification.','']
tmp=out/'README.partial';tmp.write_text('\n'.join(doc));tmp.replace(out/'README.md')
