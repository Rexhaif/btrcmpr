// Appended to wordreparse.rs by cross-parse.py in an isolated research build.
// Build one trie of all transmitted phrases. Each worker reparses its own
// original leaf sequence with a common model; no path can cross a job edge.
pub(super) fn across(terms: &[Term], rules: &[(u32,u32)], roots: &mut [Vec<u32>], rounds: usize, threads: usize) -> crate::Result<()> {
    let leaf=terms.len()-rules.len();
    if rules.is_empty() || rounds==0 {return Ok(())}
    let mut trie=Trie::new(leaf,rules.len());
    let mut length=vec![1usize;terms.len()];
    let mut stack=[0u32;65];
    let leaves=|id:u32,stack:&mut [u32;65],f:&mut dyn FnMut(u32)| {
        stack[0]=id;
        let mut sp=1;
        while sp!=0 {
            sp-=1;
            let v=stack[sp];
            if (v as usize)<leaf {f(v)} else {
                let (a,b)=rules[v as usize-leaf];stack[sp]=b;stack[sp+1]=a;sp+=2;
            }
        }
    };
    for (j,&(a,b)) in rules.iter().enumerate() {
        let id=leaf+j;length[id]=length[a as usize]+length[b as usize];
        if terms[id].pos==u32::MAX {continue}
        let mut node=u32::MAX;
        leaves(id as u32,&mut stack,&mut |v| {node=if node==u32::MAX {v} else {trie.child(node,v)}});
        trie.term[node as usize]=id as u32;
    }
    let mut raw=Vec::with_capacity(roots.len());
    for old in roots.iter() {
        let count:usize=old.iter().map(|&r|length[r as usize]).sum();
        let mut stream=Vec::with_capacity(count);
        for &r in old {leaves(r,&mut stack,&mut |v|stream.push(v))}
        raw.push(stream);
    }
    let penalty=crate::tuning("BTR_DAG_PENALTY",10,0,128) as u64;
    let rent=crate::tuning("BTR_CROSS_RENT",0,0,4096) as u64;
    for _ in 0..rounds {
        let mut freq=vec![0u32;terms.len()];
        let n=roots.iter().map(Vec::len).sum::<usize>() as f64;
        for part in roots.iter() {for &r in part {freq[r as usize]+=1}}
        let fees:Vec<_>=freq.iter().map(|&f| {
            let scale=u64::from(f.max(1));
            ((n/scale as f64).log2()*16.).round().max(1.) as u64+penalty+rent/scale
        }).collect();
        crate::parallel(threads.min(roots.len()),roots.iter_mut().zip(raw.iter()),|(old,stream)| {
            let mut back=vec![0u32;stream.len()+1];
            let mut best=[u64::MAX;128];
            best[0]=0;
            for (i,&v) in stream.iter().enumerate() {
                let start=std::mem::replace(&mut best[i&127],u64::MAX);
                let mut node=v;let mut end=i+1;
                loop {
                    let word=trie.term[node as usize];
                    if word!=u32::MAX {
                        let c=start+fees[word as usize];let b=&mut best[end&127];
                        if c<*b {*b=c;back[end]=word}
                    }
                    let Some(&next)=stream.get(end) else {break};
                    let Some(found)=trie.get(node,next) else {break};
                    node=found;end+=1;
                }
            }
            let mut at=stream.len();old.clear();
            while at>0 {let v=back[at];old.push(v);at-=length[v as usize]}
            old.reverse();Ok(())
        })?;
    }
    Ok(())
}

#[cfg(test)]
mod cross_tests {
    use super::*;
    #[test]
    fn a_phrase_learned_in_one_job_can_reparse_another_without_crossing_its_end() {
        let terms = [Term {pos:0,len:1}, Term {pos:1,len:1}, Term {pos:0,len:2}];
        let mut second = [0u32,1].repeat(1000);
        second.push(0);
        let mut roots = vec![vec![2;1000],second];
        across(&terms,&[(0,1)],&mut roots,2,2).unwrap();
        assert_eq!(roots[0],vec![2;1000]);
        assert_eq!(roots[1].len(),1001);
        assert_eq!(&roots[1][..1000],roots[0]);
        assert_eq!(roots[1][1000],0);
    }
}
