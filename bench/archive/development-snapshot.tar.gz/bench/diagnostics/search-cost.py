#!/usr/bin/env python3
"""Extract per-input-byte PMU counters for the isolated zstd level-10 search experiment."""
import argparse
import csv
import re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("folder", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
n = (root / "bench/data/enwik8").stat().st_size
with (args.folder / "per-byte.csv").open("w") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(("zstd_level", "search_log", "workers", "repetitions", "archive_bytes",
                "instructions_per_byte", "cycles_per_byte", "branches_per_byte", "counter_run_MBps"))
    for log in (3, 4, 5):
        raw = (args.folder / f"search-{log}.txt").read_text()
        if log == 5 and "byte-identical to ordinary level 10" not in raw:
            raise ValueError("missing byte-identical baseline check")
        reps = int(re.search(r"enwik8 4 (\d+)'", raw)[1])
        def count(event):
            v = re.search(r"^\s*([\d,]+)\s+" + event + r":u\s", raw, re.M)[1]
            return round(int(v.replace(",", "")) / (n * reps), 3)
        w.writerow((10, log, 4, reps, re.search(r"archive_bytes=(\d+)", raw)[1],
                    count("instructions"), count("cycles"), count("branches"),
                    re.search(r"^([\d.]+) MB/s", raw, re.M)[1]))
