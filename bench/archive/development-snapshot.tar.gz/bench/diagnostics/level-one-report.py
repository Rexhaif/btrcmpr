#!/usr/bin/env python3
"""Collect matched level-one comparisons without treating different builds as a single result."""
import csv
import os
from pathlib import Path
from statistics import median
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';report=base/'level-one-candidates.md'
def rows(f):
    with f.open() as h:return list(csv.DictReader(h))
def link(f):return os.path.relpath(f,report.parent)
table=[]
def add(label,name,a,b,c,cz,d,dz,src):
    n,z=int(a),int(b);raw={'enwik8':100_000_000,'mozilla':51_220_480,'x-ray':8_474_240}[name]
    table.append(f'| {name} | [{label}]({link(src)}) | {raw/n:.4f} / {raw/z:.4f} | {float(c):,.1f} / {float(cz):,.1f} | {float(d):,.1f} / {float(dz):,.1f} |')
for name in ('enwik8','mozilla','x-ray'):
    for label,loc in [('Previous production preset',next(base.glob('integrated/620e*/l01'))),('Current production preset',base/'native-fastest-1')]:
        r=next(r for r in rows(loc/'rates.csv') if r['file']==name);add(label,name,r['btr_bytes'],r['zstd_bytes'],r['btr_encode_MBps'],r['zstd_encode_MBps'],r['btr_decode_MBps'],r['zstd_decode_MBps'],loc/f'level-01-{name}.csv')
release=list(table);table=[]
for name,tag,loc,label in [('enwik8','enwik8-1-0','command-cost','Batched distances and greedy palette'),('mozilla','mozilla-1-2','record-cost','Seven-byte direct lookup and exact record prices'),('mozilla','mozilla-3','fastest-mix','Batched seven-byte lookup'),('mozilla','mozilla-repeat','fastest-mix','Same batched lookup, independent repeat'),('enwik8','enwik8-1','window-pick','One content-selected match start'),('mozilla','mozilla-repeat','record-pick','Sampled record predictor, independent repeat')]:
    folder=base/'research'/loc;raw=rows(folder/(tag+'.csv'));n=int(raw[0]['raw_bytes'])
    r,z=[(int(rs[0]['compressed_bytes']),*(n/median(float(v[k]) for v in rs)/1e6 for k in ('compress_seconds','decompress_seconds'))) for rs in ([v for v in raw if v['codec']==codec] for codec in ('btrcmpr','zstd'))]
    add(label,name,r[0],z[0],r[1],z[1],r[2],z[2],folder/(tag+'.csv'))
paired=rows(base/'native-fastest-1/level-01-mozilla.csv');rounds={}
for r in paired:rounds.setdefault(r['round'],{})[r['codec']]=float(r['compress_seconds'])
wins=sum(v['btrcmpr']<v['zstd'] for v in rounds.values())
stability=base/'research/native-stability-1';repeat=[]
if (stability/'README.md').is_file():
    repeat=['','The independent [15-pair native repeat](research/native-stability-1/README.md) held the executable, corpus and reference fixed. On Mozilla the overall medians passed every requirement; the original five-pair run missed encode. On enwik8 both experiments missed encode.','']
    for r in rows(stability/'summary.csv'):
        if r['rounds']=='1-15':
            last=table;table=[]
            add('Production, 15-pair repeat',r['file'],r['ours_bytes'],r['zstd_bytes'],r['ours_encode_MBps'],r['zstd_encode_MBps'],r['ours_decode_MBps'],r['zstd_decode_MBps'],stability/(r['file']+'.csv'))
            repeat.append(table[0]);table=last
hdr=['| Input | Encoder | Compression ratio, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |','|---|---|---:|---:|---:|']
report.write_text('\n'.join(['# Level-one candidates against matched zstd','',
'Both compressors and decompressors ran with four workers. Each row has its own zstd 1.5.7 baseline: five alternating paired rounds after warmup, seven decodes per timing, and one independent frame per zstd worker. Ratio is original bytes divided by archive bytes; larger is better. The acceptance rule requires strictly better ratio and encoding speed with decode throughput at least 95% of zstd’s on that file.', '',
'The current production level-1 preset is smaller than zstd on every input. X-ray passes all three requirements. Mozilla misses only on encode by 0.74%; enwik8 misses only on encode by 5.86%. Both production executables restored all three inputs with their standalone Rust CLI. The x-ray archive bytes are identical between versions.', '',*hdr,*release,'',
f'Mozilla illustrates the size of the timing variation: Rust won {wins} of {len(rounds)} corresponding production encode rounds, but the predeclared comparison takes the median time for each encoder and zstd had the lower median. The verdict remains a miss.', '',
'The following research runs isolate alternatives. Two independent comparisons of the same Mozilla configuration straddle the encode threshold; neither a single favorable trial nor the best result from a different executable establishes a production win.', '',*hdr,*table,*repeat[:3],*(hdr if repeat else []),*repeat[3:],'',
'[Native source and archive identity](native-fastest-1/README.md) · [Current hardware counters](../profiles/enwik8-general/native-fastest-1/README.md) · [Why instruction counts change with level](../profiles/enwik8-general/encoder-comparison.md) · [All 66 cells across builds](decode-tolerance.md).','']))
