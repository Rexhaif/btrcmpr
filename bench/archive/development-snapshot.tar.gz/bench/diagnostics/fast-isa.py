#!/usr/bin/env python3
"""Check the full-file impact of fast Alpha instruction representations on Mozilla level 1."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--bin-dir',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
exe=a.bin_dir.resolve();src=root/'bench/data/mozilla';n=src.stat().st_size;limit=19963738
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=dict(source_sha256=sha(src),threads=4,binaries={b:sha(exe/b) for b in
    ['compare','examples/candidate','examples/decode_loop']},codec_sha256=sha(root/'src/fastisa.rs'),driver_sha256=sha(Path(__file__)))
finished=out/'complete.json'
if finished.exists():
    old=json.loads(finished.read_text())
    if old['identity']==identity and all((out/k).is_file() and sha(out/k)==v for k,v in old['results'].items()):
        raise SystemExit(0)
(out/'manifest.json').write_text(json.dumps(identity,indent=2)+'\n')
with (out/'screen.csv').open('w', buffering=1) as f,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('isa','generic_parser','text_job_KiB','archive_bytes','encode_MBps','decode_MBps'))
    cases=[(m,0,128) for m in range(34)]+[(m,8,kib) for m in (0,1,2,3,5,6,7,9,11,14,17,19,22,31,33) for kib in (128,256)]
    random.Random(851).shuffle(cases)
    eligible=[];arc=Path(tmp)/'frame.btr'
    for m,parser,kib in cases:
        knobs=dict(env,BTR_FAST_ISA=str(m),BTR_FAST1=str(parser),BTR_TEXT_KIB=str(kib))
        run=subprocess.run([exe/'examples/candidate','4','1',src,'native'],env=knobs,capture_output=True,text=True,check=True)
        row=next(csv.DictReader(run.stdout.splitlines()));b=int(row['bytes']);c=float(row['encode_MBps']);d=float(row['decode_MBps'])
        wr.writerow((m,parser,kib,b,c,d))
        if m and b<limit:eligible.append((min(c/745.,d/1660.),c,b,m,parser,kib))
    if eligible:
        with (out/'paired.csv').open('w',buffering=1) as f:
            paired=csv.writer(f,lineterminator='\n');paired.writerow(('isa','generic_parser','text_job_KiB','codec','bytes','encode_MBps','decode_MBps'))
            for _,_,b,m,parser,kib in sorted(eligible,reverse=True)[:2]:
                key=dict(env,BTR_FAST_ISA=str(m),BTR_FAST1=str(parser),BTR_TEXT_KIB=str(kib))
                subprocess.run([exe/'examples/candidate','4','1',src,'native'],env=dict(key,BTR_CANDIDATE_FRAME=str(arc)),check=True)
                if arc.stat().st_size!=b:raise ValueError('independent archive differs')
                subprocess.run([exe/'examples/decode_loop',arc,'1','3',src],env=env,check=True)
                path=out/f'{m}-{parser}-{kib}.partial'
                subprocess.run([exe/'compare','4','5','both',src],env=dict(key,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',DEC_ITERS='7',WARMUP='1',TRIALS_CSV=str(path)),check=True)
                with path.open() as r:rows=list(csv.DictReader(r))
                for codec,size in [('btrcmpr',b),('zstd',limit)]:
                    seq=[r for r in rows if r['codec']==codec]
                    if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=size for r in seq):raise ValueError('unexpected full-file pair')
                    paired.writerow((m,parser,kib,codec,size,*(round(n/1e6/statistics.median(float(r[k]) for r in seq),3) for k in ('compress_seconds','decompress_seconds'))))
                path.replace(path.with_suffix('.csv'))
receipt=out/'complete.partial'
receipt.write_text(json.dumps(dict(identity=identity,results={p.name:sha(p) for p in out.glob('*.csv')}),indent=2)+'\n')
receipt.replace(finished)
