#!/usr/bin/env python3
"""Train full shared dictionaries with the most promising verified storage policies."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
root=Path(__file__).resolve().parents[2];bench=root/'bench/results/presets';study=bench/'research/dictionary-storage'
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sizes=[r for r in rows(study/'sizes.csv') if r['native_level']=='19']
book=min(sizes,key=lambda r:(int(r['archive_bytes']),int(r['methods'])))
aliases=[r for r in rows(study/'page-aliases.csv') if int(r['archive_bytes'])<int(book['archive_bytes']) and float(r['decode_MBps'])>635]
page=min(aliases,key=lambda r:int(r['archive_bytes'])) if aliases else None
binroot=a.bin_dir.resolve();exe=binroot/'examples/candidate';decode=binroot/'examples/decode_loop';src=root/'bench/data/enwik8'
w=root/'bench/local/levels/lanes/book-storage';w.mkdir(exist_ok=True,parents=True)
ref={int(r['level']):int(r['zstd_bytes']) for r in rows(bench/'zstd-sizes.csv') if r['file']=='enwik8'}
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};mode=int(book['methods'])
(out/'manifest.json').write_text(json.dumps(dict(executable=digest(exe),decoder=digest(decode),source=digest(src),threads=4,
    verified_storage=book,eligible_page=page,note='one full encode plus four decodes per case; independent three-worker restoration'),indent=2)+'\n')
cases=[(32768,131072,0,0),(32768,196608,0,0),(32768,262144,0,0),(49152,163840,0,0),
       (49152,262144,0,0),(65536,196608,0,0),(16384,196608,0,0)]
if page:
    cases[1:1]=[(32768,131072,int(page['page_log']),int(page['alias_cap'])),(32768,196608,int(page['page_log']),int(page['alias_cap']))]
with (out/'screen.csv').open('w',buffering=1) as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('local_merges','pooled_merges','minimum_count','dictionary_methods','conditional_heads','alias_page_log','alias_count','archive_bytes','encode_MBps','decode_MBps','last_zstd_level_smaller_than','archive_sha256'))
    for j,(cap,extra,log,alias) in enumerate(cases):
        arc=w/f'frontier-{j}.btr';params=dict(BTR_DAG_CAP=str(cap),BTR_DAG_WIDTH='64',BTR_SHARED_JOBS='4',BTR_SHARED_EXTRA=str(extra),BTR_SHARED_MIN='2',
            BTR_BOOK_PACK=str(mode),BTR_DAG_HEADS='1',BTR_ALIAS_LOG=str(log),BTR_ALIAS_CAP=str(max(1,alias)),BTR_CANDIDATE_FRAME=str(arc))
        r=subprocess.run([exe,'4','22',src,'shared-dag'],env=dict(env,**params),capture_output=True,text=True,check=True)
        row=next(csv.DictReader(r.stdout.splitlines()));n=int(row['bytes']);h=digest(arc)
        subprocess.run([decode,arc,'1','3',src],env=env,check=True)
        if j==0 and (n!=int(book['archive_bytes']) or h!=book['archive_sha256']):raise ValueError('live encoder differs from fixed dictionary rewrite')
        if page and (cap,extra,log)==(32768,131072,int(page['page_log'])) and h!=page['archive_sha256']:raise ValueError('live encoder differs from fixed-page rewrite')
        wr.writerow((cap,extra,2,mode,1,log,alias,n,row['encode_MBps'],row['decode_MBps'],max((lv for lv,lim in ref.items() if n<lim),default=0),h))
