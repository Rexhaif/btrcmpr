#!/usr/bin/env python3
"""Size and throughput as command page size varies, preserving the byte-match history."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];a.out.mkdir(exist_ok=True,parents=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
target=root/env.get('CARGO_TARGET_DIR','target')
subprocess.run(['cargo','build','--release','--offline','--locked','--features','baseline,research','--example','candidate','--bin','compare','--example','decode_loop'],cwd=root,env=env,check=True)
candidate=target/'release/examples/candidate';paired=target/'release/compare';decoder=target/'release/examples/decode_loop'
src=root/'bench/data/enwik8';arc=root/'bench/local/levels/lanes/page-control.btr'
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
(a.out/'manifest.json').write_text(json.dumps(dict(threads=4,bytes=src.stat().st_size,input_sha256=digest(src),
        candidate_sha256=digest(candidate),compare_sha256=digest(paired),decoder_sha256=digest(decoder)),indent=2)+'\n')
with (a.out/'screen.csv').open('w',buffering=1) as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('level','chunk_KiB','page_log','tag_distance_coder','context_literals','archive_bytes','encode_MBps','decode_MBps'))
    for lv,method,kib in [(8,'hwin-local8',24576),(6,'selected',5120)]:
        chosen=[]
        for log,coder,ctx in [(0,0,0),(15,0,0),(16,0,0),(17,0,0),(16,1,0),(16,2,0),(16,3,0),(16,0,1)]:
            knobs=dict(BTR_LOCAL_PAGE_LOG=str(log),BTR_LOCAL_PAGE_CODER=str(coder),BTR_LOCAL_LITERAL=str(ctx))
            run=subprocess.run([candidate,'4',str(lv),src,method],env=dict(env,**knobs,BLOCK_KIB=str(kib),PRESET_ALIGN='1',BTR_CANDIDATE_FRAME=str(arc)),text=True,capture_output=True,check=True)
            r=next(csv.DictReader(run.stdout.splitlines()));n=int(r['bytes'])
            subprocess.run([decoder,arc,'1','3',src],env=env,check=True)
            wr.writerow((lv,kib,log,coder,ctx,n,r['encode_MBps'],r['decode_MBps']))
            if log and n < {6:32648306,8:31639517}[lv] and float(r['encode_MBps'])>{6:28.,8:20.5}[lv]:
                chosen.append((float(r['decode_MBps']),n,knobs))
        if not chosen:continue
        speed,n,knobs=max(chosen,key=lambda x:x[0])
        if speed<{6:940,8:880}[lv]:continue
        out=a.out/f'paired-{lv}';out.mkdir(exist_ok=True);trials=out/'rounds.partial'
        settings=dict(env,**knobs,BTR_TRIAL_METHOD=method,BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),BTR_GRAM_JOB_KIB=str(kib),
                      ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(trials.resolve()))
        (out/'settings.json').write_text(json.dumps(knobs,indent=2)+'\n')
        subprocess.run([paired,'4','5','both',src],env=settings,check=True)
        rows=list(csv.DictReader(trials.open()));summary=[]
        for codec,size in [('btrcmpr',n),('zstd',{6:32648306,8:31639517}[lv])]:
            seq=[x for x in rows if x['codec']==codec]
            if len(seq)!=5 or {int(x['round']) for x in seq}!=set(range(1,6)) or any(int(x['compressed_bytes'])!=size for x in seq):raise ValueError('trial does not reproduce candidate')
            summary.append((codec,size,*(round(100/statistics.median(float(x[k]) for x in seq),3) for k in ('compress_seconds','decompress_seconds'))))
        trials.replace(out/'rounds.csv')
        with (out/'summary.csv').open('w') as summary_file:
            s=csv.writer(summary_file,lineterminator='\n');s.writerow(('codec','archive_bytes','encode_MBps','decode_MBps'));s.writerows(summary)
subprocess.run([sys.executable,root/'bench/diagnostics/span-endtoend.py','--out',a.out.parent/'distance-lanes'],cwd=root,env=env,check=True)
