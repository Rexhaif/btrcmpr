#!/usr/bin/env python3
"""Measure each worker in the mixed codec, then try the split predicted by those timings."""
import argparse
import csv
from collections import defaultdict
import os
from pathlib import Path
import statistics
import subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--out", type=Path, required=True)
p.add_argument("--intermediate", action="store_true", help="split only part of the byte jobs")
a = p.parse_args()
baseline = [(1,170,10,32768),(1,180,11,32768),(2,385,9,16384),(2,370,8,32768)]
def run(w, jobs, share, byte, kib, flat, partial=0):
    env = dict(os.environ, BTR_LEVEL="14", ZSTD_LEVEL="14", ZSTD_WIDE="1",
               WARMUP="0", DEC_ITERS="7", BTR_TRIAL_METHOD="mix", BTR_JOB_TRACE="1",
               BTR_GRAM_CAP="4096", BTR_GRAM_WIDTH="32", BTR_MIX_JOBS=str(jobs),
               BTR_MIX_SHARE=str(share), BTR_MIX_PLAIN=str(byte), BTR_MIX_KIB=str(kib),
               BTR_MIX_FLAT=str(flat), BTR_MIX_PARTIAL=str(partial))
    trial = subprocess.run(["target/release/compare","4","1","ours","bench/data/enwik8"],
                           env=env, capture_output=True, text=True, check=True)
    if "research method=mix" not in trial.stderr:
        raise ValueError("research comparator required")
    trial_result = next(csv.DictReader(trial.stdout.splitlines()))
    worker = defaultdict(list)
    for line in trial.stderr.splitlines():
        if line.startswith("job,"):
            _, ix, size, _, method, ns = line.split(",")
            worker[int(ix)].append((int(size), int(method), int(ns)))
    if not worker or any(len(v)!=7 for v in worker.values()):
        raise ValueError("incomplete job traces")
    detail = []
    for j in sorted(worker):
        v=worker[j]; size, method, _ = v[0]
        ns=statistics.median(s[2] for s in v)
        detail.append((size,method,ns))
    times = ";".join(f"{size}:{method}:{ns/1e6:.2f}" for size,method,ns in detail)
    word = [row for row in detail if row[1] == 43]
    byte_jobs = [row for row in detail if row[1] != 43]
    if not word or not byte_jobs:
        raise ValueError(detail)
    word_rate = jobs * sum(row[0] for row in word) / sum(row[2] for row in word)
    byte_rate = (4-jobs) * sum(row[0] for row in byte_jobs) / sum(row[2] for row in byte_jobs)
    ideal = round(word_rate/(word_rate+byte_rate)*200)*5
    w.writerow((jobs,share,byte,kib,flat,trial_result["compressed_bytes"],trial_result["compress_MBps"],
                trial_result["decompress_MBps"],ideal,times,partial))
    return ideal
with a.out.open("w", buffering=1) as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(("grammar_workers","grammar_permille","byte_preset","byte_chunk_KiB","flat",
                "bytes","encode_MBps","decode_MBps","predicted_permille","jobs_bytes_mode_ms","split_byte_jobs"))
    if a.intermediate:
        for jobs,share,byte,kib,partial in [
            (1,205,10,15360,1),(1,210,10,16384,2),(1,210,11,16384,2),
            (1,220,11,14336,1),(2,390,8,16384,1),(2,385,9,16384,1),
        ]:
            run(w,jobs,share,byte,kib,1,partial)
        raise SystemExit(0)
    for jobs, share, byte, kib in baseline:
        optimal = run(w,jobs,share,byte,kib,0)
        if optimal != share:
            run(w,jobs,optimal,byte,kib,0)
        run(w,jobs,optimal,byte,12288,1)
