#!/usr/bin/env python3
"""Compare block-local successor prediction with the original word grammar."""
import argparse,csv,os,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out",type=Path,required=True)
args=parser.parse_args()
exe=root/"target/release/examples/candidate"
src=root/"bench/data/enwik8"
with args.out.open("w",buffering=1) as f,tempfile.TemporaryDirectory() as tmp:
    w=csv.writer(f,lineterminator="\n");w.writerow(("bytes_in","merges","width","paired","candidate","bytes","encode_MBps","decode_MBps"))
    def trial(data,cap,width,pair,methods,save=None):
        env=dict(os.environ,BLOCK_KIB="24576",PRESET_ALIGN="1",BTR_GRAM_CAP=str(cap),BTR_GRAM_WIDTH=str(width),BTR_WORD_PAIRED=str(pair))
        if save is not None:env["BTR_CANDIDATE_FRAME"]=str(save)
        p=subprocess.run([exe,"4","22",data,*methods],env=env,text=True,capture_output=True)
        if p.returncode:raise RuntimeError(p.stdout+p.stderr)
        for row in csv.DictReader(p.stdout.splitlines()):
            w.writerow((data.stat().st_size,cap,width,pair,row["candidate"],row["bytes"],row["encode_MBps"],row["decode_MBps"]))
    sample=Path(tmp)/"4m"
    with src.open("rb") as source:sample.write_bytes(source.read(4<<20))
    kinds=["lex-successor","lex-successor-flat","lex-successor-bytes"]
    trial(sample,4096,32,0,kinds);trial(sample,4096,32,1,kinds)
    trial(src,4096,32,0,["lex-grammar"],args.out.parent/"grammar-4096.btr")
    for cap,width,pair in [(4096,32,0),(0,32,0),(16384,48,0),(4096,32,1)]:
        trial(src,cap,width,pair,kinds)
