"""Compare match choices at an identical window, without sharing parser output between encoders.

Run against a BTR_TRACE .seq and its original input. libzstd is used as a
reference only; its sequences are never fed into the Rust encoder.
"""
import argparse
import csv
import ctypes as ct
import ctypes.util
from pathlib import Path
import sys
import numpy as np

p=argparse.ArgumentParser()
p.add_argument("raw",type=Path);p.add_argument("btr_trace",type=Path);p.add_argument("--level",type=int,default=22);args=p.parse_args()
raw=args.raw.read_bytes(); n=len(raw)
lib=ct.CDLL(ct.util.find_library("zstd"))
def bind(name,result,*inputs):
    f=getattr(lib,name);f.argtypes=inputs;f.restype=result;return f
ptr=ct.c_void_p;sz=ct.c_size_t
new=bind("ZSTD_createCCtx",ptr);free=bind("ZSTD_freeCCtx",sz,ptr)
setparam=bind("ZSTD_CCtx_setParameter",sz,ptr,ct.c_int,ct.c_int)
bound=bind("ZSTD_sequenceBound",sz,sz);gen=bind("ZSTD_generateSequences",sz,ptr,ptr,sz,ptr,sz)
error=bind("ZSTD_isError",ct.c_uint,sz);error_name=bind("ZSTD_getErrorName",ct.c_char_p,sz)
def check(v):
    if error(v):raise ValueError(error_name(v))
    return v
c=new()
if not c:raise MemoryError("reference compressor")
try:
    check(setparam(c,100,args.level))
    arr=np.empty((bound(n),4),dtype=np.uint32)
    ct_data=ct.create_string_buffer(raw)
    size=check(gen(c,arr.ctypes.data,len(arr),ct_data,n))
finally:free(c)
off,ll,ml,_rep=arr[:size].astype(np.int64).T
ends=np.cumsum(ll+ml);assert ends[-1]==n
has=ml>0;z=np.column_stack((ends[has]-ml[has],ml[has],off[has]))
ours=np.fromfile(args.btr_trace,dtype='<u4').reshape(-1,3).astype(np.int64)
w=csv.writer(sys.stdout,lineterminator='\n')
w.writerow(('parser','input_bytes','match_count','literal_bytes','match_length_mean','matched_bytes_offset_under_256','matched_bytes_offset_over_64KiB','matched_bytes_offset_over_1MiB','matches_len_3_or_4','recent_three_distances'))
for name,seq in [('btrcmpr',ours),('zstd',z)]:
    at,m,o=seq.T
    assert np.all((m>0)&(o>0)&(o<=at)&(at+m<=n)) and np.all(at[1:]>=at[:-1]+m[:-1])
    for i in np.linspace(0,len(at)-1,min(5000,len(at)),dtype=int):
        a,k,d=at[i],m[i],o[i]
        assert raw[a:a+k]==raw[a-d:a-d+k]
    reps=[np.r_[[-1]*i,o[:-i]] for i in [1,2,3]]
    w.writerow((name,n,len(at),n-int(m.sum()),round(float(m.mean()),3),m[o<256].sum(),m[o>=65536].sum(),m[o>=1048576].sum(),(m<=4).sum(),int(((o==reps[0])|(o==reps[1])|(o==reps[2])).sum())))
