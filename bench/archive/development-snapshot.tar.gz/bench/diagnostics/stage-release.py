#!/usr/bin/env python3
"""Stage a standalone ARM binary only after all 22 levels pass on its exact executable."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from level_one_lab import costs, read, sha
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('origin',type=Path,help='native result directory with comparator and CLI identity')
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
base=root/'bench/results/presets';origin=a.origin.resolve()
if origin.parent!=base:raise ValueError('expected a native results directory')
meta=json.loads((origin/'manifest.json').read_text());code=json.loads((origin/'codegen.json').read_text())
digest=meta['benchmark_sha256'];lib=meta['zstd_library_sha256']
if digest!=code['comparator'] or not all(re.fullmatch('[a-f0-9]{64}',x) for x in (digest,lib,code['cli'])):raise ValueError('wrong executable identities')
frozen=root/'bench/local/preset-binaries';cmp=frozen/digest;cli=frozen/('cli-'+code['cli'])
if sha(cmp)!=digest or sha(cli)!=code['cli']:raise ValueError('frozen executable has changed')
series=base/'integrated'/digest;cells=read(series/'verified-cells.csv')
expected={(lv,n) for lv in range(1,23) for n in ('enwik8','x-ray','mozilla')}
if {(int(r['level']),r['file']) for r in cells}!=expected or len(cells)!=66:raise SystemExit(f'Not staged: this executable has {len(cells)}/66 standalone-verified cells.')
if {str(f.relative_to(root)):sha(f) for f in (root/'src').rglob('*.rs')}!=meta['source_sha256']:
    raise ValueError('working Rust source differs from the measured release')
crate=json.loads(subprocess.check_output(['cargo','metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=root,text=True))
if len(crate['packages'])!=1 or crate['packages'][0]['dependencies']:raise ValueError('standalone crate dependency set changed')
proofs={};local_results=[]
for r in cells:
    individual=(series/r['individual_trials']).resolve();directory=individual.parent
    if directory!=origin and series not in directory.parents:raise ValueError('unexpected archive proof directory')
    if directory not in proofs:proofs[directory]={(q['level'],q['input']):q for q in read(directory/'cli.csv')}
    q=proofs[directory][r['level'],r['file']]
    if (q.get('cli_sha256')!=code['cli'] or q['archive_sha256']!=r['archive_sha256'] or q['cli_bytes']!=r['btr_bytes'] or
        q['restored_identical']!='1' or q['source_sha256']!=meta['input_sha256'][r['file']]):
        raise ValueError('standalone proof is missing or belongs to a different CLI')
    raw=read(individual);b,z=(costs(raw,c) for c in ('btrcmpr','zstd'))
    if (b[0]!=int(q['cli_bytes']) or z[0]!=int(r['zstd_bytes']) or not qualifies((b,z),DEFAULT_DECODE_LOSS_PCT)):
        raise SystemExit(f'Not staged: this series misses a requirement on {r["file"]} at level {r["level"]}.')
    local_results.append(dict(file=r['file'],level=int(r['level']),saved_bytes=z[0]-b[0],encode_vs_zstd=float(z[1]/b[1]),
                              decode_vs_zstd=float(z[2]/b[2]),strict=qualifies((b,z),0),archive_sha256=q['archive_sha256'],
                              trials=os.path.relpath(individual,origin),trials_sha256=sha(individual)))
# A known foreign sweep corrupted one specific trial before it was replaced.
# Do not certify an earlier or overlapping copy, even if its medians passed.
incident=base/'research/host-overlap-15'
if origin.name=='native-combined-1' and (incident/'retired.json').is_file():
    repeat=json.loads((incident/'replacement.json').read_text())
    cell,=(r for r in cells if r['level']=='15' and r['file']=='enwik8')
    if (repeat['comparator']!=digest or repeat['libzstd']!=lib or repeat['concurrent_repo_benchmark_executables'] or
        repeat['comparison_process_scans']<1 or sha(series/cell['individual_trials'])!=sha(incident/'replacement-clean.csv')):
        raise ValueError('level 15 must use the isolated replacement trial')
    conflicts=incident/'remaining-conflicts.jsonl'
    if conflicts.is_file() and conflicts.stat().st_size:
        raise ValueError('repository codec overlap recorded in the remaining matrix; inspect before staging')
with tempfile.TemporaryDirectory() as td:
    subprocess.run([sys.executable,root/'bench/diagnostics/preset-audit.py','--out',td,'--require-binary',digest],check=True)
    hit,=(r for r in read(Path(td)/'decode-tolerance-builds.csv') if r['comparator_sha256']==digest and r['libzstd_sha256']==lib and r['allow_decode_loss_pct']=='5')
    if hit['complete']!='1' or hit['pass_and_cli_verified']!='66':raise SystemExit('Not staged: one or more raw comparisons missed the target.')
if any(sha(root/'bench/data'/name)!=value for name,value in meta['input_sha256'].items()):raise ValueError('benchmark input bytes changed')
linked=lambda f:subprocess.check_output(['ldd',f],text=True)
if 'libzstd' in linked(cli) or sha(Path(re.search(r'libzstd\.so\.1 => (\S+)',linked(cmp))[1]))!=lib:raise ValueError('standalone or reference linkage changed')
target=root/'target/verified'/('all-22-'+digest[:12])
result=dict(comparator_sha256=digest,cli_sha256=code['cli'],libzstd_sha256=lib,input_sha256=meta['input_sha256'],workers=meta['threads'],
            passed_on_this_binary=66,strict_wins=sum(r['strict'] for r in local_results),allow_decode_loss_pct=5,
            rounds=meta['rounds'],warmup_rounds=meta['warmup_rounds'],decodes_per_observation=meta['decodes'],zstd_frame_policy=meta['zstd_frame_policy'],
            report=str((series/'preset-ladder.md').relative_to(root)),local_binary=str((target/'btrcmpr').relative_to(root)))
if origin.name=='native-combined-1':
    from decimal import Decimal
    from statistics import median
    repeat=base/'research/selected-stability-15';m=json.loads((repeat/'manifest.json').read_text())
    if (m['benchmark_sha256']!=digest or m['zstd_library_sha256']!=lib or m['rounds']!=15 or
        m['threads']!=4 or m['decodes']!=7 or m['files']!=['enwik8','mozilla']):
        raise ValueError('long repeat does not identify the same released codecs and policy')
    longer=[]
    for f in m['files']:
        rows=read(repeat/f'level-01-{f}.csv');values=[]
        for tag in ('btrcmpr','zstd'):
            sub=sorted((r for r in rows if r['codec']==tag),key=lambda r:int(r['round']))
            if len(sub)!=15 or any(int(r['round'])!=j or int(r['order'])!=((j if tag=='btrcmpr' else j+1)%2) for j,r in enumerate(sub,1)):
                raise ValueError('bad long repeat pair')
            n,={int(r['compressed_bytes']) for r in sub}
            values.append((n,*(median(Decimal(r[k]) for r in sub) for k in ('compress_seconds','decompress_seconds'))))
        q,=(v for v in read(repeat/'cli.csv') if v['input']==f);cell,=(v for v in cells if v['level']=='1' and v['file']==f)
        if (not qualifies(values,DEFAULT_DECODE_LOSS_PCT) or q['cli_sha256']!=code['cli'] or q['restored_identical']!='1' or
            q['source_sha256']!=meta['input_sha256'][f] or q['archive_sha256']!=cell['archive_sha256'] or
            (values[0][0],values[1][0])!=(int(cell['btr_bytes']),int(cell['zstd_bytes']))):
            raise ValueError('long repeat result or archive changed')
        longer.append(dict(file=f,rounds=15,encode_vs_zstd=float(values[1][1]/values[0][1]),
                           decode_vs_zstd=float(values[1][2]/values[0][2]),trials_sha256=sha(repeat/f'level-01-{f}.csv')))
    result['independent_level_one_repeats']=longer
if (origin/'compiler.profdata').is_file():
    model=origin/'compiler.profdata'
    if sha(model)!=code['profile_data_sha256']:raise ValueError('packaged compiler profile changed')
    result['compiler_profile']=str(model.relative_to(root));result['compiler_profile_sha256']=code['profile_data_sha256']
target.mkdir(exist_ok=True,parents=True)
def stage(src,dst,digest):
    if not dst.is_file():
        with tempfile.NamedTemporaryFile(dir=target,delete=False) as f:tmp=Path(f.name)
        try:
            shutil.copy2(src,tmp)
            if sha(tmp)!=digest:raise ValueError('staging source changed during the copy')
            os.replace(tmp,dst)
        finally:tmp.unlink(missing_ok=True)
    if sha(dst)!=digest:raise ValueError('staged file has wrong identity: '+str(dst))
stage(cli,target/'btrcmpr',code['cli'])
if 'compiler_profile' in result:stage(model,target/model.name,code['profile_data_sha256'])
def save(path,value):
    with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,delete=False) as tmp:
        json.dump(value,tmp,indent=2);tmp.write('\n')
    os.replace(tmp.name,path)
save(target/'verified.json',result)
save(origin/'release.json',dict(result,cells=local_results))
from release_brief import publish
publish(cells,local_results,origin,target)
print('Verified standalone codec:',target/'btrcmpr')
