#!/usr/bin/env python3
"""Measure independent training with transmitted phrase dictionaries shared between workers."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--prepare',action='store_true')
p.add_argument('--min-level',type=int,choices=range(16,23),default=16)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
w=root/'bench/local/levels/lanes/shared-phrase'
a.out.mkdir(exist_ok=True,parents=True)
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
if a.prepare:
    w.mkdir(parents=True,exist_ok=True)
    for folder in ('src','examples','.cargo','bench/support'):shutil.copytree(root/folder,w/folder,dirs_exist_ok=True)
    for name in ('Cargo.toml','Cargo.lock'):shutil.copy2(root/name,w/name)
    (w/'src/shared-format.inc').unlink(missing_ok=True)
    raise SystemExit(0)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_') and k!='CARGO_TARGET_DIR'}
subprocess.run(['cargo','test','--all-features','--offline','--locked','--lib'],cwd=w,check=True,env=env)
subprocess.run(['cargo','build','--release','--features','baseline,research','--offline','--locked','--example','candidate','--example','decode_loop','--bin','compare'],cwd=w,check=True,env=env)
src=root/'bench/data/enwik8';candidate=w/'target/release/examples/candidate';loop=w/'target/release/examples/decode_loop'
(a.out/'manifest.json').write_text(json.dumps(dict(candidate=digest(candidate),decoder=digest(loop),input=digest(src),
    source={f.name:digest(f) for f in sorted((w/'src').glob('*')) if f.is_file()},threads=4),indent=2)+'\n')
with (a.out/'screen.csv').open('w',buffering=1) as f:
    out=csv.writer(f,lineterminator='\n');out.writerow(('cap','max_width','jobs_per_dictionary','archive_bytes','encode_MBps','decode_MBps','wire_sha256'))
    for cap,width,share in [(16384,48,1),(16384,48,2),(16384,48,4),(32768,64,2),(32768,64,4),(65536,64,2),(65536,64,4),(131072,64,4)]:
        path=w/f'wire-{share}.btr'
        run=subprocess.run([candidate,'4','22',src,'shared-dag'],env=dict(env,BTR_DAG_CAP=str(cap),BTR_DAG_WIDTH=str(width),BTR_SHARED_JOBS=str(share),BTR_CANDIDATE_FRAME=str(path)),capture_output=True,text=True)
        if run.returncode:raise RuntimeError(run.stderr+run.stdout)
        r=next(csv.DictReader(run.stdout.splitlines()))
        subprocess.run([loop,path,'2','3',src],check=True,env=env)
        out.writerow((cap,width,share,r['bytes'],r['encode_MBps'],r['decode_MBps'],digest(path)))
subprocess.run([sys.executable,root/'bench/diagnostics/piece-screen.py','--workspace',w,
                '--min-level',str(a.min_level),'--out',a.out.parent/'rare-phrases'],cwd=root,check=True,env=env)
cross=[sys.executable,root/'bench/diagnostics/cross-parse.py','--min-level',str(a.min_level),'--out',a.out.parent/'cross-phrases']
subprocess.run([*cross,'--prepare'],cwd=root,check=True,env=env)
subprocess.run(cross,cwd=root,check=True,env=env)
