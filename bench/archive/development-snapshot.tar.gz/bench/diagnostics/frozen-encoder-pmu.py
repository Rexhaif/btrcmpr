#!/usr/bin/env python3
"""Measure hardware counters for compression or decompression from a confirmed production cell."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path)
p.add_argument('--matrix',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
p.add_argument('--level',type=int,choices=range(1,23),required=True);p.add_argument('--file',choices=['enwik8','mozilla','x-ray'],required=True)
p.add_argument('--repetitions',type=int,default=2)
p.add_argument('--operation',choices=('c','d'),default='c',help='compress or decompress during the counter interval')
p.add_argument('--target-dir',type=Path,help='reuse the target directory belonging to this snapshot')
p.add_argument('--frozen-profile',type=Path,help='use the already compiled, native profile driver named in --codegen')
p.add_argument('--codegen',type=Path,help='native build identities for the comparator and profile driver')
p.add_argument('--arm-cache',action='store_true',help='also count Cortex-A76 L1D and L2D cache refills')
a=p.parse_args()
if bool(a.frozen_profile)!=bool(a.codegen):p.error('--frozen-profile and --codegen must be supplied together')
root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
if a.repetitions<1:raise ValueError('no repetitions')
meta=json.loads((a.matrix/'manifest.json').read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check():
    if meta['source_sha256']!={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}:raise ValueError('snapshot sources differ')
check()
ref=root/'bench/local/preset-binaries'/meta['benchmark_sha256']
if sha(ref)!=ref.name:raise ValueError('unverified comparator')
src=snap/'bench/data'/a.file
if sha(src)!=meta['input_sha256'][a.file]:raise ValueError('wrong input')
with (a.matrix/f'level-{a.level:02}-{a.file}.csv').open() as f:rows=list(csv.DictReader(f))
sizes={k:{int(r['compressed_bytes']) for r in rows if r['codec']==k} for k in ('zstd','btrcmpr')}
if len(rows)!=2*meta['rounds'] or any(len(v)!=1 for v in sizes.values()):raise ValueError('unverified sizes')
sizes={k:v.pop() for k,v in sizes.items()}
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','PROFILE_')) and k!='CARGO_TARGET_DIR'}
target=a.target_dir.resolve() if a.target_dir else root/'bench/local/levels/lanes/frozen-pmu-target';env.update(LC_ALL='C',BTR_LEVEL=str(a.level),ZSTD_WIDE='1',CARGO_TARGET_DIR=str(target))
if a.frozen_profile:
    exe=a.frozen_profile.resolve();stamp=json.loads(a.codegen.read_text())
    if stamp['comparator']!=meta['benchmark_sha256'] or sha(exe)!=stamp['profile']:raise ValueError('profile driver and paired comparator do not belong to the named build')
else:
    subprocess.run(['cargo','build','--release','--offline','--locked','--features','baseline','--example','profile'],cwd=snap,env=env,check=True)
    exe=target/'release/examples/profile'
check();lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',subprocess.check_output(['ldd',exe],text=True))[1])
if sha(lib)!=meta['zstd_library_sha256']:raise ValueError('different zstd library')
perf=Path(os.getenv('PERF',root/'bench/local/perf')).resolve();events=['instructions:u','cycles:u','branches:u','branch-misses:u'];extra=[]
if a.arm_cache:
    pmu=Path('/sys/bus/event_source/devices/armv8_cortex_a76/events')
    for key,event in [('l1d','l1d_cache_refill'),('l2d','l2d_cache_refill')]:
        code=re.fullmatch(r'event=(0x[0-9a-f]+)',(pmu/event).read_text().strip())[1]
        events.append(f'r{int(code,16):02x}:u');extra.append(f'{key}_refills_per_byte')
result=[];norm=src.stat().st_size*a.repetitions
for codec in ('ours','zstd'):
    with tempfile.TemporaryDirectory() as tmp:
        ctl,ack=(Path(tmp)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
        z=subprocess.run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe,a.operation,codec,src,'4',str(a.repetitions)],cwd=snap,
                         env=dict(env,PERF_CTL=str(ctl),PERF_ACK=str(ack)),text=True,capture_output=True,check=True)
    raw=z.stderr;(out/f'{codec}-perf.txt').write_text(raw)
    n=sizes['btrcmpr' if codec=='ours' else codec]
    if f'level={a.level} threads=4 archive_bytes={n}\n' not in raw:raise ValueError('profile did not reproduce paired archive size')
    counts={v[2]:float(v[0])/norm for line in raw.splitlines() if len(v:=line.split(';'))>2 and v[2] in events}
    result.append([codec,n,*(round(counts[k],4) for k in events),float(re.search(r'([\d.]+) MB/s',raw)[1])])
with (out/'per-byte.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('codec','archive_bytes','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte',*extra,'counter_MBps'));w.writerows(result)
(out/'manifest.json').write_text(json.dumps(dict(input=meta['input_sha256'][a.file],source_sha256=meta['source_sha256'],level=a.level,operation=a.operation,workers=4,repetitions=a.repetitions,
    reference_library_sha256=sha(lib),paired_comparator_sha256=sha(ref),profile_sha256=sha(exe),profile_source_sha256=sha(snap/'examples/profile.rs'),perf_version=subprocess.check_output([perf,'version'],text=True).strip()),indent=2)+'\n')
print(f'{result[1][2]/result[0][2]:.3f} zstd instructions per Rust instruction ({a.operation})')
