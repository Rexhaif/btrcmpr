#!/usr/bin/env python3
"""Freeze and audit the integrated regional scanner, signal predictor and object windows."""
import csv
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from level_one_lab import read, sha

root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';lanes=root/'bench/local/levels/lanes'
snap=lanes/'combined-presets';dest=base/'native-combined-1';dest.mkdir(exist_ok=True)
if not snap.exists():
    choices={n:dict(csv='native-regional-scan-1/cli.csv',match=dict(input=n,level='1')) for n in ['enwik8','x-ray','mozilla']}
    p=dest/'archive-references.json';p.write_text(json.dumps(choices,indent=2)+'\n')
    subprocess.run([sys.executable,root/'bench/diagnostics/freeze-low.py','--workspace',snap,'--choices',p],check=True)
if '--prepare' in sys.argv:raise SystemExit()
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PERF_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS','LLVM_PROFILE_FILE','BTRCMPR_NATIVE_SCAN')}
out=snap/'target/profiled'
mat=dest/'manifest.json'
with (dest/'run.log').open('a',buffering=1) as log:
    def run(cmd,allowed=(0,),env=e):
        print(' '.join(map(str,cmd)),file=log,flush=True)
        proc=subprocess.run(cmd,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT)
        if proc.returncode not in allowed:raise ValueError('command failed: '+str(cmd[0])+'; see '+str(dest/'run.log'))
    if not (out/'build-profiled.json').is_file():
        run(['cargo','test','--offline','--locked','--all-features'])
        run(['cargo','test','--offline','--locked','--features','regional-models'],env=dict(e,BTRCMPR_NATIVE_SCAN='7'))
        run(['cargo','clippy','--offline','--locked','--all-features','--all-targets','--','-D','warnings'])
        run([sys.executable,root/'scripts/build-profiled.py','--workspace',snap,'--target-dir',out,'--comparators','--regional-models','--regional-scan','7'])
    co=json.loads((out/'build-profiled.json').read_text());digest=co['comparator_sha256'];cli=out/'release/btrcmpr'
    src={str(p.relative_to(snap)):sha(p) for p in (snap/'src').rglob('*.rs')}
    if src!=co['source_sha256'] or co['regional_scan']!=7:raise ValueError('production source changed')
    files=root/'bench/local/preset-binaries'
    for filename,where,d in [('compare',digest,digest),('btrcmpr','cli-'+co['cli_sha256'],co['cli_sha256'])]:
        exe=out/'release'/filename;dst=files/where
        if sha(exe)!=d:raise ValueError('compiler output changed')
        if not dst.exists():shutil.copy2(exe,dst)
        if sha(dst)!=d:raise ValueError('wrong immutable artifact')
    origin=json.loads((base/'native-regional-scan-1/manifest.json').read_text())
    origin.update(benchmark_sha256=digest,source_sha256=src)
    def frozen(path,info):
        if path.exists() and json.loads(path.read_text())!=info:raise ValueError('frozen metadata changed: '+str(path))
        path.write_text(json.dumps(info,indent=2)+'\n')
    frozen(dest/'reference.json',origin)
    frozen(dest/'codegen.json',dict(comparator=digest,cli=co['cli_sha256'],profile=co['profile_runner_sha256'],settings=co['settings'],regional_scan=7,profile_data_sha256=co['profile_data_sha256']))
    frozen(dest/'training.json',co['training'])
    # Before timing, compare newly emitted signal archives with an independent
    # research build with explicit policies, and restore using its scalar path.
    lab=lanes/'signal-grid-trials/target/release/examples';wire=json.loads((base/'research/object-step/wire.json').read_text())
    signal_screen=read(base/'research/signal-grid/screen.csv')
    with tempfile.TemporaryDirectory(dir=snap/'target') as td,(dest/'changed-archives.csv').open('w') as f:
        w=csv.writer(f,lineterminator='\n');w.writerow(['level','file','bytes','archive_sha256','source_sha256','independent_decoder'])
        arc,ref,back=(Path(td)/x for x in ('native','control','restored'))
        for lv,ref_lv,effort,reach,kib in [(2,2,1,2048,512),(3,2,2,4096,1024),(5,6,1,2048,2048),(12,6,3,8192,2048),(22,6,3,8192,2048)]:
            x=root/'bench/data/x-ray';env=dict(e,BTR_CANDIDATE_FRAME=str(ref),BTR_JOB_KIB=str(kib),BTR_SIGNAL_GRID='2',BTR_SIGNAL_SEARCH=str(effort),BTR_SIGNAL_REACH=str(reach))
            run([lab/'candidate','4',str(lv),x,'native'],env=env)
            run([cli,'c',f'-{lv}',x,arc,'4'])
            gold,=(r for r in signal_screen if (r['level'],r['mode'],r['search'],r['reach'],r['KiB'])==tuple(map(str,(ref_lv,2,effort,reach,kib))))
            if arc.stat().st_size!=int(gold['bytes']) or sha(arc)!=sha(ref):raise ValueError('signal preset does not reproduce independent wire')
            run([cli,'d',arc,back,'3'])
            if sha(back)!=origin['input_sha256']['x-ray']:raise ValueError('wrong signal')
            run([lab/'decode_loop',arc,'1','3',x],env=dict(e,BTR_SIGNAL_SCALAR='1'))
            w.writerow([lv,'x-ray',arc.stat().st_size,sha(arc),sha(back),'scalar research build'])
        run([cli,'c','-20',root/'bench/data/mozilla',arc,'4'])
        run([files/('cli-'+wire['decoding_cli_sha256']),'d',arc,back,'3'])
        if sha(arc)!=wire['archive_sha256'] or sha(back)!=wire['source_sha256']:raise ValueError('object preset differs')
        w.writerow([20,'mozilla',arc.stat().st_size,sha(arc),sha(back),'prior production CLI'])
    run([sys.executable,'scripts/preset-matrix.py',*(['--resume'] if mat.exists() else ['--from-manifest',dest/'reference.json']),'--levels','1','--rounds','5','--decodes','7','--threads','4','--out',dest],(0,1))
    run([sys.executable,root/'bench/diagnostics/preset-cli.py',dest/'matrix.csv','--out',dest/'cli.csv','--binary',cli,'--sha256',co['cli_sha256']])
    run([sys.executable,snap/'bench/diagnostics/preset-rates.py',dest/'matrix.csv','--out',dest/'rates.csv'])
known=json.loads((snap/'expected.json').read_text())
checks={r['input']:[int(r['cli_bytes']),r['archive_sha256']] for r in read(dest/'cli.csv') if r['restored_identical']=='1'}
if checks!=known:raise ValueError('changed level-one archive')
result=read(dest/'matrix-decode-tolerance.csv');passed=sum(r['all_pass_with_allowance']=='1' for r in result)
(dest/'README.md').write_text(f'# Combined production presets\n\nThe independently trained standalone binary includes the regional match scanner, content-learned signal spacing and the level-20 object instruction window. Its [changed archives](changed-archives.csv) match separate implementations and independent decoders. The [fresh level-one series](rates.csv) passes {passed} of 3 files at the 5% decode allowance. See the [same-executable matrix](../integrated/{digest}/README.md), [round-trip proofs](cli.csv), [compiler build](codegen.json), and [training](training.json).\n')
verify=[sys.executable,root/'bench/diagnostics/integrated.py','--workspace',snap,'--origin',dest,'--out',base/'integrated'/digest,'--levels']
subprocess.run([*verify,'2,3,6'],check=True)
if passed==3:subprocess.run([*verify,'4:22'],check=True)
