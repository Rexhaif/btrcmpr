#!/usr/bin/env python3
"""Count the transmitted spellings and root tokens directly in a verified shared-dictionary archive."""
import argparse
import csv
import hashlib
from pathlib import Path
import struct
p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('--cli',type=Path,required=True)
p.add_argument('--level',type=int,required=True);p.add_argument('--input',required=True);p.add_argument('--out',required=True,type=Path)
a=p.parse_args()
with a.cli.open() as f:row=next(r for r in csv.DictReader(f) if int(r['level'])==a.level and r['input']==a.input)
s=a.archive.read_bytes()
if len(s)!=int(row['cli_bytes']) or hashlib.sha256(s).hexdigest()!=row['archive_sha256']:raise ValueError('different serialized archive')
magic,raw,shard=struct.unpack_from('<8sQI',s)
if magic!=b'BTRCMP01' or shard>>31 or shard==0:raise ValueError('not a standalone native frame')
u32=lambda s,i:struct.unpack_from('<I',s,i)[0]
at=20;blocks=[]
while at<len(s):
    n=u32(s,at);at+=4
    if n>len(s)-at:raise ValueError('short frame')
    blocks.append(memoryview(s)[at:at+n]);at+=n
if len(blocks)!=(raw+shard-1)//shard:raise ValueError('wrong job count')
groups=[];i=0
while i<len(blocks):
    b=blocks[i];leader,count=b[0],b[1]
    if leader!=50 or not 1<=count<=len(blocks)-i:raise ValueError('not a native shared dictionary')
    d=u32(b,2);book=b[6:6+d];ng=1+book[0];nt=u32(book,1)
    sizes=[0,*struct.unpack_from('<64I',book,5)];head=261
    for j in range(ng):
        width=book[head];k=u32(book,head+1);head+=5
        if not 1<=width<=64:raise ValueError('impossible spelling')
        sizes[width]+=k
    tokens=[u32(b,6+d)]
    for job in blocks[i+1:i+count]:
        if job[0]!=51:raise ValueError('invalid member')
        tokens.append(u32(job,1))
    if sum(tokens)!=nt:raise ValueError('token count mismatch')
    n=min(shard*count,raw-i*shard)
    groups.append((i,count,n,d,sum(sizes),sum(w*c for w,c in enumerate(sizes)),nt,round(n/nt,4),';'.join(map(str,tokens))))
    i+=count
a.out.parent.mkdir(parents=True,exist_ok=True)
with a.out.open('w') as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('first_job','workers_in_group','original_bytes','dictionary_wire_bytes','distinct_spellings','expanded_dictionary_bytes','root_tokens','mean_output_bytes_per_token','tokens_per_job'));wr.writerows(groups)
