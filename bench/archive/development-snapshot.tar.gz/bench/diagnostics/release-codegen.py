#!/usr/bin/env python3
"""Hold the Rust source and libzstd fixed while changing release code generation and profile guidance."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
from statistics import median
import subprocess
import sys
import tempfile
from decode_gate import qualifies,DEFAULT_DECODE_LOSS_PCT
from level_one_lab import costs,read
from profile_training import train
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','out'):p.add_argument('--'+k,required=True,type=Path)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
base=root/'bench/results/presets';origin=base/'native-fastest-1';frozen=json.loads((origin/'manifest.json').read_text());known={r['input']:r for r in read(origin/'cli.csv')};rates={r['file']:r for r in read(origin/'rates.csv')}
cache=root/'bench/local/levels/lanes/low-codegen';cache.mkdir(exist_ok=True);training=cache/'training';bench=root/'bench/data';perf=root/'bench/local/perf'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
if {str(p.relative_to(snap)):sha(p) for p in (snap/'src').rglob('*.rs')}!=frozen['source_sha256']:raise ValueError('not the production source')
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','PROFILE_','CARGO_PROFILE_','ZSTD_')) and k not in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR','LLVM_PROFILE_FILE')};env['LC_ALL']='C'
def run(cmd,e=env):
    return subprocess.run([str(x) for x in cmd],cwd=snap,env=e,text=True,capture_output=True,check=True)
rustc=run(['rustc','-Vv']).stdout;host=re.search(r'host: (\S+)',rustc)[1]
prof=Path(run(['rustc','--print','sysroot']).stdout.strip())/'lib/rustlib'/host/'bin/llvm-profdata'
if not prof.is_file():raise ValueError('install rustup component llvm-tools-preview')
run([sys.executable,root/'bench/diagnostics/codegen-training.py','--out',training]);shutil.copy2(training/'training.json',out/'training.json')
identity={'rustc':rustc,'profdata_version':run([prof,'--version']).stdout,'source_sha256':frozen['source_sha256'],'reference_library_sha256':frozen['zstd_library_sha256'],'workers':4,'rounds':5,'warmup':1,'decodes':7,'input_sha256':frozen['input_sha256'],'training_manifest_sha256':sha(out/'training.json'),'builds':{}}
def register(kind,exe,cli,profile,settings):
    lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',exe]).stdout)[1])
    if sha(lib)!=frozen['zstd_library_sha256'] or 'libzstd' in run(['ldd',cli]).stdout:raise ValueError('different reference or nonstandalone CLI')
    identity['builds'][kind]=dict(comparator=sha(exe),cli=sha(cli),profile=sha(profile),settings=settings)
    (out/'manifest.json').write_text(json.dumps(identity,indent=2)+'\n');return (exe,cli,profile)
def build(kind,thin,phase,model=None):
    dest=cache/kind
    if phase=='generate':
        stamp=hashlib.sha256(json.dumps([identity['rustc'],identity['source_sha256'],identity['training_manifest_sha256'],sha(Path(__file__).with_name('profile_training.py')),bool(thin)],sort_keys=True).encode()).hexdigest()
        dest=dest/stamp
    dest.mkdir(exist_ok=True,parents=True)
    if phase=='generate' and (dest/'model.sha256').is_file():
        model=dest/'learned.profdata'
        if sha(model)!=(dest/'model.sha256').read_text().strip():raise ValueError('cached compiler profile changed')
        return model
    flags=['-Ctarget-cpu=native'];e=dict(env,CARGO_TARGET_DIR=str(dest/'target'))
    if thin:e.update(CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1',CARGO_PROFILE_RELEASE_LTO='thin')
    if phase=='generate':
        raw=dest/'raw';raw.mkdir(exist_ok=True);flags.append('-Cprofile-generate='+str(raw))
    elif model:flags.append('-Cprofile-use='+str(model))
    e['CARGO_ENCODED_RUSTFLAGS']='\x1f'.join(flags)
    cmd=['cargo','build','--offline','--locked','--release','--features','baseline','--example','profile']
    if phase!='generate':cmd+=['--bin','compare','--bin','btrcmpr']
    with (dest/'build.log').open('w') as log:
        subprocess.run(cmd,cwd=snap,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
    loc=dest/'target/release';runner=loc/'examples/profile'
    if phase=='generate':
        model=dest/'learned.profdata';train(runner,training,raw,prof,model,e,snap)
        (dest/'model.sha256').write_text(sha(model)+'\n');return model
    settings={'cgu':1 if thin else 'cargo default','lto':'thin' if thin else 'cargo default','rustflags':flags,'profile_data_sha256':sha(model) if model else None}
    return register(kind,loc/'compare',loc/'btrcmpr',runner,settings)
stock=root/'bench/local/preset-binaries'/frozen['benchmark_sha256'];profile=snap/'target/release/examples/profile'
if sha(stock)!=stock.name:raise ValueError('initial comparator changed')
stockbin=register('stock',stock,snap/'target/release/btrcmpr',profile,{'existing_native_release':1})
te=dict(env,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7');scores={};doc=[]
qf=(out/'paired.csv').open('w',buffering=1);qw=csv.writer(qf,lineterminator='\n');qw.writerow('file build tag codec bytes encode_MBps decode_MBps pass_at_5pct'.split())
cf=(out/'counters.csv').open('w',buffering=1);cw=csv.writer(cf,lineterminator='\n');cw.writerow('file build codec archive_bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte'.split())
events=('instructions:u','cycles:u','branches:u','branch-misses:u')
def collect(name,bins,kind,codec):
    exe=bins[2];src=bench/name;tag=f'{kind}-{name}-{codec}'
    with tempfile.TemporaryDirectory() as tm:
        ctl,ack=[Path(tm)/k for k in ('ctl','ack')];os.mkfifo(ctl);os.mkfifo(ack)
        v=run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe,'c',codec,src,4,6],dict(te,PERF_CTL=str(ctl),PERF_ACK=str(ack)))
    (out/(tag+'-perf.txt')).write_text(v.stderr);n=int(rates[name]['btr_bytes' if codec=='ours' else 'zstd_bytes'])
    if f'archive_bytes={n}\n' not in v.stderr:raise ValueError('wrong PMU archive')
    norm=src.stat().st_size*6;c={r[2]:int(r[0])/norm for line in v.stderr.splitlines() if len(r:=line.split(';'))>2 and r[2] in events};cw.writerow((name,kind,codec,n,*(round(c[k],5) for k in events)))
def timed(kind,bins,name,tag,check=True):
    src=bench/name
    if sha(src)!=frozen['input_sha256'][name]:raise ValueError('wrong corpus')
    if check:
        with tempfile.TemporaryDirectory(dir=cache) as tm:
            ar,rest=[Path(tm)/k for k in ('frame','out')];run([bins[1],'c','-1',src,ar,4]);run([bins[1],'d',ar,rest,3])
            if sha(ar)!=known[name]['archive_sha256'] or sha(rest)!=frozen['input_sha256'][name]:raise ValueError('archive or restoration changed')
        collect(name,bins,kind,'ours')
        if kind=='stock':collect(name,bins,kind,'zstd')
    path=out/(tag+'.csv')
    tmp=path.with_suffix('.partial');run([bins[0],4,5,'both',src],dict(te,TRIALS_CSV=str(tmp)));tmp.replace(path)
    pair=[costs(read(path),k) for k in ('btrcmpr','zstd')]
    if [e[0] for e in pair]!=[int(rates[name][k]) for k in ('btr_bytes','zstd_bytes')]:raise ValueError('wrong sizes')
    ok=qualifies(pair,DEFAULT_DECODE_LOSS_PCT);v=[]
    for code,(n,c,d) in zip(('btrcmpr','zstd'),pair,strict=True):
        c,d=[float(Decimal(src.stat().st_size)/t/1_000_000) for t in (c,d)];qw.writerow((name,kind,tag,code,n,round(c,3),round(d,3),int(ok)));v.append((c,d))
    (c,d),(cz,dz)=v;doc.append(f"| [{tag}]({tag}.csv) | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |");return ok,c/cz
builds={}
for kind in ('stock','pgo','thin','thin-pgo'):
    if kind=='stock':bins=stockbin
    else:
        thin=kind.startswith('thin');model=build('train-'+kind,thin,'generate') if 'pgo' in kind else None
        bins=build(kind,thin,'use',model)
    builds[kind]=bins
    for name in ('enwik8','mozilla'):scores[kind,name]=timed(kind,bins,name,kind+'-'+name)
for name in ('enwik8','mozilla'):
    best=max((v,k) for (k,f),v in scores.items() if k!='stock' and f==name)[1]
    timed(best,builds[best],name,best+'-'+name+'-repeat',False)
qf.close();cf.close()
spread=[]
for case in ('thin-pgo-enwik8','thin-pgo-enwik8-repeat','thin-pgo-mozilla','thin-pgo-mozilla-repeat'):
    src=read(out/(case+'.csv'))
    each={r['round']:{v['codec']:v for v in src if v['round']==r['round']} for r in src}
    enc=[Decimal(t['zstd']['compress_seconds'])/Decimal(t['btrcmpr']['compress_seconds']) for t in each.values()]
    dec=[Decimal(t['zstd']['decompress_seconds'])/Decimal(t['btrcmpr']['decompress_seconds']) for t in each.values()]
    spread.append(f"| [{case}]({case}.csv) | {sum(x>1 for x in enc)} / 5 | {min(enc):.3f}–{max(enc):.3f}× | {sum(x>=Decimal('.95') for x in dec)} / 5 |")
(out/'rounds.md').write_text('\n'.join(['# Variation within the paired compiler runs','','The production comparison independently takes the median time for each codec. Here each Rust timing is instead compared with zstd in the same round, to show how stable a small margin is. This does not change the predeclared verdict.','','| Experiment | Encode wins by Rust | Range of paired encode speedups | Rounds within decode allowance |','|---|---:|---:|---:|',*spread,'']))

(out/'README.md').write_text('\n'.join(['# Compiler profile guidance and code generation on the native codec','',
'All builds use the exact production Rust source and the same installed zstd library. The stock build, compiler profile guidance, one code generation unit with thin link-time optimization, and both together are compared separately. Instrumented training used independent software documentation, Python source, host executables and synthetic records and numeric data; it did not read any benchmark input. No dictionary or trained model is needed by the resulting codec.','',
'| Raw paired measurements | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---|',*doc,'',
'The subsequent [hardware sampling study](samples/README.md) includes annotated ARM instructions for both inputs. See the [fresh production comparison](../../native-profiled-1/README.md) for all three inputs. The [per-round comparisons](rounds.md) show that the combined build won all five Mozilla encode pairs initially, but only two of five on repeat. Its separate median encode times still passed the predeclared gate twice. The standalone encoder of every variant reproduced each complete native level-one archive hash and its decoder restored the original with three workers. Five warmed alternating pairs per result with four workers per side and seven decodes per measurement. The strongest revised build on each input received an independent five-pair repeat. [Hardware counters](counters.csv), [paired medians](paired.csv), [training inputs](training.json), [exact builds](manifest.json).','']))
