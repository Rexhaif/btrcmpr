#!/usr/bin/env python3
"""Spend an object's compressed-size margin on independent code, record and other job sizes."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--levels',nargs='+',type=int,choices=[6,17,19,21],default=[6],help='default: the Mozilla decode miss outside a 5% allowance');a=p.parse_args()
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';src=root/'bench/data/mozilla';ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,e):return subprocess.run(cmd,env=e,capture_output=True,text=True,check=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
limits={int(r['level']):int(r['zstd_bytes']) for r in read(base/'zstd-sizes.csv') if r['file']=='mozilla'}
original={6:17207799,17:15742461,19:15190160,21:15157699};windows={6:112,17:448,19:656,21:704}
ids={v:sha(ex/v) for v in ['examples/candidate','examples/decode_loop','compare']}
if sha(src)!='657fc3764b0c75ac9de9623125705831ebbfbe08fed248df73bc2dc66e2a963b':raise ValueError('not the benchmark input')
(out/'manifest.json').write_text(json.dumps(dict(input_sha256=sha(src),binaries=ids,workers=4,anchor_sizes=original),indent=2)+'\n')
def output(k,columns):
    f=(out/(k+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(columns.split());return f,w
sf,sw=output('screen','level other_KiB records_KiB code_KiB bank_policy bytes encode_MBps decode_MBps')
tf,tw=output('fixed','level other_KiB records_KiB code_KiB bank_policy bytes archive_sha256 verified_decode_MBps')
pf,pw=output('paired','level other_KiB records_KiB code_KiB bank_policy codec bytes encode_MBps decode_MBps all_three_pass')
with sf,tf,pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    arc=Path(tmp)/'object.btr'
    for level in a.levels:
        b=windows[level];native_policy=2 if level>=18 else 0
        small=max(48,(b//2)//16*16);medium=max(64,(b*3//4)//16*16);big=min(1536,2*b)
        control=(b,b,b,native_policy)
        # Enlarge the other-data or record history to pay for shorter code
        # jobs. Varying every section together obscures that tradeoff.
        cases={control,(b,b,b,2),(b,b,medium,2),(b,b,small,2),(b,b,medium,native_policy),(b,b,small,native_policy),
               (big,b,medium,2),(big,b,small,2),(big,big,medium,2),(big,small,medium,2),
               (medium,big,b,2),(small,big,b,2),(b,small,b,2),(medium,small,b,2),
               (medium,small,big,2),(b,big,b,2),(small,small,big,native_policy),(big,small,small,native_policy)}
        if level>=17:cases.update([(512,128,352,2),(640,224,448,2),(672,336,544,2),(704,448,576,2)])
        cases=list(cases);random.Random(2246+level).shuffle(cases);pool=[]
        def cfg(case):
            o,r,c,pol=case;return dict(env,BTR_OTHER_KIB=str(o),BTR_RECORD_KIB=str(r),BTR_TEXT_KIB=str(c),BTR_BANK_MODE=str(pol))
        def bench(case,keep=False):
            e=cfg(case)
            if keep:e['BTR_CANDIDATE_FRAME']=str(arc)
            row=next(csv.DictReader(run([ex/'examples/candidate','4',str(level),src,'native'],e).stdout.splitlines()))
            return int(row['bytes']),float(row['encode_MBps']),float(row['decode_MBps'])
        for case in cases:
            n,c,d=bench(case);sw.writerow((level,*case,n,c,d))
            if case==control and n!=original[level]:raise ValueError('native control changed')
            keep=(15148357<=n<=15190562) if level==21 else (n>=15190562 if level==19 else True)
            if case!=control and n<limits[level] and keep:pool.append((d,c,n,case))
        if not pool:continue
        fixed=[]
        for _,_,n,case in sorted(pool,reverse=True)[:3]:
            nb,_,_=bench(case,True)
            if nb!=n or arc.stat().st_size!=n:raise ValueError('unstable candidate')
            run([ex/'examples/decode_loop',arc,'1','3',src],env)
            speeds=[]
            for _ in range(3):
                z=run([ex/'examples/decode_loop',arc,'9','4',src],env);speeds.append(float(re.search(r'([\d.]+) MB/s',z.stderr)[1]))
            d=statistics.median(speeds);tw.writerow((level,*case,n,sha(arc),d));fixed.append((d,n,case))
        _,n,case=max(fixed);path=out/f'level-{level}-mozilla.partial'
        if any(sha(ex/k)!=v for k,v in ids.items()):raise ValueError('research executable changed')
        run([ex/'compare','4','5','both',src],dict(cfg(case),BTR_LEVEL=str(level),ZSTD_LEVEL=str(level),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(path)))
        data=read(path);summ=[]
        for codec,nb in [('btrcmpr',n),('zstd',limits[level])]:
            seq=[r for r in data if r['codec']==codec]
            if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=nb for r in seq):raise ValueError('invalid paired gate')
            summ.append((codec,nb,*(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in seq) for k in ('compress_seconds','decompress_seconds'))))
        x,y=summ;ok=int(x[1]<y[1] and x[2]>y[2] and x[3]>y[3])
        for codec,nb,c,d in summ:pw.writerow((level,*case,codec,nb,round(c,3),round(d,3),ok))
        path.replace(path.with_suffix('.csv'))
