// Estimate the attainable size of an LZ-free conditional rank transform.
// A best-case histogram is learned on the same sample being scored. These
// are optimistic costs, not archive sizes or timed codec results.
use std::{env, fs};

fn ctx(a: u8, b: u8, bits: usize, kind: usize) -> usize {
    match kind {
        0 => usize::from(b),
        1 => ((u32::from(a) << 8 | u32::from(b)).wrapping_mul(0x9e3779b1) >> (32 - bits)) as usize,
        _ => {
            // Preserve the last byte (ASCII case folded) and a few bits of
            // the preceding letter; common letter pairs remain distinct.
            let fold = |x: u8| if x.is_ascii_uppercase() { x + 32 } else { x };
            let wide = (usize::from(fold(a)) * 131) ^ usize::from(fold(a) >> 3);
            ((wide << 7) | usize::from(fold(b) & 127)) & ((1 << bits) - 1)
        }
    }
}
fn bits(count: &[u32]) -> f64 {
    let n = count.iter().copied().map(u64::from).sum::<u64>() as f64;
    if n == 0.0 {
        return 0.0;
    }
    count
        .iter()
        .filter(|&&v| v > 0)
        .map(|&v| f64::from(v) * (n / f64::from(v)).log2())
        .sum()
}
fn analyze(data: &[u8], file: &str, offset: usize, width: usize, kind: usize) {
    let k = 1 << width;
    let mut count = vec![[0u32; 256]; k];
    let mut all = [0u32; 256];
    let (mut a, mut b) = (0, 0);
    for &c in data {
        count[ctx(a, b, width, kind)][c as usize] += 1;
        all[c as usize] += 1;
        a = b;
        b = c;
    }
    let mut global = (0..256).collect::<Vec<_>>();
    global.sort_unstable_by_key(|&i| (std::cmp::Reverse(all[i]), i));
    let conditional = count.iter().map(|r| bits(r)).sum::<f64>();
    let n = data.len();
    let mut rank = [[0u32; 256]; 4];
    let mut header = [256 + k.div_ceil(8); 4];
    for row in count.iter().filter(|r| r.iter().any(|&c| c != 0)) {
        let mut ord = global.clone();
        ord.sort_by_key(|&x| std::cmp::Reverse(row[x]));
        let used = ord.iter().take_while(|&&x| row[x] > 0).count();
        for (lane, limit) in [4, 8, 16, 32].into_iter().enumerate() {
            let t = used.min(limit);
            header[lane] += 1 + t;
            let mut seen = [false; 256];
            for (j, &v) in ord[..t].iter().enumerate() {
                seen[v] = true;
                rank[lane][j] += row[v];
            }
            let mut pos = t;
            for &v in &global {
                if !seen[v] {
                    rank[lane][pos] += row[v];
                    pos += 1;
                }
            }
        }
    }
    for (j, limit) in [4, 8, 16, 32].into_iter().enumerate() {
        let entropy = bits(&rank[j]);
        println!(
            "{file},{offset},{n},{kind},{width},{limit},{:.5},{:.5},{},{:.5}",
            conditional / n as f64,
            entropy / n as f64,
            header[j],
            (entropy / 8.0 + header[j] as f64) / n as f64
        );
    }
}
fn main() {
    let args = env::args().skip(1).collect::<Vec<_>>();
    assert!(!args.is_empty());
    println!(
        "file,offset,bytes,context_kind,context_bits,top_symbols,ideal_conditional_bits_per_byte,ideal_rank_bits_per_byte,model_bytes,optimistic_fraction"
    );
    for p in args {
        let data = fs::read(&p).unwrap();
        let file = std::path::Path::new(&p)
            .file_name()
            .unwrap()
            .to_str()
            .unwrap();
        let n = (1 << 20).min(data.len());
        for j in 0..5 {
            let at = j * (data.len() - n) / 4;
            for (w, k) in [(8, 0), (9, 1), (11, 1), (13, 1), (10, 2), (12, 2), (14, 2)] {
                analyze(&data[at..at + n], file, at, w, k);
            }
        }
    }
}
