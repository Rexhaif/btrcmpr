#!/usr/bin/env python3
"""Test per-region training of block-local, standard native entropy headers."""
import argparse
import json
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha

p=argparse.ArgumentParser(description=__doc__)
for key in ('workspace','bin-dir','out'):p.add_argument('--'+key,required=True,type=Path)
p.add_argument('--resume-screen',action='store_true',help='reuse the verified full-input screen for this exact build')
a=p.parse_args()
prior_manifest=json.loads((a.out/'manifest.json').read_text()) if a.resume_screen else None
prior=read(a.out/'screen.csv') if a.resume_screen else []
l=Lab(a.workspace,a.bin_dir,a.out)
if prior_manifest is not None and prior_manifest!=l.spec:raise ValueError('screen identity differs')
name='enwik8';control=(0,16,0,384)
native=next(x for x in read(l.root/'bench/results/presets/native-fastest-1/cli.csv') if x['input']==name)
prod=l.root/'bench/local/levels/lanes/native-fastest-1/target/release/btrcmpr'
ref=costs(read(l.base/'tile-match/enwik8-0.csv'),'zstd')[0]
if sha(l.data/name)!=l.spec['input_sha256'][name] or 'libzstd' in l.run(['ldd',prod],l.env).stdout:raise ValueError('wrong input or linked decoder')
def cfg(x):
    fields,period,pairs,kib=x
    return dict(l.env,BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='5',BTR_FAST_PLAN='1',BTR_FAST_COUNTS='2',BTR_JOB_KIB=str(kib),BTR_SHARED_FIELDS=str(fields),BTR_SHARED_PERIOD=str(period),BTR_SHARED_PAIRS=str(pairs))
sf,sw=l.report('screen','fields blocks pairs KiB bytes encode_MBps decode_MBps')
pf,pw=l.report('paired','fields blocks pairs KiB tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
cf,cw=l.report('counters','fields blocks pairs KiB instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
pool={};doc=[]
with sf,pf,cf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    for row in prior:
        x=tuple(int(row[k]) for k in ('fields','blocks','pairs','KiB'))
        if x in pool:raise ValueError('duplicate screen configuration')
        pool[x]=(int(row['bytes']),float(row['encode_MBps']),float(row['decode_MBps']));sw.writerow((*x,*pool[x]))
    arc=Path(td)/'block.ar';rest=Path(td)/'restored'
    cases=[(f,period,b,384) for f in (1,2,4,3,5,6,7) for period in (8,32,128) for b in (0,1)]+[control]
    random.Random(225161).shuffle(cases)
    def screen(x):
        if x not in pool:
            pool[x]=l.trial(name,cfg(x));sw.writerow((*x,*pool[x]))
    for x in cases:screen(x)
    def best(xs):
        small=[x for x in xs if pool[x][0]<ref]
        return max(small,key=lambda x:pool[x][1]) if small else min(xs,key=lambda x:pool[x][0])
    starters=[best([x for x in pool if x[0] and x[2]==b]) for b in (0,1)]
    for f,period,b,_ in starters:
        for kib in (256,512,768):
            for n in (period,max(4,period//2)):
                screen((f,n,b,kib))
    xs=[x for x in pool if x[0]]
    picks=list(dict.fromkeys([control,best([x for x in xs if not x[2]]),best([x for x in xs if x[2]]),min(xs,key=lambda x:pool[x][0])]))
    def pair(x,tag,pmu):
        n,_,_=l.trial(name,cfg(x),arc)
        if n!=pool[x][0]:raise ValueError('unstable size')
        h=sha(arc)
        if x==control and h!=native['archive_sha256']:raise ValueError('control not native')
        l.run([prod,'d',arc,rest,'3'],l.env)
        if sha(rest)!=l.spec['input_sha256'][name]:raise ValueError('production decoder mismatch')
        if pmu:cw.writerow((*x,*l.perf(name,cfg(x),n,tag)))
        rates,ok=l.pair(name,cfg(x),n,ref,tag)
        for code,(nb,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*x,tag,code,h if code=='btrcmpr' else '',nb,round(c,3),round(d,3),int(ok)))
        (n,c,d),(nz,cz,dz)=rates
        doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} / {x[2]} / {x[3]} | {n:,} / {nz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
        return ok,c/cz
    scores=[(pair(x,f'enwik8-{j}',True),x) for j,x in enumerate(picks)]
    if max(scores[1:])[0][1]>.96:pair(max(scores[1:])[1],'enwik8-repeat',False)
(l.out/'README.md').write_text('\n'.join(['# Reusing entropy models across independent blocks','',
    'Each region learns its symbol groups from its middle block during compression. All bytes remain encodable even if absent in that block. A second variant precomputes the joint selector, rank bits and bit count for every pair of input symbols. Both write the existing native block format. Fields mask: command tags = 1, distance selectors = 2, literals = 4. Ratios and throughput are measured on the complete enwik8 file, never just on the pilot block.','',
    '| Raw pairs | Fields / blocks per model / pair lookup / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
    'Each row used four workers in both directions, five warmed alternating pairs, and seven decodes per measurement. The pre-existing standalone production CLI, without any research code or libzstd, also restored each complete archive with three workers. [All configurations](screen.csv), [normalized hardware counters](counters.csv), [archive hashes](paired.csv), [build and reference](manifest.json).','']))
