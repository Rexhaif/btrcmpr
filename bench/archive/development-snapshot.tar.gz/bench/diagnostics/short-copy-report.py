#!/usr/bin/env python3
"""Summarize the six fixed-archive screens and the corresponding gated ARM PMU measurements."""
import csv
import json
from pathlib import Path

root=Path(__file__).resolve().parents[2];out=root/'bench/results/presets/research/short-copy'
def read(k):
    with (out/k).open() as f:return list(csv.DictReader(f))
checks=json.loads((out/'manifest.json').read_text())['inputs'];screen=read('screen.csv');counts=read('counters.csv');trials=read('trials.csv');pairs=read('paired.csv')
expected={(r['level'],r['file']) for r in checks}
if len(expected)!=6 or {(r['level'],r['file']) for r in screen}!=expected or len(screen)!=6 or len(trials)!=6*9*3:raise ValueError('incomplete research screen')
eligible={(r['level'],r['file'],r['best_mode']) for r in screen if r['level']!='1' and r['best_mode']!='0' and float(r['best_MBps'])>1.015*float(r['native_MBps'])}
if {(r['level'],r['file'],r['mode'],r['codec']) for r in pairs}!={(*k,c) for k in eligible for c in ('btrcmpr','zstd')} or len(pairs)!=2*len(eligible):raise ValueError('incomplete paired confirmation')
if any(not (out/f'{name}-{lv}.csv').is_file() for lv,name,_ in eligible):raise ValueError('unpublished raw pair')
lines=['# Short LZ copies on fixed archives','',
    'All nine decoder settings read the same six native archives. The alternatives handle 17–48 byte nonoverlapping matches with two or three vector loads; other settings gather short overlapping matches from the last sixteen output bytes and the new literals with an ARM table lookup. One setting lowers a short copy to an eight-byte load and store. These are changes to how the already validated commands execute. No encoding decision or compressed byte changes.','',
    '| Input | Level | Best mode | Decode MB/s, control / best | Instructions per output byte, control / best | CPU cycles per output byte, control / best |',
    '|---|---:|---:|---:|---:|---:|']
rates={(r['level'],r['file'],r['mode']):r for r in counts}
for r in screen:
    key=(r['level'],r['file']);m=r['best_mode'];a=rates[*key,'0'];b=rates[*key,m]
    lines.append(f"| {key[1]} | {key[0]} | {m} | {r['native_MBps']} / {r['best_MBps']} | {float(a['instructions_per_byte']):.2f} / {float(b['instructions_per_byte']):.2f} | {float(a['cycles_per_byte']):.2f} / {float(b['cycles_per_byte']):.2f} |")
lines+=['','The speed columns are medians of three shuffled processes per setting, each running six warmed decodes on four workers. Separate perf-stat runs counted sixteen decodes, enabling counters after a verified warmup and disabling them before the final full byte comparison. The fastest setting is selected on this screen, so small leads are provisional. [Individual speeds](trials.csv), [PMU counts](counters.csv), [binary and archive hashes](manifest.json).','']
if pairs:
    lines+=['Candidates improving fixed-archive decode by more than 1.5% at levels above 1 were then tested against zstd in five warmed alternating pairs. [Absolute rates and sizes](paired.csv).','',
            '| Level | Input | Mode | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Passed all three |','|---:|---|---:|---:|---:|---:|:---:|']
    for r in pairs:
        if r['codec']!='btrcmpr':continue
        z=next(s for s in pairs if s['codec']=='zstd' and (s['file'],s['level'])==(r['file'],r['level']))
        win=int(r['archive_bytes'])<int(z['archive_bytes']) and all(float(r[k])>float(z[k]) for k in ('encode_MBps','decode_MBps'))
        lines.append(f"| {r['level']} | {r['file']} | {r['mode']} | {int(r['archive_bytes']):,} / {int(z['archive_bytes']):,} | {r['encode_MBps']} / {z['encode_MBps']} | {r['decode_MBps']} / {z['decode_MBps']} | {'Yes' if win else 'No'} |")
else:lines+=['No setting cleared the 1.5% threshold for a new comparison against zstd at levels above 1.']
tmp=out/'README.partial';tmp.write_text('\n'.join(lines)+'\n');tmp.replace(out/'README.md')
