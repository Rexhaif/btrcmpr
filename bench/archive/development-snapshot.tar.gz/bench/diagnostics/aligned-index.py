#!/usr/bin/env python3
"""Test 16-bit aligned source history with unrestricted byte-aligned queries."""
import argparse
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);native={x['input']:x for x in read(l.root/'bench/results/presets/native-fastest-1/cli.csv')}
sf,sw=l.report('screen','file mode KiB bytes encode_MBps decode_MBps')
pf,pw=l.report('paired','file mode KiB tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
ct,cw=l.report('counters','file mode KiB codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte');doc=[]
with sf,pf,ct,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'target.btr'
    for name in ('enwik8','mozilla'):
        if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('unverified input')
        arch=name=='mozilla';control=(0,192 if arch else 384);ref=costs(read(l.base/'group-key'/f'{name}-1.csv'),'zstd')[0]
        def cfg(x):
            m,k=x
            return dict(l.env,BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='10' if arch else '5',BTR_ALIGNED_INDEX=str(m),BTR_FAST_PLAN='0' if arch else '1',BTR_FAST_COUNTS='2',BTR_ARCH_KIB=str(k),BTR_RECORD_KIB='128',BTR_JOB_KIB=str(k))
        cases=[(m,k) for m in range(1,21) for k in ((128,192) if arch else (256,384))]+[control];random.Random(227143).shuffle(cases);pool={}
        def screen(x):
            if x in pool:return
            n,c,d=l.trial(name,cfg(x));pool[x]=(n,c,d);sw.writerow((name,*x,n,c,d))
        for x in cases:screen(x)
        smaller=lambda x:pool[x][0]<ref
        novel=[x for x in pool if x[0]]
        for x in sorted(novel,key=lambda x:(smaller(x),pool[x][1]),reverse=True)[:4]+sorted(novel,key=lambda x:pool[x][0])[:2]:
            screen((x[0],384 if arch else 640))
        novel=[x for x in pool if x[0]];eligible=[x for x in novel if smaller(x)]
        best=max(eligible,key=lambda x:(pool[x][2]>=1510,pool[x][1])) if eligible else min(novel,key=lambda x:pool[x][0])
        fast=max([x for x in novel if pool[x][0]<ref*1.025] or novel,key=lambda x:pool[x][1]);picks=list(dict.fromkeys([control,best,fast]))
        def pair(x,tag):
            n,_,_=l.trial(name,cfg(x),arc);digest=sha(arc);l.restore(name,arc,l.env)
            if n!=pool[x][0] or (x==control and digest!=native[name]['archive_sha256']):raise ValueError('wire changed')
            rates,ok=l.pair(name,cfg(x),n,ref,tag)
            for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((name,*x,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
            (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
            return ok,c/cz
        scored=[]
        for i,x in enumerate(picks):
            tag=f'{name}-{i}';cw.writerow((name,*x,'btrcmpr',pool[x][0],*l.perf(name,cfg(x),pool[x][0],tag)));r=pair(x,tag)
            if i:scored.append((r,x))
        if scored and max(scored)[0][1]>.96:pair(max(scored)[1],name+'-repeat')
(l.out/'README.md').write_text('\n'.join(['# Packed 16-bit aligned source positions','',
'Each source slot holds a 16-bit position in units of two, four or eight bytes. Queries may start on any byte. The previous tile supplies aligned source positions before either of the next two queries; optional fingerprints reject misses before loading the source. Confirmed matches extend backwards. The ordinary command format and decoder are unchanged.','',
'| Raw pairs | Mode / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
'Mode zero reproduces the original production archive. Every finalist restored the full original on three workers. Timings used four workers per codec, five alternating pairs after warmup, and seven decodes per time measurement. [Normalized hardware counters](counters.csv), [full-file screens](screen.csv), [paired archive hashes](paired.csv), [manifest](manifest.json).','']))
