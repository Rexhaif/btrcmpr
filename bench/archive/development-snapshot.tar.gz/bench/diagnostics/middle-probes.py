#!/usr/bin/env python3
"""Count match lookups in the level-10 Rust encoder; never use these builds for timing."""
import argparse
import csv
import hashlib
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("out", type=Path)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
source = root / "bench/data/enwik8"
columns = ("input_bytes", "probe_calls", "fingerprint_rejects", "no_prior_position",
           "verified_under_4", "verified_at_least_4", "commands", "matched_bytes", "matched_beyond_4_MiB")

with tempfile.TemporaryDirectory(prefix="btr-middle-probes-") as tmp:
    folder = Path(tmp)
    for name in ("src", "examples", "bench/support", ".cargo"):
        shutil.copytree(root / name, folder / name)
    for name in ("Cargo.toml", "Cargo.lock"):
        shutil.copy2(root / name, folder / name)
    path = folder / "src/lz.rs"
    text = path.read_text()
    a = text.index("    let mut i = 0;", text.index("pub(crate) fn history_model<"))
    b = text.index("    if CONTEXT &&", a)
    inner = text[a:b].replace("wide_probe::<PB>(s,", "counted(")
    code = """
    let mut counts = [0u64; 5];
    let mut made = [0u64; 3];
    let mut counted = |i:usize, w:u64, slot:u32, sig:u32| {
        counts[0] += 1;
        let result = wide_probe::<PB>(s,i,w,slot,sig);
        let mask = (1u32 << PB)-1;
        let k = if slot^sig > mask {1}
                else if (slot&mask)as usize >= i {2}
                else if result.0<4 {3} else {4};
        counts[k] += 1;
        result
    };
"""
    marker = "        streams.emit(s, anchor, i, best, off);"
    assert inner.count(marker) == 1
    inner = inner.replace(marker, marker + """
        made[0]+=1; made[1]+=best as u64;
        made[2]+=if off>4<<20 {best as u64}else{0};
""")
    # Multiline calls can have the input slice on a separate line after rustfmt.
    import re
    inner = re.sub(r"wide_probe::<PB>\(\s*s,\s*", "counted(", inner)
    assert "wide_probe::<PB>" not in inner and inner.count("counted(") >= 10
    tail = '''
    eprintln!("COUNTS,{},{},{},{},{},{},{},{},{}",s.len(),counts[0],counts[1],counts[2],
              counts[3],counts[4],made[0],made[1],made[2]);
'''
    path.write_text(text[:a] + code + inner + tail + text[b:])
    def build(cwd):
        subprocess.run(["cargo", "build", "--release", "--offline", "--locked", "--bin", "btrcmpr"],
                       cwd=cwd, check=True)
        return cwd / "target/release/btrcmpr"
    clean_env = {k: v for k, v in os.environ.items() if not k.startswith("BTR_")}
    reference = folder / "reference.btr"
    trial = folder / "instrumented.btr"
    plain = build(root)
    counted = build(folder)
    def compress(exe, name):
        return subprocess.run([exe, "c", "-10", source, name, "4"], env=clean_env,
                              check=True, text=True, capture_output=True)
    compress(plain, reference)
    instrumented = compress(counted, trial)
    rows = [list(map(int, x.split(",")[1:])) for x in instrumented.stderr.splitlines() if x.startswith("COUNTS,")]
    if len(rows) != 4 or sum(r[0] for r in rows) != source.stat().st_size:
        raise ValueError("unexpected number of blocks or bytes")
    for r in rows:
        if r[1] != sum(r[2:6]):
            raise ValueError("inconsistent counts")
    subprocess.run(["cmp", trial, reference], check=True)
    restored = folder / "restored.bin"
    subprocess.run([plain, "d", trial, restored, "4"], env=clean_env, check=True)
    subprocess.run(["cmp", restored, source], check=True)
    with (args.out / "match-probes.csv").open("w") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(columns)
        writer.writerows(sorted(rows))
    with reference.open("rb") as handle:
        (args.out / "probe-archive.sha256").write_text(hashlib.file_digest(handle, "sha256").hexdigest() + "\n")
