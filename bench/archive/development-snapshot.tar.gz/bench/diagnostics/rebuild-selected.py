#!/usr/bin/env python3
"""Rebuild the selected configuration from the user's checkout and verify the release archives."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from level_one_lab import read, sha
from elf_sections import compare as compare_sections


p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--origin', type=Path, required=True)
p.add_argument('--profile-data', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
origin, dest, model = (x.resolve() for x in (a.origin, a.out, a.profile_data))
dest.mkdir(exist_ok=True, parents=True)
native = json.loads((origin / 'manifest.json').read_text())
code = json.loads((origin / 'codegen.json').read_text())
if ({str(s.relative_to(root)): sha(s) for s in (root/'src').rglob('*.rs')} != native['source_sha256']
        or sha(model) != code['profile_data_sha256'] or code['comparator'] != native['benchmark_sha256']):
    raise SystemExit('This checkout or training profile is different from the measured build.')
training = root/'target/profiled'
env = {k: v for k, v in os.environ.items() if not k.startswith(('BTR_', 'ZSTD_', 'PERF_', 'PROFILE_'))}
with (dest/'build.log').open('w') as log:
    subprocess.run([sys.executable, root/'scripts/build-profiled.py', '--selected', '--profile-data', model,
                    '--profile-sha256', code['profile_data_sha256']], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
with tempfile.TemporaryDirectory(dir=training) as tmp:
    def machine_text(exe):
        raw = Path(tmp)/'instructions.bin'
        subprocess.run(['objcopy','-O','binary','--only-section=.text',exe,raw],check=True)
        return sha(raw)
    binaries = {}
    for name,key in [('btrcmpr','cli'),('compare','comparator')]:
        previous = root/'bench/local/preset-binaries'/('cli-'+code[key] if key=='cli' else code[key])
        release = training/'release'/name
        if sha(previous) != code[key]:raise ValueError('frozen executable changed')
        before,after = machine_text(previous),machine_text(release)
        binaries[name] = dict(rebuilt_sha256=sha(release), frozen_sha256=code[key], identical=sha(release)==code[key],
                              frozen_text_sha256=before, rebuilt_text_sha256=after, identical_text=before==after,
                              allocated_sections=compare_sections(previous,release))
cli = training/'release/btrcmpr'
subprocess.run([sys.executable,root/'bench/diagnostics/preset-cli.py',origin/'matrix.csv','--binary',cli,
                '--sha256',sha(cli),'--out',dest/'cli.csv'],cwd=root,env=env,check=True)
def archives(path):
    return {(r['input'],r['level']):(r['archive_sha256'],r['cli_bytes'],r['source_sha256']) for r in read(path)
            if r['restored_identical']=='1'}
control,repeat=archives(origin/'cli.csv'),archives(dest/'cli.csv')
if len(control)!=3 or control!=repeat:raise ValueError('rebuilt CLI did not reproduce all three production archives')
(dest/'identity.json').write_text(json.dumps(dict(binaries=binaries,source_sha256=native['source_sha256'],
     profile_sha256=sha(model),verified_level=1,identical_archives=len(control)),indent=2)+'\n')
print('Rebuilt',cli, 'and matched all three production level-1 archives.')
series=origin.parent/'integrated'/code['comparator']
subprocess.run([sys.executable,root/'bench/diagnostics/native_blocks.py',series,'--fill-with',
                root/'bench/local/preset-binaries'/('cli-'+code['cli'])],cwd=root,env=env,check=True)
