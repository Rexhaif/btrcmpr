#!/usr/bin/env python3
"""Localize the level-10 instruction gap on the exact combined build."""
import csv, json, os, re, subprocess, sys
from pathlib import Path
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';origin=base/'native-combined-1'
snap=root/'bench/local/levels/lanes/combined-presets';out=root/'bench/results/profiles/enwik8-general/combined-10'
exe=snap/'target/profiled/release/examples/profile';stamp=json.loads((origin/'codegen.json').read_text())
if sha(exe)!=stamp['profile']:raise ValueError('wrong frozen native profile')
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PROFILE_','PERF_','ZSTD_'))};e.update(LC_ALL='C',PERF=str(root/'bench/local/perf'))
report=out/'encode-instructions.txt'
subprocess.run([sys.executable,root/'bench/diagnostics/sample-search.py','--level','10','--file','enwik8','--event','instructions','--period','850009','--repetitions','1','--out',snap.parent/'combined-10-instruction-samples','--zstd-debug',root/'bench/local/zstd.debug','--exe',exe,'--verified-cell',out/'c','--summary',report],env=e,check=True)
raw=report.read_text().split('c-zstd insn samples ');assert len(raw)==2
b,z=read(out/'c/per-byte.csv');table=[]
for rows,r in zip(raw,(b,z),strict=True):
    m=re.search(r'^\s*([\d.]+)%\s+(\d+) (.+)$',rows,re.M)
    if not m:raise ValueError('no function samples')
    table.append((r['codec'],m[3],float(m[1]),float(m[1])/100*float(r['instructions_per_byte'])))
prior=out.parent/'middle-preset/search-depth'
work=read(prior/'zstd-row-probes.csv');checks=sum(int(r['candidates_checked']) for r in work);extended=sum(int(r['four_byte_passes']) for r in work)
control,= [r for r in read(prior/'per-byte.csv') if r['search_log']=='5']
limited,= [r for r in read(prior/'per-byte.csv') if r['search_log']=='3']
if control['archive_bytes']!=z['archive_bytes']:raise ValueError('historical zstd search control had a different size')
def ratio(key):return float(z[key])/float(b[key])
paired,=[r for r in read(base/'integrated'/stamp['comparator']/'l10/rates.csv') if r['file']=='enwik8']
ipc=lambda r:float(r['instructions_per_byte'])/float(r['cycles_per_byte'])
doc=['# Where the level-10 encoder spends its instructions','',
     f"The [counter run](README.md) on the frozen combined release measured **{float(b['instructions_per_byte']):.2f} vs {float(z['instructions_per_byte']):.2f} retired instructions per input byte**. Rust used {100*(1-1/ratio('instructions_per_byte')):.1f}% fewer instructions ({ratio('instructions_per_byte'):.2f}× as many on zstd). The CPU-cycle ratio was {ratio('cycles_per_byte'):.2f}×. Both used four workers and produced {int(b['archive_bytes']):,} and {int(z['archive_bytes']):,} bytes respectively.",'',
     f"In the independent paired wall-time benchmark Rust encoded at **{paired['btr_encode_MBps']} vs {paired['zstd_encode_MBps']} MB/s** and decoded at **{paired['btr_decode_MBps']} vs {paired['zstd_decode_MBps']} MB/s**. The encoder retired {ipc(b):.3f} vs {ipc(z):.3f} instructions per CPU cycle and {float(b['branches_per_byte']):.2f} vs {float(z['branches_per_byte']):.2f} branches per input byte. Cutting the number of instructions did not cut time by the same factor: the sparse Rust probes are expensive operations to retire.",'',
     '| Encoder | Hottest sampled function | Instruction samples | Estimated instructions per input byte there |','|---|---|---:|---:|']
for tag,fn,pct,ibytes in table:doc.append(f'| {tag} | `{fn}` | {pct:.2f}% | {ibytes:.1f} |')
doc+=['','The [instruction samples](encode-instructions.txt) and hardware totals come from separate runs of the same native profile driver. Multiplying a sample share by an instruction total gives an estimate, not an exact function counter; the Rust and zstd function boundaries also differ.','',
      f"The earlier [instrumented search study](../middle-preset/README.md) explains the difference. Zstd's row matcher checks candidates surviving a fingerprint mask; it performed **{checks:,}** preliminary candidate checks on enwik8, of which **{extended:,}** reached the full length comparison. The instrumented Rust parser made **57,954,544** candidate-text comparisons including lookahead and repeats. Rust probes a bounded number of positions indexed by several prefix lengths and the last distance; the fingerprint in each table entry can reject a candidate before reading its text. Those two counts are different units of work, not a tenfold instruction-speed prediction.",'',
      f"A [controlled change to zstd](../middle-preset/search-depth/README.md) reduced its searchLog from 5 to 3 with the rest of level 10 fixed: instructions fell from {float(control['instructions_per_byte']):.2f} to {float(limited['instructions_per_byte']):.2f} per byte, and its archive grew by {int(limited['archive_bytes'])-int(control['archive_bytes']):,} bytes. This shows the cost of search depth within zstd. The unmodified level-10 reference is used for the release comparison. These results apply to this level and input; the Mozilla level-one encoders retire [nearly the same instruction count](../../combined-01-mozilla/interpretation.md).",'']
(out/'interpretation.md').write_text('\n'.join(doc))
