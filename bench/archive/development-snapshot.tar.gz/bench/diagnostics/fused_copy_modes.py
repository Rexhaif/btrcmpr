"""Generate wire-identical ARM variants for already validated LZ commands."""
def modify(src):
    mark='#[inline(always)]\n#[allow(clippy::too_many_arguments)]\nfn restore_ready<const BOOK: bool>('
    if src.count(mark)!=1:raise ValueError('copy routine changed')
    wrapper='''struct CopyTotals(std::cell::Cell<[usize;6]>);
impl Drop for CopyTotals {
    fn drop(&mut self) { let v=self.0.get(); eprintln!("copy-totals {} {} {} {} {} {}", v[0],v[1],v[2],v[3],v[4],v[5]); }
}
thread_local! { static COPY_TOTALS: CopyTotals=const{CopyTotals(std::cell::Cell::new([0;6]))}; }
#[inline(never)]
#[allow(clippy::too_many_arguments)]
fn restore_ready<const BOOK:bool>(dst:&mut [u8], lits:&[u8], book:&[[u8;16]], f:&Fields,
    run:Ready, copy_mode:usize, early:bool, prefetch:usize) {
    static MODE:std::sync::OnceLock<u8>=std::sync::OnceLock::new();
    let m=*MODE.get_or_init(||std::env::var("BTR_LAB_ALPHABET").unwrap_or_default().parse().unwrap_or(0));
    if m==9 {
        COPY_TOTALS.with(|tot| {
            let mut v=tot.0.get();v[0]+=run.count;
            if run.at+16<=dst.len() && run.lit+16<=lits.len() {
                for h in 0..run.count {
                    if BOOK && f.src[h]>=BOOK_BIT {continue;}
                    let ll=f.ll[h] as usize;let size=ll+f.ml[h] as usize;
                    let off=f.dst[h].wrapping_sub(f.src[h]) as usize;
                    if size<=16 && off>=size {v[1]+=1;v[match ll {0=>2,1=>3,2..=4=>4,_=>5}]+=1;}
                }
            }
            tot.0.set(v);
        });
    }
    macro_rules! do_copy {($v:literal)=>{restore_style::<BOOK,$v>(dst,lits,book,f,run,copy_mode,early,prefetch)};}
    match m {1=>do_copy!(1),2=>do_copy!(2),3=>do_copy!(3),_=>do_copy!(0)}
}
'''
    s=src.replace(mark,wrapper+mark.replace('restore_ready<const BOOK: bool>','restore_style<const BOOK: bool, const STYLE: u8>'))
    hook='''                    let a = vld1q_u8(l);
                    let b = vld1q_u8(source);
                    let ix = vld1q_u8(SHUF[ll].as_ptr());'''
    if s.count(hook)!=1:raise ValueError('fused copy changed')
    return s.replace(hook,'''                    let b = vld1q_u8(source);
                    if (STYLE == 1 || STYLE == 2) && ll == 0 {
                        vst1q_u8(d, b);
                        continue;
                    }
                    let a = vld1q_u8(l);
                    if STYLE == 2 {
                        // Read both vectors before either store. The verified
                        // destination headroom permits both complete stores.
                        vst1q_u8(d.sub(ll), a);
                        vst1q_u8(d, b);
                        continue;
                    }
                    let ix = if STYLE == 3 {
                        let lane=vld1q_u8([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15].as_ptr());
                        let shift=vdupq_n_u8((16-ll) as u8);
                        vaddq_u8(lane,vandq_u8(vcgeq_u8(lane,vdupq_n_u8(ll as u8)),shift))
                    } else {vld1q_u8(SHUF[ll].as_ptr())};''')
