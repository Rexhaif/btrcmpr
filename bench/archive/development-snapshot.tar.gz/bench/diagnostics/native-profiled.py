#!/usr/bin/env python3
"""Independently verify the fastest repeatable compiler variant using its exact measured executables."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--levels',default='2,6',help='additional predeclared holdout levels');p.add_argument('--prepare',action='store_true');p.add_argument('--regional',action='store_true',help='formally retest the frozen regional scanner after repeated enwik8 wins');a=p.parse_args()
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';lab=base/'research/release-codegen';cache=root/'bench/local/levels/lanes';snap=cache/'native-fastest-1';out=base/'native-profiled-1'
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
meta=json.loads((base/'native-fastest-1/manifest.json').read_text())
if a.regional:
    name='native-regional-scan-1';lab=base/'research'/name;snap=cache/name;out=base/name
if not (lab/'README.md').is_file():raise ValueError('compiler trial incomplete')
study=json.loads((lab/'manifest.json').read_text())
rates={r['tag']:r for r in read(lab/'paired.csv') if r['codec']=='btrcmpr'}
if a.regional:
    from decode_gate import DEFAULT_DECODE_LOSS_PCT,qualifies
    from level_one_lab import costs
    if not a.prepare and rates['regional-enwik8']['pass_at_5pct']=='1':
        subprocess.run([sys.executable,root/'bench/diagnostics/regional-repeat.py'],cwd=root,check=True)
    tags=('regional-enwik8','regional-enwik8-repeat','regional-mozilla','regional-x-ray')
    missed=[]
    for tag in tags:
        paired=read(lab/(tag+'.csv'));pair=[costs(paired,c) for c in ('btrcmpr','zstd')]
        ok=qualifies(pair,DEFAULT_DECODE_LOSS_PCT)
        if ok!=(rates[tag]['pass_at_5pct']=='1'):raise ValueError('scanner summary and raw pairs disagree')
        if not ok:missed.append(tag)
    if missed:
        # A missed repeat remains a miss. When the independent, longer follow-up
        # qualifies on every input, characterize a fresh 66-cell matrix once
        # without asserting that the original five-pair repeat was successful.
        from decimal import Decimal
        from statistics import median
        valid=missed==['regional-enwik8-repeat']
        for name in ('enwik8','x-ray','mozilla'):
            longer=lab/'long-repeat'/(name+'.csv')
            if not longer.is_file():valid=False;continue
            rows15=read(longer);vals=[]
            for codec,n in [('btrcmpr',study['expected_archives'][name][0]),('zstd',int(next(r['bytes'] for r in read(lab/'paired.csv') if r['tag']=='regional-'+name and r['codec']=='zstd')))]:
                seq=[r for r in rows15 if r['codec']==codec]
                if len(seq)!=15 or {int(r['round']) for r in seq}!=set(range(1,16)) or any(int(r['compressed_bytes'])!=n for r in seq):raise ValueError('invalid extended regional trials')
                vals.append((n,*(median(Decimal(r[k]) for r in seq) for k in ('compress_seconds','decompress_seconds'))))
            valid=valid and qualifies(vals,DEFAULT_DECODE_LOSS_PCT)
        if not valid:
            print('Regional characterization deferred: the replicate and the longer check did not establish qualification.');raise SystemExit()
    build={k:study[v] for k,v in [('comparator','comparator_sha256'),('cli','cli_sha256'),('profile','profile_runner_sha256'),('settings','settings')]}
    if meta['input_sha256']!=study['input_sha256'] or meta['zstd_library_sha256']!=study['reference_sha256'] or int(study['regional_scan'])==0:raise ValueError('wrong regional comparator or baseline')
    meta['source_sha256']=study['source_sha256'];binary_dir=snap/'target/profiled/release';training='manifest.json'
    known={r['file']:(r['archive_sha256'],r['bytes'],r['source_sha256']) for r in read(lab/'cli.csv') if r['independent_stock_decoder']=='1'}
    intro=('The initial five-pair series passed all three files, but its five-pair enwik8 repeat missed on encode. The [separate 15-pair study](../research/native-regional-scan-1/long-repeat/README.md) passed all three. This series characterizes the candidate afresh; the earlier miss remains recorded.' if missed else 'Both enwik8 comparisons and one on each other input qualified in the [regional scanner study](../research/native-regional-scan-1/README.md).')+' These are the exact independently trained executables, without research switches, with separate standalone restoration.'
else:
    build=study['builds']['thin-pgo']
    if meta['source_sha256']!=study['source_sha256'] or meta['input_sha256']!=study['input_sha256'] or meta['zstd_library_sha256']!=study['reference_library_sha256']:raise ValueError('source or reference changed')
    if not all(rates['thin-pgo-mozilla'+suffix]['pass_at_5pct']=='1' for suffix in ('','-repeat')):raise ValueError('release candidate did not repeat')
    binary_dir=cache/'low-codegen/thin-pgo/target/release';training='training.json'
    known={v['input']:(v['archive_sha256'],v['cli_bytes'],v['source_sha256']) for v in read(base/'native-fastest-1/cli.csv')}
    intro='Fresh warmed pairs on all three inputs. The executable was frozen after two independent Mozilla wins in the [compiler study](../research/release-codegen/README.md). No research switches are compiled into it. Each complete archive is byte-identical to the stock native level 1; the exact frozen standalone CLI restores every input without linking libzstd.'
digest=build['comparator']
if {str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}!=meta['source_sha256']:raise ValueError('wrong source tree')
folder=root/'bench/local/preset-binaries';folder.mkdir(parents=True,exist_ok=True)
for name,target,expect in [('compare',digest,digest),('btrcmpr','cli-'+build['cli'],build['cli'])]:
    src=binary_dir/name;dst=folder/target
    if sha(src)!=expect:raise ValueError('measured executable has changed')
    if not dst.exists():shutil.copy2(src,dst)
    if sha(dst)!=expect:raise ValueError('wrong frozen executable')
out.mkdir(exist_ok=True)
runid=dict(build,source_manifest=f'../research/{lab.name}/manifest.json',training_manifest=f'../research/{lab.name}/{training}',compiler=study['rustc'],holdouts=a.levels)
meta['benchmark_sha256']=digest
for name,obj in [('codegen.json',runid),('reference.json',meta)]:
    path=out/name
    if path.exists() and json.loads(path.read_text())!=obj:raise ValueError('frozen metadata changed')
    path.write_text(json.dumps(obj,indent=2)+'\n')
if a.prepare:raise SystemExit()
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','CARGO_PROFILE_','ZSTD_'))}
with (out/'run.log').open('a',buffering=1) as log:
    def run(cmd,status=(0,)):
        print(cmd,file=log,flush=True);v=subprocess.run(cmd,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT)
        if v.returncode not in status:raise ValueError(str(cmd[1])+' failed; see '+str(out/'run.log'))
    run([sys.executable,'scripts/preset-matrix.py',*(['--resume'] if (out/'manifest.json').exists() else ['--from-manifest',out/'reference.json']),'--levels','1','--threads','4','--rounds','5','--decodes','7','--out',out],(0,1))
    run([sys.executable,root/'bench/diagnostics/preset-cli.py',out/'matrix.csv','--out',out/'cli.csv','--binary',folder/('cli-'+build['cli']),'--sha256',build['cli']])
    run([sys.executable,snap/'bench/diagnostics/preset-rates.py',out/'matrix.csv','--out',out/'rates.csv'])
checked={v['input']:(v['archive_sha256'],v['cli_bytes'],v['source_sha256']) for v in read(out/'cli.csv') if v['restored_identical']=='1'}
if checked!=known or len(checked)!=3:raise ValueError('native level 1 archives changed')
status={x['file']:x for x in read(out/'matrix-decode-tolerance.csv')}
rows=[]
for v in read(out/'rates.csv'):
    f=v['file'];yes=status[f]['all_pass_with_allowance']=='1'
    rows.append(f"| [{f}](level-01-{f}.csv) | {v['btr_ratio']} / {v['zstd_ratio']} | {v['btr_encode_MBps']} / {v['zstd_encode_MBps']} | {v['btr_decode_MBps']} / {v['zstd_decode_MBps']} | {'Yes' if yes else 'No'} |")
(out/'README.md').write_text('\n'.join(['# Independent production check of the profiled build','',
  intro,'',
  '| Raw pairs | Ratio, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---|',*rows,'',
  f'Four workers per codec in both directions. [Exact compiler build and standalone identity](codegen.json), [production archive identities](cli.csv), [production matrix](../integrated/{digest}/README.md). Levels {a.levels} were selected for further checks before measuring the new native series.','']))
subprocess.run([sys.executable,root/'bench/diagnostics/integrated.py','--workspace',snap,'--origin',out,'--out',base/'integrated'/digest,'--levels',a.levels],cwd=root,check=True)
