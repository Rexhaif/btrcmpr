#!/usr/bin/env python3
"""Verify integrated offset lanes against rewritten archives and time complete encoders."""
import argparse,csv,hashlib,json,os,shutil,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];dest=a.out.resolve();dest.mkdir(parents=True,exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
bindir=root/env.get('CARGO_TARGET_DIR','target')/'release'
candidate=bindir/'examples/candidate';paired=bindir/'compare';dec=bindir/'examples/decode_loop'
raw=root/'bench/data/enwik8';w=root/'bench/local/levels/lanes';arc=w/'integrated-span.btr'
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
eh=digest(paired);frozen=root/'bench/local/preset-binaries'/eh
if not frozen.exists():shutil.copy2(paired,frozen)
if digest(frozen)!=eh:raise ValueError('frozen executable changed')
(dest/'manifest.json').write_text(json.dumps(dict(input_sha256=digest(raw),candidate_sha256=digest(candidate),paired_sha256=eh,
        threads=4,source={str(x.relative_to(root)):digest(x) for x in sorted((root/'src').rglob('*.rs'))}),indent=2)+'\n')
options={}
with (dest/'screen.csv').open('w',buffering=1) as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('level','shape','ranked_offsets','archive_bytes','encode_MBps','decode_MBps','wire_sha256','rewritten_identical'))
    for lv,tag,kib,rank in [(9,'nine',24576,1),(8,'eight',24576,0),(6,'six',5120,0)]:
        for shape in ([2,6] if lv!=6 else [7]):
            run=subprocess.run([candidate,'4',str(lv),raw,'selected'],env=dict(env,BTR_SPAN_SHAPE=str(shape+1),BTR_SPAN_RANK=str(rank),
                  BLOCK_KIB=str(kib),PRESET_ALIGN='1',BTR_CANDIDATE_FRAME=str(arc)),capture_output=True,text=True,check=True)
            row=next(csv.DictReader(run.stdout.splitlines()));n=int(row['bytes']);h=digest(arc)
            old=w/f'span-{tag}-{shape}-{rank}.btr'
            if old.is_file() and digest(old)!=h:raise ValueError(f'new encoder differs from rewritten {old}')
            subprocess.run([dec,arc,'1','3',raw],check=True,env=env)
            wr.writerow((lv,shape,rank,n,row['encode_MBps'],row['decode_MBps'],h,'1' if old.is_file() else ''))
            if n<{6:32648306,8:31639517,9:31168040}[lv]:
                options.setdefault(lv,[]).append((float(row['decode_MBps']),shape,rank,kib,n))
for lv in (8,9):
    if lv not in options:continue
    speed,shape,rank,kib,size=max(options[lv])
    if lv==8 and speed<880:continue
    sub=dest/f'paired-{lv}';sub.mkdir(exist_ok=True);trial=sub/'rounds.partial'
    (sub/'settings.json').write_text(json.dumps(dict(level=lv,shape=shape,ranked_offsets=rank,chunk_KiB=kib,rounds=5,decodes=7))+'\n')
    subprocess.run([frozen,'4','5','both',raw],env=dict(env,BTR_TRIAL_METHOD='selected',BTR_SPAN_SHAPE=str(shape+1),BTR_SPAN_RANK=str(rank),
         BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),BTR_GRAM_JOB_KIB=str(kib),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(trial)),check=True)
    with trial.open() as f:rows=list(csv.DictReader(f))
    summary=[]
    for codec,want in [('btrcmpr',size),('zstd',{8:31639517,9:31168040}[lv])]:
        seq=[r for r in rows if r['codec']==codec]
        if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=want for r in seq):raise ValueError('incomplete pair')
        summary.append((codec,want,*(round(100/statistics.median(float(r[k]) for r in seq),3) for k in ('compress_seconds','decompress_seconds'))))
    trial.replace(sub/'rounds.csv')
    with (sub/'summary.csv').open('w') as f:
        wr=csv.writer(f,lineterminator='\n');wr.writerow(('codec','archive_bytes','encode_MBps','decode_MBps'));wr.writerows(summary)
