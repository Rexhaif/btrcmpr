#!/usr/bin/env python3
"""Preserve the sampled ARM code behind the level-one palette lookup experiment."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',type=Path,required=True);p.add_argument('--profile-dir',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();out=a.profile_dir.resolve();exe=snap/'target/release/examples/profile';perf=root/'bench/local/perf'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
build=re.search(r'Build ID: ([0-9a-f]+)',subprocess.check_output(['readelf','-n',exe],text=True))[1]
for name in ('enwik8','mozilla'):
    meta=json.loads((out/name/'c/manifest.json').read_text());data=root/'bench/local/levels/lanes'/('native-fastest-samples-'+name)/'ours.data'
    if sha(exe)!=meta['profile_sha256'] or sha(snap/'src/palette.rs')!=meta['source_sha256']['src/palette.rs']:raise ValueError('build changed')
    if build not in subprocess.check_output([perf,'buildid-list','--with-hits','-i',data],text=True):raise ValueError('samples from wrong build')
    lines=subprocess.check_output([perf,'script','-i',data,'-F','ip,sym,dsoff'],text=True).splitlines()
    hits=Counter(int(m[1],16) for row in lines if 'palette::write_groups' in row and (m:=re.search(r'\+0x([a-f0-9]+)\)',row)))
    if not hits:raise ValueError('no palette samples')
    addr,n=hits.most_common(1)[0];window=subprocess.check_output(['objdump','-dC','--start-address',hex(addr-96),'--stop-address',hex(addr+144),exe],text=True)
    fn=subprocess.check_output(['addr2line','-fCi','-e',exe,hex(addr)],text=True)
    (out/name/'palette-disassembly.txt').write_text(f'ELF build ID {build}\nHighest-count instruction address in palette::write_groups: {hex(addr)}, {n} retired-instruction samples.\nThe window shows scalar byte loads from the per-symbol table. Sample addresses are not exact stall attribution.\n\n{fn}\n{window}')
