#!/usr/bin/env python3
"""Specialize NEON rank-to-symbol lookup to the transmitted alphabet, keeping wire bytes fixed."""
import argparse,csv,json,os,re,shutil,subprocess,sys,tempfile
from pathlib import Path
from statistics import median
from level_one_lab import read,sha
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';origin=base/'native-object-workspace-1';prior=root/'bench/local/levels/lanes/native-object-workspace';lab=prior.parent/'palette-alphabet';out=base/'research/palette-alphabet'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepare',action='store_true');options=p.add_mutually_exclusive_group();options.add_argument('--copies',action='store_true',help='compare fused short-match writes instead of palette loops');options.add_argument('--chains',action='store_true',help='compare independent lookup chains for large alphabets');a=p.parse_args()
if a.copies:lab=prior.parent/'fused-copies';out=base/'research/fused-copies'
if a.chains:lab=prior.parent/'palette-chains';out=base/'research/palette-chains'
stamp=json.loads((origin/'codegen.json').read_text());meta=json.loads((origin/'manifest.json').read_text());src=root/'bench/data/enwik8';perf=root/'bench/local/perf'
if sha(src)!=meta['input_sha256']['enwik8'] or any(sha(prior/k)!=v for k,v in meta['source_sha256'].items()):raise ValueError('wrong candidate for decoder experiment')
lab.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
for f in ('Cargo.toml','Cargo.lock'):shutil.copy2(prior/f,lab/f)
for d in ('src','examples','.cargo','bench/support'):shutil.copytree(prior/d,lab/d,dirs_exist_ok=True)
def once(s,old,new):
    if s.count(old)!=1:raise ValueError('unexpected source: '+old)
    return s.replace(old,new)
r=lab/'src/palette.rs';s=r.read_text();lo=s.index('unsafe fn vector<const K: usize>(');hi=s.index('pub fn get(',lo)
orig=s[lo:hi];borrowed=once(orig,'fn vector<const K: usize>','fn by_alphabet<const K: usize, const BANKS: u8, const ADAPT: bool>')
lo2=borrowed.index('            let mut sym = vqtbl4q_u8(t0, rank);');hi2=borrowed.index('            vst1q_u8(out.',lo2)
borrowed=borrowed[:lo2]+'''            // Ranks outside the declared alphabet decode to zero, exactly like
            // the padded symbol table in the full lookup. TBL also returns zero
            // for an index outside its vector table.
            let mut sym = if BANKS == 0 { vqtbl1q_u8(vld1q_u8(sy.as_ptr()), rank) } else { vqtbl4q_u8(t0, rank) };
            if BANKS >= 2 && (!ADAPT || vmaxvq_u8(rank) >= 64) {
                sym = vqtbx4q_u8(sym, t1, vsubq_u8(rank, vdupq_n_u8(64)));
                if BANKS >= 3 { sym = vqtbx4q_u8(sym, t2, vsubq_u8(rank, vdupq_n_u8(128))); }
                if BANKS >= 4 { sym = vqtbx4q_u8(sym, t3, vsubq_u8(rank, vdupq_n_u8(192))); }
            }
'''+borrowed[hi2:]
if a.chains:
    begin=borrowed.index('            // Ranks outside');end=borrowed.index('            vst1q_u8(out.',begin)
    borrowed=borrowed[:begin]+(root/'bench/diagnostics/experiments/palette-chains.rs').read_text()+borrowed[end:]
s=s[:hi]+'''#[cfg(target_arch="aarch64")]
#[allow(clippy::too_many_arguments)]
'''+borrowed+s[hi:]
lo=s.index('    #[cfg(target_arch = "aarch64")]\n    let (at, mut bit) = unsafe',s.index('pub fn get('));hi=s.index('    #[cfg(not(target_arch = "aarch64"))]',lo)
old=s[lo:hi];control=old[old.index('        match k'):old.index('\n    };')]
variants=control.replace('vector::<','by_alphabet::<')
for k in range(1,6):variants=variants.replace(f'::<{k}>',f'::<{k}, $banks, $adapt>')
new='''    #[cfg(target_arch = "aarch64")]
    let (at, mut bit) = unsafe {
        static MODE: std::sync::OnceLock<u8> = std::sync::OnceLock::new();
        let mode = *MODE.get_or_init(|| std::env::var("BTR_LAB_ALPHABET").unwrap_or_default().parse().unwrap_or(0));
        if mode == 9 { eprintln!("palette-field {ns} {n}"); }
        macro_rules! run { ($banks:literal,$adapt:literal) => { '''+variants+''' }; }
        match (mode,ns) {
            (1..=3, 0..=16) => run!(0,false),
            (1..=3, 17..=64) => run!(1,false),
            (2..=3, 65..=128) => run!(2,false),
            (2..=3, 129..=192) => run!(3,false),
            (3, _) => run!(4,true),
            _ => '''+control+'''
        }
    };
'''
if a.chains:
    i=new.index('        match (mode,ns)');j=new.index('            _ => ',i)
    new=new[:i]+'''        match mode {
            1 => run!(1,false),
            2 => run!(2,false),
            3 => run!(3,false),
'''+new[j:]
if a.copies:
    from fused_copy_modes import modify
    r=lab/'src/lz.rs';r.write_text(modify(r.read_text()))
else:
    r.write_text(once(s,old,new))
if a.prepare:raise SystemExit()
target=lab/'target';exe=target/'release';gold,=[v for v in read(origin/'cli.csv') if v['input']=='enwik8'];ref,=[v for v in read(origin/'rates.csv') if v['file']=='enwik8'];frozen=root/'bench/local/preset-binaries'/('cli-'+stamp['cli'])
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','ZSTD_','PROFILE_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS','BTRCMPR_NATIVE_SCAN')}
e.update(BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',DEC_ITERS='7',WARMUP='1',LC_ALL='C')
model=prior/'target/profiled'/('native-'+stamp['profile_data_sha256']+'.profdata')
with (out/'build.log').open('w') as f:
    subprocess.run([sys.executable,root/'scripts/build-profiled.py','--workspace',lab,'--target-dir',target,'--profile-data',model,'--profile-sha256',stamp['profile_data_sha256'],'--selected'],env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
if sha(frozen)!=stamp['cli']:raise ValueError('frozen CLI changed')
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',subprocess.check_output(['ldd',exe/'compare'],text=True))[1])
if sha(lib)!=meta['zstd_library_sha256']:raise ValueError('zstd reference changed')
def write(path,header,rows):
    with (out/path).open('w') as f:
        w=csv.writer(f,lineterminator='\n');w.writerow(header);w.writerows(rows)
arc=lab/'frozen.btr';subprocess.run([frozen,'c','-1',src,arc,'4'],env=e,capture_output=True,check=True)
if sha(arc)!=gold['archive_sha256']:raise ValueError('archive differs')
proof=[];bins=[[0,0] for _ in range(5)];counts_by_length=[0]*6
with tempfile.TemporaryDirectory(dir=lab) as td:
    for mode in [0,1,2,3,9]:
        back=Path(td)/'output';z=subprocess.run([exe/'btrcmpr','d',arc,back,'4'],env=dict(e,BTR_LAB_ALPHABET=str(mode)),text=True,capture_output=True,check=True)
        if sha(back)!=gold['source_sha256']:raise ValueError('wrong decoded output')
        proof.append([mode,sha(arc),sha(back)])
        if mode==9 and a.copies:
            for row in re.findall(r'^copy-totals (.+)$',z.stderr,re.M):
                for i,n in enumerate(row.split()):counts_by_length[i]+=int(n)
            if not counts_by_length[1] or counts_by_length[1]!=sum(counts_by_length[2:]):raise ValueError('wrong copy counts')
        if mode==9 and not a.copies:
            for ns,n in re.findall(r'^palette-field (\d+) (\d+)$',z.stderr,re.M):
                idx=next(i for i,v in enumerate((16,64,128,192,256)) if int(ns)<=v);bins[idx][0]+=1;bins[idx][1]+=int(n)
            if not sum(k[1] for k in bins):raise ValueError('no measured palette fields')
write('wire.csv',['mode','archive_sha256','restored_sha256'],proof)
if a.copies:write('command-counts.csv',['commands','eligible','no_literal','one_literal','two_to_four_literals','five_or_more_literals'],[counts_by_length])
else:write('alphabet.csv',['max_symbols','fields','decoded_field_bytes'],[(n,*v) for n,v in zip((16,64,128,192,256),bins,strict=True)])
events=('instructions:u','cycles:u','branches:u','branch-misses:u','r03:u','r17:u');pmu=[];order=[[0,1,2,3],[1,0,3,2],[2,3,0,1],[3,2,1,0]];reps=8;raw=src.stat().st_size
for b,seq in enumerate(order):
    for mode in seq:
        with tempfile.TemporaryDirectory() as td:
            ctl,ack=(Path(td)/n for n in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
            proc=subprocess.run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exe/'examples/profile','d','ours',src,'4',str(reps)],env=dict(e,BTR_LAB_ALPHABET=str(mode),PERF_CTL=str(ctl),PERF_ACK=str(ack)),text=True,capture_output=True,check=True)
        log=proc.stderr;(out/f'block-{b}-mode-{mode}.txt').write_text(log)
        if 'archive_bytes='+gold['cli_bytes']+'\n' not in log:raise ValueError('wrong frame for counters')
        counts={v[2]:int(v[0])/(raw*reps) for line in log.splitlines() if len(v:=line.split(';'))>2 and v[2] in events}
        pmu.append([b+1,mode,*[counts[x] for x in events],float(re.search(r'([\d.]+) MB/s',log)[1])])
write('counters.csv',['block','mode','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','l1d_refills_per_byte','l2d_refills_per_byte','MBps'],pmu)
val=lambda m,j:median(r[j] for r in pmu if r[1]==m)
names=['All 256 symbols','Short alphabet up to 64','All alphabet lengths','Also test rank range per group'];ordered=sorted(range(1,4),key=lambda m:val(m,3))
if a.copies:names=['Original shuffle mask','Skip shuffle for zero literals','Two writes','Compute shuffle in registers']
if a.chains:names=['Four serial lookups','Two chains of two','Four independent lookups','Chain of three plus one']
best=ordered[0];pairs={};promotion=False
if val(best,3)<=.98*val(0,3) and val(best,8)>=1.02*val(0,8):
    for m in (best,0):
        path=out/f'paired-mode-{m}.csv';partial=path.with_suffix('.partial');z=subprocess.run([exe/'compare','4','15','both',src],env=dict(e,BTR_LAB_ALPHABET=str(m),TRIALS_CSV=str(partial)),text=True,capture_output=True,check=True);(out/f'paired-mode-{m}.log').write_text(z.stdout+z.stderr)
        groups={};rr=read(partial)
        for c,size in [('btrcmpr',gold['cli_bytes']),('zstd',ref['zstd_bytes'])]:
            seq=sorted((r for r in rr if r['codec']==c),key=lambda r:int(r['round']))
            if len(seq)!=15 or any((int(r['round']),r['compressed_bytes'],int(r['order']))!=(i,size,i%2 if c=='btrcmpr' else (i+1)%2) for i,r in enumerate(seq,1)):raise ValueError('invalid 15 pairs')
            groups[c]=[raw/1e6/median(float(r[k]) for r in seq) for k in ('compress_seconds','decompress_seconds')]
        partial.replace(path);pairs[m]=groups
    t=pairs[best];c=pairs[0];promotion=t['btrcmpr'][0]>t['zstd'][0] and t['btrcmpr'][1]>=.95*t['zstd'][1] and t['btrcmpr'][1]/t['zstd'][1]>=1.02*c['btrcmpr'][1]/c['zstd'][1]
doc=['# Rank lookup for short transmitted alphabets','','The existing ARM palette decoder loads 256 symbol values and applies four table lookups to every 16 output symbols. When the header declares at most 16 or 64 symbols, the first table already contains all possible nonzero entries. The other experiments also specialize 128 and 192 symbols, or inspect the maximum rank in each group. Out-of-range indices still yield the original zero padding. The [alphabet census](alphabet.csv) counts each field exactly once while independently restoring the frozen archive.','','| Lookup | Instructions/output B | Cycles/output B | Decode MB/s |','|---|---:|---:|---:|']
if a.copies:
    doc[0]='# Short literal and match copies on ARM'
    doc[2]='In the native [enwik8 decode profile](../../../profiles/object-workspace-enwik8-decode/decode-cycles.txt) 20.7% of cycle samples mapped near the fused shuffle-mask load. Such a sample can also reflect a neighboring history load. On the identical archive, these variants skip the shuffle for zero literals, issue two overlapping writes after loading both inputs, or calculate shuffle indices in registers. [Command counts](command-counts.csv) come from one full decode with instrumentation disabled during timing.'
if a.chains:
    doc[0]='# Independent ARM lookups for full alphabets'
    doc[2]='The [alphabet census](../palette-alphabet/alphabet.csv) showed that most decoded bytes have a large alphabet. The current ARM decoder applies three dependent table extensions after its first 64-entry lookup. Each rank is in exactly one of the four banks, so shorter independent lookup chains can be ORed without changing any result. The three modes test different groupings of those banks. They use the same wire and measured input as the original.'
for m in range(4):doc.append(f'| {names[m]} | {val(m,2):.3f} | {val(m,3):.3f} | {val(m,8):.2f} |')
doc+=['','[Six hardware events from every run](counters.csv). Four Cortex-A76 workers, eight decodes per observation, four balanced orders, one experimental binary. Each variant restored the original file [byte-for-byte](wire.csv). The follow-up requires 2% fewer cycles and 2% higher decode throughput in the median before timing paired Rust and zstd trials.','']
if pairs:
    doc+=['| 15 pairs | Encode MB/s Rust / zstd | Decode MB/s Rust / zstd |','|---|---:|---:|']
    for m,v in pairs.items():doc.append(f"| [{names[m]}](paired-mode-{m}.csv) | {v['btrcmpr'][0]:.2f} / {v['zstd'][0]:.2f} | {v['btrcmpr'][1]:.2f} / {v['zstd'][1]:.2f} |")
else:doc.append('No variant cleared the fixed-archive screening rule.')
doc+=['',f'Passed the paired follow-up rule for a native candidate: **{promotion}**.','']
(out/'README.md').write_text('\n'.join(doc))
(out/'manifest.json').write_text(json.dumps(dict(prior=stamp,source=sha(r),profile=sha(exe/'examples/profile'),cli=sha(exe/'btrcmpr'),comparator=sha(exe/'compare'),reference_sha256=sha(lib),input=sha(src),archive=sha(arc),candidate=best,promotion=promotion,orders=order),indent=2)+'\n')
