"""Normalize enwik8 hardware-counter logs written by scripts/perf-stat.sh."""
import csv
import re
import sys
from pathlib import Path


def number(pattern, log):
    match = re.search(pattern, log, re.MULTILINE)
    if not match:
        raise ValueError(f"missing measurement: {pattern}")
    return match[1]


def rows(directory):
    for path in sorted(directory.glob("l*-?-*.txt")):
        level, phase, codec = path.stem[1:].split("-")
        log = path.read_text()
        if f"level={level} threads=4 " not in log:
            raise ValueError(f"unexpected preset or worker count: {path}")
        repetitions = int(number(rf"/profile {phase} {codec} bench/data/enwik8 4 (\d+)'", log))
        size = int(number(r"archive_bytes=(\d+)", log))
        cycles = int(number(r"^\s*(\d+)\s+cycles:u", log))
        instructions = int(number(r"^\s*(\d+)\s+instructions:u", log))
        rate = float(number(r"^([\d.]+) MB/s", log))
        original = 100_000_000
        total = original * repetitions
        yield [int(level), phase, codec, repetitions, original, size,
               round(cycles / total, 3), round(instructions / total, 3),
               round(instructions / cycles, 3), rate]


if __name__ == "__main__":
    out = csv.writer(sys.stdout, lineterminator="\n")
    out.writerow(("level", "phase", "codec", "repetitions", "original_bytes", "archive_bytes",
                  "cycles_per_byte", "instructions_per_byte", "instructions_per_cycle",
                  "counter_run_MBps"))
    out.writerows(sorted(rows(Path(sys.argv[1]))))
