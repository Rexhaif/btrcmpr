#!/usr/bin/env python3
"""Compile an isolated research snapshot, check it, then time its selected driver."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

arg=argparse.ArgumentParser(description=__doc__)
arg.add_argument('--snapshot',type=Path,required=True);arg.add_argument('--prepare',action='store_true')
arg.add_argument('--driver',type=Path);arg.add_argument('--out',type=Path)
a=arg.parse_args();root=Path(__file__).resolve().parents[2];snap=a.snapshot.resolve()
if a.prepare:
    snap.mkdir()
    for name in ['src','examples','tests','.cargo','bench/support']:shutil.copytree(root/name,snap/name)
    for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(root/name,snap/name)
    raise SystemExit()
if not a.driver or not a.out:arg.error('measuring needs --driver and --out')
target=snap/'target';env=dict(os.environ,CARGO_TARGET_DIR=str(target))
for name,args in [('tests',['test','--locked','--all-features']),('lint',['clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('build',['build','--locked','--release','--all-features','--bin','compare','--example','profile','--example','candidate','--example','decode_loop'])]:
    with (snap/('pre-'+name+'.log')).open('w') as log:subprocess.run(['cargo',*args],cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([sys.executable,a.driver.resolve(),'--workspace',snap,'--bin-dir',target/'release','--out',a.out.resolve()],cwd=root,check=True)
