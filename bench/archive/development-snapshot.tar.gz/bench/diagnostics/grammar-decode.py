#!/usr/bin/env python3
"""Compare decoder loops on exactly the same phrase archive, validating every process."""
import argparse
import csv
import os
from pathlib import Path
import random
import re
import subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--out", type=Path, required=True)
p.add_argument("--archive", type=Path, default=Path("bench/local/levels/lanes/grammar-4096.btr"))
p.add_argument("--rounds", type=int, default=3)
a = p.parse_args()
exe = Path("target/release/examples/decode_loop")
rng = random.Random(9062)
with a.out.open("w", buffering=1) as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(("round", "decoder", "neon_numbers", "spelling_pipeline", "decode_MBps"))
    for n in range(a.rounds):
        configs = [(0,0,0), (0,1,0), (0,0,1), (0,0,2), (0,1,3), (6,1,0)]
        rng.shuffle(configs)
        for mode, numbers, pipeline in configs:
            env = dict(os.environ, BTR_GRAM_DECODE=str(mode), BTR_GRAM_NUMBERS=str(numbers),
                       BTR_GRAM_PIPE=str(pipeline))
            trial = subprocess.run([exe, a.archive, "5", "4", "bench/data/enwik8"], env=env,
                                   capture_output=True, text=True, check=True)
            rate = re.search(r"([.\d]+) MB/s", trial.stderr)
            if rate is None:
                raise ValueError(trial.stderr)
            w.writerow((n+1, mode, numbers, pipeline, rate.group(1)))
