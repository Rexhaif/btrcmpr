#!/usr/bin/env python3
"""Verify the default level-20 window in the production executable without research options."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
from level_one_lab import sha, read

root=Path(__file__).resolve().parents[2];snap=root/'bench/local/levels/lanes/object-step-20'
out=root/'bench/results/presets/research/object-step';proof=json.loads((out/'wire.json').read_text())
if len(read(out/'code-window.csv'))!=10:raise ValueError('missing size-qualified paired run')
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PROFILE_','PERF_','CARGO_PROFILE_'))}
e['CARGO_TARGET_DIR']=str(snap/'target')
with (out/'standalone-build.log').open('w') as log:
    for cmd in [['cargo','test','--locked','--offline','--no-default-features'],['cargo','build','--locked','--offline','--release','--no-default-features','--bin','btrcmpr']]:
        subprocess.run(cmd,cwd=snap,env=e,check=True,stdout=log,stderr=subprocess.STDOUT)
cli=snap/'target/release/btrcmpr';prior=root/'bench/local/preset-binaries'/('cli-'+proof['decoding_cli_sha256'])
if sha(prior)!=proof['decoding_cli_sha256'] or 'libzstd' in subprocess.check_output(['ldd',cli],text=True):raise ValueError('wrong standalone codec')
src=root/'bench/data/mozilla'
with tempfile.TemporaryDirectory(dir=snap/'target') as td:
    arc,back=(Path(td)/k for k in ('archive','restored'))
    subprocess.run([cli,'c','-20',src,arc,'4'],check=True,env=e,capture_output=True)
    if sha(arc)!=proof['archive_sha256'] or arc.stat().st_size!=proof['bytes']:raise ValueError('default does not match independently predicted wire')
    for decoder in (cli,prior):
        subprocess.run([decoder,'d',arc,back,'3'],check=True,env=e,capture_output=True)
        if sha(back)!=proof['source_sha256']:raise ValueError('standalone restoration disagrees')
record=dict(encoder_and_decoder_sha256=sha(cli),independent_decoder_sha256=sha(prior),archive_sha256=proof['archive_sha256'],source_sha256=proof['source_sha256'],
            archive_bytes=proof['bytes'],encode_workers=4,decode_workers=3,rust_source={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))})
(out/'standalone.json').write_text(json.dumps(record,indent=2)+'\n')
