#!/usr/bin/env python3
"""Compare the ordinary LZ parse with separate absolute distance byte planes."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tempfile

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];out=a.out.resolve();out.mkdir(exist_ok=True,parents=True);exe=a.bin_dir.resolve()
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
(out/'manifest.json').write_text(json.dumps(dict(workers=4,source={p:sha(root/'src'/p) for p in ('flatdist.rs','lz.rs')},executables={b:sha(exe/b) for b in ('compare','examples/candidate','examples/decode_loop')}),indent=2)+'\n')
with (out/'screen.csv').open('w',buffering=1) as sf,(out/'paired.csv').open('w',buffering=1) as pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as tmp:
    sw=csv.writer(sf,lineterminator='\n');sw.writerow(('file','level','mode','KiB','fast_entropy','bytes','encode_MBps','decode_MBps'))
    pw=csv.writer(pf,lineterminator='\n');pw.writerow(('file','level','mode','KiB','fast_entropy','codec','bytes','encode_MBps','decode_MBps'))
    for name,lv,base,limit,ref_c,ref_d in [('enwik8',1,256,40669611,630,1640),('mozilla',1,128,19963738,740,1650),('enwik8',6,5120,32648306,30,990)]:
        src=root/'bench/data'/name;var='BTR_FLAT_OFFSETS' if lv==1 else 'BTR_PLANE_MIDDLE';job='BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB'
        cases=[(k,base,0) for k in (range(17) if lv==1 else [0,1,2,5,6,9,10,13,14])]
        if lv==1:cases.extend((k,b,h) for k in (1,2,3,5,6,9,13) for b,h in [(base//2,1),(2*base,1),(base,1)])
        else:cases.extend((k,b,0) for k in (1,2,5,9,10) for b in (6144,8192))
        random.Random(199+lv).shuffle(cases);eligible=[];best_size=None
        def cfg(mode,kib,h):return dict(env,**{var:str(mode),job:str(kib)},BTR_FAST_COUNTS=str(2*h),BTR_FAST_PLAN=str(2*h))
        def run(key):
            r=subprocess.run([exe/'examples/candidate','4',str(lv),src,'native'],env=key,capture_output=True,text=True,check=True)
            return next(csv.DictReader(r.stdout.splitlines()))
        for k,b,h in cases:
            row=run(cfg(k,b,h));n=int(row['bytes']);c=float(row['encode_MBps']);d=float(row['decode_MBps']);sw.writerow((name,lv,k,b,h,n,c,d))
            if k:
                cand=(min(c/ref_c,d/ref_d),c,d,n,k,b,h)
                if best_size is None or n<best_size[3]:best_size=cand
                if n<limit:eligible.append(cand)
        win=max(eligible) if eligible else best_size
        _,c,d,n,k,b,h=win;key=cfg(k,b,h);arc=Path(tmp)/'plane.btr'
        run(dict(key,BTR_CANDIDATE_FRAME=str(arc)))
        if arc.stat().st_size!=n:raise ValueError('unstable selected archive')
        subprocess.run([exe/'examples/decode_loop',arc,'1','3',src],env=env,check=True)
        subprocess.run([sys.executable,root/'bench/diagnostics/fast-wire.py','--single',arc,'--name',name,'--out',out/f'{lv}-{name}-wire'],check=True)
        if not eligible:continue
        f=out/f'{lv}-{name}.partial';subprocess.run([exe/'compare','4','5','both',src],env=dict(key,BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(f)),check=True)
        with f.open() as source:rows=list(csv.DictReader(source))
        for codec,expected in [('btrcmpr',n),('zstd',limit)]:
            group=[r for r in rows if r['codec']==codec]
            if len(group)!=5 or {int(r['round']) for r in group}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=expected for r in group):raise ValueError('unexpected comparison')
            pw.writerow((name,lv,k,b,h,codec,expected,*(round(src.stat().st_size/1e6/statistics.median(float(r[z]) for r in group),3) for z in ('compress_seconds','decompress_seconds'))))
        f.replace(f.with_suffix('.csv'))
