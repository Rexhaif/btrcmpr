#!/usr/bin/env python3
"""Measure file-learned row prediction in the 16-bit signal presets."""
import argparse
import csv
from pathlib import Path
import random
import struct
import tempfile
from level_one_lab import Lab,read,sha
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();name='x-ray';l=Lab(a.workspace,a.bin_dir,a.out,extra_inputs=(name,));orig=l.data/name
if sha(orig)!=l.spec['input_sha256'][name]:raise ValueError('unverified signal')
refs={int(r['level']):int(r['zstd_bytes']) for r in read(l.root/'bench/results/presets/decode-tolerance-cells.csv') if r['file']==name}
old={int(r['level']):int(r['btr_bytes']) for r in read(l.root/'bench/results/presets/decode-tolerance-cells.csv') if r['file']==name}
sf,sw=l.report('screen','level mode search reach KiB bytes encode_MBps decode_MBps')
pf,pw=l.report('paired','level mode search reach KiB tag codec bytes ratio encode_MBps decode_MBps pass_at_5pct')
ff,fw=l.report('fields','tag job kind stride smoothed coded bytes')
cf,cw=l.report('counters','level mode search reach KiB codec instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
doc=[];selected=[]
with sf,pf,ff,cf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'signal.btr'
    for lv in (2,6,12,22):
        control=(0,2,4096,2048)
        def cfg(x):
            m,t,d,k=x
            return dict(l.env,BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),BTR_SIGNAL_GRID=str(m),BTR_SIGNAL_SEARCH=str(t),BTR_SIGNAL_REACH=str(d),BTR_JOB_KIB=str(k))
        def trial(x,save=None):
            e=cfg(x)
            if save:e=dict(e,BTR_CANDIDATE_FRAME=str(save))
            v=next(csv.DictReader(l.run([l.exe/'examples/candidate','4',str(lv),orig,'native'],e).stdout.splitlines()))
            return int(v['bytes']),float(v['encode_MBps']),float(v['decode_MBps'])
        cases=[(m,t,d,k) for m in (1,2,3,4) for t,d in ((1,2048),(2,4096),(3,8192)) for k in (512,1024,2048)] if lv<=6 else list(dict.fromkeys(selected))
        cases=[control]+cases;random.Random(1908+lv).shuffle(cases);pool={}
        for x in cases:
            if x not in pool:pool[x]=trial(x);sw.writerow((lv,*x,*pool[x]))
        if pool[control][0]!=old[lv]:raise ValueError('native signal archive changed')
        # Use the current level's measured reference decoding rate to choose
        # the smallest candidate whose preliminary rate clears 95%.
        latest=next(r for r in read(l.root/'bench/results/presets/decode-tolerance-cells.csv') if r['file']==name and int(r['level'])==lv)
        raw=read(l.root/'bench/results/presets'/latest['latest_trials'])
        from level_one_lab import costs
        dz=float(orig.stat().st_size)/float(costs(raw,'zstd')[2])/1e6
        novel=[x for x in pool if x!=control];eligible=[x for x in novel if pool[x][0]<old[lv] and pool[x][2]>=.95*dz]
        keep=min(eligible or novel,key=lambda x:pool[x][0])
        fast=max(eligible or novel,key=lambda x:pool[x][1])
        smallest=min(novel,key=lambda x:pool[x][0])
        if lv<=6:selected.extend([keep,fast,smallest])
        for j,x in enumerate(dict.fromkeys([control,keep,fast,smallest])):
            tag=f'l{lv:02}-{j}';n,_,_=trial(x,arc);enc=arc.read_bytes()
            if n!=pool[x][0] or enc[:8]!=b'BTRCMP01' or int.from_bytes(enc[8:16],'little')!=orig.stat().st_size:raise ValueError('wrong signal frame')
            off=20;idx=0
            while off<len(enc):
                k=struct.unpack_from('<I',enc,off)[0];b=enc[off+4:off+4+k];off+=4+k
                if len(b)!=k or not k:raise ValueError('invalid job')
                fw.writerow((tag,idx,b[0],int.from_bytes(b[2:4],'little') if b[0]==63 else '',int(b[1]&1) if b[0]==63 else '',int(bool(b[1]&2)) if b[0]==63 else '',k));idx+=1
            for scalar in ('1','0'):l.restore(name,arc,dict(l.env,BTR_SIGNAL_SCALAR=scalar))
            if lv==6:cw.writerow((lv,*x,'btrcmpr',*l.perf(name,cfg(x),n,tag)))
            vals,ok=l.pair(name,cfg(x),n,refs[lv],tag)
            for codec,(b,c,d) in zip(('btrcmpr','zstd'),vals,strict=True):pw.writerow((lv,*x,tag,codec,b,round(orig.stat().st_size/b,4),round(c,3),round(d,3),int(ok)))
            (n,c,d),(z,cz,dz)=vals
            doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} / {x[3]} | {n:,} / {z:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
(l.out/'README.md').write_text('\n'.join(['# Standalone adaptive row prediction for 16-bit signals','',
  'Each job searches earlier sample spacings using a coarse sample and refines the shortlist using different positions. The predictor averages the most recent sample with either the earlier sample or three smoothed earlier samples. The encoder compares actual bytes against the native adjacent-sample representation. The decoder can invert eight rounded predictions in parallel from weighted prefix sums, with a scalar correction on wrapped residuals. All selected strides, mode flags, seeds and exceptional bytes are charged to the frame.','',
  '| Paired run | Predictor / search effort / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
  'Five alternating rounds after warmup, seven decodes, four workers per codec. Independent scalar and ARM vector decoders each restored every full finalist on three workers. [Which predictor and stride each job selected](fields.csv), [screens](screen.csv), [hardware counters](counters.csv), [binary and input hashes](manifest.json).','']))
