#!/usr/bin/env python3
"""Build the release without research controls and check three independently known level-one archives."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',type=Path,required=True);p.add_argument('--out',type=Path,help='new release results under bench/results/presets');a=p.parse_args()
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';out=a.out.resolve() if a.out else base/'native-fastest-1';snap=a.workspace.resolve()
if out.parent!=base or not out.name.startswith('native-fastest-'):raise ValueError('invalid native results path')
if not snap.is_relative_to(root/'bench/local'):raise ValueError('requires frozen source')
out.mkdir(exist_ok=True);env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};env.update(CARGO_TARGET_DIR=str(snap/'target'))
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
expected=json.loads((snap/'expected.json').read_text())
if set(expected)!={'enwik8','x-ray','mozilla'}:raise ValueError('incomplete expectations')
with (out/'run.log').open('a',buffering=1) as log:
    def run(cmd,allow=(0,)):
        print(cmd,file=log,flush=True);r=subprocess.run(cmd,cwd=snap,stdout=log,stderr=subprocess.STDOUT,env=env)
        if r.returncode not in allow:raise ValueError(f'{cmd[0]} exited {r.returncode}; see {out}/run.log')
    for features in (['--all-features'],['--no-default-features']):
        run(['cargo','test','--offline','--locked',*features])
        run(['cargo','clippy','--offline','--locked',*features,'--all-targets','--','-D','warnings'])
    run([sys.executable,'scripts/preset-matrix.py','--levels','1','--threads','4','--rounds','5','--decodes','7','--out',out,*(['--resume'] if (out/'manifest.json').exists() else [])],(0,1))
    for script,name in [('preset-cli','cli.csv'),('preset-rates','rates.csv')]:
        run([sys.executable,snap/'bench/diagnostics'/f'{script}.py',out/'matrix.csv','--out',out/name])
rates={r['file']:r for r in rows(out/'rates.csv')};checks={r['input']:r for r in rows(out/'cli.csv')};statuses={r['file']:r for r in rows(out/'matrix-decode-tolerance.csv')}
if not set(expected)==set(rates)==set(checks)==set(statuses):raise ValueError('matrix missing inputs')
table=[]
for name,(size,digest) in expected.items():
    r,c,st=rates[name],checks[name],statuses[name]
    if c['archive_sha256']!=digest or c['restored_identical']!='1' or int(c['cli_bytes'])!=size or int(r['btr_bytes'])!=size or st['allow_decode_loss_pct']!='5':raise ValueError('unexpected archive or allowance: '+name)
    table.append(f"| [{name}](level-01-{name}.csv) | {size:,} / {int(r['zstd_bytes']):,} | {r['btr_ratio']} / {r['zstd_ratio']} | {r['btr_encode_MBps']} / {r['zstd_encode_MBps']} | {r['btr_decode_MBps']} / {r['zstd_decode_MBps']} | {'Yes' if st['all_pass_with_allowance']=='1' else 'No'} |")
digest=json.loads((out/'manifest.json').read_text())['benchmark_sha256']
description=(snap/'description.txt').read_text().strip() if (snap/'description.txt').is_file() else 'General blocks use six-byte match keys, 32 queued copy distances, a greedy rank-group planner, and 384 KiB jobs on ARM. Object archives choose a separate search and job policy for unstructured sections. Numeric records get exact bit-width prices from a cumulative histogram; constant columns bypass the predictor trials. The image predictor is unchanged.'
(out/'README.md').write_text('\n'.join(['# Production level one on all three inputs','',
description,'',
'| Input | Archive bytes, Rust / zstd | Ratio, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*table,'',
f'The [standalone CLI](cli.csv) restored every byte and matched the expected archive SHA-256 on every file. The [manifest](manifest.json) identifies comparator `{digest}`. Both codecs used four workers in both directions, five alternating pairs after warmup and seven decodes per measurement. Zstd had one independent quarter-file frame per worker. See the [single-build results](../integrated/{digest}/README.md).','']))
if (snap/'choices.json').is_file():
    (out/'choices.json').write_text((snap/'choices.json').read_text())
if (out/'choices.json').is_file():
    with (out/'README.md').open('a') as doc:doc.write('\n[Archive selection references](choices.json) identify the independently measured hashes that this build had to reproduce. The [snapshot preparation tool](../../../diagnostics/freeze-low.py) copies the source and checks those references before a new run.\n')

for cmd in [['integrated.py','--workspace',snap,'--origin',out,'--out',base/'integrated'/digest,'--report-only'],['preset-coverage.py','--out',base/'coverage.csv','--update-overview']]:
    subprocess.run([sys.executable,root/'bench/diagnostics'/cmd[0],*cmd[1:]],cwd=root,check=True)
