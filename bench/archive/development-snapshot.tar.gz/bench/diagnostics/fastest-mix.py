#!/usr/bin/env python3
"""Cross histogram, LZ job and structured-record job choices on full Mozilla."""
import argparse
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);name='mozilla';src=l.data/name
if sha(src)!=l.spec['input_sha256'][name]:raise ValueError('wrong corpus')
ref=costs(read(l.base/'group-key/mozilla-1.csv'),'zstd')
def cfg(x):
    key,k,count,batch,rec,plan=x
    return dict(l.env,BTR_RECORD_COST='2',BTR_QUICK_KEY='10' if key==10 else '0',BTR_GROUP_KEY='10' if key==10 else '0',BTR_FAST1='8' if key==8 else '0',BTR_FAST_COUNTS=str(count),BTR_FAST_PLAN=str(plan),BTR_GROUP_OFFSETS=str(batch),BTR_ARCH_KIB=str(k),BTR_RECORD_KIB=str(rec))
screen,sw=l.report('screen','key job_KiB counts batch record_KiB plan bytes encode_MBps decode_MBps')
pair,pw=l.report('paired','key job_KiB counts batch record_KiB plan tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
base=(10,128,1,0,128,0)
cases=[(key,k,c,b,128,0) for key in (10,8) for k in (96,128,192,256) for c in (0,1,2) for b in ((0,2) if key==10 else (0,))]
cases.extend((8,k,2,0,128,3) for k in (128,192,256))
random.Random(11159).shuffle(cases)
with screen,pair,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as tmp:
    arc=Path(tmp)/'candidate.btr';results={}
    def screen_one(x):
        if x in results:return
        n,c,d=l.trial(name,cfg(x));sw.writerow((*x,n,c,d));results[x]=(n,c,d)
    def rank():
        return sorted((x for x,(n,c,d) in results.items() if n<ref[0]),key=lambda x:(results[x][2]>1540,results[x][1]),reverse=True)
    for x in cases:screen_one(x)
    for x in rank()[:3]+[base]:
        for k in (64,256,512,1024):screen_one((*x[:4],k,x[5]))
    picks=[base]
    for x in rank():
        if len(picks)>=4:break
        if x not in picks and all(results[x][0]!=results[y][0] for y in picks):picks.append(x)
    table=[]
    def compare(x,tag):
        n=results[x][0];saved,_,_=l.trial(name,cfg(x),arc)
        if saved!=n:raise ValueError('screen changed size')
        digest=sha(arc);l.restore(name,arc,l.env)
        rates,ok=l.pair(name,cfg(x),n,ref[0],tag)
        for codec,(num,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((*x,tag,codec,digest if codec=='btrcmpr' else '',num,round(c,3),round(d,3),int(ok)))
        (nr,c,d),(nz,cz,dz)=rates
        table.append(f"| [{tag}]({tag}.csv) | {', '.join(map(str,x))} | {nr:,} / {nz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
        return ok,c/cz
    ranked=[(compare(x,f'mozilla-{i}'),x) for i,x in enumerate(picks)]
    x=max(ranked)[1];compare(x,'mozilla-repeat')
(l.out/'README.md').write_text('\n'.join(['# Level-one Mozilla combinations','', 'Every configuration uses the exact record-width optimizer. The columns in the configuration are key, generic archive job KiB, histogram policy, distance batch, record job KiB and palette planner. Key 10 uses a seven-byte key; key 8 uses the two-position stride parser. Histogram policies were varied independently of the palette planner.','', '| Raw samples | Configuration | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---|---:|---:|---:|---|',*table,'','Five alternating pairs per result, four workers on each side, seven decodes per measurement. The final pair independently repeats the strongest measured configuration. Every finalist was restored with three workers. [All screens](screen.csv), [archive hashes](paired.csv), [manifest](manifest.json).','']))
