#!/usr/bin/env python3
"""Screen token references over a phrase dictionary and run traced four-worker partition controls."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--dest',type=Path,required=True)
a=p.parse_args();a.dest.mkdir(parents=True,exist_ok=True)
root=Path(__file__).resolve().parents[2]
binroot=(root/os.environ.get('CARGO_TARGET_DIR','target'))/'release'
ours=binroot/'examples/candidate';paired=binroot/'compare';loop=binroot/'examples/decode_loop'
raw=root/'bench/data/enwik8'
local=root/'bench/local/levels/lanes'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
clean={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
subprocess.run(['cargo','test','--offline','--locked','--all-features'],cwd=root,check=True)
subprocess.run(['cargo','clippy','--offline','--locked','--all-features','--all-targets','--','-D','warnings'],cwd=root,check=True)
counters=subprocess.run([sys.executable,'bench/diagnostics/phrase-pmu.py','--level','13','--out',
                         'bench/results/profiles/enwik8-general/phrase-preset'],cwd=root)
if counters.returncode:
    print(f'Phrase PMU run exited {counters.returncode}; raw or partial perf logs are retained.',file=sys.stderr,flush=True)
def one(exe,args,env):
    r=subprocess.run([exe,*args],env={**clean,**env},capture_output=True,text=True)
    if r.returncode:raise RuntimeError(r.stderr+r.stdout)
    row=next(csv.DictReader(r.stdout.splitlines()))
    return row,r.stderr
(a.dest/'followup-manifest.json').write_text(json.dumps(dict(threads=4,full_bytes=raw.stat().st_size,input_sha256=digest(raw),
                   candidate_sha256=digest(ours),compare_sha256=digest(paired),decode_sha256=digest(loop),
                   sources={str(f.relative_to(root)):digest(f) for f in sorted((root/'src').rglob('*.rs'))}),indent=2)+'\n')
with (a.dest/'dag-matched.csv').open('w',buffering=1) as f,(a.dest/'dag-components.csv').open('w',buffering=1) as sizes:
    w=csv.writer(f,lineterminator='\n');cs=csv.writer(sizes,lineterminator='\n')
    w.writerow(('phrase_cap','width','matched','conditional_heads','bytes','encode_MBps','decode_MBps'))
    cs.writerow(('phrase_cap','width','matched','conditional_heads','raw_bytes','literal_tokens','dictionary_entries','match_bytes','dictionary_bytes','head_bytes','payload_bytes'))
    for cap,width,match,ctx in [(16384,48,0,0),(16384,48,0,1),(65536,64,0,1),
                               (4096,32,1,0),(16384,48,1,0),(32768,64,1,0),(65536,64,1,0),(16384,48,1,1)]:
        key=(cap,width,match,ctx)
        env=dict(BTR_DAG_CAP=str(cap),BTR_DAG_WIDTH=str(width),BTR_DAG_MIN='3',BTR_DAG_LZ=str(match),
                 BTR_DAG_TRACE='1',BTR_DAG_HEADS=str(ctx),BLOCK_KIB='24576',PRESET_ALIGN='1')
        if key in [(16384,48,0,0),(16384,48,1,0)]:env['BTR_CANDIDATE_FRAME']=str(local/f'dag-{match}.btr')
        r,log=one(ours,['4','22',raw,'lex-dag'],env)
        w.writerow((*key,r['bytes'],r['encode_MBps'],r['decode_MBps']))
        blocks=[list(map(int,line.split(',')[1:])) for line in log.splitlines() if line.startswith('dag,')]
        if len(blocks)!=4 or sum(x[0] for x in blocks)!=100_000_000:raise ValueError('incomplete block accounting')
        # Outer header is 20 bytes; each block has a four-byte outer size,
        # a one-byte mode and a four-byte count of rank payload bytes.
        if 20+sum(9+sum(x[3:]) for x in blocks)!=int(r['bytes']):raise ValueError('components do not sum to archive size')
        for block in sorted(blocks):cs.writerow((*key,*block))
with (a.dest/'dag-reparse.csv').open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n')
    w.writerow(('phrase_cap','rounds','penalty_sixteenths','matched','conditional_heads','bytes','encode_MBps','decode_MBps'))
    for cap,rounds,penalty,matched,ctx in [(32768,0,10,0,0),(32768,1,10,0,0),(65536,1,10,0,0),
                                          (65536,2,10,0,0),(65536,2,24,0,1),(16384,1,16,1,0)]:
        env=dict(BTR_DAG_CAP=str(cap),BTR_DAG_WIDTH='64',BTR_DAG_MIN='3',BTR_DAG_LZ=str(matched),
                 BTR_DAG_REPARSE=str(rounds),BTR_DAG_PENALTY=str(penalty),BTR_DAG_HEADS=str(ctx),
                 BLOCK_KIB='24576',PRESET_ALIGN='1')
        row,_=one(ours,['4','22',raw,'lex-dag'],env)
        w.writerow((cap,rounds,penalty,matched,ctx,row['bytes'],row['encode_MBps'],row['decode_MBps']))
with (a.dest/'weighted-jobs.csv').open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n')
    w.writerow(('level','mode','chunk_KiB','bytes','encode_MBps','decode_MBps','job_bytes_and_median_ms'))
    import statistics
    for lv,kib in [(8,24576),(6,5120),(8,12288)]:
        for mode in (0,1,2,3):
            env=dict(BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),ZSTD_WIDE='1',WARMUP='0',DEC_ITERS='7',
                     BTR_TRIAL_METHOD='weighted',BTR_WEIGHT_KIB=str(kib),BTR_MIX_WEIGHT=str(mode),BTR_JOB_TRACE='1')
            r,log=one(paired,['4','1','ours',raw],env)
            jobs={}
            for line in log.splitlines():
                if line.startswith('job,'):
                    _,ix,n,_,_,ns=line.split(',');jobs.setdefault((int(ix),int(n)),[]).append(int(ns))
            if not jobs or any(len(t)!=7 for t in jobs.values()):raise ValueError('incomplete job timings')
            detail=';'.join(f'{n}:{statistics.median(jobs[ix,n])/1e6:.2f}' for ix,n in sorted(jobs))
            w.writerow((lv,mode,kib,r['compressed_bytes'],r['compress_MBps'],r['decompress_MBps'],detail))
with (a.dest/'dag-mixtures.csv').open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('grammar_workers','share','weight_mode','bytes','encode_MBps','decode_MBps'))
    for jobs,share,weight in [(1,195,0),(1,195,2),(1,220,1),(2,405,0),(2,405,2),(2,450,1),(3,630,1)]:
        env=dict(BTR_LEVEL='16',ZSTD_LEVEL='16',ZSTD_WIDE='1',WARMUP='0',DEC_ITERS='7',BTR_TRIAL_METHOD='mix',
           BTR_GRAM_CAP='4096',BTR_GRAM_WIDTH='32',BTR_GRAM_PIPE='2',BTR_MIX_JOBS=str(jobs),BTR_MIX_SHARE=str(share),
           BTR_MIX_PLAIN='16',BTR_MIX_KIB='32768',BTR_MIX_WEIGHT=str(weight))
        r,log=one(paired,['4','1','ours',raw],env)
        w.writerow((jobs,share,weight,r['compressed_bytes'],r['compress_MBps'],r['decompress_MBps']))
perf=os.getenv('PERF') or shutil.which('perf')
if not perf and (root/'bench/local/perf').is_file():perf=str(root/'bench/local/perf')
if perf:
    for match in [0,1]:
        arc=local/f'dag-{match}.btr';samples=local/f'dag-{match}.perf'
        subprocess.run([perf,'record','-q','-e','cycles:u','-c','450009','-o',samples,'--',loop,arc,'12','4',raw],check=True)
        with (a.dest/f'dag-{match}-cycles.txt').open('w') as report:
            subprocess.run([perf,'report','--stdio','--no-children','--percent-limit','1','-i',samples],stdout=report,check=True)
subprocess.run([sys.executable,'bench/diagnostics/phrase-promotion.py','--research',a.dest,
                '--level','16','--out',a.dest/'paired-candidate-16'],cwd=root,check=True)
shared=[sys.executable,'bench/diagnostics/shared-phrases.py','--out','bench/results/presets/research/shared-phrases']
subprocess.run([*shared,'--prepare'],cwd=root,check=True)
subprocess.run(shared,cwd=root,check=True)
