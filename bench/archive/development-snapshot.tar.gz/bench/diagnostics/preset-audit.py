#!/usr/bin/env python3
"""Do not combine different executable, reference-library, or corpus identities in a 66-cell claim."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import statistics
from decode_gate import DEFAULT_DECODE_LOSS_PCT, allowance, columns, label, qualifies, write_csv

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',required=True,type=Path)
p.add_argument('--require-complete',action='store_true',help='exit nonzero unless one exact build passes all 66 cells')
p.add_argument('--require-binary',help='require this exact comparator to pass all 66 cells with verified CLI restorations')
p.add_argument('--allow-decode-loss-pct',type=allowance,default=DEFAULT_DECODE_LOSS_PCT,help='maximum per-cell decode throughput loss vs zstd (default: 5); 0 requires a strict win')
a=p.parse_args();root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
if a.require_binary and not re.fullmatch('[0-9a-f]{64}',a.require_binary):p.error('invalid comparator SHA-256')
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
corpus=dict(re.findall(r'^fetch (\S+) ([a-f0-9]{64}) ',(root/'scripts/fetch-data.sh').read_text(),re.M))
sizes={(int(r['level']),r['file']):(int(r['source_bytes']),int(r['zstd_bytes'])) for r in rows(base/'zstd-sizes.csv')}
if len(corpus)!=3 or len(sizes)!=66:raise ValueError('missing corpus identities or reference sizes')
known={};frozen=set()
for manifest in sorted(base.rglob('manifest.json')):
    relative=manifest.relative_to(base)
    if 'research' in relative.parts:continue
    spec=json.loads(manifest.read_text());digest=spec.get('benchmark_sha256','');lib=spec.get('zstd_library_sha256','')
    if not re.fullmatch('[a-f0-9]{64}',digest) or not re.fullmatch('[a-f0-9]{64}',lib):continue
    if spec.get('threads')!=4 or spec.get('zstd_frame_policy')!='one independent frame per worker' or spec.get('warmup_rounds',0)<1 or spec.get('rounds',0)<3 or spec.get('decodes',0)<5:continue
    if digest not in frozen:
        binary=root/'bench/local/preset-binaries'/digest
        if not binary.is_file() or sha(binary)!=digest:raise ValueError(f'frozen comparator missing or changed for {manifest}')
        frozen.add(digest)
    identity=(digest,lib);cells=known.setdefault(identity,{})
    standalone=manifest.parent/'cli.csv'
    native={(int(r['level']),r['input']):r for r in rows(standalone)} if standalone.is_file() else {}
    for lv in spec['levels']:
        for name in spec['files']:
            if spec['input_sha256'].get(name)!=corpus[name]:raise ValueError(f'wrong input in {manifest}')
            file=manifest.parent/f'level-{lv:02}-{name}.csv'
            if not file.is_file():continue
            data=rows(file);n=spec['rounds'];raw,rz=sizes[lv,name]
            if len(data)!=n*2 or any(Path(r['file']).name!=name or int(r['raw_bytes'])!=raw for r in data):raise ValueError(f'incomplete or wrong input: {file}')
            costs=[]
            for codec in ('btrcmpr','zstd'):
                group=[r for r in data if r['codec']==codec];sz={int(r['compressed_bytes']) for r in group}
                if len(group)!=n or len(sz)!=1 or {int(r['round']) for r in group}!=set(range(1,n+1)):raise ValueError(f'incomplete {file}')
                vals=(sz.pop(),*(statistics.median(Decimal(r[k]) for r in group) for k in ('compress_seconds','decompress_seconds')))
                if min(vals)<=0:raise ValueError(f'invalid costs {file}')
                costs.append(vals)
            if costs[1][0]!=rz:raise ValueError(f'zstd archive size mismatch in {file}')
            first=None
            for k in range(1,n+1):
                pair=[r for r in data if int(r['round'])==k]
                if {int(r['order']) for r in pair}!={0,1}:raise ValueError(f'not a pair: {file}')
                who=next(r['codec'] for r in pair if int(r['order'])==0)
                if first==who:raise ValueError(f'order did not alternate in {file}')
                first=who
            keep=(file.stat().st_mtime_ns,str(file.relative_to(base)))
            key=(lv,name)
            if key not in cells or keep>cells[key][0]:
                cli=native.get(key)
                if cli and (cli['source_sha256']!=corpus[name] or int(cli['cli_bytes'])!=costs[0][0] or
                        cli['restored_identical']!='1' or not re.fullmatch('[a-f0-9]{64}',cli['archive_sha256'])):raise ValueError(f'bad standalone check in {standalone}')
                cells[key]=(keep,tuple(v<u for v,u in zip(*costs,strict=True)),bool(cli),costs)
ranked=sorted(known.items(),key=lambda row:(-sum(all(v[1]) for v in row[1].values()),-len(row[1]),row[0]))
complete=0
with (out/'single-build.csv').open('w') as sf,(out/'single-build-cells.csv').open('w') as cf:
    sw=csv.writer(sf,lineterminator='\n');cw=csv.writer(cf,lineterminator='\n')
    sw.writerow(('comparator_sha256','libzstd_sha256','cells_measured','all_three_pass','miss','unmeasured','standalone_verified','complete'))
    cw.writerow(('comparator_sha256','libzstd_sha256','level','file','size_pass','encode_pass','decode_pass','standalone_verified','latest_trials'))
    for (binary,lib),cells in ranked:
        wins=sum(all(v[1]) for v in cells.values());clis=sum(v[2] for v in cells.values());ok=int(wins==clis==66);complete+=ok
        sw.writerow((binary,lib,len(cells),wins,len(cells)-wins,66-len(cells),clis,ok))
        for (lv,name),((_,file),flags,verified,_) in sorted(cells.items()):cw.writerow((binary,lib,lv,name,*map(int,flags),int(verified),file))
limits=columns(a.allow_decode_loss_pct);summ=[];details=[];allowed_complete=0
for (binary,lib),cells in ranked:
    for p in limits:
        wins=sum(qualifies(v[3],p) for v in cells.values())
        verified=sum(v[2] and qualifies(v[3],p) for v in cells.values())
        ok=int(verified==66)
        if p==a.allow_decode_loss_pct:allowed_complete+=ok
        summ.append((binary,lib,label(p),len(cells),wins,verified,66-len(cells),ok))
    for (lv,name),((_,file),flags,verified,costs) in sorted(cells.items()):
        ratio=costs[1][2]/costs[0][2]
        details.append((binary,lib,lv,name,int(flags[0]),int(flags[1]),f'{100*(ratio-1):.5f}',*(int(qualifies(costs,p)) for p in limits),int(verified),file))
ids=['comparator_sha256','libzstd_sha256']
write_csv(out/'decode-tolerance-builds.csv',ids+['allow_decode_loss_pct','measured','pass','pass_and_cli_verified','unmeasured','complete'],summ)
write_csv(out/'decode-tolerance-build-cells.csv',ids+['level','file','size_pass','encode_pass','decode_delta_pct',*(f'pass_at_{label(p)}pct' for p in limits),'standalone_verified','latest_trials'],details)
print(f'{len(ranked)} frozen build/reference pairs; complete passing builds: {complete} strict or {allowed_complete} at {label(a.allow_decode_loss_pct)}% decode loss')
if a.require_binary:
    matches=[r for r in summ if r[0]==a.require_binary and r[2]==label(a.allow_decode_loss_pct)]
    if not any(r[-1] for r in matches):
        print('Exact comparator is incomplete: '+', '.join(f'{r[5]}/66 qualifying cells with standalone verification against {r[1]}' for r in matches) if matches else 'No verified measurements for this comparator.')
        raise SystemExit(1)
if a.require_complete and not allowed_complete:raise SystemExit(1)
