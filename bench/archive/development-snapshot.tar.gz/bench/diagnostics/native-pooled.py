#!/usr/bin/env python3
"""Freeze and verify a production pool of phrase dictionaries, separate from running experiments."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepare',action='store_true')
p.add_argument('--workspace',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--levels',default='18:19');a=p.parse_args()
root=Path(__file__).resolve().parents[2];w=a.workspace.resolve();out=a.out.resolve()
levels=[]
for spec in a.levels.split(','):
    span=list(map(int,spec.split(':')));levels.extend(range(span[0],span[-1]+1))
if not levels or len(set(levels))!=len(levels) or min(levels)<1 or max(levels)>22:raise SystemExit('invalid levels')
if w==root or not w.is_relative_to(root/'bench/local'):raise SystemExit('workspace must be a separate local snapshot')
if a.prepare:
    w.mkdir(parents=True,exist_ok=False)
    for folder in ('src','examples','tests','.cargo','bench/support'):shutil.copytree(root/folder,w/folder,dirs_exist_ok=True)
    for name in ('Cargo.lock','Cargo.toml','scripts/preset-matrix.py','bench/diagnostics/preset-cli.py','bench/diagnostics/preset-rates.py'):
        (w/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,w/name)
    (w/'bench/local').mkdir();(w/'bench/local/preset-binaries').symlink_to(root/'bench/local/preset-binaries',target_is_directory=True)
    (w/'bench/data').symlink_to(root/'bench/data',target_is_directory=True)
    raise SystemExit(0)
out.mkdir(exist_ok=True,parents=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_') and k!='CARGO_TARGET_DIR'}
# Share only the build cache, not the source, with the four-core coordinator.
env['CARGO_TARGET_DIR']=str(root/'bench/local/levels/lanes/production-target')
(w/'target').mkdir(exist_ok=True)
def run(name,args,**kw):
    with (w/(name+'.log')).open('w') as f:
        return subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,**kw)
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,options in [('test',['test','--all-features']),('clippy',['clippy','--all-features','--all-targets']),
        ('default-clippy',['clippy','--no-default-features','--all-targets'])]:
    run(name,['cargo',*options,'--offline','--locked',*(['--','-D','warnings'] if 'clippy' in name else [])],check=True)
run('build',['cargo','build','--bin','btrcmpr','--no-default-features','--release','--offline','--locked'],check=True)
cli=Path(env['CARGO_TARGET_DIR'])/'release/btrcmpr';data=w/'bench/data/enwik8'
if 'libzstd' in subprocess.check_output(['ldd',cli],text=True):raise ValueError('production binary links zstd')
with (out/'preflight.csv').open('w',buffering=1) as f:
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('level','archive_bytes','archive_sha256','source_sha256','encoder_threads','decoder_threads','identical'))
    for lv in levels:
        arc=w/f'enwik8-{lv}.btr';restored=w/'restored'
        run(f'encode-{lv}',[cli,'c',f'-{lv}',data,arc,'4'],check=True)
        run(f'decode-{lv}',[cli,'d',arc,restored,'3'],check=True)
        subprocess.run(['cmp',data,restored],check=True)
        wr.writerow((lv,arc.stat().st_size,digest(arc),digest(data),4,3,1))
r=run('pairs',[sys.executable,'scripts/preset-matrix.py','--out',out,'--levels',a.levels,'--files','enwik8','x-ray','mozilla','--rounds','5','--decodes','7'])
if r.returncode and not (out/'matrix.csv').exists():raise SystemExit('incomplete paired benchmark')
run('cli',[sys.executable,'bench/diagnostics/preset-cli.py',out/'matrix.csv','--out',out/'cli.csv'],check=True)
run('rates',[sys.executable,'bench/diagnostics/preset-rates.py',out/'matrix.csv','--out',out/'rates.csv'],check=True)
manifest=json.loads((out/'manifest.json').read_text())
snap=root/'bench/local/preset-binaries'/(manifest['benchmark_sha256']+'.src.tar.gz')
if not snap.exists():
    with tarfile.open(snap,'w:gz') as t:
        for folder in ('src','examples','tests','Cargo.toml','Cargo.lock','.cargo','bench/support','scripts','bench/diagnostics'):
            t.add(w/folder,arcname=folder)
