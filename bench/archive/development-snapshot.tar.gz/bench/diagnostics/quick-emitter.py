#!/usr/bin/env python3
"""Four-worker level-1 comparison in an isolated build; validate exact archive equivalence."""
import argparse
import csv
import hashlib
import os
from pathlib import Path
import random
import shutil
import subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--prepare',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2];w=root/'bench/local/levels/lanes/quick-emit'
a.out.mkdir(parents=True,exist_ok=True)
if a.prepare:
    w.mkdir(parents=True,exist_ok=True)
    for name in ('src','examples','.cargo','bench/support'):shutil.copytree(root/name,w/name,dirs_exist_ok=True)
    for name in ('Cargo.toml','Cargo.lock'):shutil.copy2(root/name,w/name)
    shutil.copy2(root/'bench/diagnostics/quick-emitter.rs',w/'src/quickemit.rs')
    source=w/'src/lz.rs';s=source.read_text();key='fn quick<const Q: u8>(s: &[u8], archive: bool) -> Vec<u8> {'
    assert s.count(key)==1;s=s.replace(key,'#[path="quickemit.rs"]\nmod quickemit;\n'+key+'\n    if Q==1{let t=crate::tuning("BTR_QUICK_EMIT",0,0,4);if t>0{return quickemit::encode(s,archive,t)}}')
    source.write_text(s);raise SystemExit(0)
env0={k:v for k,v in os.environ.items() if not k.startswith('BTR_') and k!='CARGO_TARGET_DIR'}
subprocess.run(['cargo','build','--release','--offline','--locked','--features','baseline,research','--bin','compare','--bin','btrcmpr'],cwd=w,env=env0,check=True)
cli=w/'target/release/btrcmpr';compare=w/'target/release/compare'
with (a.out/'checks.csv').open('w',buffering=1) as checks,(a.out/'trials.csv').open('w',buffering=1) as f:
    ck=csv.writer(checks,lineterminator='\n');ck.writerow(('input','variant','bytes','archive_sha256','roundtrip_identical'))
    wr=csv.writer(f,lineterminator='\n');wr.writerow(('input','round','variant','bytes','encode_MBps','decode_MBps'))
    for name in ('enwik8','mozilla'):
        src=root/'bench/data'/name;expected=None
        for mode in range(5):
            arc=w/'trial.btr';raw=w/'restored';env=dict(env0,BTR_QUICK_EMIT=str(mode))
            subprocess.run([cli,'c','-1',src,arc,'4'],env=env,check=True);subprocess.run([cli,'d',arc,raw,'4'],check=True,env=env)
            subprocess.run(['cmp',raw,src],check=True)
            with arc.open('rb') as h:digest=hashlib.file_digest(h,'sha256').hexdigest()
            if expected is None: expected=digest
            if expected!=digest:raise ValueError(f'changed archive in variant {mode}')
            ck.writerow((name,mode,arc.stat().st_size,digest,1))
        rng=random.Random(536)
        for j in range(3):
            modes=list(range(5));rng.shuffle(modes)
            for mode in modes:
                env=dict(env0,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='5',BTR_QUICK_EMIT=str(mode))
                r=subprocess.run([compare,'4','1','ours',src],env=env,capture_output=True,text=True,check=True)
                row=next(csv.DictReader(r.stdout.splitlines()))
                wr.writerow((name,j+1,mode,row['compressed_bytes'],row['compress_MBps'],row['decompress_MBps']))
