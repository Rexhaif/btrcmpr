#!/usr/bin/env python3
"""Compare single and paired deferred-prefix checks at fixed wire settings on both level-one bottlenecks."""
import argparse
from pathlib import Path
import random
import tempfile
from level_one_lab import Lab,costs,read,sha
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out)
native={r['input']:r for r in read(l.root/'bench/results/presets/native-fastest-1/cli.csv')}
sc,sw=l.report('screen','file mode job_KiB bytes encode_MBps decode_MBps')
pa,pw=l.report('paired','file mode job_KiB tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
ct,cw=l.report('counters','file mode job_KiB codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
doc=[]
with sc,pa,ct,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as td:
    arc=Path(td)/'confirmed.btr'
    for name in ('enwik8','mozilla'):
        arch=name=='mozilla';ref=costs(read(l.base/'group-key'/f'{name}-1.csv'),'zstd')[0]
        if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('wrong corpus')
        job=192 if arch else 384;control=(0,job);exact=(10 if arch else 1,job);pool={}
        def cfg(pair):
            m,k=pair
            return dict(l.env,BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='10' if arch else '5',BTR_CONFIRM_MATCH=str(m),BTR_FAST_COUNTS='2',BTR_FAST_PLAN='0' if arch else '1',BTR_JOB_KIB=str(k),BTR_ARCH_KIB=str(k),BTR_RECORD_KIB='128',BTR_RECORD_COST='2')
        seq=[(m,k) for m in ((0,10,11,12,13,14,15,19,20) if arch else (0,1,2,3,4,5,6,7,8,9,16,17,18,19,20)) for k in ((128,192,256) if arch else (320,384,512))]
        random.Random(4304).shuffle(seq)
        for x in seq:
            n,c,d=l.trial(name,cfg(x));pool[x]=(n,c,d);sw.writerow((name,*x,n,c,d))
            if x[0] in ((10,) if arch else (1,4,7)) and x[1]==job and n!=int(native[name]['cli_bytes']):raise ValueError('exact parse changed size')
        ok=[x for x in pool if x[0] and pool[x][0]<ref]
        floor=1510 if arch else 1495
        picks=[control,exact]
        for x in sorted(ok,key=lambda x:(pool[x][2]>=floor,pool[x][1]),reverse=True):
            if len(picks)>=4:break
            if x not in picks and x[0] not in {y[0] for y in picks}:picks.append(x)
        def pair(x,tag):
            n,_,_=l.trial(name,cfg(x),arc);digest=sha(arc);l.restore(name,arc,l.env)
            if n!=pool[x][0]:raise ValueError('size changed')
            if x in (control,exact) and digest!=native[name]['archive_sha256']:raise ValueError('did not reproduce native archive')
            rates,ok=l.pair(name,cfg(x),n,ref,tag)
            for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((name,*x,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
            (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {x[0]} / {x[1]} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
            return ok,c/cz
        scored=[]
        for i,x in enumerate(picks):
            tag=f'{name}-{i}';cw.writerow((name,*x,'btrcmpr',pool[x][0],*l.perf(name,cfg(x),pool[x][0],tag)))
            r=pair(x,tag)
            if x!=control:scored.append((r,x))
        if scored:
            best=max(scored)
            if best[0][0] or best[0][1]>=.97:pair(best[1],name+'-repeat')
(l.out/'README.md').write_text('\n'.join(['# Measure match length only after the prefix succeeds','',
'Candidates first verify a minimum number of matching bytes. Only the selected candidate counts its full length. The first implementation preserves the native four-byte/distance rule; other variants require longer prefixes or change when the second hash lookup is issued. The original six-byte text and seven-byte archive parsers serve as controls.','',
'| Raw pairs | Mode / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---:|---|',*doc,'',
'Five alternating warmed pairs, four workers on both sides, seven decodes per measurement. Every finalist restored the original in a separate three-worker run. Both control and exact deferred checks also reproduced the native SHA-256 digests. [Hardware counters](counters.csv), [screen](screen.csv), [paired archive digests](paired.csv), [manifest](manifest.json).','']))
