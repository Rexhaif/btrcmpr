#!/usr/bin/env python3
"""Audit the requested 5% decode allowance and the original strict comparison against zstd."""
import argparse
import csv
from decimal import Decimal
import json
from pathlib import Path
import re
from statistics import median
from decode_gate import DEFAULT_DECODE_LOSS_PCT, allowance, columns, label, qualifies, write_csv
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
p.add_argument('--update-overview',action='store_true',help='also refresh the coverage sentence in the two project READMEs')
p.add_argument('--allow-decode-loss-pct',type=allowance,default=DEFAULT_DECODE_LOSS_PCT,help='report this throughput allowance alongside 0, 2, 5 (default) and 10 percent')
args=p.parse_args()
base=Path(__file__).resolve().parents[1]/'results/presets';files=['enwik8','x-ray','mozilla']
def rows(path):
    with path.open() as f:return list(csv.DictReader(f))
latest={};wins={};latest_costs={}
def add(lv,name,path,n,values,costs):
    passed=all(v>1 for v in values)
    key=(lv,name)
    def newer(old):
        return not path.startswith('integrated/') or not old or (base/path).stat().st_mtime_ns>=(base/old).stat().st_mtime_ns
    if newer(latest.get(key,(None,))[0]):latest[key]=(path,n,passed);latest_costs[key]=costs
    if passed and newer(wins.get(key)):wins[key]=path
# Order is the order of experiments; regenerating a summary cannot make an older trial newer.
groups='''x-ray mozilla-v1 palette mozilla-cache-v2 enwik8-wide-v2 mozilla-cache-v3
mozilla-banks-v4 enwik8-l3-wide enwik8-long-window enwik8-window-prefetch
enwik8-neighbor-v1 low-recheck enwik8-final-l5 enwik8-far-l6 wide-l7 sampled-l7
vector-mozilla20 tight-mozilla22 ranked-distance-l9 ranked-distance-l10-l11
ninth-index-l12 paged-l9 short-jobs-l6 phrase-levels-13-15 paged-l9/repeat
native-eighth shared-16-17 pooled-18-19 dictionary-20-22 native-six-after-ahead native-object-recheck'''.split()
for native in ('native-object-6-17','native-fastest-1','native-fastest-2','native-profiled-1','native-regional-scan-1','native-combined-1'):
    if all((base/native/k).is_file() for k in ('README.md','cli.csv','rates.csv')):groups.append(native)
# The integrated series reuses a frozen binary, and publishes each level
# independently after all three pairs and its CLI restorations are complete.
groups.extend(str(p.relative_to(base)) for p in sorted([*(base/'integrated').glob('*/l[0-9][0-9]'),*(base/'integrated').glob('*/tracks/*')]) if (p/'rates.csv').is_file() and (p/'cli.csv').is_file())
for g in groups:
    if g=='palette':cells=[dict(level=1,file=name,rounds=5) for name in ('enwik8','mozilla')]
    elif (base/g/'matrix.csv').is_file():cells=rows(base/g/'matrix.csv')
    elif g in ('pooled-18-19','dictionary-20-22','native-six-after-ahead','native-object-recheck'):
        m=base/g/'manifest.json'
        if not m.is_file():continue
        manifest=json.loads(m.read_text())
        if manifest['threads']!=4 or manifest['warmup_rounds']!=1 or manifest['rounds']!=5 or manifest['decodes']!=7:raise ValueError('unexpected native trial settings')
        cells=[dict(level=lv,file=name,rounds=manifest['rounds']) for lv in manifest['levels'] for name in manifest['files']
               if (base/g/f'level-{lv:02}-{name}.csv').is_file()]
    else:raise ValueError('missing reference matrix: '+g)
    for row in cells:
        lv=int(row['level']);name=row['file'];n=int(row['rounds'])
        if n<3:raise ValueError('single screens cannot confirm a cell')
        path=f'{g}/level-{lv:02}-{name}.csv' if g!='palette' else 'palette/level-1-trials.csv'
        trial=rows(base/path)
        costs=[]
        for codec in ('btrcmpr','zstd'):
            seq=[r for r in trial if r['codec']==codec and Path(r['file']).name==name]
            sizes={int(r['compressed_bytes']) for r in seq}
            if len(sizes)!=1 or len(seq)!=n or {int(r['round']) for r in seq}!=set(range(1,n+1)):raise ValueError(path)
            costs.append((sizes.pop(),*(median(Decimal(r[k]) for r in seq) for k in ('compress_seconds','decompress_seconds'))))
        a,b=costs
        values=[v/u for u,v in zip(a,b,strict=True)]
        if 'all_pass' in row and all(v>1 for v in values)!=bool(int(row['all_pass'])):raise ValueError('summary inconsistent: '+path)
        add(lv,name,path,n,values,costs)
args.out.parent.mkdir(exist_ok=True,parents=True)
with args.out.open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['level','file','ever_passed','latest_result','verified_rounds','latest_trials','most_recent_passing_trials'])
    for lv in range(1,23):
        for name in files:
            key=(lv,name);path,n,passed=latest.get(key,('',0,None))
            w.writerow((lv,name,int(key in wins),{None:'no paired run',True:'pass',False:'miss'}[passed],n,path,wins.get(key,'')))
print(f'{len(wins)} of 66 ever passed; {sum(v[2] for v in latest.values())} passed their latest warmed paired run.')
limits=columns(args.allow_decode_loss_pct);sensitivity=[];summary=[]
for (lv,name),costs in sorted(latest_costs.items()):
    (size,enc,dec),(refsize,refenc,refdec)=costs
    sensitivity.append((lv,name,size,refsize,f'{refenc/enc:.5f}',f'{100*(refdec/dec-1):.5f}',*(int(qualifies(costs,p)) for p in limits),latest[lv,name][0]))
for p in limits:
    passed=sum(qualifies(costs,p) for costs in latest_costs.values())
    summary.append((label(p),len(latest_costs),passed,len(latest_costs)-passed,66-len(latest_costs)))
working=sum(qualifies(c,DEFAULT_DECODE_LOSS_PCT) for c in latest_costs.values())
print(f'{working} of {len(latest_costs)} latest comparisons meet the 5% decode allowance and beat zstd on size and encode (across builds).')
write_csv(args.out.parent/'decode-tolerance-cells.csv',['level','file','btr_bytes','zstd_bytes','encode_vs_zstd','decode_delta_pct',*(f'pass_at_{label(p)}pct' for p in limits),'latest_trials'],sensitivity)
write_csv(args.out.parent/'decode-tolerance-summary.csv',['allow_decode_loss_pct','measured_across_builds','pass','miss','unmeasured'],summary)
if args.update_overview:
    if args.out.resolve()!=base/'coverage.csv':raise ValueError('overview must reference the project ledger')
    if len(latest_costs)==66:
        from preset_ladder import write,write_native_rates
        write(base)
        for series in (base/'integrated').iterdir():
            source=series/'verified-cells.csv';dest=series/'rates.md'
            if source.is_file() and (not dest.is_file() or dest.stat().st_mtime_ns<source.stat().st_mtime_ns):
                write_native_rates(series)
                if (series/'cached-blocks.json').is_file():
                    from native_blocks import write as write_blocks
                    write_blocks(series)
    doc=['# Decode throughput allowance','',
         'Each row compares the same file, numeric level and four-worker configuration against zstd. The archive must be strictly smaller, compression strictly faster, and median decode throughput at least **95% of zstd**. The table also shows how the answer changes at other allowances. Percentages refer to uncompressed MB/s; the original zero-allowance gate requires a strict decode win.','',
         '| Allowed decode loss | Latest production comparisons that qualify |','|---:|---:|']
    for p,n,k,_,_ in summary:doc.append(f'| {p}% | {k} / {n} |')
    doc+=['','The latest observation for each cell is selected across executables. See the [separate audit by exact binary and zstd library](decode-tolerance-builds.csv) for a release claim. All three metrics for any one cell come from the same warmed paired run.','',
          '| File | Level | Bytes saved | Encode vs zstd | Decode vs zstd | At 5% decode loss |','|---|---:|---:|---:|---:|---|']
    for (lv,name),costs in sorted(latest_costs.items()):
        if qualifies(costs,Decimal(0)):continue
        (size,enc,dec),(refsize,refenc,refdec)=costs
        reasons=', '.join(k for k,f in [('size',size>=refsize),('encode',enc>=refenc),('decode',100*refdec<95*dec)] if f)
        doc.append(f'| [{name}]({latest[lv,name][0]}) | {lv} | {refsize-size:,} | {refenc/enc:.3f}× | {100*(refdec/dec-1):+.2f}% | '+(f'Miss: {reasons}' if reasons else 'Pass')+' |')
    doc+=['','Only strict misses are shown above. The [full cell ledger](decode-tolerance-cells.csv) includes all successes and links to all raw trials.','']
    tmp=base/'decode-tolerance.partial';tmp.write_text('\n'.join(doc));tmp.replace(base/'decode-tolerance.md')
    def ranges(name):
        span=[]
        for lv in range(1,23):
            if (lv,name) not in wins:continue
            if span and lv==span[-1][-1]+1:span[-1].append(lv)
            else:span.append([lv])
        return ', '.join(str(s[0]) if len(s)==1 else f'{s[0]}–{s[-1]}' for s in span) or 'none'
    def replace(path,pattern,line):
        s=path.read_text();s,n=re.subn(pattern,lambda _:line,s)
        if n!=1:raise ValueError(f'expected one coverage sentence: {path}')
        if s!=path.read_text():
            tmp=path.with_suffix('.coverage-tmp');tmp.write_text(s);tmp.replace(path)
    cells=len(wins);fresh=sum(v[2] for v in latest.values())
    selected=base/'native-combined-1/codegen.json'
    if selected.is_file():
        current=base/'integrated'/json.loads(selected.read_text())['comparator']
        native=current/'verified-cells.csv'
        if native.is_file():
            from level_one_lab import costs as trial_costs,read
            nc=read(native);counts={0:0,5:0}
            for r in nc:
                rdata=read(current/r['individual_trials'])
                c=(trial_costs(rdata,'btrcmpr'),trial_costs(rdata,'zstd'))
                for pct in counts:counts[pct]+=qualifies(c,Decimal(pct))
            replace(base.parents[2]/'README.md',r'\*\*Selected executable: \d+ of 66 comparisons verified; \d+ meet the 5% decode rule, \d+ also decode faster than zstd\.\*\*',
                    f'**Selected executable: {len(nc)} of 66 comparisons verified; {counts[5]} meet the 5% decode rule, {counts[0]} also decode faster than zstd.**')
    replace(base.parents[2]/'README.md',r'\[\d+ of \d+ latest file/level comparisons meet the 5% decode allowance\]',
        f'[{working} of {len(latest_costs)} latest file/level comparisons meet the 5% decode allowance]')
    replace(base.parents[2]/'README.md',r'Across versions, \[\d+ of 66 file/level combinations.*?\. The full matrix',
        f'Across versions, [{cells} of 66 file/level combinations have passed all three tests at least once](bench/results/presets/coverage.csv): x-ray {ranges("x-ray")}; Mozilla {ranges("mozilla")}; enwik8 {ranges("enwik8")}. The full matrix')
    replace(base/'README.md',r'Across versions, \d+ cells have passed at least once[^.]*\.',
        f'Across versions, {cells} cells have passed at least once; {fresh} passed in their latest warmed paired run.')
    builds=base/'decode-tolerance-builds.csv'
    if builds.is_file():
        with builds.open() as f:complete=[r for r in csv.DictReader(f) if r['allow_decode_loss_pct']=='5' and r['complete']=='1']
        passed=bool(complete)
        statement='The full matrix has passed on one executable.' if passed else 'The full matrix has not passed on one executable.'
        replace(base.parents[2]/'README.md',r'The full matrix has (?:not )?passed on one executable\.',statement)
        replace(base.parents[2]/'README.md',r'\*\*Preset comparison(?: in progress| verified on one executable)\.\*\*',
                '**Preset comparison verified on one executable.**' if passed else '**Preset comparison in progress.**')
        replace(base/'README.md',r'The 22-level objective has (?:not )?been met on one executable\.',
                'The 22-level objective has been met on one executable.' if passed else 'The 22-level objective has not been met on one executable.')
