#!/usr/bin/env python3
"""Extend the latest eligible frozen production comparator; do not merge different builds."""
import argparse
from decimal import Decimal
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--levels',default='1:22')
p.add_argument('--revised-only',action='store_true',help='skip this priority slot unless both changed presets were natively confirmed')
p.add_argument('--report-only',action='store_true')
p.add_argument('--select-only',action='store_true',help='identify and stage the eligible candidate without starting or updating a matrix')
p.add_argument('--profiled-only',action='store_true',help='use this slot only if the frozen profiled build passed its low and middle holdouts')
p.add_argument('--regional-only',action='store_true',help='require the regional scanner to pass the fresh native level-one series and the holdouts')
p.add_argument('--combined-only',action='store_true',help='require both updated archive types and complete native level 1/2/3/6 holdouts')
a=p.parse_args();root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';lanes=root/'bench/local/levels/lanes'
if sum((a.regional_only,a.profiled_only,a.combined_only))>1:p.error('select only one comparator')
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def eligible(path):
    if not (path/'README.md').is_file():return False
    results=rows(path/'matrix-decode-tolerance.csv');cli=rows(path/'cli.csv')
    return (len(results)==len(cli)==2 and {r['file'] for r in results}=={'mozilla'} and
            {r['input'] for r in cli}=={'mozilla'} and {r['level'] for r in results}=={r['level'] for r in cli}=={'6','17'} and
            all(r['allow_decode_loss_pct']=='5' and r['all_pass_with_allowance']=='1' for r in results) and all(r['restored_identical']=='1' for r in cli))
origin=base/'native-object-6-17';snap=lanes/'native-region-17'
if not eligible(origin):
    if a.revised_only:
        print('Priority slot skipped: revised native results are incomplete or failed the per-file requirements.');raise SystemExit(0)
    origin=base/'dictionary-20-22';snap=lanes/'native-dict-20-22'
# Prefer the newer low preset only when each formerly missing file improves
# against its own matched baseline, and every output meets size and decode.
fast=base/'native-fastest-1'
if origin.name=='native-object-6-17' and (fast/'README.md').is_file():
    old_digest=json.loads((origin/'manifest.json').read_text())['benchmark_sha256']
    control=base/'integrated'/old_digest/'l01/matrix.csv'
    if control.is_file():
        prior={r['file']:r for r in rows(control)}
        trial={r['file']:r for r in rows(fast/'matrix.csv')}
        cli={r['input']:r for r in rows(fast/'cli.csv')}
        if (set(prior)==set(trial)==set(cli)=={'enwik8','mozilla','x-ray'} and
            all(r['level']=='1' and r['size_pass']=='1' and Decimal(r['decode_speedup'])>=Decimal('.95') and
                cli[n]['restored_identical']=='1' and cli[n]['cli_bytes']==r['btr_bytes'] for n,r in trial.items()) and
            trial['x-ray']['all_pass']=='1' and
            all(Decimal(trial[n]['encode_speedup'])>Decimal(prior[n]['encode_speedup']) for n in ('enwik8','mozilla'))):
            origin=fast;snap=lanes/'native-fastest-1'
# Compiler flags change the executable identity. Prefer the independently
# trained build only after fresh comparisons cover all three low-preset files,
# keep the previous native archive bytes, and pass the two holdout levels.
profiled=base/'native-profiled-1'
if origin==fast and (profiled/'README.md').is_file():
    pm=json.loads((profiled/'manifest.json').read_text());fm=json.loads((fast/'manifest.json').read_text())
    bm=json.loads((profiled/'codegen.json').read_text())
    checks=lambda d:{r['input']:(r['archive_sha256'],r['cli_bytes']) for r in rows(d/'cli.csv') if r['restored_identical']=='1'}
    released={r['file']:r for r in rows(profiled/'matrix-decode-tolerance.csv')}
    new={r['file']:r for r in rows(profiled/'matrix.csv')}
    old={r['file']:r for r in rows(fast/'matrix.csv')}
    hold=base/'integrated'/pm['benchmark_sha256']
    def passed(lv):
        loc=hold/f'l{lv:02}'
        if not (loc/'cli.csv').is_file() or not (loc/'rates.csv').is_file():return False
        h=rows(loc/'matrix-decode-tolerance.csv');c=rows(loc/'cli.csv')
        return (len(h)==len(c)==3 and {r['file'] for r in h}=={r['input'] for r in c}==set(released) and
                all(r['allow_decode_loss_pct']=='5' and r['all_pass_with_allowance']=='1' for r in h) and all(r['restored_identical']=='1' for r in c))
    if (bm['comparator']==pm['benchmark_sha256'] and bm['holdouts']=='2,6' and
        all(pm[key]==fm[key] for key in ('source_sha256','input_sha256','zstd_library_sha256','threads','rounds','decodes')) and
        set(released)==set(old)==set(new)=={'enwik8','x-ray','mozilla'} and checks(profiled)==checks(fast) and len(checks(profiled))==3 and
        all(released[n]['all_pass_with_allowance']=='1' for n in ('mozilla','x-ray')) and
        all(new[n]['size_pass']=='1' and Decimal(new[n]['decode_speedup'])>=Decimal('.95') for n in new) and
        Decimal(new['enwik8']['encode_speedup'])>Decimal(old['enwik8']['encode_speedup']) and all(passed(lv) for lv in (2,6))):
        origin=profiled  # same verified Rust source; the runner pins the compiled CLI separately
regional=base/'native-regional-scan-1'
if not a.profiled_only and origin==profiled and (regional/'README.md').is_file():
    from level_one_lab import sha
    rm=json.loads((regional/'manifest.json').read_text());rd=base/'research/native-regional-scan-1'
    study=json.loads((rd/'manifest.json').read_text())
    stamp=json.loads((regional/'codegen.json').read_text());rsnap=lanes/'native-regional-scan-1'
    seen={r['file']:(r['archive_sha256'],int(r['bytes'])) for r in rows(rd/'cli.csv') if r['independent_stock_decoder']=='1'}
    proof={r['input']:(r['archive_sha256'],int(r['cli_bytes'])) for r in rows(regional/'cli.csv') if r['restored_identical']=='1'}
    def regional_pass(loc,lv):
        p=loc/'matrix-decode-tolerance.csv';q=loc/'cli.csv'
        if not p.exists() or not q.exists():return False
        ts=rows(p);cs=rows(q)
        return len(ts)==len(cs)==3 and {r['file'] for r in ts}=={r['input'] for r in cs}==set(proof) and all(
            int(r['level'])==lv and r['allow_decode_loss_pct']=='5' and r['all_pass_with_allowance']=='1' for r in ts) and all(r['restored_identical']=='1' and int(r['level'])==lv for r in cs)
    rs=base/'integrated'/rm['benchmark_sha256']
    if (seen==proof and set(seen)=={'enwik8','mozilla','x-ray'} and
        all(rm[k]==pm[k] for k in ('input_sha256','zstd_library_sha256','threads','rounds','decodes','warmup_rounds','zstd_frame_policy')) and
        rm['benchmark_sha256']==study['comparator_sha256']==stamp['comparator'] and stamp['cli']==study['cli_sha256'] and rm['source_sha256']==study['source_sha256'] and
        sha(root/'bench/local/preset-binaries'/('cli-'+stamp['cli']))==stamp['cli'] and regional_pass(regional,1) and all(regional_pass(rs/f'l{lv:02}',lv) for lv in (2,6))):
        origin=regional;snap=rsnap
if a.regional_only and origin!=regional:
    print('Regional release not selected: the fresh level-one series and holdouts have not all passed.');raise SystemExit()
if a.profiled_only and origin!=profiled:
    print('Profiled release slot skipped: the fresh level-one improvement and complete level-2/6 holdouts were not confirmed.');raise SystemExit()
combined=base/'native-combined-1'
if origin==regional and not (a.regional_only or a.profiled_only) and (combined/'README.md').is_file():
    cm=json.loads((combined/'manifest.json').read_text());cc=json.loads((combined/'codegen.json').read_text())
    series=base/'integrated'/cm['benchmark_sha256'];csnap=lanes/'combined-presets'
    studies=base/'research'
    predicted={(int(r['level']),'x-ray'):(int(r['archive_bytes']),r['archive_sha256'],r['restored_sha256'])
               for r in rows(studies/'signal-grid/current-source-cli.csv')}
    predicted[12,'x-ray']=predicted[22,'x-ray']  # first preset with the high-budget grid and its full job size
    obj=json.loads((studies/'object-step/wire.json').read_text())
    predicted[20,'mozilla']=(obj['bytes'],obj['archive_sha256'],obj['source_sha256'])
    changed={(int(r['level']),r['file']):(int(r['bytes']),r['archive_sha256'],r['source_sha256']) for r in rows(combined/'changed-archives.csv')}
    anchor=rows(combined/'cli.csv')
    frozen=root/'bench/local/preset-binaries';production=frozen/('cli-'+cc['cli'])
    def ready(loc,lv):
        return regional_pass(loc,lv) and all(r['cli_sha256']==cc['cli'] for r in rows(loc/'cli.csv'))
    if (all(cm[k]==rm[k] for k in ('input_sha256','zstd_library_sha256','threads','rounds','decodes','warmup_rounds','zstd_frame_policy')) and
        cc['comparator']==cm['benchmark_sha256'] and cc['regional_scan']==7 and sha(frozen/cc['comparator'])==cc['comparator'] and
        sha(production)==cc['cli'] and 'libzstd' not in subprocess.check_output(['ldd',production],text=True) and
        predicted==changed and {r['input']:(r['archive_sha256'],int(r['cli_bytes'])) for r in anchor}==proof and
        ready(combined,1) and all(ready(series/f'l{lv:02}',lv) for lv in (2,3,6))):
        origin=combined;snap=csnap
        stage=root/'target/verified/combined-presets';stage.mkdir(parents=True,exist_ok=True)
        if not (stage/'btrcmpr').exists():shutil.copy2(production,stage/'btrcmpr')
        if sha(stage/'btrcmpr')!=cc['cli']:raise ValueError('staged combined executable has changed')
        (stage/'identity.json').write_text(json.dumps(dict(cli_sha256=cc['cli'],comparator_sha256=cc['comparator'],
                  report=str((series/'preset-ladder.md').relative_to(root))),indent=2)+'\n')
if a.combined_only and origin!=combined:
    print('Combined candidate not selected: changed archive proofs or the level-1/2/3/6 holdouts did not qualify.');raise SystemExit(1)
digest=json.loads((origin/'manifest.json').read_text())['benchmark_sha256']
if a.select_only:
    print(f'Selected {origin.name}, comparator {digest}');raise SystemExit()
print(f'Extending {origin.name}, comparator {digest}, levels {a.levels}',flush=True)
subprocess.run([sys.executable,root/'bench/diagnostics/integrated.py','--workspace',snap,'--origin',origin,'--out',base/'integrated'/digest,'--levels',a.levels,*(['--report-only'] if a.report_only else [])],cwd=root,check=True)
