#!/usr/bin/env python3
"""Measure a sampled byte-pair dictionary in front of level-one match search."""
import argparse
from decimal import Decimal
from pathlib import Path
import random
import struct
import tempfile
from level_one_lab import Lab,costs,read,sha

def fields(arc):
    b=arc.read_bytes()
    if b[:8]!=b'BTRCMP01':raise ValueError('wrong frame')
    size,block=struct.unpack_from('<QI',b,8);p=20
    def word():
        nonlocal p
        n=struct.unpack_from('<I',b,p)[0];p+=4;return n
    def var():
        nonlocal p
        v=0
        for sh in range(0,64,7):
            x=b[p];p+=1;v|=(x&127)<<sh
            if x<128:return v
        raise ValueError('bad varint')
    if block>>31:
        sizes=[var() for _ in range(word())];pieces=word()
        for _ in range(2*pieces):var()
    else:sizes=[min(block,size-j) for j in range(0,size,block)]
    if sum(sizes)!=size:raise ValueError('job sizes')
    stats=[0]*7
    def walk(payload,raw):
        if payload[0]==5:
            pos=1;total=0
            while pos<len(payload):
                n,k=struct.unpack_from('<II',payload,pos);pos+=8;walk(payload[pos:pos+k],n);pos+=k;total+=n
            if total!=raw or pos!=len(payload):raise ValueError('bad member')
        elif payload[0]==62:
            n=payload[1];t,e=struct.unpack_from('<II',payload,3);header=11+2*n
            if len(payload)<=header+e or not raw//2<=t<=raw or e>t:raise ValueError('bad dictionary')
            for i,v in enumerate((1,raw,t,e,header,len(payload)-header-e,len(payload))):stats[i]+=v
    for n in sizes:
        k=word();walk(memoryview(b)[p:p+k],n);p+=k
    if p!=len(b):raise ValueError('bad boundary')
    return stats

p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();lab=Lab(a.workspace,a.bin_dir,a.out);doc=[]
sf,sw=lab.report('screen','file parser KiB planner slots sample_windows cutoff bytes encode_MBps decode_MBps')
pf,pw=lab.report('paired','file parser KiB planner slots sample_windows cutoff archive_sha256 codec bytes encode_MBps decode_MBps pass_at_5pct')
cf,cw=lab.report('counters','file parser KiB planner slots sample_windows cutoff writer bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
ff,fw=lab.report('fields','file archive_sha256 folded_blocks original_bytes_in_folded_blocks tokens_after_folding escaped_literals header_bytes inner_archive_bytes folded_block_bytes')
with sf,pf,cf,ff,tempfile.TemporaryDirectory(dir=lab.root/'bench/local') as temp:
    arc=Path(temp)/'full.btr'
    for name,std in [('enwik8',256),('mozilla',128)]:
        src=lab.data/name;size=src.stat().st_size
        if sha(src)!=lab.spec['input_sha256'][name]:raise ValueError('wrong file')
        baseline=costs(read(lab.base/'group-key'/f'{name}-1.csv'),'zstd')
        def env(case,scalar=False):
            q,k,h,n,rows,cut=case;ke=(5 if name=='enwik8' else 10) if q=='prefix' else 0
            group=(2 if name=='enwik8' else 8) if q=='group' else 0
            mode=({16:6,32:2,64:4}[n]-int(scalar)) if n else 0
            return dict(lab.env,BTR_GROUP_KEY=str(ke),BTR_QUICK_KEY=str(ke),BTR_PROBE_GROUP=str(group),BTR_GROUP_OFFSETS=str(2 if group or (ke and name=='enwik8') else 0),
                BTR_FAST_COUNTS='2' if h else '0',BTR_FAST_PLAN=str(h),BTR_PAIR_FOLD=str(mode),BTR_PAIR_SAMPLES=str(rows),BTR_PAIR_CUTOFF=str(cut),
                **{'BTR_JOB_KIB' if name=='enwik8' else 'BTR_ARCH_KIB':str(k)})
        orig=('native',std,0,0,32,8);lab.trial(name,env(orig),arc)
        known=next(r['verified_sha256'] for r in read(lab.base/'palette-write/checks.csv') if r['file']==name and r['mode']=='0')
        if sha(arc)!=known:raise ValueError('changed native control')
        cases=[(q,k,h,n,rows,cut) for q in ('native','prefix','group') for n in (16,32,64)
               for k,h,rows,cut in [(std,0,32,8),(std,1,16,18),(2*std,3,16,8),(std,0,64,8)]]
        controls={(*case[:3],0,32,8) for case in cases};schedule=sorted(set(cases)|controls);random.Random(519+std).shuffle(schedule);seen={}
        for case in schedule:
            z=lab.trial(name,env(case));sw.writerow((name,*case,*z));seen[case]=z
        pool=[]
        for case in cases:
            n,c,d=seen[case]
            if n==seen[(*case[:3],0,32,8)][0]:continue
            pool.append((n<baseline[0] and d>=.95*float(Decimal(size)/baseline[2]/1_000_000),n<baseline[0],c,-n,case))
        if not pool:raise ValueError('no candidate used pair folding')
        best=(max(pool) if any(r[1] for r in pool) else max(pool,key=lambda r:r[3]))[-1]
        c=(*best[:3],0,32,8)
        for case in [c,best]:
            n,_,_=lab.trial(name,env(case),arc);digest=sha(arc);count=fields(arc);fw.writerow((name,digest,*count))
            tag=f'{name}-{case[3]}'
            lab.restore(name,arc,lab.env)
            if case[3]:
                if count[0]==0:raise ValueError('no transformed blocks in finalist')
                lab.restore(name,arc,dict(lab.env,BTR_PAIR_SCALAR_READ='1'))
                lab.trial(name,env(case,True),arc)
                if sha(arc)!=digest:raise ValueError('scalar/vector dictionary or folded bytes differ')
                cw.writerow((name,*case,'scalar',n,*lab.perf(name,env(case,True),n,tag+'-scalar')))
            cw.writerow((name,*case,'vector' if case[3] else 'control',n,*lab.perf(name,env(case),n,tag)))
            rates,ok=lab.pair(name,env(case),n,baseline[0],tag)
            for codec,(n,x,y) in zip(('btrcmpr','zstd'),rates,strict=True):
                pw.writerow((name,*case,digest if codec=='btrcmpr' else '',codec,n,round(x,3),round(y,3),int(ok)))
            (nr,x,y),(nz,xx,yy)=rates;doc.append(f'| [{name}]({tag}.csv) | {case[0]}, {case[1]} KiB | {case[3]} | {nr:,} / {nz:,} | {x:.2f} / {xx:.2f} | {y:.2f} / {yy:.2f} | {"Yes" if ok else "No"} |')
(lab.out/'README.md').write_text('\n'.join(['# A small byte-pair dictionary before level-one match search','',
    'Each block samples consecutive source bytes, selects one frequent pair per hash slot, and chooses an uncommon range of byte values to hold their codes. The file contains the complete dictionary and an escape stream for literal bytes that would otherwise look like codes. ARM NEON checks overlapping starts in groups of sixteen; a short lookup selects nonoverlapping pairs. The existing LZ encoder compresses the resulting token sequence.','',
    '| Input | Parser and job | Dictionary slots (0 = control) | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---|---:|---:|---:|---:|---|',*doc,'',
    'Both scalar and vector encoders produced the same finalist archive and both inverse paths restored it on three workers. Controls use the same parser, job size and entropy settings as their finalist. Each timing used four workers per codec, five alternating warmed pairs and seven decodes per measurement. [All full-input screens](screen.csv), [actual transformed bytes, tokens and escapes](fields.csv), [PMU counters](counters.csv), [paired rates](paired.csv), [source and library hashes](manifest.json).','']))
