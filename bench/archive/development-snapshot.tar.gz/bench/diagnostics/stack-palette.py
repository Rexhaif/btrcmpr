#!/usr/bin/env python3
"""Compare sixteen independent bit stacks against the original palette on the full level-one inputs."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import random
import re
from statistics import median
import subprocess
import sys
import tempfile
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

arg=argparse.ArgumentParser(description=__doc__)
for key in ('workspace','bin-dir','out'):arg.add_argument('--'+key,type=Path,required=True)
a=arg.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();exe=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
base=root/'bench/results/presets/research';env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def run(cmd,e):
    v=subprocess.run(cmd,cwd=snap,env=e,text=True,capture_output=True)
    if v.returncode:raise RuntimeError(str(cmd[0])+': '+v.stderr[-2500:])
    return v
def writer(name,fields):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(fields.split());return f,w
def costs(rr,codec):
    rows=[r for r in rr if r['codec']==codec]
    if len(rows)!=5 or {int(r['round']) for r in rows}!=set(range(1,6)) or len({r['compressed_bytes'] for r in rows})!=1:raise ValueError('bad trial')
    return (int(rows[0]['compressed_bytes']),*(median(Decimal(r[k]) for r in rows) for k in ('compress_seconds','decompress_seconds')))
old=json.loads((base/'prefix-probes/manifest.json').read_text());lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',exe/'compare'],env).stdout)[1])
if sha(lib)!=old['zstd_library_sha256']:raise ValueError('different reference')
spec=dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,input_sha256=old['input_sha256'],zstd_library_sha256=sha(lib),
  pmu_full_encodes=8,source_sha256={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))},binaries={k:sha(exe/k) for k in old['binaries']})
(out/'manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
sc,sw=writer('screen','file parser KiB planner writer bytes encode_MBps decode_MBps')
pp,pw=writer('paired','file parser KiB planner writer archive_sha256 codec bytes encode_MBps decode_MBps pass_at_5pct')
cc,cw=writer('counters','file parser KiB planner writer codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte')
events=['instructions:u','cycles:u','branches:u','branch-misses:u','r03:u'];doc=[]
with sc,pp,cc,tempfile.TemporaryDirectory(dir=root/'bench/local') as t:
    arc=Path(t)/'frame.btr'
    for name,std in [('enwik8',256),('mozilla',128)]:
        src=root/'bench/data'/name;sz=src.stat().st_size
        if sha(src)!=spec['input_sha256'][name]:raise ValueError('wrong data')
        ref=costs(read(base/'group-key'/f'{name}-1.csv'),'zstd')
        def cfg(case):
            search,k,planner,v=case;key=(5 if name=='enwik8' else 10) if search=='prefix' else 0
            group=(2 if name=='enwik8' else 8) if search=='group' else 0
            batched=2 if group or (key and name=='enwik8') else 0
            return dict(env,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',BTR_STACK_PALETTE=str(v),BTR_GROUP_KEY=str(key),BTR_QUICK_KEY=str(key),
                BTR_GROUP_OFFSETS=str(batched),BTR_PROBE_GROUP=str(group),BTR_FAST_COUNTS='2' if planner else '0',BTR_FAST_PLAN=str(planner),
                **{'BTR_ARCH_KIB' if name=='mozilla' else 'BTR_JOB_KIB':str(k)})
        def trial(case,save=False):
            e=cfg(case)
            if save:e['BTR_CANDIDATE_FRAME']=str(arc)
            z=next(csv.DictReader(run([exe/'examples/candidate','4','1',src,'native'],e).stdout.splitlines()))
            return int(z['bytes']),float(z['encode_MBps']),float(z['decode_MBps'])
        known=next(r['verified_sha256'] for r in read(base/'palette-write/checks.csv') if r['file']==name and r['mode']=='0')
        trial(('native',std,0,0),True)
        if sha(arc)!=known:raise ValueError('production control changed')
        cases=[(q,k,h,v) for q in ('native','prefix','group') for k in (std,2*std) for h in (0,1,3) for v in (0,2)]
        random.Random(9242+len(name)).shuffle(cases);pool=[]
        for case in cases:
            n,c,d=trial(case);sw.writerow((name,*case,n,c,d))
            if case[-1]==2:pool.append((n<ref[0] and d>=.95*float(Decimal(sz)/ref[2]/1_000_000),n<ref[0],c,-n,case))
        best=(max(pool) if any(r[1] for r in pool) else max(pool,key=lambda r:r[3]))[-1]
        control=(*best[:-1],0);scalar=(*best[:-1],1)
        n,_,_=trial(best,True);digest=sha(arc)
        run([exe/'examples/decode_loop',arc,'1','3',src],env)
        run([exe/'examples/decode_loop',arc,'1','3',src],dict(env,BTR_STACK_SCALAR_READ='1'))
        trial(scalar,True)
        if sha(arc)!=digest:raise ValueError('scalar and vector writers differ')
        for case,codec in [(control,'ours'),(scalar,'ours'),(best,'ours'),(best,'zstd')]:
            n,_,_=trial(case,True);n=ref[0] if codec=='zstd' else n
            e=cfg(case)
            with tempfile.TemporaryDirectory() as tmp:
                ctl,ack=(Path(tmp)/s for s in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                pr=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',
                       exe/'examples/profile','c',codec,src,'4','8'],dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            (out/f'{name}-{case[-1]}-{codec}-perf.txt').write_text(pr.stderr)
            if f'archive_bytes={n}\n' not in pr.stderr:raise ValueError('changed PMU size')
            counts={v[2]:float(v[0])/(sz*8) for s in pr.stderr.splitlines() if len(v:=s.split(';'))>2 and v[2] in events}
            cw.writerow((name,*case,codec,n,*(round(counts[k],5) for k in events)))
        for case in [control,best]:
            n,_,_=trial(case,True);h=sha(arc);tag=f'{name}-{case[-1]}'
            run([exe/'examples/decode_loop',arc,'1','3',src],env)
            run([sys.executable,root/'bench/diagnostics/fast-wire.py','--single',arc,'--name',name,'--out',out/(tag+'-fields')],env)
            raw=out/(tag+'.partial')
            run([exe/'compare','4','5','both',src],dict(cfg(case),WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            values=[costs(read(raw),codec) for codec in ('btrcmpr','zstd')]
            if values[0][0]!=n or values[1][0]!=ref[0]:raise ValueError('changed paired size')
            ok=qualifies(values,DEFAULT_DECODE_LOSS_PCT);rates=[]
            for k,(n,c,d) in zip(('btrcmpr','zstd'),values,strict=True):
                c=float(Decimal(sz)/c/1_000_000);d=float(Decimal(sz)/d/1_000_000);rates.append((n,c,d))
                pw.writerow((name,*case,h if k=='btrcmpr' else '',k,n,round(c,3),round(d,3),int(ok)))
            raw.replace(raw.with_suffix('.csv'));(nb,c,d),(nz,cz,dz)=rates
            doc.append(f'| [{name}]({tag}.csv) | {case[0]}, {case[1]} KiB | {"16 stacks" if case[-1] else "Native packing"} | {nb:,} / {nz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {"Yes" if ok else "No"} |')
        if name=='mozilla':
            prof=snap/'mozilla-profile';prof.mkdir(exist_ok=True)
            run([sys.executable,root/'bench/diagnostics/sample-search.py','--file',name,'--level','1','--repetitions','7','--exe',exe/'examples/profile','--out',prof,'--zstd-debug',root/'bench/local/zstd.debug'],dict(cfg(best),PERF=str(root/'bench/local/perf')))
            (out/'mozilla-encode-samples.txt').write_bytes((prof/'encode-samples.txt').read_bytes())
(out/'README.md').write_text('\n'.join(['# Sixteen independent bit buffers for palette ranks','',
 'The match parser and alphabet planner are unchanged within each pair. The encoder visits groups backwards and packs the residual bits in sixteen independent stacks. A lane sends one byte when its next rank would overflow a 16-bit state. The decoder visits groups forwards and infers which lanes need a byte from their state. No per-group refill mask is stored. ARM NEON updates eight states per vector and compacts or expands selected bytes with a table lookup.','',
 '| Input | Parser and job | Packing | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---|---|---:|---:|---:|---|',*doc,'',
 'Each finalist used five alternating full-input pairs with four workers and seven decodes per measurement, after warmup. The scalar and NEON writers reproduced the same complete new-format archive; independent scalar and NEON reads on three workers restored every byte. These are research binaries. [Screen](screen.csv), [paired medians](paired.csv), [eight-encode PMU counts](counters.csv), [Mozilla instruction samples](mozilla-encode-samples.txt), [manifest](manifest.json).','']))
