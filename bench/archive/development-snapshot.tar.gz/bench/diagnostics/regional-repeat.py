#!/usr/bin/env python3
"""Check the first size-qualified enwik8 level-one winner in a longer paired run."""
import csv
import argparse
from decimal import Decimal
import json
import os
from pathlib import Path
from statistics import median
import subprocess
import time
from level_one_lab import read, sha
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

root=Path(__file__).resolve().parents[2]
study=root/'bench/results/presets/research/native-regional-scan-1'
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--with-host-repeat',action='store_true');args=parser.parse_args()
spec=json.loads((study/'manifest.json').read_text());out=study/('long-repeat-with-host' if args.with_host_repeat else 'long-repeat');out.mkdir(exist_ok=True)
exe=root/'bench/local/levels/lanes/native-regional-scan-1/target/profiled/release/compare'
if sha(exe)!=spec['comparator_sha256']:raise ValueError('wrong standalone comparator')
first=next(r for r in read(study/'paired.csv') if r['tag']=='regional-enwik8' and r['codec']=='btrcmpr')
if first['pass_at_5pct']!='1':raise ValueError('expected the first full enwik8 pair series to qualify')
env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PROFILE_','PERF_'))}
env.update(WARMUP='1',DEC_ITERS='7',BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1')
report=['# Longer check of the standalone regional scanner','',
    'Fifteen alternating pairs after warmup on each file, seven decodes per timed observation and four workers for each codec. The first qualifying five-pair enwik8 result prompted this longer check; both original five-pair trials are reported separately. No archive or binary changes between runs.','',
    '| File | Rust / zstd encode MB/s | Rust / zstd decode MB/s | Paired encode wins | Paired decode rates at least 95% | Gate on medians |','|---|---:|---:|---:|---:|---|']
for name in ('enwik8','mozilla','x-ray'):
    src=root/'bench/data'/name
    if sha(src)!=spec['input_sha256'][name]:raise ValueError('wrong input')
    original=src.stat().st_size;ref=next(r for r in read(study/'paired.csv') if r['tag']=='regional-'+name and r['codec']=='zstd')
    final=out/(name+'.csv')
    if not final.exists():
        partial=out/(name+'.partial')
        start=time.monotonic()
        def sensor(path):
            try:return Path(path).read_text().strip()
            except OSError:return ''
        def firmware(command):
            try:return subprocess.check_output(['/usr/bin/vcgencmd',*command.split()],text=True,stderr=subprocess.DEVNULL,timeout=1).strip().split('=')[-1]
            except (OSError,subprocess.SubprocessError):return ''
        with (out/(name+'-host.csv')).open('w',buffering=1) as f, subprocess.Popen(
                [exe,'4','15','both',src],env=dict(env,TRIALS_CSV=str(partial)),stdout=subprocess.DEVNULL) as child:
            w=csv.writer(f,lineterminator='\n');w.writerow(['elapsed_s','completed_codec_timings','cpu_millicelsius','policy_kHz','firmware_arm_Hz','firmware_throttled'])
            while True:
                rows_so_far=max(0,len(partial.read_text().splitlines())-1) if partial.exists() else 0
                w.writerow([round(time.monotonic()-start,2),rows_so_far,sensor('/sys/class/thermal/thermal_zone0/temp'),
                            sensor('/sys/devices/system/cpu/cpufreq/policy0/scaling_cur_freq'),firmware('measure_clock arm'),firmware('get_throttled')])
                try:code=child.wait(timeout=2)
                except subprocess.TimeoutExpired:continue
                if code:raise ValueError('long paired measurement failed')
                break
        partial.replace(final)
    rows=read(final);group={};cost=[]
    for k,expect in [('btrcmpr',spec['expected_archives'][name][0]),('zstd',int(ref['bytes']))]:
        seq=sorted((r for r in rows if r['codec']==k),key=lambda r:int(r['round']))
        if [int(r['round']) for r in seq]!=list(range(1,16)) or any((int(r['raw_bytes']),int(r['compressed_bytes']))!=(original,expect) for r in seq):
            raise ValueError('incorrect archive or raw trials')
        group[k]=[(Decimal(r['compress_seconds']),Decimal(r['decompress_seconds'])) for r in seq]
        cost.append((expect,*(median(x) for x in zip(*group[k]))))
    wins=sum(a[0]<b[0] for a,b in zip(*group.values(),strict=True))
    dec=sum(95*a[1]<=100*b[1] for a,b in zip(*group.values(),strict=True))
    ok=qualifies(cost,DEFAULT_DECODE_LOSS_PCT);(_,a,b),(_,c,d)=cost;mb=Decimal(original)/1000000
    report.append(f'| [{name}]({name}.csv) | {mb/a:.2f} / {mb/c:.2f} | {mb/b:.2f} / {mb/d:.2f} | {wins} / 15 | {dec} / 15 | {"Pass" if ok else "Miss"} |')
    (out/'README.md').write_text('\n'.join(report)+'\n')
if all((out/(n+'-host.csv')).is_file() for n in ('enwik8','mozilla','x-ray')):
    with (out/'README.md').open('a') as f:
        f.write('\nTwo-second samples from sysfs and the Pi firmware record CPU temperature, requested and actual ARM clock, and the firmware status flags. These host readings do not establish how much either codec was affected. The status column shows the low four current-state bits only; historical sticky bits are retained in the CSVs.\n\n| File | Temperature °C | Reported ARM GHz | Current status bits |\n|---|---:|---:|---|\n')
        for name in ('enwik8','mozilla','x-ray'):
            rs=read(out/(name+'-host.csv'))
            def span(key,den):
                x=[int(row[key])/den for row in rs if row[key].isdecimal()]
                return f'{min(x):.2f}–{max(x):.2f}' if x else 'Unavailable'
            states=sorted({hex(int(row['firmware_throttled'],16)&15) for row in rs if row['firmware_throttled'].startswith('0x')})
            f.write(f'| [{name}]({name}-host.csv) | {span("cpu_millicelsius",1000)} | {span("firmware_arm_Hz",10**9)} | {", ".join(states) or "Unavailable"} |\n')
