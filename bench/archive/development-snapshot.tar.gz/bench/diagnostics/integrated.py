#!/usr/bin/env python3
"""Extend one verified production executable to the rest of the 22-level matrix."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from decimal import Decimal
from statistics import median
from decode_gate import DEFAULT_DECODE_LOSS_PCT, columns, label, qualifies

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',required=True,type=Path)
p.add_argument('--origin',required=True,type=Path,help='directory with original paired and standalone results')
p.add_argument('--out',required=True,type=Path);p.add_argument('--levels',default='1:22')
p.add_argument('--report-only',action='store_true',help='refresh the report from completed measurements without running a benchmark')
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();origin=a.origin.resolve();out=a.out.resolve()
base=root/'bench/results/presets';files=['enwik8','x-ray','mozilla']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
spec=json.loads((origin/'manifest.json').read_text());digest=spec['benchmark_sha256']
if (spec['threads']!=4 or spec['rounds']!=5 or spec['decodes']!=7 or spec['warmup_rounds']!=1 or
        spec['zstd_frame_policy']!='one independent frame per worker' or not spec['files'] or len(set(spec['files']))!=len(spec['files']) or
        not set(spec['files'])<=set(files)):raise ValueError('wrong origin policy')
if out!=base/'integrated'/digest or not snap.is_relative_to(root/'bench/local'):raise ValueError('use canonical path for this build')
def source():
    if {str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))}!=spec['source_sha256']:raise ValueError('standalone and frozen benchmark sources differ')
source()
if sha(root/'bench/local/preset-binaries'/digest)!=digest:raise ValueError('comparator changed')
out.mkdir(parents=True,exist_ok=True)
corpus=dict(re.findall(r'^fetch (\S+) ([a-f0-9]{64}) ',(root/'scripts/fetch-data.sh').read_text(),re.M))
if set(corpus)!=set(files) or spec['input_sha256']!={n:corpus[n] for n in spec['files']}:raise ValueError('origin corpus does not match published digests')
cli_proof=[]
if (origin/'codegen.json').is_file():
    codegen=json.loads((origin/'codegen.json').read_text())
    if codegen['comparator']!=digest or not re.fullmatch(r'[a-f0-9]{64}',codegen['cli']):raise ValueError('wrong native compiler build')
    artifact=root/'bench/local/preset-binaries'/('cli-'+codegen['cli'])
    if sha(artifact)!=codegen['cli']:raise ValueError('frozen standalone program changed')
    cli_proof=['--binary',artifact,'--sha256',codegen['cli']]
reference=origin/'manifest.json' 
if set(spec['files'])!=set(files):
    # A first native repeat may cover only the changed file. Establish the
    # other input identities from actual files before extending its comparator.
    if any(sha(snap/'bench/data'/n)!=corpus[n] for n in files):raise ValueError('additional input differs')
    reference=out/'reference.json'
    identity=dict(spec,input_sha256=corpus,files=files,levels=[],identity_only=True,measured_origin=str(origin.relative_to(base)))
    if reference.exists() and json.loads(reference.read_text())!=identity:raise ValueError('expansion identity changed')
    if not reference.exists():
        reference.write_text(json.dumps(identity,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')};env['CARGO_TARGET_DIR']=str(root/'bench/local/levels/lanes'/('cli-'+digest[:12]))
target=[]
for item in a.levels.split(','):
    v=list(map(int,item.split(':')));target.extend(range(v[0],v[-1]+1))
if min(target)<1 or max(target)>22 or len(set(target))!=len(target):raise ValueError('invalid or duplicate level')
order=origin/'audit-order.json'
if order.is_file():
    levels=json.loads(order.read_text())['levels']
    if sorted(levels)!=list(range(1,23)):raise ValueError('invalid priority list')
    target.sort(key=levels.index)
def report():
    full={};costs={}
    for loc in [origin,*sorted((out/'tracks').glob('*')),*sorted(out.glob('l[0-9][0-9]'))]:
        if not (loc/'cli.csv').exists() or not (loc/'rates.csv').exists():
            if loc==origin:raise ValueError('origin standalone or rates missing')
            continue
        meta=json.loads((loc/'manifest.json').read_text())
        for key in ('benchmark_sha256','zstd_library_sha256','source_sha256','threads','rounds','warmup_rounds','decodes','zstd_frame_policy'):
            if meta[key]!=spec[key]:raise ValueError(f'changed {key}')
        if not meta['files'] or len(set(meta['files']))!=len(meta['files']) or meta['input_sha256']!={n:corpus[n] for n in meta['files']}:raise ValueError('trial inputs differ')
        cells=rows(loc/'rates.csv');clis={(int(r['level']),r['input']):r for r in rows(loc/'cli.csv')}
        expected={(lv,n) for lv in meta['levels'] for n in meta['files']}
        if {(int(r['level']),r['file']) for r in cells}!=expected or set(clis)!=expected:raise ValueError('declared and verified cells differ')
        for r in cells:
            lv=int(r['level']);name=r['file'];k=(lv,name)
            if k in full or k not in clis:raise ValueError('duplicate or incomplete native cell')
            cli=clis[k]
            if cli['source_sha256']!=corpus[name] or cli['restored_identical']!='1' or r['btr_bytes']!=cli['cli_bytes'] or r['rounds']!='5':raise ValueError('bad standalone result')
            if cli_proof and cli.get('cli_sha256') and cli['cli_sha256']!=codegen['cli']:raise ValueError('standalone binary changed')
            full[k]=dict(r,archive_sha256=cli['archive_sha256'],individual_trials=os.path.relpath(loc/f'level-{lv:02}-{name}.csv',out))
            trial=rows(loc/f'level-{lv:02}-{name}.csv')
            costs[k]=[(int(r[sz]),*(median(Decimal(v[t]) for v in trial if v['codec']==codec) for t in ('compress_seconds','decompress_seconds'))) for codec,sz in [('btrcmpr','btr_bytes'),('zstd','zstd_bytes')]]
    with tempfile.NamedTemporaryFile(mode='w',dir=out,delete=False) as f:
        w=csv.DictWriter(f,fieldnames=list(next(iter(full.values()))),lineterminator='\n');w.writeheader();w.writerows(v for k,v in sorted(full.items()))
    os.replace(f.name,out/'verified-cells.csv')
    command=[sys.executable,root/'bench/diagnostics/preset-audit.py','--out',base];subprocess.run(command,check=True)
    audit=next(r for r in rows(base/'decode-tolerance-builds.csv') if r['comparator_sha256']==digest and r['libzstd_sha256']==spec['zstd_library_sha256'] and Decimal(r['allow_decode_loss_pct'])==DEFAULT_DECODE_LOSS_PCT)
    wins=sum(v['all_pass']=='1' for v in full.values())
    accepted=sum(qualifies(v,DEFAULT_DECODE_LOSS_PCT) for v in costs.values())
    # Keep incomplete levels visible. Positive archive gain means a smaller
    # file; speed factors use raw medians rather than rounded MB/s.
    ladder=['# Presets on the exact executable','',
            f'Comparator `{digest}`, four workers, matched zstd for each file and level. Each cell links to the individual alternating rounds and shows **archive bytes saved / encode throughput × zstd / decode throughput × zstd**. Pass requires positive bytes saved, encode above 1.0 and decode at least 0.95. A dash is unmeasured. See the [side-by-side ratios and absolute speeds](rates.md) and the [CSV with archive hashes](verified-cells.csv).','',
            '| Level | enwik8 | x-ray | Mozilla |','|---:|---:|---:|---:|']
    for lv in range(1,23):
        group=[]
        for name in files:
            key=(lv,name)
            if key not in costs:
                group.append('—');continue
            (n,c,d),(z,cz,dz)=costs[key]
            mark='' if qualifies(costs[key],DEFAULT_DECODE_LOSS_PCT) else ' **miss**'
            group.append(f'[{z-n:+,} / {cz/c:.3f} / {dz/d:.3f}]({full[key]["individual_trials"]})'+mark)
        ladder.append('| '+ ' | '.join([str(lv),*group])+' |')
    if costs:
        checks=[('Smallest byte margin',lambda v:v[1][0]-v[0][0],lambda n:f'{n:+,} bytes'),
                ('Lowest encode rate relative to zstd',lambda v:v[1][1]/v[0][1],lambda n:f'{n:.4f}×'),
                ('Lowest decode rate relative to zstd',lambda v:v[1][2]/v[0][2],lambda n:f'{n:.4f}×')]
        ladder+=['','| Closest measured comparison | File and level | Value |','|---|---|---:|']
        for title,val,fmt in checks:
            k=min(costs,key=lambda k:val(costs[k]))
            ladder.append(f'| {title} | [{k[1]}, {k[0]}]({full[k]["individual_trials"]}) | {fmt(val(costs[k]))} |')
    ladder+=['','| File | Distinct archive sizes so far | Verified adjacent level increases |','|---|---:|---|']
    for name in files:
        sizes={lv:v[0][0] for (lv,n),v in costs.items() if n==name}
        jumps=[f'{lv-1} → {lv}: +{sz-sizes[lv-1]:,} bytes' for lv,sz in sorted(sizes.items()) if lv-1 in sizes and sz>sizes[lv-1]]
        ladder.append(f'| {name} | {len(set(sizes.values()))} of {len(sizes)} measured levels | '+('; '.join(jumps) or 'None observed')+' |')
    tmp=out/'preset-ladder.partial';tmp.write_text('\n'.join(ladder)+'\n');tmp.replace(out/'preset-ladder.md')
    # Other independent repeats with this digest may also exist. The global
    # audit uses the latest raw result per cell; this report lists its own runs.
    pending_text=f'The remaining {66-len(full)} cells have not yet been verified in this series.' if len(full)<66 else 'All 22 levels have been verified on each of the three files.'
    lines=['# Integrated production matrix','',f'**{accepted} of {len(full)} verified cells meet the 5% decode allowance and beat zstd on size and encode; {wins} win strictly on all three.** {pending_text} All rows use the same Rust production source snapshot, frozen comparator `{digest}`, and zstd library `{spec["zstd_library_sha256"]}`. See [every measured size, ratio, speed, archive hash and raw pair](verified-cells.csv).','',
        'The [22-level table for this exact executable](preset-ladder.md) separates measured cells from missing ones and identifies the tightest margins. Each cell uses four workers per codec in both directions, five alternating pairs after warmup and seven decodes per time measurement. A production CLI without libzstd separately reproduces the reported size and restores the complete original. The [single-build audit](../../single-build.csv) checks the raw unrounded comparison.','',
        '| File | Cells verified | Pass at 5% | Verified levels missing a requirement |','|---|---:|---:|---|']
    for name in files:
        group=sorted((k[0],qualifies(v,DEFAULT_DECODE_LOSS_PCT)) for k,v in costs.items() if k[1]==name)
        lines.append(f'| {name} | {len(group)} | {sum(p for _,p in group)} | '+(', '.join(str(lv) for lv,p in group if not p) or 'None in verified cells')+' |')
    lines+=['','| Allowed decode throughput loss per cell | Verified cells meeting all requirements |','|---:|---:|']
    for p in columns(Decimal(5)):
        lines.append(f'| {label(p)}% | {sum(qualifies(v,p) for v in costs.values())} / {len(full)} |')
    lines+=['',f'Global 5% audit complete flag for this binary: `{audit["complete"]}`. The [tolerance audit](../../decode-tolerance-builds.csv) also checks the production CLI. Size and encode must win for every allowance. Historical winning runs from other binaries are not counted here.','']
    tmp=out/'README.partial';tmp.write_text('\n'.join(lines));tmp.replace(out/'README.md')
    subprocess.run([sys.executable,root/'bench/diagnostics/preset-coverage.py','--out',base/'coverage.csv','--update-overview'],check=True)
    if len(full)==accepted==66 and audit['complete']=='1' and cli_proof:
        subprocess.run([sys.executable,root/'bench/diagnostics/stage-release.py',origin],check=True)
    return set(full)
done=report()
if a.report_only:raise SystemExit(0)
def measure(loc,levels,names):
    loc.mkdir(exist_ok=True,parents=True)
    mode=['--resume'] if (loc/'manifest.json').exists() else ['--from-manifest',reference]
    if mode==['--resume']:
        old=json.loads((loc/'manifest.json').read_text())
        if old['files']!=names or old['levels']!=levels:raise ValueError('resumed series does not cover the pending inputs and levels')
    with (loc/'run.log').open('a') as log:
        res=subprocess.run([sys.executable,'scripts/preset-matrix.py',*mode,'--levels',','.join(map(str,levels)),'--files',*names,'--threads','4','--rounds','5','--decodes','7','--out',loc],cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT)
        if res.returncode not in (0,1) or not (loc/'matrix.csv').is_file():raise ValueError('incomplete benchmark')
        source()
        for tool,output in [('preset-cli','cli.csv'),('preset-rates','rates.csv')]:
            script=(root if cli_proof and tool=='preset-cli' else snap)/'bench/diagnostics'/f'{tool}.py'
            subprocess.run([sys.executable,script,loc/'matrix.csv','--out',loc/output,*(cli_proof if tool=='preset-cli' else [])],cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
if len(target)>10 and order.is_file() and (first:=json.loads(order.read_text()).get('first_full_file')):
    if first not in files:raise ValueError('unknown early verification input')
    todo=sorted(lv for lv in target if (lv,first) not in done)
    if todo:
        loc=out/'tracks'/first
        if (loc/'manifest.json').exists():
            # A track is immutable and resumable, even if a caller later
            # requests more levels; other cells use the ordinary level path.
            taken=json.loads((loc/'manifest.json').read_text())['levels']
            if not (loc/'rates.csv').exists() or not (loc/'cli.csv').exists():
                if any((lv,first) in done for lv in taken):raise ValueError('overlapping early verification cells')
                measure(loc,taken,[first]);done=report()
        else:
            measure(loc,todo,[first]);done=report()
for lv in target:
    pending=[n for n in files if (lv,n) not in done]
    if pending:
        measure(out/f'l{lv:02}',[lv],pending);done=report()
