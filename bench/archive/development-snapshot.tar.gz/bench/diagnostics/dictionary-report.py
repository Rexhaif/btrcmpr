#!/usr/bin/env python3
"""Check the pooled-dictionary frame identities and report all nine native comparisons."""
import csv
from decimal import Decimal
from pathlib import Path
from statistics import median
import subprocess
import sys
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

root=Path(__file__).resolve().parents[2]
base=root/'bench/results/presets'
directory=base/'dictionary-20-22'
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
native={int(r['level']):r for r in read(directory/'preflight.csv')}
rewrites={int(r['methods']):r for r in read(base/'research/dictionary-storage/sizes.csv') if r['native_level']=='19'}
for level,mode in ((21,1),(22,7)):
    if native[level]['identical']!='1' or native[level]['archive_sha256']!=rewrites[mode]['archive_sha256']:
        raise ValueError(f'native level {level} did not reproduce the dictionary-only change')
cells=read(directory/'rates.csv')
keys={(int(r['level']),r['file']) for r in cells}
if sorted(keys)!=sorted((lv,f) for lv in (20,21,22) for f in ('enwik8','x-ray','mozilla')) or len(cells)!=9:
    raise ValueError('wrong set of results')
checks={(int(r['level']),r['input']):r for r in read(directory/'cli.csv')};accepted={};at_two=0
for r in cells:
    lv=int(r['level']);name=r['file'];check=checks[lv,name]
    if int(r['rounds'])!=5 or r['btr_bytes']!=check['cli_bytes'] or check['restored_identical']!='1':
        raise ValueError('paired size or independent round trip mismatch')
    if name=='enwik8' and check['archive_sha256']!=native[lv]['archive_sha256']:raise ValueError('different CLI archives')
    pairs=read(directory/f'level-{lv:02}-{name}.csv')
    costs=[(int(r[sz]),*(median(Decimal(v[t]) for v in pairs if v['codec']==codec) for t in ('compress_seconds','decompress_seconds'))) for codec,sz in [('btrcmpr','btr_bytes'),('zstd','zstd_bytes')]]
    accepted[lv,name]=qualifies(costs,DEFAULT_DECODE_LOSS_PCT);at_two+=qualifies(costs,Decimal(2))
lines=['# Native levels 20–22','',
    f"{sum(accepted.values())} of nine comparisons meet the 5% decode throughput allowance on one executable ({at_two} also pass at 2%); {sum(int(r['all_pass']) for r in cells)} beat zstd strictly on all three measures. Size and compression speed must win in every cell. On text, four workers learn a shared phrase dictionary and transmit it once; the upper presets also compress the spelling dictionary itself. The level-21 and level-22 standalone archives reproduced the [isolated dictionary experiment](../research/dictionary-storage/README.md) byte for byte. All ratios, sizes and speeds below include the transmitted dictionary.",'',
    '| Level | File | Archive bytes, Rust / zstd | Compress MB/s, Rust / zstd | Decompress MB/s, Rust / zstd | Pass at 5% | Strict win |',
    '|---:|---|---:|---:|---:|:---:|:---:|']
for r in sorted(cells,key=lambda v:(int(v['level']),('enwik8','x-ray','mozilla').index(v['file']))):
    lines.append(f"| {r['level']} | {r['file']} | {int(r['btr_bytes']):,} / {int(r['zstd_bytes']):,} | {r['btr_encode_MBps']} / {r['zstd_encode_MBps']} | {r['btr_decode_MBps']} / {r['zstd_decode_MBps']} | {'Yes' if accepted[int(r['level']),r['file']] else 'No'} | {'Yes' if r['all_pass']=='1' else 'No'} |")
lines+=['','Five alternating pairs after warmup, seven decodes per round, four workers per codec in each direction. zstd 1.5.7 used one independent quarter-file frame per worker. The [matrix](matrix.csv) records the individual gates; [rates](rates.csv) gives the compression ratios. The [native preflight](preflight.csv) reopened the enwik8 archives with three decoder workers; the [independent production CLI](cli.csv) reproduced all nine archive sizes and restored every original byte. The [manifest](manifest.json) identifies the frozen comparator, inputs and baseline.','']
tmp=directory/'README.partial'
tmp.write_text('\n'.join(lines))
tmp.replace(directory/'README.md')
subprocess.run([sys.executable,root/'bench/diagnostics/preset-coverage.py','--out',base/'coverage.csv','--update-overview'],check=True,cwd=root)
subprocess.run([sys.executable,root/'bench/diagnostics/preset-audit.py','--out',base],check=True,cwd=root)
