#!/usr/bin/env python3
"""Use byte-identical archives to isolate copy preparation and execution order."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bin-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--pair',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2];exe=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True);space=root/'bench/local/levels/lanes/ahead-frames';space.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sets=[(6,'enwik8',32646471),(6,'mozilla',17207799),(17,'mozilla',int(next(r['btr_bytes'] for r in read(root/'bench/results/presets/shared-16-17/rates.csv') if r['file']=='mozilla' and r['level']=='17'))),(19,'mozilla',15190160),(1,'enwik8',40542760),(1,'mozilla',19121858)]
if not a.pair:
    selected=[]
    (out/'manifest.json').write_text(json.dumps(dict(workers=4,decoder_sha256=sha(exe/'examples/decode_loop'),candidate_sha256=sha(exe/'examples/candidate'),compare_sha256=sha(exe/'compare')),indent=2)+'\n')
    with (out/'trials.csv').open('w',buffering=1) as f,(out/'checks.csv').open('w',buffering=1) as checks:
        wr=csv.writer(f,lineterminator='\n');wr.writerow(('level','file','copy_policy','round','decode_MBps'))
        cw=csv.writer(checks,lineterminator='\n');cw.writerow(('level','file','archive_bytes','archive_sha256','source_sha256'))
        for lv,name,size in sets:
            src=root/'bench/data'/name;arc=space/f'{name}-{lv}.btr'
            subprocess.run([exe/'examples/candidate','4',str(lv),src,'native'],env=dict(env,BTR_CANDIDATE_FRAME=str(arc)),check=True)
            if arc.stat().st_size!=size:raise ValueError('not the expected native comparison')
            cw.writerow((lv,name,size,sha(arc),sha(src)))
            vs={k:[] for k in range(13)};rng=random.Random(477+lv)
            for trial in range(3):
                order=list(vs);rng.shuffle(order)
                for k in order:
                    res=subprocess.run([exe/'examples/decode_loop',arc,'6','4',src],env=dict(env,BTR_DECODE_AHEAD=str(k)),text=True,capture_output=True,check=True)
                    rate=float(re.search(r'([\d.]+) MB/s',res.stderr)[1]);vs[k].append(rate)
                    wr.writerow((lv,name,k,trial+1,rate))
            rates={k:statistics.median(v) for k,v in vs.items()};best=max(rates,key=rates.get)
            selected.append((lv,name,best,rates[0],rates[best],round(rates[best]/rates[0],4)))
    with (out/'screen.csv').open('w') as f:
        wr=csv.writer(f,lineterminator='\n');wr.writerow(('level','file','policy','native_decode_MBps','best_decode_MBps','relative'));wr.writerows(selected)
else:
    info=json.loads((out/'manifest.json').read_text())
    if info['compare_sha256']!=sha(exe/'compare'):raise ValueError('different comparator from screen')
    for row in read(out/'screen.csv'):
        lv=int(row['level']);name=row['file'];pol=int(row['policy'])
        if lv==1 or not pol or float(row['relative'])<1.01:continue
        size=next(b for k,f,b in sets if k==lv and f==name)
        reference=int(next(r['zstd_bytes'] for r in read(root/'bench/results/presets/zstd-sizes.csv') if int(r['level'])==lv and Path(r['file']).name==name))
        src=root/'bench/data'/name;path=out/f'{lv}-{name}.partial'
        subprocess.run([exe/'compare','4','5','both',src],env=dict(env,BTR_DECODE_AHEAD=str(pol),BTR_LEVEL=str(lv),ZSTD_LEVEL=str(lv),ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(path)),check=True)
        data=read(path);summary=[]
        for codec,n in [('btrcmpr',size),('zstd',reference)]:
            g=[r for r in data if r['codec']==codec]
            if len(g)!=5 or {int(r['round']) for r in g}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=n for r in g):raise ValueError('unstable size or incomplete comparison')
            summary.append((codec,n,*(round(src.stat().st_size/1e6/statistics.median(float(r[k]) for r in g),3) for k in ('compress_seconds','decompress_seconds'))))
        path.replace(path.with_suffix('.csv'))
        with (out/f'{lv}-{name}-rates.csv').open('w') as f:
            w=csv.writer(f,lineterminator='\n');w.writerow(('codec','bytes','encode_MBps','decode_MBps'));w.writerows(summary)
