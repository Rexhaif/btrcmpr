#!/usr/bin/env python3
"""Ask the benchmark's system libzstd for its per-frame compression parameters."""
import argparse
import csv
import ctypes as c
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--frame-bytes',type=int,default=25000000)
a=p.parse_args()
fields=('windowLog','chainLog','hashLog','searchLog','minMatch','targetLength','strategy')
class Params(c.Structure):
    _fields_=[(name,c.c_uint) for name in fields]
zstd=c.CDLL('libzstd.so.1')
zstd.ZSTD_getCParams.argtypes=(c.c_int,c.c_ulonglong,c.c_size_t)
zstd.ZSTD_getCParams.restype=Params
zstd.ZSTD_versionNumber.restype=c.c_uint
names=('','fast','dfast','greedy','lazy','lazy2','btlazy2','btopt','btultra','btultra2')
w=csv.writer(sys.stdout,lineterminator='\n')
w.writerow(('level','version','frame_bytes','dict_bytes',*fields,'strategy_name'))
for level in range(1,23):
    v=zstd.ZSTD_getCParams(level,a.frame_bytes,0)
    w.writerow((level,zstd.ZSTD_versionNumber(),a.frame_bytes,0,*(getattr(v,name) for name in fields),names[v.strategy]))
