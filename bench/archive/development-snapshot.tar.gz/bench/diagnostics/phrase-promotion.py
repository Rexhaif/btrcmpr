#!/usr/bin/env python3
"""Confirm at most one new text setting per invocation after independent full-input screening."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--research',type=Path,required=True)
p.add_argument('--level',type=int,choices=range(16,23),default=16)
p.add_argument('--rounds',type=int,default=5)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2]
def read(path):return list(csv.DictReader(path.open()))
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sizes=read(root/'bench/results/presets/zstd-sizes.csv')
ceiling=int(next(r['zstd_bytes'] for r in sizes if int(r['level'])==a.level and r['file']=='enwik8'))
ref=next(r for r in read(root/f'bench/results/presets/enwik8-screen-v1/level-{a.level:02}-enwik8.csv') if r['codec']=='zstd')
base=dict(encode_MBps=100/float(ref['compress_seconds']),decode_MBps=100/float(ref['decompress_seconds']))
candidates=[]
def add(row,method,settings):
    if int(row['bytes'])>=ceiling:return
    # The archive size is deterministic. Historical unpaired times can only
    # screen out obvious losses, never qualify a setting as a win.
    speed=min(float(row[k])/v for k,v in base.items())
    if speed>=0.90:candidates.append((speed,int(row['bytes']),method,settings,row))
for r in read(a.research/'dag-mixtures.csv'):
    add(r,'mix',dict(BTR_MIX_JOBS=r['grammar_workers'],BTR_MIX_SHARE=r['share'],BTR_MIX_WEIGHT=r['weight_mode'],
                     BTR_MIX_PLAIN='16',BTR_MIX_KIB='32768',BTR_GRAM_CAP='4096',BTR_GRAM_WIDTH='32',BTR_GRAM_PIPE='2'))
for r in read(a.research/'dag-matched.csv')+read(a.research/'dag-reparse.csv'):
    add(r,'lex-dag',dict(BTR_DAG_CAP=r['phrase_cap'],BTR_DAG_WIDTH=r.get('width','64'),BTR_DAG_LZ=r['matched'],
                         BTR_DAG_REPARSE=r.get('rounds','0'),BTR_DAG_PENALTY=r.get('penalty_sixteenths','10'),
                         BTR_DAG_HEADS=r['conditional_heads'],BTR_GRAM_JOB_KIB='24576'))
a.out.mkdir(exist_ok=True,parents=True)
(a.out/'eligibility.json').write_text(json.dumps(dict(level=a.level,max_bytes_exclusive=ceiling,
    rough_rates=base,eligible=sorted(candidates,key=lambda c:-c[0])),indent=2)+'\n')
if not candidates:
    print(f'No size-qualified level-{a.level} candidate within 10% of the screening reference.');raise SystemExit(0)
_,size,method,settings,_=max(candidates,key=lambda t:t[0])
exe=root/os.environ.get('CARGO_TARGET_DIR','target')/'release/compare';sha=digest(exe)
frozen=root/'bench/local/preset-binaries'/sha
if not frozen.exists():shutil.copy2(exe,frozen)
if digest(frozen)!=sha:raise ValueError('frozen executable mismatch')
trial=a.out/'rounds.partial'
env={k:v for k,v in os.environ.items() if not k.startswith('BTR_')}
env.update(settings,BTR_TRIAL_METHOD=method,BTR_LEVEL=str(a.level),ZSTD_LEVEL=str(a.level),ZSTD_WIDE='1',
           WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(trial.resolve()))
(a.out/'manifest.json').write_text(json.dumps(dict(level=a.level,method=method,settings=settings,threads=4,
    verified_rounds=a.rounds,decodes=7,benchmark_sha256=sha,input_sha256=digest(root/'bench/data/enwik8')),indent=2)+'\n')
subprocess.run([frozen,'4',str(a.rounds),'both','bench/data/enwik8'],cwd=root,env=env,check=True)
rows=read(trial)
with (a.out/'summary.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(('codec','bytes','encode_MBps','decode_MBps'))
    for codec,expected in [('btrcmpr',size),('zstd',ceiling)]:
        seq=[r for r in rows if r['codec']==codec]
        if (len(seq)!=a.rounds or {int(r['round']) for r in seq}!=set(range(1,a.rounds+1))
                or any(int(r['raw_bytes'])!=100000000 or int(r['compressed_bytes'])!=expected for r in seq)):
            raise ValueError('incomplete trials or changed archive')
        w.writerow((codec,expected,*(f'{100/statistics.median(float(r[k]) for r in seq):.3f}' for k in ('compress_seconds','decompress_seconds'))))
trial.replace(a.out/'rounds.csv')
