#!/usr/bin/env python3
"""Check the size-qualified regional entropy trial in a release without research switches."""
import argparse
import csv
from decimal import Decimal
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from level_one_lab import costs,read,sha
from decode_gate import qualifies,DEFAULT_DECODE_LOSS_PCT
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--select-scan',action='store_true',help='select a wire-identical scanner using the two completed ARM counter experiments')
args=p.parse_args()
root=Path(__file__).resolve().parents[2];base=root/'bench/results/presets';lanes=root/'bench/local/levels/lanes'
series='native-regional-scan-1' if args.select_scan else 'native-regional-1'
snap=lanes/series;target=snap/'target/profiled';out=base/'research'/series;out.mkdir(exist_ok=True,parents=True)
scan=0;scan_options=[]
if args.select_scan:
    for experiment,remap in [('wide-length',{i:i for i in range(1,6)}),('pair-head',{1:6,4:7})]:
        loc=base/'research'/experiment
        if not (loc/'README.md').exists():raise ValueError('scanner evidence incomplete')
        pairs=read(loc/'paired.csv')
        counts=[r for r in read(loc/'counters.csv') if r['file']=='enwik8' and r['KiB']=='384']
        zero=next(float(r['cycles_per_byte']) for r in counts if r['mode']=='0')
        gold=next(r['archive_sha256'] for r in pairs if r['file']=='enwik8' and r['codec']=='btrcmpr' and r['mode']=='0')
        for r in counts:
            m=int(r['mode'])
            if m not in remap:continue
            if not any(v['file']=='enwik8' and v['codec']=='btrcmpr' and v['mode']==r['mode'] and v['KiB']=='384' and v['archive_sha256']==gold for v in pairs):continue
            scan_options.append(dict(scan=remap[m],experiment=experiment,mode=m,cycles_vs_own_control=float(r['cycles_per_byte'])/zero))
    if not scan_options:raise ValueError('no archive-identical scanner')
    scan=min(scan_options,key=lambda v:(v['cycles_vs_own_control'],v['scan']))['scan']
    (out/'selection.json').write_text(json.dumps(dict(chosen=scan,eligible=scan_options,rule='lowest PMU cycles per byte relative to the same executable native control, exact native archive and 384 KiB settings'),indent=2)+'\n')
frozen=json.loads((base/'native-profiled-1/manifest.json').read_text());code=json.loads((base/'native-profiled-1/codegen.json').read_text())
stockcmp=root/'bench/local/preset-binaries'/code['comparator'];stockcli=root/'bench/local/preset-binaries'/('cli-'+code['cli'])
stockprof=lanes/'low-codegen/thin-pgo/target/release/examples/profile';stock=(stockcmp,stockcli,stockprof)
if [sha(p) for p in stock]!=[code[k] for k in ('comparator','cli','profile')]:raise ValueError('reference release changed')
native={r['input']:(int(r['cli_bytes']),r['archive_sha256']) for r in read(base/'native-profiled-1/cli.csv')};expected=dict(native)
small=next(r for r in read(base/'research/shared-palette/paired.csv') if r['codec']=='btrcmpr' and (r['fields'],r['blocks'],r['pairs'],r['KiB'])==('6','128','0','384'))
expected['enwik8']=(int(small['bytes']),small['archive_sha256'])
zbytes={r['file']:int(r['zstd_bytes']) for r in read(base/'native-profiled-1/rates.csv')}
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','ZSTD_','PERF_','PROFILE_','CARGO_PROFILE_')) and k not in ('LLVM_PROFILE_FILE','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','CARGO_TARGET_DIR')}
with (out/'build.log').open('w') as log:
    if scan:e['BTRCMPR_NATIVE_SCAN']=str(scan)
    for cmd in [['cargo','test','--locked','--offline','--features','regional-models'],
                ['cargo','clippy','--locked','--offline','--features','regional-models','--all-targets','--','-D','warnings'],
                [sys.executable,root/'scripts/build-profiled.py','--workspace',snap,'--target-dir',target,'--regional-models','--comparators',*(['--regional-scan',str(scan)] if scan else [])]]:
        subprocess.run(cmd,cwd=snap,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
bn=target/'release';region=(bn/'compare',bn/'btrcmpr',bn/'examples/profile');meta=json.loads((target/'build-profiled.json').read_text())
if [sha(p) for p in region]!=[meta[k] for k in ('comparator_sha256','cli_sha256','profile_runner_sha256')]:raise ValueError('wrong candidate build')
def run(cmd,env=e):
    p=subprocess.run([str(x) for x in cmd],cwd=snap,env=env,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(str(cmd[0])+': '+p.stderr[-2000:])
    return p
for exe in (region[0],region[2]):
    lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',exe]).stdout)[1])
    if sha(lib)!=frozen['zstd_library_sha256']:raise ValueError('different zstd')
if 'libzstd' in run(['ldd',region[1]]).stdout:raise ValueError('candidate CLI links the reference')
meta['regional_scan']=scan;meta['production_control']=code;meta['input_sha256']=frozen['input_sha256'];meta['reference_sha256']=frozen['zstd_library_sha256'];meta['expected_archives']=expected
meta['test_policy']=dict(threads=4,rounds=5,warmup=1,decodes=7,allow_decode_loss_pct=5,counters='eight complete timed encodes on enwik8')
(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
te=dict(e,BTR_LEVEL='1',ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7')
with (out/'cli.csv').open('w',buffering=1) as fp,tempfile.TemporaryDirectory(dir=snap/'target') as tm:
    w=csv.writer(fp,lineterminator='\n');w.writerow('file bytes source_sha256 archive_sha256 independent_stock_decoder'.split())
    for name,(n,digest) in expected.items():
        original=root/'bench/data'/name
        if sha(original)!=frozen['input_sha256'][name]:raise ValueError('unverified input')
        arc,back=[Path(tm)/k for k in ('compressed','original')]
        run([region[1],'c','-1',original,arc,4])
        if arc.stat().st_size!=n or sha(arc)!=digest:raise ValueError('production candidate differs from independently restored research archive: '+name)
        for cli in (region[1],stockcli):
            run([cli,'d',arc,back,3])
            if sha(back)!=frozen['input_sha256'][name]:raise ValueError('restoration differs')
        w.writerow((name,n,frozen['input_sha256'][name],digest,1))
doc=[]
with (out/'paired.csv').open('w',buffering=1) as fp:
    w=csv.writer(fp,lineterminator='\n');w.writerow('file build tag codec bytes ratio encode_MBps decode_MBps pass_at_5pct'.split())
    prior_run=[]
    if scan:
        prev=lanes/'native-regional-1/target/profiled/release';pb=tuple(prev/k for k in ('compare','btrcmpr','examples/profile'))
        proof=json.loads((base/'research/native-regional-1/manifest.json').read_text())
        if [sha(p) for p in pb]!=[proof[k] for k in ('comparator_sha256','cli_sha256','profile_runner_sha256')]:raise ValueError('original regional binary changed')
        prior_run=[('region-control',pb,'enwik8','')]
    for label,bins,name,suffix in [('profiled',stock,'enwik8',''),*prior_run,('regional',region,'enwik8',''),('regional',region,'mozilla',''),('regional',region,'x-ray',''),('regional',region,'enwik8','-repeat')]:
        orig=root/'bench/data'/name;size=Decimal(orig.stat().st_size);tag=label+'-'+name+suffix;path=out/(tag+'.partial')
        run([bins[0],4,5,'both',orig],dict(te,TRIALS_CSV=str(path)))
        vals=[costs(read(path),k) for k in ('btrcmpr','zstd')]
        if [v[0] for v in vals]!=[(native if label=='profiled' else expected)[name][0],zbytes[name]]:raise ValueError('wrong paired archive')
        path.replace(path.with_suffix('.csv'));ok=qualifies(vals,DEFAULT_DECODE_LOSS_PCT);rates=[]
        for k,(b,c,d) in zip(('btrcmpr','zstd'),vals,strict=True):
            v=(float(size/b),float(size/c/1_000_000),float(size/d/1_000_000));rates.append(v);w.writerow((name,label,tag,k,b,round(v[0],4),round(v[1],3),round(v[2],3),int(ok)))
        (r,c,d),(rz,cz,dz)=rates
        doc.append(f"| [{tag}]({tag}.csv) | {r:.4f} / {rz:.4f} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |")
with (out/'counters.csv').open('w',buffering=1) as fp:
    w=csv.writer(fp,lineterminator='\n');w.writerow('build codec bytes instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte'.split())
    keys=('instructions:u','cycles:u','branches:u','branch-misses:u','r03:u');orig=root/'bench/data/enwik8'
    for name,exe,codec,archive in [('profiled',stockprof,'ours',native['enwik8'][0]),('regional',region[2],'ours',expected['enwik8'][0]),('reference',stockprof,'zstd',zbytes['enwik8'])]:
        with tempfile.TemporaryDirectory() as tm:
            ctl,ack=[Path(tm)/k for k in ('ctl','ack')];os.mkfifo(ctl);os.mkfifo(ack)
            raw=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(keys),'--',exe,'c',codec,orig,4,8],dict(te,PERF_CTL=str(ctl),PERF_ACK=str(ack))).stderr
        if f'archive_bytes={archive}\n' not in raw:raise ValueError('profiled wrong archive')
        (out/(name+'-perf.txt')).write_text(raw);counts={t[2]:int(t[0])/(orig.stat().st_size*8) for x in raw.splitlines() if len(t:=x.split(';'))>2 and t[2] in keys}
        w.writerow((name,codec,archive,*(round(counts[k],6) for k in keys)))
(out/'README.md').write_text('\n'.join(['# Standalone compiler-profiled regional palette candidate','',
  'The candidate learns the distance-selector and literal alphabets on the middle job in a region of 128 jobs, each up to 384 KiB. The same tables are reused by other jobs, but stored independently in each frame. It uses scalar packing, retains the native record and signal paths, and is built without the research feature. Both it and the reference Rust binary use thin LTO and compiler profiles from independent inputs. The unchanged stock decoder restored each candidate archive as well.','',
  *([f'The wire-identical scanner mode {scan} was fixed before native measurements. [Selection and ARM evidence](selection.json).',''] if scan else []),
  '| Five alternating four-worker pairs | Ratio, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---:|---:|---:|---|',*doc,'',
  '[Hardware counters](counters.csv), [timing medians](paired.csv), [independent CLI verification](cli.csv), [compiler, training and binaries](manifest.json). The combined candidate is available with `python3 scripts/build-profiled.py --regional-models'+(f' --regional-scan {scan}' if scan else '')+'`.','']))
