#!/usr/bin/env python3
"""Count zstd 1.5.7 row candidates, using an isolated diagnostic build, never for timing."""
import argparse
import concurrent.futures
import csv
import ctypes as C
import hashlib
from pathlib import Path
import subprocess
import tarfile
import tempfile

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path, help="Debian libzstd_1.5.7+dfsg.orig.tar.xz")
parser.add_argument("out", type=Path)
args = parser.parse_args()
digest = "0c092ef267edce57ba7f3f2645c861f72eaf5e76273c6c3632869423464b90a5"
if hashlib.sha256(args.source.read_bytes()).hexdigest() != digest:
    raise ValueError("unexpected reference source")
args.out.mkdir(parents=True, exist_ok=True)

def instrument(s):
    def once(old, new):
        nonlocal s
        if s.count(old) != 1:
            raise ValueError(f"unexpected count of: {old}")
        s = s.replace(old, new)
    s = """
/* Diagnostic counters are private to a worker. Read them after its one frame. */
static __thread unsigned long long btr_row_counts[6];
__attribute__((visibility("default"))) void btr_get_row_counts(unsigned long long *out);
void btr_get_row_counts(unsigned long long *out) {
    unsigned i;
    for (i=0; i<6; ++i) { out[i]=btr_row_counts[i]; btr_row_counts[i]=0; }
}
""" + s
    once("        /* Cycle through the matches and prefetch */",
         "        ++btr_row_counts[0]; btr_row_counts[1]+=rowEntries;\n        /* Cycle through the matches and prefetch */")
    once("        /* Speed opt: insert current byte into hashtable too.",
         "        btr_row_counts[2]+=numMatches;\n        /* Speed opt: insert current byte into hashtable too.")
    key = "            if ((dictMode != ZSTD_extDict) || matchIndex >= dictLimit) {\n                const BYTE* const match = base + matchIndex;"
    once(key, "            ++btr_row_counts[3];\n" + key)
    key = "                if (MEM_read32(match + ml - 3) == MEM_read32(ip + ml - 3))   /* potentially better */\n                    currentMl = ZSTD_count(ip, match, iLimit);"
    once(key, key.replace("   /* potentially better */", " { ++btr_row_counts[4];").replace("iLimit);","iLimit); }"))
    key = "            /* Save best solution */\n            if (currentMl > ml) {"
    once(key, key + "\n                ++btr_row_counts[5];")
    return s

def library(name):
    lib = C.CDLL(str(name))
    for func, res, argv in [
            ("ZSTD_compressBound", C.c_size_t, [C.c_size_t]),
            ("ZSTD_compress", C.c_size_t, [C.c_void_p,C.c_size_t,C.c_void_p,C.c_size_t,C.c_int]),
            ("ZSTD_decompress", C.c_size_t, [C.c_void_p,C.c_size_t,C.c_void_p,C.c_size_t]),
            ("ZSTD_isError", C.c_uint, [C.c_size_t]),
            ("ZSTD_versionNumber", C.c_uint, [])]:
        f=getattr(lib,func);f.restype=res;f.argtypes=argv
    if lib.ZSTD_versionNumber()!=10507:
        raise ValueError("expected zstd 1.5.7")
    return lib

with tempfile.TemporaryDirectory(prefix="zstd-row-") as tmp:
    with tarfile.open(args.source) as tar:
        tar.extractall(tmp, filter="data")
    source, = Path(tmp).glob("*/lib/compress/zstd_lazy.c")
    source.write_text(instrument(source.read_text()))
    libdir=source.parents[1]
    subprocess.run(["make", "-s", "-j4", "-C", libdir, "libzstd",
                    "ZSTD_LEGACY_SUPPORT=0", "ZSTD_LIB_DEPRECATED=0"], check=True)
    sys=library("libzstd.so.1")
    local=library((libdir/"libzstd.so").resolve())
    if sys._handle==local._handle or hasattr(sys,"btr_get_row_counts"):
        raise ValueError("reference and counted libraries are not distinct")
    arr=C.c_ulonglong*6
    local.btr_get_row_counts.argtypes=[C.POINTER(C.c_ulonglong)]
    local.btr_get_row_counts.restype=None
    def job(src):
        def compress(lib):
            cap=lib.ZSTD_compressBound(len(src))
            buf=C.create_string_buffer(cap)
            n=lib.ZSTD_compress(buf,cap,src,len(src),10)
            if lib.ZSTD_isError(n): raise ValueError("encoding failed")
            return buf.raw[:n]
        ref=compress(sys)
        counts=arr()
        local.btr_get_row_counts(counts)
        wire=compress(local)
        local.btr_get_row_counts(counts)
        if wire!=ref: raise ValueError("instrumented archive differs from system libzstd")
        out=C.create_string_buffer(len(src))
        if sys.ZSTD_decompress(out,len(src),wire,len(wire))!=len(src) or out.raw!=src:
            raise ValueError("system reconstruction differs")
        return [len(src),len(wire),*counts]
    src=(root/"bench/data/enwik8").read_bytes()
    if len(src)!=100_000_000: raise ValueError("wrong input")
    chunk=len(src)//4
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        rows=list(pool.map(job,[src[i:i+chunk] for i in range(0,len(src),chunk)]))
    if sum(r[1] for r in rows)+36!=30_740_221 or not all(r[3]==32*r[2] and r[4]>=r[5]>=r[6]>=r[7] for r in rows):
        raise ValueError(f"inconsistent counts: {rows}")
    with (args.out/"zstd-row-probes.csv").open("w") as f:
        w=csv.writer(f,lineterminator="\n")
        w.writerow(["input_bytes","zstd_frame_bytes","rows_queried","row_slots","survivors_buffered","candidates_checked","four_byte_passes","best_updates"])
        w.writerows(rows)
