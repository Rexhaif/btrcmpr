#!/usr/bin/env python3
"""Try independent parser, record and palette gains together before a native promotion."""
import argparse
import json
from pathlib import Path
import random
import tempfile
import subprocess
import sys
import time
from level_one_lab import Lab,read,sha,costs
p=argparse.ArgumentParser(description=__doc__)
for k in ('workspace','bin-dir','out'):p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();l=Lab(a.workspace,a.bin_dir,a.out);base=l.base
native={r['input']:r for r in read(l.root/'bench/results/presets/native-fastest-1/cli.csv')}
def shortlist(path,keys,name,limit,defaults):
    rows=read(path);pairs={}
    for r in rows:
        if r.get('file',name)!=name:continue
        key=tuple(int(r[k]) for k in keys)
        pairs.setdefault((key,r['tag']),{})[r['codec']]=r
    score={}
    for (key,_),both in pairs.items():
        r=both['btrcmpr'];z=both['zstd']
        if int(r['bytes'])>=int(z['bytes']):continue
        c=float(r['encode_MBps'])/float(z['encode_MBps']);d=float(r['decode_MBps'])/float(z['decode_MBps'])
        score.setdefault(key,[]).append((d>=.95,c))
    return list(dict.fromkeys([defaults,*sorted((x for x in score if x!=defaults),key=lambda x:min(score[x]),reverse=True)[:limit]]))
sf,sw=l.report('screen','file confirm job_KiB record record_KiB word bytes encode_MBps decode_MBps')
pf,pw=l.report('paired','file confirm job_KiB record record_KiB word tag codec archive_sha256 bytes encode_MBps decode_MBps pass_at_5pct')
doc=[]
with sf,pf,tempfile.TemporaryDirectory(dir=l.root/'bench/local') as temp:
    arc=Path(temp)/'joint.btr'
    for name in ('enwik8','mozilla'):
        native_job=192 if name=='mozilla' else 384;control=(0,native_job,2,128,0)
        ref=costs(read(base/'group-key'/f'{name}-1.csv'),'zstd')[0]
        parsers=shortlist(base/'confirm-match/paired.csv',('mode','job_KiB'),name,3,(0,native_job))
        record=shortlist(base/'record-pick/paired.csv',('predictor','job_KiB','record_KiB'),name,2,(2,192,128)) if name=='mozilla' else [(2,384,128)]
        words=[x[0] for x in shortlist(base/'word-palette/paired.csv',('mode',),name,2,(0,))]
        if sha(l.data/name)!=l.spec['input_sha256'][name]:raise ValueError('wrong corpus')
        cases={(q,k,m,r,w) for q,k in parsers for m,_,r in record for w in words}
        cases.update((q,rk,m,r,w) for q,_ in parsers for m,rk,r in record for w in words)
        cases=sorted(cases);random.Random(8912).shuffle(cases);results={}
        def cfg(x):
            q,k,m,r,w=x
            return dict(l.env,BTR_GROUP_OFFSETS='2',BTR_GROUP_KEY='10' if name=='mozilla' else '5',BTR_CONFIRM_MATCH=str(q),BTR_FAST_COUNTS='2',BTR_FAST_PLAN='0' if name=='mozilla' else '1',BTR_RECORD_COST=str(m),BTR_WORD_PALETTE=str(w),BTR_ARCH_KIB=str(k),BTR_JOB_KIB=str(k),BTR_RECORD_KIB=str(r))
        for x in cases:
            n,c,d=l.trial(name,cfg(x));results[x]=(n,c,d);sw.writerow((name,*x,n,c,d))
        candidates=[x for x in cases if x!=control and results[x][0]<ref]
        picks=[control]
        for x in sorted(candidates,key=lambda x:(results[x][2]>=1510,results[x][1]),reverse=True):
            # Keep the two best distinct configurations, including bit-identical
            # encoders if their implementation differs.
            if len(picks)>=3:break
            picks.append(x)
        def pair(x,tag):
            n,_,_=l.trial(name,cfg(x),arc);digest=sha(arc);l.restore(name,arc,l.env)
            if n!=results[x][0] or (x==control and digest!=native[name]['archive_sha256']):raise ValueError('control or archive changed')
            rates,ok=l.pair(name,cfg(x),n,ref,tag)
            for codec,(b,c,d) in zip(('btrcmpr','zstd'),rates,strict=True):pw.writerow((name,*x,tag,codec,digest if codec=='btrcmpr' else '',b,round(c,3),round(d,3),int(ok)))
            (b,c,d),(bz,cz,dz)=rates;doc.append(f"| [{tag}]({tag}.csv) | {' / '.join(map(str,x))} | {b:,} / {bz:,} | {c:.2f} / {cz:.2f} | {d:.2f} / {dz:.2f} | {'Yes' if ok else 'No'} |");return ok,c/cz
        scores=[]
        for i,x in enumerate(picks):
            res=pair(x,f'{name}-{i}')
            if i:scores.append((res,x))
        if scores:pair(max(scores)[1],name+'-repeat')
(l.out/'README.md').write_text('\n'.join(['# Joint level-one candidates','',
'The candidates combine separately tested changes to match confirmation, record prediction and palette packing. The settings below are match mode, generic job KiB, record policy, record job KiB, and packed-word mode. Each file uses the same baseline and worker count; the shipped configuration is row zero.','',
'| Raw trials | Configuration | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |','|---|---|---:|---:|---:|---|',*doc,'',
'The two size-eligible finalists advanced from a full-file screen, and the better paired result received a fresh five-pair repeat. All archives were independently restored. Timings use four workers per side, five alternating pairs after warmup and seven decodes per measurement. [All configurations](screen.csv), [paired hashes](paired.csv), [manifest](manifest.json).','']))
# Identify only candidates which beat the matched benchmark twice with the
# same archive. A future release must still pass a fresh native comparison.
selected={}
for name in ('enwik8','mozilla'):
    group=[r for r in read(l.out/'paired.csv') if r['file']==name and r['codec']=='btrcmpr']
    repeated=next((r for r in group if r['tag']==name+'-repeat' and r['pass_at_5pct']=='1'),None)
    if repeated is None:continue
    keys=('confirm','job_KiB','record','record_KiB','word','archive_sha256','bytes')
    initial=next((r for r in group if r['tag']!=repeated['tag'] and r['pass_at_5pct']=='1' and all(r[k]==repeated[k] for k in keys)),None)
    if initial is not None:selected[name]={k:repeated[k] for k in keys}|{'first':initial['tag'],'repeat':repeated['tag']}
(l.out/'repeatable.json').write_text(json.dumps(selected,indent=2)+'\n')

# A separately frozen release can use this time slot only if its expected
# archives name the independently repeated finalists. Do not promote screens.
if selected:
    prepared=l.root/'bench/local/levels/lanes/native-fastest-2'
    for _ in range(100):
        if (prepared/'ready').is_file():break
        time.sleep(1)
    if (prepared/'ready').is_file():
        known=json.loads((prepared/'expected.json').read_text())
        if any(known[name]!=[int(row['bytes']),row['archive_sha256']] for name,row in selected.items()):raise ValueError('new production snapshot does not identify the repeated candidates')
        subprocess.run([sys.executable,l.root/'bench/diagnostics/native-fastest.py','--workspace',prepared,'--out',l.root/'bench/results/presets/native-fastest-2'],check=True)
