#!/usr/bin/env python3
"""Isolate the level-8 history update that accounts for 36% of L1 refill samples."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import shutil
from statistics import median
import subprocess
import sys
import tempfile
from level_one_lab import read,sha

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepare',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2];lab=root/'bench/local/levels/lanes/index-tail';out=root/'bench/results/presets/research/index-tail'
origin=root/'bench/results/presets/native-combined-1';frozen=lab.parent/'combined-presets';stamp=json.loads((origin/'codegen.json').read_text())
meta=json.loads((origin/'manifest.json').read_text());series=origin.parent/'integrated'/stamp['comparator']
src=root/'bench/data/enwik8';gold,=(r for r in read(series/'verified-cells.csv') if r['level']=='8' and r['file']=='enwik8')
if sha(src)!=meta['input_sha256']['enwik8']:raise ValueError('wrong input')
if any(sha(frozen/k)!=v for k,v in meta['source_sha256'].items()):raise ValueError('frozen Rust source differs')
lab.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
for f in ('Cargo.toml','Cargo.lock'):shutil.copy2(frozen/f,lab/f)
for d in ('src','examples','.cargo','bench/support'):shutil.copytree(frozen/d,lab/d,dirs_exist_ok=True)
rust=lab/'src/lz.rs';s=rust.read_text()
mark='    #[inline(always)]\n    fn wide_probe'
gate='''    let lab_tail = if !ARCHIVE && SHORT == 18 && LONG == 21 && !TWICE && FILL == 1 && EXTRA == 18 && PB == 25 && COST && GATE == 2 && LIMIT == 1 && !CONTEXT && DISTINCT && PACK == 0 && !NINTH {
        std::env::var("BTR_LAB_INDEX_TAIL").ok().and_then(|v| v.parse::<u8>().ok()).unwrap_or(0)
    } else { 0 };
'''
if s.count(mark)!=1:raise ValueError('history entry changed')
s=s.replace(mark,gate+mark);lo=s.index('pub(crate) fn history_model');end=s.index('pub(crate) fn eighth_text',lo)
hook='        for (which, j) in [i + 1, i + 2, i + 3, end - 3, end - 2, end - 1]'
if s[lo:end].count(hook)!=1:raise ValueError('history tail changed')
rust.write_text(s[:lo]+s[lo:end].replace(hook,(root/'bench/diagnostics/experiments/index-tail.rs').read_text()+hook)+s[end:])
if a.prepare:raise SystemExit()
e={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_','ZSTD_','PROFILE_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS','BTRCMPR_NATIVE_SCAN')}
e.update(LC_ALL='C',BTR_LEVEL='8',ZSTD_WIDE='1')
target=lab/'target';model=frozen/'target/profiled'/('native-'+stamp['profile_data_sha256']+'.profdata')
with (out/'build.log').open('w') as log:
    subprocess.run([sys.executable,root/'scripts/build-profiled.py','--workspace',lab,'--target-dir',target,'--profile-data',model,
                    '--profile-sha256',stamp['profile_data_sha256'],'--selected'],env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
exes=target/'release';restore=root/'bench/local/preset-binaries'/('cli-'+stamp['cli']);perf=root/'bench/local/perf'
if sha(restore)!=stamp['cli']:raise ValueError('wrong production decoder')
identity=[]
with tempfile.TemporaryDirectory(dir=lab) as td:
    archive,back=(Path(td)/k for k in ('archive','back'))
    for mode in range(4):
        subprocess.run([exes/'btrcmpr','c','-8',src,archive,'4'],env=dict(e,BTR_LAB_INDEX_TAIL=str(mode)),capture_output=True,check=True)
        if sha(archive)!=gold['archive_sha256'] or archive.stat().st_size!=int(gold['btr_bytes']):raise ValueError('index scheduling changed archive bytes')
        subprocess.run([restore,'d',archive,back,'3'],capture_output=True,check=True)
        if sha(back)!=meta['input_sha256']['enwik8']:raise ValueError('independent decode differs')
        identity.append([mode,archive.stat().st_size,sha(archive),sha(back)])
with (out/'wire.csv').open('w') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['mode','bytes','archive_sha256','restored_sha256']);w.writerows(identity)
events=('instructions:u','cycles:u','branches:u','branch-misses:u','r03:u','r17:u')
order=[0,1,2,3,3,2,1,0];norm=2*src.stat().st_size
with (out/'counters.csv').open('w',buffering=1) as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['order','mode','archive_bytes','instructions_per_byte','cycles_per_byte','branches_per_byte','branch_misses_per_byte','l1d_refills_per_byte','l2d_refills_per_byte','MBps'])
    for i,mode in enumerate(order):
        with tempfile.TemporaryDirectory() as td:
            ctl,ack=(Path(td)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
            z=subprocess.run([perf,'stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',exes/'examples/profile','c','ours',src,'4','2'],
                env=dict(e,BTR_LAB_INDEX_TAIL=str(mode),PERF_CTL=str(ctl),PERF_ACK=str(ack)),cwd=lab,text=True,capture_output=True,check=True)
        raw=z.stderr;(out/f'run-{i}.txt').write_text(raw)
        if 'archive_bytes='+gold['btr_bytes']+'\n' not in raw:raise ValueError('counter run changed archive size')
        counts={a[2]:int(a[0])/norm for line in raw.splitlines() if len(a:=line.split(';'))>2 and a[2] in events}
        w.writerow([i,mode,gold['btr_bytes'],*(f'{counts[k]:.5f}' for k in events),re.search(r'([\d.]+) MB/s',raw)[1]])
rows=read(out/'counters.csv');table=[]
for mode,name in enumerate(('Original updates','Stage six addresses','Stage, prefetch seven-byte index','Stage, prefetch both indices')):
    rs=[r for r in rows if int(r['mode'])==mode]
    vals=[median(float(r[k]) for r in rs) for k in ('instructions_per_byte','cycles_per_byte','l1d_refills_per_byte','MBps')]
    table.append('| '+name+' | '+' | '.join(f'{v:.3f}' for v in vals)+' |')
(out/'README.md').write_text('\n'.join(['# Cache hints for the level-8 match index','',
    'The [native profile](../../../profiles/enwik8-general/combined-08/interpretation.md) found a large share of refill samples in the seven-byte index update. '
    'These variants calculate the addresses for up to six insertions first, then commit the original updates in order. Two also issue ARM store-prefetch hints. '
    'All used the same experimental binary, compiler profile, four workers, full enwik8 input, and [identical archive](wire.csv), independently restored by the production CLI.','',
    '| Mode | Instructions/byte | Cycles/byte | L1 data refills/byte | Encode MB/s |','|---|---:|---:|---:|---:|',*table,'',
    'Two counter runs per mode, forward then reverse order, with two full encodes and an untimed warmup per run; table entries are medians. '
    '[All observations](counters.csv). The [compiler log](build.log) records profile mismatches where the experiment changed control flow. '
    'Compare the variants with mode zero in this same binary; its absolute speed need not match the production comparator. '
    'The [release comparison](../../native-combined-1/README.md) uses the unchanged production executable.','']))
(out/'manifest.json').write_text(json.dumps(dict(native_comparator=stamp['comparator'],decoder=sha(restore),experimental_profile=sha(exes/'examples/profile'),experimental_cli=sha(exes/'btrcmpr'),
    source=sha(rust),source_before=meta['source_sha256']['src/lz.rs'],compiler_profile=sha(model),input=meta['input_sha256']['enwik8'],order=order,events=events),indent=2)+'\n')
