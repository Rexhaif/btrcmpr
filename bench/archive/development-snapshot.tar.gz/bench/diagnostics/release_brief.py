"""Generate the reader-facing release comparison from the certified trial medians."""
import json
import os
import tempfile


def render(cells, results, origin, target):
    lookup={(int(r['level']),r['file']):r for r in cells}
    metrics={(r['level'],r['file']):r for r in results}
    if len(lookup)!=len(cells) or lookup.keys()!=metrics.keys():raise ValueError('release report inputs disagree')
    files=('enwik8','x-ray','mozilla')
    complete=set(lookup)=={(lv,f) for f in files for lv in range(1,23)}
    prefix='Verified release' if complete else 'Unpublished preview'
    strict=sum(r['strict'] for r in results)
    series=origin.parent/'integrated'/json.loads((origin/'manifest.json').read_text())['benchmark_sha256']
    rel=lambda p:os.path.relpath(p,origin)
    lines=[f'# {prefix}: all 22 compression presets','',
           f'**{len(results)}/66** file/level comparisons verified with the same Rust executable and zstd 1.5.7 on four Cortex-A76 workers in both directions. The Rust archive was smaller, encoding was faster, and decoding reached at least 95% of zstd throughput in every listed comparison. In **{strict}** it also decoded strictly faster. Each archive was independently reproduced and restored by the standalone Rust CLI.','',
           f'[Standalone executable]({rel(target/"btrcmpr")}) · [All 66 absolute comparisons]({rel(series/"rates.md")}) · [Individual alternating rounds]({rel(series/"paired-rounds.md")}) · [Binary and archive hashes](release.json)','',
           'The following are the tightest margins for each input. The smallest size margin, lowest encode speedup and lowest decode speedup can occur at different levels. A speedup is Rust throughput divided by matched zstd throughput.','',
           '| File | Levels checked | Distinct Rust sizes | Smallest saving | Lowest encode speedup | Lowest decode speedup |','|---|---:|---:|---:|---:|---:|']
    for f in files:
        group=[(k[0],v) for k,v in metrics.items() if k[1]==f]
        if not group:continue
        size,enc,dec=[min(group,key=lambda x:x[1][field]) for field in ('saved_bytes','encode_vs_zstd','decode_vs_zstd')]
        count=len({lookup[l,f]['btr_bytes'] for l,_ in group})
        lines.append(f"| {f} | {len(group)} | {count} | {size[1]['saved_bytes']:,} B (−{size[0]}) | {enc[1]['encode_vs_zstd']:.3f}× (−{enc[0]}) | {dec[1]['decode_vs_zstd']:.3f}× (−{dec[0]}) |")
    lines+=['','A few matched levels, **Rust / zstd**. Ratio is original bytes divided by archive bytes; rates are original decimal MB/s.','',
            '| Input | Preset | Ratio | Encode MB/s | Decode MB/s |','|---|---:|---:|---:|---:|']
    for lv in (1,10,22):
        for f in files:
            if r:=lookup.get((lv,f)):
                numbers=[r['btr_'+k]+' / '+r['zstd_'+k] for k in ('ratio','encode_MBps','decode_MBps')]
                lines.append(f'| {f} | [−{lv}]({rel(series/r["individual_trials"])}) | '+' | '.join(numbers)+' |')
    lines+=['',f'The [preset guide]({rel(origin.parents[3]/"PRESETS.md")}) describes the algorithms for text, 16-bit signals and object sections. The baseline encodes four independent standard zstd frames, one per worker, so it can decode in parallel too. Every size includes framing and model metadata. Each timing comparison uses five alternating pairs after warmup and seven decodes per observation; this is a result about median throughput on this machine.','']
    if origin.name=='native-combined-1':
        lines+=['The selected format uses literal bytes and backward matches for ordinary data. At medium levels the encoder probes positions indexed by several prefix lengths; an inline fingerprint often rules out a position without loading its text. It stores lengths, distances and literals separately, which lets the ARM decoder unpack commands in batches. At high text levels it learns frequent phrases and stores their dictionary in the archive. On smooth 16-bit inputs it predicts neighboring samples; on recognized object archives it groups similar sections and packs integer records by column. These paths depend on input structure, not benchmark filenames.','',
                'On [enwik8 level 10](../../profiles/enwik8-general/combined-10/interpretation.md), the selected encoder retired 93.26 vs 295.96 instructions per byte, a 68.5% reduction. Instruction samples attributed about 274 instructions per byte to zstd’s row match finder and about 80 to Rust’s main text parser. A [controlled change to zstd](../../profiles/enwik8-general/middle-preset/search-depth/README.md) reduced search depth alone: zstd then used 178.19 instructions per byte but its archive grew by 625,934 bytes. Rust’s sparse lookups retire fewer instructions per cycle, so its throughput advantage was 1.29×. On [Mozilla level 1](../../profiles/combined-01-mozilla/interpretation.md), encode instruction counts were much closer (23.07 vs 23.86); the twofold reduction there was on decode (4.14 vs 8.71).','',
                'The [candidate table](../level-one-candidates.md) gives absolute speeds and compression ratios against a matched zstd run for each level-one encoder. The selected binary uses the regional scanner and has one set of results for all 22 levels.','']
        lines+=['The [15-pair check of the exact release](../research/selected-stability-15/README.md) passed level 1 on enwik8 and Mozilla, winning 12/15 and 15/15 individual encode pairs respectively. Mozilla level 1 is sensitive to timing: a [source rebuild](../research/combined-rebuild/README.md) with the same machine code lost 0.37% on encode over five pairs and won 2.22% over fifteen. A [different binary that reused buffers](../native-object-workspace-1/README.md) increased Mozilla encode throughput but missed the enwik8 decode floor, so it is not counted in this release. The [level-10 enwik8 profile](../../profiles/enwik8-general/combined-10/interpretation.md) explains where the selected encoder saves instructions.','']
    return '\n'.join(lines)


def publish(cells,results,origin,target):
    content=render(cells,results,origin,target)
    if not content.startswith('# Verified release:'):raise ValueError('only a complete series may publish a release brief')
    with tempfile.NamedTemporaryFile(mode='w',dir=origin,delete=False) as f:f.write(content)
    os.replace(f.name,origin/'release.md')
