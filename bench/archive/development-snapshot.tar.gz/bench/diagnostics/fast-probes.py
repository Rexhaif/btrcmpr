#!/usr/bin/env python3
"""Ablate exact five-byte candidate checks on the same archives, with ARM PMU counters."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import random
import re
from statistics import median
import subprocess
import tempfile
from decode_gate import DEFAULT_DECODE_LOSS_PCT, qualifies

p=argparse.ArgumentParser(description=__doc__)
for k in ['workspace','bin-dir','out']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2];snap=a.workspace.resolve();ex=a.bin_dir.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
base=root/'bench/results/presets/research';env={k:v for k,v in os.environ.items() if not k.startswith(('BTR_','PERF_'))};env['LC_ALL']='C'
def run(cmd,e):return subprocess.run(cmd,cwd=snap,env=e,text=True,capture_output=True,check=True)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def writer(name,cols):
    f=(out/(name+'.csv')).open('w',buffering=1);w=csv.writer(f,lineterminator='\n');w.writerow(cols.split());return f,w
known={r['file']:(r['verified_sha256'],int(r['archive_bytes'])) for r in read(base/'palette-write/checks.csv') if r['mode']=='0'}
old=json.loads((base/'group-offsets/manifest.json').read_text())
lib=Path(re.search(r'libzstd\.so\.1 => (\S+)',run(['ldd',ex/'compare'],env).stdout)[1])
if sha(lib)!=old['zstd_library_sha256']:raise ValueError('reference changed')
events=['instructions:u','cycles:u','branches:u','branch-misses:u','r03:u','r04:u']
spec=dict(workers=4,rounds=5,warmup_rounds=1,decodes=7,allow_decode_loss_pct=5,input_sha256=old['input_sha256'],
    zstd_library_sha256=sha(lib),source_sha256={str(p.relative_to(snap)):sha(p) for p in sorted((snap/'src').rglob('*.rs'))},
    binaries={k:sha(ex/k) for k in ['compare','examples/profile','examples/candidate','examples/decode_loop']},
    pmu_events=events,pmu_repeats=8,raw_events={'r03':'A76 L1D_CACHE_REFILL','r04':'A76 L1D_CACHE'})
(out/'manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
cf,cw=writer('counters','file probe batch bytes archive_sha256 instructions_per_byte cycles_per_byte branches_per_byte branch_misses_per_byte l1d_refills_per_byte l1d_accesses_per_byte counter_MBps')
pf,pw=writer('paired','file probe batch codec bytes encode_MBps decode_MBps pass_at_5pct')
with cf,pf,tempfile.TemporaryDirectory(dir=root/'bench/local') as work:
    arc=Path(work)/'probe.btr'
    for name,reference in [('enwik8',40669611),('mozilla',19963738)]:
        src=root/'bench/data'/name;nbytes=src.stat().st_size;digest,nb=known[name]
        if sha(src)!=old['input_sha256'][name]:raise ValueError('input changed')
        cases=[(m,b) for m in range(5) for b in [0,2]];random.Random(186+len(name)).shuffle(cases);cycles={}
        def cfg(case):return dict(env,BTR_PREFIX_PROBE=str(case[0]),BTR_GROUP_OFFSETS=str(case[1]),BTR_LEVEL='1')
        for case in cases:
            e=cfg(case);sample=next(csv.DictReader(run([ex/'examples/candidate','4','1',src,'native'],dict(e,BTR_CANDIDATE_FRAME=str(arc))).stdout.splitlines()))
            if int(sample['bytes'])!=nb or sha(arc)!=digest:raise ValueError('candidate changed the native archive')
            run([ex/'examples/decode_loop',arc,'1','3',src],env)
            with tempfile.TemporaryDirectory() as tmp:
                ctl,ack=(Path(tmp)/k for k in ('ctl','ack'));os.mkfifo(ctl);os.mkfifo(ack)
                r=run([root/'bench/local/perf','stat','-x',';','-D','-1',f'--control=fifo:{ctl},{ack}','-e',','.join(events),'--',ex/'examples/profile','c','ours',src,'4','8'],dict(e,PERF_CTL=str(ctl),PERF_ACK=str(ack)))
            (out/f'{name}-{case[0]}-{case[1]}-perf.txt').write_text(r.stderr)
            if f'archive_bytes={nb}\n' not in r.stderr:raise ValueError('wrong archive in PMU loop')
            counts={v[2]:float(v[0])/(8*nbytes) for s in r.stderr.splitlines() if len(v:=s.split(';'))>2 and v[2] in events}
            cw.writerow((name,*case,nb,digest,*(round(counts[k],5) for k in events),re.search(r'([\d.]+) MB/s',r.stderr)[1]));cycles[case]=counts['cycles:u']
        best=min((c for c in cases if c[0]!=0),key=cycles.get)
        for case in [(0,best[1]),best]:
            raw=out/f'{name}-{case[0]}-{case[1]}.partial'
            run([ex/'compare','4','5','both',src],dict(cfg(case),ZSTD_LEVEL='1',ZSTD_WIDE='1',WARMUP='1',DEC_ITERS='7',TRIALS_CSV=str(raw)))
            data=read(raw);costs=[]
            for k,n in [('btrcmpr',nb),('zstd',reference)]:
                seq=[r for r in data if r['codec']==k]
                if len(seq)!=5 or {int(r['round']) for r in seq}!=set(range(1,6)) or any(int(r['compressed_bytes'])!=n for r in seq):raise ValueError('bad timing pairs')
                costs.append((n,*(median(Decimal(r[t]) for r in seq) for t in ['compress_seconds','decompress_seconds'])))
            for k,(n,c,d) in zip(['btrcmpr','zstd'],costs,strict=True):
                pw.writerow((name,*case,k,n,round(Decimal(nbytes)/c/1_000_000,3),round(Decimal(nbytes)/d/1_000_000,3),int(qualifies(costs,DEFAULT_DECODE_LOSS_PCT))))
            raw.replace(raw.with_suffix('.csv'))
