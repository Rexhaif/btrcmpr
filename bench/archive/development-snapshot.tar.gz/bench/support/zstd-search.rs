// Diagnostic baseline only. All other parameters come from the installed zstd
// level, including strategy, hash-table sizes, match length and history window.
use btrcmpr::Result;
use std::{
    ffi::{c_int, c_void},
    io,
};
#[link(name = "libzstd.so.1", kind = "dylib", modifiers = "+verbatim")]
unsafe extern "C" {
    fn ZSTD_createCCtx() -> *mut c_void;
    fn ZSTD_freeCCtx(p: *mut c_void) -> usize;
    fn ZSTD_isError(code: usize) -> u32;
    fn ZSTD_CCtx_setParameter(ctx: *mut c_void, param: c_int, value: c_int) -> usize;
    fn ZSTD_compressBound(n: usize) -> usize;
    fn ZSTD_compress2(
        ctx: *mut c_void,
        dst: *mut c_void,
        cap: usize,
        src: *const c_void,
        n: usize,
    ) -> usize;
}
pub fn encode(src: &[u8], level: i32, log: i32) -> Result<Vec<u8>> {
    struct Ctx(*mut c_void);
    impl Drop for Ctx {
        fn drop(&mut self) {
            unsafe {
                ZSTD_freeCCtx(self.0);
            }
        }
    }
    unsafe {
        let ctx = Ctx(ZSTD_createCCtx());
        if ctx.0.is_null() {
            return Err(io::Error::other("zstd context allocation failed"));
        }
        for (param, value) in [(100, level), (104, log)] {
            // ZSTD_c_compressionLevel, ZSTD_c_searchLog
            if ZSTD_isError(ZSTD_CCtx_setParameter(ctx.0, param, value)) != 0 {
                return Err(io::Error::other("zstd rejected a search setting"));
            }
        }
        let cap = ZSTD_compressBound(src.len());
        let mut out: Vec<u8> = Vec::with_capacity(cap);
        let n = ZSTD_compress2(
            ctx.0,
            out.as_mut_ptr().cast(),
            cap,
            src.as_ptr().cast(),
            src.len(),
        );
        if n > cap || ZSTD_isError(n) != 0 {
            return Err(io::Error::other("zstd compress2 failed"));
        }
        out.set_len(n);
        Ok(out)
    }
}
