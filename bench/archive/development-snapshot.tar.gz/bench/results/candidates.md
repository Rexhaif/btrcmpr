Exploratory results on a four-core Cortex-A76
============================================

Each entry gives candidate / system libzstd 1.5.7 at level 3 from the same run.
Both codecs used four concurrent block jobs in each direction. Sizes include
the framing. MB/s uses original input bytes and decimal MB. These short runs
guided development; the final comparison, when available, is separate.

| Input | Candidate | Bytes (candidate / zstd) | Encode MB/s | Decode MB/s |
|---|---|---:|---:|---:|
| x-ray | 16-lane signal predictor | 5,842,461 / 6,118,146 | 742 / 45 | 1,892 / 1,044 |
| enwik8 | palette + one long-hash candidate | 35,681,034 / 35,727,119 | 109 / 75 | 1,269 / 1,193 |
| enwik8 | palette + two long-hash candidates | 35,482,561 / 35,727,119 | 86 / 75 | 1,281 / 1,182 |
| mozilla | palette + one long-hash candidate | 18,306,329 / 18,496,096 | 130 / 90 | 1,465 / 1,626 |
| mozilla | palette + two long-hash candidates | 18,228,980 / 18,496,096 | 101 / 85 | 1,416 / 1,553 |
| mozilla | gather all like sections, byte-plane record coding | 16,734,818 / 18,496,096 | 129 / 90 | 947 / 1,529 |
| mozilla | packed integer records, direct restoration of scattered records | 18,049,498 / 18,496,096 | 127 / 89 | 1,527 / 1,514 |

The x-ray row had one measured round. The single-candidate palette had three,
the two-candidate palette had two, the gathered archive had three, and direct
record restoration had five. Every row used a warmup and checked reconstructed
bytes. The sub-percent decode lead in the last row is within run-to-run noise.
