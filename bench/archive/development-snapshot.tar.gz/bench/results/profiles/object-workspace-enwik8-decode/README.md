# Level-one enwik8 decoder comparison

The [native object-buffer candidate](../../presets/native-object-workspace-1/README.md) missed the 5% decode gate on enwik8. This crossover compares the original and the candidate on byte-identical Rust archives, and also runs the same libzstd decoder in each executable. Each of the four cases occupied each position once. Each perf interval followed a verified warmup and covers eight four-worker decodes of the full input. Table entries are medians of the four runs per case.

| Build | Decoder | Instructions/B | Cycles/B | L1D refills/B | L2D refills/B | Decode MB/s |
|---|---|---:|---:|---:|---:|---:|
| Original | ours | 5.223 | 5.107 | 0.041 | 0.008 | 1618.385 |
| Original | zstd | 9.616 | 4.762 | 0.041 | 0.006 | 1642.015 |
| Object buffers | ours | 5.221 | 5.118 | 0.041 | 0.009 | 1617.880 |
| Object buffers | zstd | 9.616 | 4.769 | 0.042 | 0.006 | 1619.420 |

[All counters and timing observations](counter-runs.csv), [identities](manifest.json), [candidate and zstd cycle samples](decode-cycles.txt). These are fixed-archive diagnostic measurements. The original five-pair acceptance result is unchanged.
