# Where the enwik8 speed difference comes from

Raspberry Pi 5, four Cortex-A76 workers in each direction, 100,000,000-byte enwik8, libzstd 1.5.7 level 3. This input uses the general codec in all 48 blocks. Each hardware-counter run enables the user-mode PMU after building and verifying a frame. Cycles and instructions below are summed across workers and divided by original bytes processed. Throughput is from the separate [13-round paired run](../../confirmation-summary.csv).

| Operation | Instructions/byte, btrcmpr / zstd | Cycles/byte, btrcmpr / zstd | MB/s, btrcmpr / zstd |
|---|---:|---:|---:|
| Compress | 65.42 / 36.78 | 92.89 / 114.43 | 90.63 / 74.81 |
| Decompress | 5.43 / 12.38 | 6.80 / 7.37 | 1,170.22 / 1,069.60 |

Sources: [encode counters, btrcmpr](encode-btrcmpr.txt) and [zstd](encode-zstd.txt), five repetitions each; [decode counters, btrcmpr](../enwik8-ours.txt) and [zstd](../enwik8-zstd.txt), thirty each.

On compression, btrcmpr retired about **0.70 instructions per cycle**, versus **0.32** for zstd. On decompression it was **0.80 versus 1.68**. This is how the encoder can execute 78% more instructions in less time, and why the decoder's 56% reduction in instructions translates to a much smaller reduction in time. These are retired ARM instructions, not a count of bytes moved or SIMD lanes used. The table refers to the original level-3 comparison with the same block sizes for both codecs; the later preset matrix uses a different frame policy.

## Compression: candidate lookup latency

Cycle sampling attributed 93.5% of zstd's cycles to `ZSTD_compressBlock_doubleFast` and 93.2% of btrcmpr's to its LZ encode routine. For zstd the hottest lines were in [its two-table match search](https://github.com/facebook/zstd/blob/v1.5.7/lib/compress/zstd_double_fast.c#L176-L220): probing tables, deriving addresses, and comparing bytes at earlier positions. In separate runs the A76 counted backend stalls (cycles in which it issued no operation because of the execution backend) in [86.3% of cycles for zstd](encode-stalls-zstd.txt) and [70.9% for btrcmpr](encode-stalls-btrcmpr.txt). This counter is broader than cache misses. The profile localizes the bottleneck but does not assign every stalled cycle to a specific load.

In btrcmpr, a table entry contains both the old position and an 11-bit fingerprint. A mismatching fingerprint rejects the candidate without reading bytes from that position. In an isolated build we forced that otherwise unnecessary read and left the match decision intact. The output file was byte-identical (`cmp`). Throughput fell from 90.47 to 64.24 MB/s and cycles rose from 93.14 to 132.80 per input byte; instructions changed by less than 1%. A reverse-order repeat saw [87.62](encode-reference-repeat.txt) versus [60.67 MB/s](encode-always-load-repeat.txt), with 40% more L2 read refills when we forced the load. This establishes the value of early rejection in this encoder. The zstd comparison is between two complete encoders, not a test of adding the same filter to zstd.

For example, two prefixes can land in the same hash-table slot. The slot is already in hand. If its fingerprint differs, there is no need to follow the stored position into older input. If it agrees, the encoder still compares the actual bytes; a fingerprint collision cannot create a false match. See [the lookup](../../../../src/lz.rs).

## Decompression: 16 symbols or commands at a time

Of the six internal streams, tags, offset selectors, excess lengths and literals used the palette on every block: 30,299,144 symbols per file, including 10,189,814 command tags. The two remaining offset-byte streams were raw. A palette symbol is a fixed-width group number plus a variable number of bits selecting a byte within the group. The NEON path can read 16 group numbers, look up their widths, compute bit positions, and recover 16 symbols together. The LZ path separately expands 16 offset codes and prepares lengths and copy positions together; the actual copies preserve match dependencies.

| Controlled decoder change | Instructions/output byte | Change from selected |
|---|---:|---:|
| Selected | 5.43 | — |
| Only palette unpacking uses the scalar fallback | 14.12 | +8.69 |
| Only offset/length/position preparation uses the scalar fallback | 9.60 | +4.18 |
| Only the single-shuffle short-copy shortcut is disabled | 4.87 | −0.56 |
| All three changes together | 17.89 | +12.46 |

All decoder changes leave the encoder unchanged and each build verifies its output. The shortcut for short copies actually increased the instruction count on this input. These are comparisons with this codec's own fallback implementations, not additive shares of zstd's cost. The main zstd decompression routine, including its inlined sequence decoding and execution, accounted for about 90% of zstd's retired-instruction samples. Its literal Huffman fast loop accounted for about 5.5%. The zstd path also uses NEON for copies. The formats organize the commands differently.

The [controlled-change counters](controlled-changes.csv) and [sampled hotspots with source positions](sampled-hotspots.txt) are included. The latter used fixed periods of 410,009 instructions or 610,007 cycles, three compression or 22 decompression repetitions, and Debian debug symbols matching the running zstd library (build ID `4219c01a844f9cdcdf978669bad08682c95492f6`). Sampled instruction pointers are approximate. Individual profiling runs should not replace the paired benchmark for wall-time comparisons.

## Recheck after optimizing palette encoding

With the newer preset implementation, the same enwik8 file, level 3, four workers, and matching block sizes, a fresh run of the A76 performance counters found:

| Operation | Retired instructions per original byte, btrcmpr / zstd | CPU cycles per original byte, btrcmpr / zstd |
|---|---:|---:|
| Compress | 57.09 / 36.78 | 91.77 / 112.68 |
| Decompress | 5.43 / 12.38 | 6.38 / 7.06 |

Raw counters: [compress btrcmpr](preset-build-c-ours.txt), [compress zstd](preset-build-c-zstd.txt), [decompress btrcmpr](preset-build-d-ours.txt), [decompress zstd](preset-build-d-zstd.txt). Five encoding and twenty decoding repetitions per run; PMU counting starts after creating and verifying a frame. The optimized encoder now retires fewer instructions than our original encoder, but still **55% more** than zstd. The measured 2.28× instruction difference still applies to decoding.

An [instrumented count of the selected level-3 match finder](preset-probe-outcomes.csv) measured how often the fingerprint guard did useful work on the same file. There were 110,325,128 candidate probes, including repeat-distance and lookahead probes. Of these, 144 had no earlier position and **56,257,818 (51.0%)** failed the fingerprint before reading old input. The remaining 54,067,166 read an old position: 17,433,973 matched fewer than four leading bytes, and 36,633,193 matched at least four. Skipping a read is not necessarily avoiding a cache miss. This diagnostic verifies the instrumented and uninstrumented archives are byte-identical and checks the restored file. To reproduce it without timing instrumentation, run `python3 bench/diagnostics/count-probes.py`.

In [seven alternating paired trials](preset-build-paired-trials.csv) with warmup and five decodes per trial, this build compressed at **95.27 vs 73.28 MB/s** and decompressed at **1,327.11 vs 1,189.10 MB/s** (btrcmpr vs zstd). The [median results](preset-build-paired.csv) also report archive length, 35,103,083 vs 35,727,119 bytes including framing. The difference in instruction count is much larger than the 12% decode throughput gain.

Reproduce the changes on AArch64 with the data in `bench/data/enwik8`, `perf` on PATH (or set `PERF`), and a fresh scratch directory:

```sh
python3 bench/diagnostics/enwik8-ablate.py . "$(mktemp -d)"
```

The [current preset hardware counters](current-presets/README.md) use the wider zstd frames of the 22-level matrix. They compare levels 2, 3 and 5, and include separate instruction samples of the level-5 match finders.
