# Native level-one hardware counters

Four Cortex-A76 workers compressed and decompressed the entire input with the release representation. Each counter run recreated the archive sizes of the warmed paired experiment, restored the input, enabled the hardware counters only for the measured operation, then disabled them. Compression counted eight full inputs and decompression 24. CPU cycles are summed across workers.

| Input / operation | Instructions per original byte, Rust / zstd | CPU cycles per byte, Rust / zstd | Branch misses per byte, Rust / zstd |
|---|---:|---:|---:|
| [enwik8, encode](enwik8/c/per-byte.csv) | 28.55 / 29.42 | 14.93 / 13.21 | 0.167 / 0.106 |
| [enwik8, decode](enwik8/d/per-byte.csv) | 5.63 / 9.62 | 5.11 / 4.72 | 0.039 / 0.019 |
| [mozilla, encode](mozilla/c/per-byte.csv) | 23.84 / 23.86 | 11.31 / 10.83 | 0.089 / 0.071 |
| [mozilla, decode](mozilla/d/per-byte.csv) | 4.30 / 8.71 | 4.94 / 4.42 | 0.044 / 0.032 |

On enwik8, 30.4% of samples in `quicktwo.rs`, 24.7% of samples in `lz.rs`, 18.4% of samples in `palette.rs`. The denominator is all 28,507 recorded samples; 28,226 were in the Rust executable. [Source lines](enwik8/encode-lines.csv), [function samples for both encoders](enwik8/encode-samples.txt).
On mozilla, 29.3% of samples in `quicktwo.rs`, 24.6% of samples in `palette.rs`, 15.6% of samples in `lz.rs`. The denominator is all 12,193 recorded samples; 11,993 were in the Rust executable. [Source lines](mozilla/encode-lines.csv), [function samples for both encoders](mozilla/encode-samples.txt).

[Annotated ARM instructions for enwik8](enwik8/palette-disassembly.txt) and [Mozilla](mozilla/palette-disassembly.txt) show the separate byte loads from each symbol’s code entry.

The samples use the release sources without research settings, and the debug file for the matched zstd build. Source attribution uses the first project source line in each address’s inline stack. Instruction sampling identifies where work occurs; it does not measure the time of an individual source statement. [Paired wall-time results](../../../presets/native-fastest-1/README.md).
