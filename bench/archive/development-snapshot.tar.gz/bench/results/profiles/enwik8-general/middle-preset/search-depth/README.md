# Counting match candidates at level 10 on enwik8

Four Cortex-A76 workers each compressed a separate 25,000,000-byte quarter of enwik8 at level 10. On the same full file, the scratch Rust encoder looked at the bytes of **57,954,544** candidate positions; zstd's row matcher did its four-byte candidate check **573,728,700** times, **9.90× as often**. These are source-level event counts, not memory-bus transactions. The two checks also test different things: Rust compares the first eight bytes of a candidate, while zstd compares four bytes near the end of its current best length to decide whether to measure the full match.

| Event on 100,000,000 input bytes | Count |
|---|---:|
| zstd row lookups (32 slots per row) | 32,206,441 |
| Positions buffered after zstd's row fingerprint and window checks | 573,733,600 |
| Buffered positions checked against the current best | 573,728,700 |
| Checks that entered the full match-length comparison | 47,972,622 |
| Checks that improved zstd's best length | 47,776,910 |
| Rust candidate lookups, including lookahead and repeat distance | 95,168,915 |
| Rust lookups rejected by a fingerprint before reading the candidate text | 37,214,371 |
| Rust candidates compared against the text | 57,954,544 |

The row scan in zstd is vectorized. It covers 32 slots at once; it does not issue 32 string comparisons per call. The actual average was **17.81 checked positions per lookup** on this input. Only **8.36%** of those checks called the full match-length routine. Collecting candidate indices, prefetching, checking, and advancing the survivor list cost instructions even on failures. See [per-worker zstd counts](zstd-row-probes.csv), [per-worker Rust counts](../match-probes.csv), and the separate [retired-instruction samples](../encode-samples.txt). The zstd count is specifically its row finder; other paths, such as repeat-offset checks in the lazy parser, are outside this count. Rust's count includes repeat-offset and lookahead probes. The ratio is a comparison of the measured paths, not an instruction speedup.

**A controlled change to the baseline.** Keeping the installed 1.5.7 library, input, four independent workers, encoding strategy, window and other configured compression parameters fixed, we changed only zstd's search log. This parameter determines the search budget and affects the row width. The default search log of 5 produced the ordinary baseline archive byte for byte. Each entry below used one verified warmup and two counter-gated compressions; throughput is from the counter runs, not the five-pair confirmation benchmark.

| Encoder | Archive bytes | Instructions/input byte | CPU cycles/input byte | Encode MB/s |
|---|---:|---:|---:|---:|
| Rust level 10, [previous counter run](../per-byte.csv) | 30,566,906 | 106.636 | 531.917 | 14.33 |
| zstd level 10, search log 3 | 31,366,155 | 178.187 | 392.050 | 19.70 |
| zstd level 10, search log 4 | 31,041,295 | 216.917 | 466.477 | 16.48 |
| zstd level 10, default search log 5 | 30,740,221 | 295.964 | 700.092 | 11.27 |

Reducing the search log from 5 to 3 saved **117.78 instructions per byte** but added **625,934 archive bytes**. It also made this modified zstd encoder faster in wall time than the Rust encoder despite retiring more instructions. The default-level [paired benchmark](../../../../presets/ranked-distance-l10-l11/level-10-enwik8.csv) separately measured 14.96 vs 11.46 MB/s in favor of Rust. Retired instructions, CPU cycles, archive size and wall time answer different questions.

The [raw counters](per-byte.csv) include branches; the accompanying perf logs and executable and input checksums are in this folder. The [zstd event counter](../../../../../diagnostics/zstd-row-probes.py) patches only an isolated build of the reference library. Each of its four frames was compared byte for byte with the system library's output and decoded with that library. None of the timed results uses the instrumented library. The original source archive is from [Debian](https://deb.debian.org/debian/pool/main/libz/libzstd/libzstd_1.5.7+dfsg.orig.tar.xz), checked against its SHA-256 in the distribution source manifest. The reference code is not part of the Rust codec.

From the repository root (set PERF if perf is not on PATH):

```sh
mkdir -p bench/local/search-depth
for log in 5 3 4; do
  PROFILE_ZSTD_SEARCH_LOG=$log ZSTD_WIDE=1 BTR_LEVEL=10 \
    scripts/perf-stat.sh c zstd bench/data/enwik8 4 2 >bench/local/search-depth/search-$log.txt 2>&1
done
python3 bench/diagnostics/search-cost.py bench/local/search-depth
python3 bench/diagnostics/zstd-row-probes.py /path/to/libzstd_1.5.7+dfsg.orig.tar.xz bench/local/search-depth
```
