# Where level 1 spends instructions after choosing matches

On full enwik8, the native encoder retired 33.97 instructions per input byte while zstd retired 29.42. We resolved the same recorded ARM instruction samples to the inlined Rust entropy code. Packing the chosen symbols accounts for more instructions than deciding their code widths.

| Work inside the two entropy functions | Instruction samples | Share of complete encoder | Estimated instructions/input byte |
|---|---:|---:|---:|
| Pack fixed-width selectors and variable-width ranks | 3,358 | 14.02% | 4.76 |
| Count byte frequencies | 2,001 | 8.36% | 2.84 |
| Choose widths for the palette | 1,209 | 5.05% | 1.71 |

Widths tell the decoder how many bits each group of symbols needs. Even eliminating width selection entirely would save only an estimated 1.71 of the 4.55 extra instructions per byte on this build. This is an instruction budget, not a prediction of elapsed time. The two functions account for 6,701 of 23,949 samples. Other work, including calls to the system math library, is outside those functions; [all measured groups](groups.csv) retain unattributed samples.

The [source and binary hashes](manifest.json) match the [original six-encode profile](../README.md). The [per-address inline stacks](addresses.csv) show how each group was assigned. The normalized cost is its share of the entire sample multiplied by the independently measured instruction count. Reproduce the attribution with `bench/diagnostics/fast-parser-lines.py --entropy`, passing the original executable, perf recording, and source directory.
