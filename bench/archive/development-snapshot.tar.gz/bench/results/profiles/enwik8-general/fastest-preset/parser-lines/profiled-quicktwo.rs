// Look up two neighboring positions before deciding the first one. When the
// indices collide, the second lookup must see the just-inserted first slot.
// A successful first match discards the speculative second lookup.
use super::{Streams, probe, word};
#[inline(always)]
fn keys(w: u64) -> (usize, u32) {
    (
        ((w << 24).wrapping_mul(0x9e3779b97f4a7c15) >> 49) as usize,
        (w as u32).wrapping_mul(0x9e3779b1) << 21,
    )
}
pub(super) fn encode(s: &[u8], archive: bool) -> Vec<u8> {
    let mut st = Streams::sized(s.len());
    let mut table = vec![0u32; 1 << 15];
    let (mut i, mut anchor) = (0, 0);
    while i + 8 <= s.len() {
        let w = word(s, i);
        let (k, sig) = keys(w);
        let here = sig | i as u32;
        let (mut len, mut q) = if i + 9 <= s.len() {
            let w1 = word(s, i + 1);
            let (k1, sig1) = keys(w1);
            let old = table[k];
            let old1 = if k == k1 { here } else { table[k1] };
            table[k] = here;
            let (a, b) = probe(s, i, w, old, sig);
            if a > 4 || (a == 4 && i - b <= 12000) {
                (a, b)
            } else {
                i += 1;
                table[k1] = sig1 | i as u32;
                probe(s, i, w1, old1, sig1)
            }
        } else {
            let old = std::mem::replace(&mut table[k], here);
            probe(s, i, w, old, sig)
        };
        if len < 4 || (len == 4 && i - q > 12000) {
            i += 1;
            continue;
        }
        let off = i - q;
        while i > anchor && q > 0 && s[i - 1] == s[q - 1] {
            i -= 1;
            q -= 1;
            len += 1;
        }
        st.emit(s, anchor, i, len, off);
        i += len;
        anchor = i;
        for j in i - 2..i {
            if j + 8 <= s.len() {
                let (k, sig) = keys(word(s, j));
                table[k] = sig | j as u32;
            }
        }
    }
    st.finish(s, anchor, archive)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn speculative_second_slot_preserves_the_single_probe_parse() {
        let mut input = Vec::from(&b"aaaaabaaaaac1234"[..]);
        let mut r = 1234u32;
        for j in 0..8192 {
            r = r.wrapping_mul(1664525).wrapping_add(1013904223);
            input.push(b'a' + ((r >> 28) as u8));
            if j % 13 == 0 {
                input.extend_from_slice(b"abcdefghijklmnopqrst_");
            }
        }
        for n in (0..23).chain([4095, input.len()]) {
            for archive in [false, true] {
                let a = encode(&input[..n], archive);
                let b = super::super::quick_impl::<1, 15, false, 2>(&input[..n], archive);
                assert_eq!(a, b);
            }
        }
    }
}
