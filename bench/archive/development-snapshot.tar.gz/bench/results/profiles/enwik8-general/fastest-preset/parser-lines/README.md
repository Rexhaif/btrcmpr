# Level-1 match-loop instruction samples

On the complete enwik8, 16,384 of 23,949 sampled retired user instructions fell inside the native two-position match-and-emit function. Inline source information identifies several separate costs inside it. The totals below are percentages of the **entire encoder**; the instructions per input byte are estimates obtained by multiplying the sample share by the independently measured 33.967 instructions/input byte.

| Group | Samples | Share of whole encoder | Estimated instructions/input byte |
|---|---:|---:|---:|
| verify candidate or extend match | 4,594 | 19.18% | 6.516 |
| emit literals, lengths and distance | 3,442 | 14.37% | 4.882 |
| other or unassigned | 2,751 | 11.49% | 3.902 |
| form keys or access current index | 2,061 | 8.61% | 2.923 |
| index inside accepted match | 1,628 | 6.8% | 2.309 |
| parse decisions and loop control | 1,592 | 6.65% | 2.258 |
| extend match backwards or form distance | 316 | 1.32% | 0.448 |

Debug line tables could not place all instructions; the unassigned samples are left visible. A sample assigned to a source line may represent several instructions, and a source-group estimate is not an independent causal intervention. The original [profiled parser](profiled-quicktwo.rs) and [binary identities](manifest.json) were matched before symbolization. The [individual instruction offsets and inline stacks](addresses.csv) are retained.
