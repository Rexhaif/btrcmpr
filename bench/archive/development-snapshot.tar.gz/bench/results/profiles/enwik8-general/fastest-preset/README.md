# Why the instruction advantage reverses at level 1

On the full 100 MB enwik8, the production Rust encoder retired **33.97 instructions per input byte** versus **29.42** for zstd 1.5.7. It also used more CPU cycles per byte, **17.17 vs 13.46**. Unlike levels 10 and 17, zstd uses its fast matcher here. Rust's level-1 archive was smaller (40,542,760 vs 40,669,611 bytes), but it did not win on compression speed.

| Encoder | Hottest function, share of instruction samples | Approximate instructions/input byte in that function |
|---|---|---:|
| Rust | Two-position LZ lookup and command emission, 68.41% | 23.2 |
| zstd | Fast block compressor, 51.95% | 15.3 |

The function boundaries differ. Rust spent a further 19.28% of samples in palette coding and 8.70% in other stream coding. For zstd, encoding match sequences took 19.97%, Huffman bit emission took 11.24% and the parallel histogram loop took 9.69%. Cutting search breadth cannot yield the same savings here as at level 10: zstd already does relatively little search.

The [native archive fields](wire.csv) account for every byte of the original level-1 frames. On enwik8, 10,557,552 copy commands represented 81,785,126 original bytes (7.75 per copy); 18,214,874 literal bytes cost 13,066,855 on the wire. The command tags and distance selectors together cost 15,375,348 bytes. All 384 blocks stored the low and middle distance payloads raw. These counts distinguish a change in which matches are chosen from changing how the same commands are written.

Each codec had four Cortex-A76 workers. The [PMU totals](per-byte.csv) cover eight full encodes or twelve full decodes after a verified warmup; the [instruction samples](encode-samples.txt) cover six encodes per codec in a separate process. The [manifest](manifest.json) identifies the executable, input, and source. The counter runs measure one codec at a time; use the [alternating level-1 trials](../../../presets/research/fast-one/README.md) to compare elapsed time with zstd.

```sh
PERF=bench/local/perf python3 bench/diagnostics/phrase-pmu.py --level 1 --out bench/local/pmu-1
```

[Instruction samples within the match loop](parser-lines/README.md) separate checking candidates, updating indices and writing the chosen commands.

[Instruction samples within the entropy encoder](entropy-lines/README.md) attribute 14.02% of the complete encoder's instructions to bit packing, 8.36% to counting symbols and 5.05% to choosing palette widths.
