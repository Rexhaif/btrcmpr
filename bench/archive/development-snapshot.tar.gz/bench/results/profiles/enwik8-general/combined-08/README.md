# Level 8, enwik8: hardware counters on the combined build

Four Cortex-A76 workers on each side. The [paired wall-time trials](../../../presets/integrated/f8d320e7b5b2449a2586eccc6af365eafb306215e6c6b403a91de57e03078464/l08/level-08-enwik8.csv) used a separate comparator from the same [native build](../../../presets/native-combined-1/codegen.json). Each counter run checked the paired archive size and original contents. Counters cover the measured operation only; each value is summed over all workers and divided by the number of uncompressed bytes processed.

| Operation | Event per input byte | Rust | zstd | zstd / Rust |
|---|---|---:|---:|---:|
| Encode | Instructions | 119.447 | 201.876 | 1.69× |
| Encode | CPU cycles | 364.708 | 364.583 | 1.00× |
| Encode | Branch misses | 0.895 | 0.922 | 1.03× |
| Encode | L1 data cache refills | 2.145 | 1.137 | 0.53× |
| Encode | L2 data cache refills | 1.956 | 2.445 | 1.25× |
| Decode | Instructions | 6.830 | 11.112 | 1.63× |
| Decode | CPU cycles | 9.064 | 9.242 | 1.02× |
| Decode | Branch misses | 0.072 | 0.012 | 0.17× |
| Decode | L1 data cache refills | 0.029 | 0.086 | 2.94× |
| Decode | L2 data cache refills | 0.051 | 0.039 | 0.76× |

Raw perf output and executable identities: [encode](c/manifest.json), [decode](d/manifest.json).
