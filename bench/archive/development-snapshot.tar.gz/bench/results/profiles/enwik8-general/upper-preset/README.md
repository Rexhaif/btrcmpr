# Level 22: hardware counters for the confirmed enwik8 encoder

On the 100,000,000-byte input, the scratch Rust compressor retired **279.63 instructions/input byte**, versus **1665.79** for zstd 1.5.7 level 22 (83.2% fewer). Four Cortex-A76 workers ran per codec. The [separate five-pair run](../../../presets/dictionary-20-22/enwik8-22.md) measured a 2.475× encode and 1.155× decode speedup with a 19,962-byte smaller archive.

| Encoder | Archive bytes | Instructions/B | Aggregate user CPU cycles/B | Branches/B | Branch misses/B | Counter-run MB/s |
|---|---:|---:|---:|---:|---:|---:|
| ours | 26,790,565 | 279.63 | 696.30 | 47.58 | 2.23 | 6.28 |
| zstd | 26,810,527 | 1665.79 | 3,353.85 | 234.74 | 14.23 | 2.50 |

The two measured full compressions per codec followed a verified warmup. Perf was enabled only around the repeated encode operation. The driver checked the exact Rust source tree, comparator identity, input SHA-256, baseline library hash and reproduction of both measured archive sizes. The [manifest](manifest.json), [normalized counters](per-byte.csv), [Rust PMU output](ours-perf.txt) and [zstd PMU output](zstd-perf.txt) identify the evidence.

Rust learns a shared phrase dictionary and compresses its spelling fields at this level. The two encoders accumulated CPU cycles at different rates during wall time: approximately 4.37 billion aggregate user cycles/second for Rust and 8.38 billion for zstd. Time spent on different numbers of cores, stalls, and clock rates can all affect the relationship. The counter run does not measure phase-by-phase utilization. The [level-17 instruction samples](../shared-preset/README.md) localize tree-search and parse costs at level 17; these level-22 totals alone do not give those function shares at level 22.
