# Instructions and cycles for the level-13 phrase preset

On enwik8 the production phrase encoder retired **172.89 vs 318.12 instructions per input byte** for zstd 1.5.7 at the same level (45.7% fewer). It also sustained a higher instruction rate, 0.421 vs 0.289 per CPU cycle. The combination reduced the aggregate cycle cost from 1,099.02 to 410.76 cycles per byte. The separate [five-pair wall-time comparison](../../../presets/phrase-levels-13-15/README.md) found a 2.54× encoding speedup with a 245,737-byte smaller archive.

| Operation | Instructions/byte (ours / zstd) | CPU cycles/byte (ours / zstd) | Paired MB/s (ours / zstd) |
|---|---:|---:|---:|
| Encode | 172.89 / 318.12 | 410.76 / 1,099.02 | 19.54 / 7.69 |
| Decode | 11.94 / 10.36 | 8.82 / 12.10 | 882.09 / 694.89 |

On decode the instruction count actually increased by 15.3%. After building the phrase dictionary, the decoder can compute the source for each token directly and prepare multiple independent dictionary reads before copying their spellings. Its measured instruction rate was 1.353 vs 0.856 per cycle; fewer cycles, rather than fewer instructions, explain the 1.27× throughput gain.

The [reference parameters](../reference-parameters.csv) switch to a binary-tree lazy match finder for these 25 MB level-13 zstd frames. The Rust preset tokenizes spans of letters, digits and punctuation, counts repeated adjacent pairs, replaces frequent pairs with phrase IDs, and sends the reachable dictionary and token codes. Consequently the [measured level-10 row-candidate count](../middle-preset/search-depth/README.md) cannot be extrapolated to either encoder at level 13.

In separate [retired-instruction samples](encode-samples.txt), **84.61%** of zstd's samples landed in its binary-tree match search and **8.04%** in tree updates. For Rust, **33.25%** landed in learning the merge rules and **29.58%** in tokenization; entropy coding was 5.68%. Multiplying the sample shares by each encoder's counter total gives about **295 instructions per input byte in those two zstd tree functions**, versus **109 instructions per byte in the two Rust training functions**. These estimates locate the work; the function boundaries differ.

The [raw normalized counters](per-byte.csv) come from four Cortex-A76 workers, two warmed encodes and twelve warmed decodes per codec. The PMU was enabled only around the measured operation, after verifying the warmup frame. CPU cycles are summed over workers; throughput in the table is from separate alternating trials. [Executable, source, input hashes and perf version](manifest.json).

From the repository root, with perf on PATH or PERF set to its executable:

```sh
python3 bench/diagnostics/phrase-pmu.py --level 13 --out bench/local/phrase-pmu
# Optionally include --zstd-debug /path/to/zstd.debug to sample encoder instructions.
```
