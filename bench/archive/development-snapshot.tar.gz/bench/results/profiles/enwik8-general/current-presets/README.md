# General codec on enwik8 with the preset benchmark's zstd frames

These Pi 5 Cortex-A76 hardware counters cover 100,000,000 original bytes per repetition. Four workers ran for each codec in both directions. The baseline was libzstd 1.5.7 at the stated positive level, compressing one 25,000,000-byte independent frame per worker. The btrcmpr side used the shipped preset and selected its own block size. Counters were enabled after frame creation, warmup and a full byte comparison, and disabled before process exit. The compressed lengths in the logs match the paired trials. The [raw normalized counts](per-byte.csv) and individual perf logs are in this directory.

| Preset | Encode instructions/B, btrcmpr / zstd | Decode instructions/B, btrcmpr / zstd | Encode cycles/B, btrcmpr / zstd | Paired throughput gain, encode / decode |
|---|---:|---:|---:|---:|
| [2](../../../presets/enwik8-neighbor-v1/matrix.csv) | 42.94 / 30.13 | 5.21 / 11.81 | 31.79 / 35.46 | 1.15× / 1.07× |
| [3](../../../presets/enwik8-l3-wide/matrix.csv) | 61.58 / 36.57 | 5.43 / 12.36 | 94.71 / 113.32 | 1.18× / 1.24× |
| [5](../../../presets/enwik8-final-l5/matrix.csv) | 57.84 / 99.47 | 7.24 / 12.79 | 187.53 / 229.81 | 1.31× / 1.17× |

The first three numeric columns come from the hardware-counter runs (three encodes or twelve decodes). The throughput ratios come from the separate warmed paired trials linked in the table. Cycles are user CPU cycles summed across workers, not wall-clock time. Ratios of retired instructions rarely predict throughput: for example, at level 3 the encoder sustained 0.65 retired instructions per cycle against 0.32 for zstd.

The [earlier level-3 controlled changes](../README.md) isolate the reason skipping a candidate read can save time despite costing instructions and why decoding the palette and commands in batches saves instructions. The earlier comparison used shorter zstd frames. In that experiment the 11-bit fingerprint rejected 56.26 million of 110.33 million candidate probes without reading old input. Forcing the loads while producing exactly the same archive reduced encoding throughput from 90.47 to 64.24 MB/s. On decode, replacing just the palette unpacker with scalar code raised instructions/B from 5.43 to 14.12; replacing just the command preparation raised it to 9.60. These isolated changes are not additive shares of zstd's cost. On the current frame policy, the level-3 decoder still retires 56% fewer instructions (12.36 / 5.43 = 2.28); the encoder retires 68% more.

At level 5 the instruction comparison reverses on compression. In [separate PMU instruction samples](level5-encode-samples.txt), 79.24% of zstd's samples landed in the row match finder and 10.57% in sequence encoding. Multiplying the sample fractions by its measured 99.47 instructions/B puts about 79 instructions/B in the row match finder alone. The Rust encoder spent 89.74% of its smaller 57.84 instructions/B total in its LZ parser, about 52 instructions/B. That parser tests at most one short-prefix position, two long-prefix positions, and the last match distance at the current position; it also probes ahead and indexes positions inside accepted matches. These are different algorithms: sampling identifies where the instructions ran, without attributing the entire cross-codec difference to any single code change.

To reproduce either counter with perf on PATH, or with PERF set to the executable:

```sh
BTR_LEVEL=3 ZSTD_WIDE=1 scripts/perf-stat.sh c ours bench/data/enwik8 4 3
BTR_LEVEL=3 ZSTD_WIDE=1 scripts/perf-stat.sh c zstd bench/data/enwik8 4 3
BTR_LEVEL=3 ZSTD_WIDE=1 scripts/perf-stat.sh d ours bench/data/enwik8 4 12
BTR_LEVEL=3 ZSTD_WIDE=1 scripts/perf-stat.sh d zstd bench/data/enwik8 4 12
```

To normalize the saved perf logs, run `python3 bench/diagnostics/preset-counters.py bench/results/profiles/enwik8-general/current-presets` from the repository root.

The instruction samples used the same gated profile executable, three compression repetitions and a fixed period of 410,009 user instructions, with zstd debug symbols matching build ID 4219c01a844f9cdcdf978669bad08682c95492f6. Input and executable hashes are in [checksums.txt](checksums.txt).

[Level-10 counters and instruction samples](../middle-preset/README.md) show where the encoder uses 2.78 times fewer instructions on enwik8. At that level the decoding instruction counts are much closer.
