# Faster palette encoding

Cycle sampling at level 1 on the four-core A76 put 28.8% of enwik8 encoding in the palette encoder and 30.5% for Mozilla. The new encoder computes four palette-planning states together, stops when an extra selector bit would cost more than the best plan, and packs ranks four at a time. All three changes leave the format and the decoder unchanged. We used the production CLI and `cmp` to compare the full original and optimized level-1 archives: enwik8 SHA-256 `44de5513f094eefef73e32debfa3f7ec6cccafdac2f20e20101139ced576453e`; Mozilla `b158ca98158464fc4c49375c011186382d9b4d71b85700a27ed0e24b92ba1508`.

Five alternating runs after warmup, five decodes per round, four workers for both directions and both codecs, zstd 1.5.7 with four independent quarter-file frames. Each pair verified the full output. Measurements here are medians, in millions of original bytes per second.

| Level and input | Bytes, ours / zstd | Encode MB/s, ours / zstd | Decode MB/s, ours / zstd | Passes all three |
|---|---:|---:|---:|:---:|
| 1 enwik8 | 40,542,760 / 40,669,611 | 472.96 / 642.22 | 1,639.19 / 1,651.20 | No |
| 1 mozilla | 19,121,858 / 19,963,738 | 525.34 / 765.61 | 1,651.08 / 1,641.12 | No |
| 2 mozilla | 18,501,909 / 18,979,149 | 378.19 / 329.97 | 1,683.07 / 1,558.30 | Yes |

[Level 1 trials](level-1-trials.csv) · [Level 2 trials](level-2-trials.csv)
