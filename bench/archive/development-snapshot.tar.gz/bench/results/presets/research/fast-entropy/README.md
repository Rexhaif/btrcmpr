# Testing the cost of the level-1 entropy model

The candidate planner starts with a ranked alphabet and splits power-of-two groups, charging each possible split its exact bit cost. This avoids solving for every possible starting rank and suffix. Other switches count symbols into four independent histograms, defer normalization until rANS actually needs it, and approximate logarithms used only to choose the coder. All probabilities and codes needed by the decoder are transmitted exactly. Neither the input filename nor an external model is available to the codec.

| Fastest size-qualified candidate in the screen, afterwards paired against zstd 1 | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---:|---:|---:|
| enwik8, direct prefix lookup, four histograms and approximate group planning | 40,662,331 / 40,669,611 | 519.49 / 595.98 | 1,558.85 / 1,657.48 |
| Mozilla, sparse CRC lookup and approximate group planning | 19,704,811 / 19,963,738 | 562.30 / 751.58 | 1,593.79 / 1,631.21 |

The encoder stayed below the target archive size on both files but never beat all three measures. These are [five alternating pairs](paired.csv), four workers per codec, warmup and seven decodes per round. The [screen](screen.csv) varied one or both fast paths; the [driver](../../../../diagnostics/fast-entropy.py) additionally restored the selected archives on three decoder workers.
