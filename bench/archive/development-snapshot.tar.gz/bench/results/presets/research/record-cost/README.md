# Exact record-width prices on the full Mozilla archive

For a candidate width, every exception needs one position and at least one high-byte digit. A cumulative histogram gives the exception count and the number of extra digits crossing each successive seven-bit boundary. This computes the identical byte cost without a nested scan of all histogram bins. Policy 2 also handles constant runs directly; policy 3 adds a four-lane ARM bit writer. The match parser and archive format are unchanged by these policies.

| Parser and job | Planner / distance batch mode | Record policy | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---:|---:|---:|---:|---:|---|
| [0, 128 KiB](mozilla-0-0.csv) | 0 / 0 | 0 | 19,121,858 / 19,963,738 | 540.41 / 760.62 | 1653.02 / 1653.14 | No |
| [0, 128 KiB](mozilla-0-2.csv) | 0 / 0 | 2 | 19,121,858 / 19,963,738 | 626.12 / 726.23 | 1638.92 / 1649.23 | No |
| [10, 128 KiB](mozilla-1-0.csv) | 0 / 0 | 0 | 19,961,918 / 19,963,738 | 598.15 / 736.52 | 1628.22 / 1658.78 | No |
| [10, 128 KiB](mozilla-1-2.csv) | 0 / 0 | 2 | 19,961,918 / 19,963,738 | 725.56 / 759.86 | 1657.86 / 1677.48 | No |
| [18, 256 KiB](mozilla-2-2.csv) | 3 / 0 | 2 | 19,630,993 / 19,963,738 | 693.68 / 701.69 | 1598.16 / 1571.69 | No |
| [18, 96 KiB](mozilla-3-2.csv) | 0 / 0 | 2 | 19,649,759 / 19,963,738 | 675.95 / 707.65 | 1652.42 / 1673.65 | No |

Policy 2 used the fewest measured cycles among the three new implementations on the same archived bytes. The scalar control and all three implementations reproduced the full archive hash. Each finalist was separately checked against its unchanged control archive and restored with three workers. Timing used five alternating four-worker pairs after warmup, with seven decodes per measurement. [Counters](counters.csv), [all screens](screen.csv), [paired medians](paired.csv), [source and build hashes](manifest.json).
