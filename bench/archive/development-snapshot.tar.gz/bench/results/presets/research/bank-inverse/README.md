# Level 6: restore the same instruction banks in larger groups

On the same 17,207,799-byte Mozilla archive, the selected decoder restores up to 128 instructions together. NEON extracts the bank IDs; the decoder gathers the low halfwords, omits software prefetch, and skips delta reconstruction for banks containing zero or one halfword. The output is byte-identical.

| Measurement | Native inverse | Selected inverse |
|---|---:|---:|
| Fixed-archive median decode MB/s | 1,375.2 | 1,439.0 |
| Retired instructions per original byte | 10.296 | 8.861 |
| Aggregate CPU cycles per original byte | 5.992 | 5.731 |

In [five alternating warmed pairs](level-6-mozilla.csv), the candidate compressed at **67.981 vs 45.818 MB/s** for zstd and decoded at **1414.164 vs 1373.615 MB/s**. It saved 27,593 bytes. Each codec used four workers and the matching numeric level; each trial included seven decodes. The separate fixed-archive [screen](screen.csv) and [PMU runs](counters.csv) compare decoder policies within Rust and should not substitute for the paired zstd result.
