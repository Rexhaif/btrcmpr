# Writing identical level-1 distances in small batches

The match finder, literal and length format, block boundaries and decoder stay the same. The encoder collects 8, 32 or 64 distances locally; ARM NEON compares each against the preceding three absolute distances, then packs the extra bytes. Every setting reproduced the native full-file SHA-256 and independently restored the input on three decoder workers.

| File | Distances per batch | Instructions/input byte | Aggregate CPU cycles/input byte | Branch misses/input byte |
|---|---:|---:|---:|---:|
| enwik8 | Native | 33.9363 | 17.3683 | 0.212 |
| enwik8 | 8 | 31.3331 | 16.3706 | 0.1946 |
| enwik8 | 32 | 31.2324 | 16.1555 | 0.1833 |
| enwik8 | 64 | 30.8948 | 16.4213 | 0.1817 |
| mozilla | Native | 30.8262 | 15.9621 | 0.1304 |
| mozilla | 8 | 30.0178 | 15.6209 | 0.1174 |
| mozilla | 32 | 29.9691 | 15.4469 | 0.1127 |
| mozilla | 64 | 29.8138 | 15.5618 | 0.1104 |

The [gated perf totals](counters.csv) cover ten full encodes per setting. The table below compares both native and the best experimental batch by CPU cycles against a fresh zstd level-1 measurement: five alternating pairs after warmup, four workers, seven decodes per measurement. A factor above 1 means Rust was faster.

| File | Distances per batch | Bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Encode vs zstd | Decode vs zstd |
|---|---:|---:|---:|---:|---:|---:|
| [enwik8](enwik8-0.csv) | Native | 40,542,760 / 40,669,611 | 499.33 / 616.60 | 1,587.69 / 1,635.35 | 0.810× | 0.971× |
| [enwik8](enwik8-32.csv) | 32 | 40,542,760 / 40,669,611 | 517.01 / 650.87 | 1,575.47 / 1,633.30 | 0.794× | 0.965× |
| [mozilla](mozilla-0.csv) | Native | 19,121,858 / 19,963,738 | 544.61 / 750.89 | 1,658.65 / 1,591.26 | 0.725× | 1.042× |
| [mozilla](mozilla-32.csv) | 32 | 19,121,858 / 19,963,738 | 552.23 / 727.96 | 1,645.06 / 1,660.52 | 0.759× | 0.991× |

The [manifest](manifest.json) identifies the two inputs, Rust sources, executables and reference library. This research report does not count as production preset verification.
