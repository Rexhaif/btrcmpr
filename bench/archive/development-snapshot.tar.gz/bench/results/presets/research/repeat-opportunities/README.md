# Can recent copy distances bypass the level-one hash lookup?

This diagnostic replays the recorded five-byte parser on every enwik8 block. For each native command it checks recent distances at the first few positions following the preceding match, stopping at the native match start. A hit is counted as a possible replacement only if it reaches at least the original match end. This is a replay of fixed commands, not an alternate encoder or a timing benchmark.

| Distances checked | Positions checked | Minimum length | Commands reached or exceeded | Share of native commands |
|---:|---:|---:|---:|---:|
| 1 | 2 | 4 | 37,104 / 10,557,552 | 0.35% |
| 1 | 8 | 4 | 72,901 / 10,557,552 | 0.69% |
| 3 | 8 | 4 | 162,884 / 10,557,552 | 1.54% |
| 3 | 8 | 8 | 109,932 / 10,557,552 | 1.04% |

Even checking three distances at up to eight positions reached the old match end for fewer than two percent of commands. The pilot cannot price a different downstream parse; it rules out assuming that most of this parser’s hash lookups can be replaced with cheap recent-distance hits. [All 27 counts](counts.csv), [corpus, archive, and source hashes](manifest.json).
