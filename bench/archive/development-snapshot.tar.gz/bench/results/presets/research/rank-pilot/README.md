# Is a byte-context rank stream large enough to replace low-level match search?

This pilot sampled five 1 MiB slices, evenly spaced across each input. For each slice, a previous-byte or bigram model ranks likely next bytes. Up to 4, 8, 16 or 32 popular bytes per context have local ranks; the remaining bytes keep global frequency order. It fits and scores on the same data, charges the specified raw row header, and assumes ideal zero-order entropy coding for the resulting rank stream. There is no actual bitstream and no throughput claim.

| File | Best model across sampled slices | Estimated output / input | Actual full-file zstd level 1 |
|---|---|---:|---:|
| enwik8 | 8,192 bigram buckets, 32 local ranks | 45.03% | 40.67% |
| mozilla | 8,192 bigram buckets, 8 local ranks | 58.37% | 38.98% |

The level-1 comparison is a target, not a same-slice benchmark. These estimates did not justify implementing this particular transform in place of LZ. They are specific to the tested context functions, headers and training window; other representations can have different costs. [All 280 measurements](samples.csv), [means](average.csv), [standalone Rust diagnostic](../../../../diagnostics/rank-pilot.rs).
