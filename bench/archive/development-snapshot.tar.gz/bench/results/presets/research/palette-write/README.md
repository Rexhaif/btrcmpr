# Scalar versus NEON bit packing at level 1

The experimental writer looks up each symbol's bit width and packs 16 successive values using ARM NEON table lookups and shifts. Its [outputs](checks.csv) are byte-identical to the scalar writer on both full inputs, including frame metadata. The decoder is unchanged.

| Input | Archive bytes with either writer | Scalar encode MB/s | NEON encode MB/s |
|---|---:|---:|---:|
| enwik8 | 40,542,760 | 486.38 | 445.11 |
| Mozilla | 19,121,858 | 531.23 | 520.52 |

The scalar writer remains the default. Filling more vector lanes did not make complete encoding faster on this CPU; these runs do not isolate any single instruction as the cause. The [driver](../../../../diagnostics/palette-write.py) verified the files independently and compared both implementations on the same four workers in five warmed trials ([individual trials](trials.csv), [medians](summary.csv), [binary hashes](manifest.json)).
