# Two match cursors in one level-1 block

Splitting a block into two independent cursors lets a worker issue lookups from different regions before choosing either match. The second table can be seeded with sampled positions before the split. The encoder reconciles the first three right-hand distances and the literal run crossing the split; the standard decoder needs no extra header.

The sequential and interleaved versions made byte-identical full archives for each selected split. On this CPU interleaving increased instruction and cycle counts on both inputs.

| Input | Same split and hash policy | Instructions/B | Aggregate CPU cycles/B | Rust / zstd encode MB/s | Rust / zstd decode MB/s |
|---|---|---:|---:|---:|---:|
| [enwik8](enwik8-2.csv) | Sequential | 41.51 | 23.33 | 366.33 / 628.37 | 1570.04 / 1615.61 |
| [enwik8](enwik8-3.csv) | Interleaved | 42.99 | 26.37 | 309.10 / 617.82 | 1598.07 / 1608.96 |
| [mozilla](mozilla-2.csv) | Sequential | 36.22 | 18.50 | 475.34 / 766.68 | 1673.96 / 1639.05 |
| [mozilla](mozilla-3.csv) | Interleaved | 37.35 | 18.97 | 448.21 / 741.58 | 1649.20 / 1604.60 |

The selected enwik8 archive used 40,593,032 bytes versus 40,669,611 for zstd; Mozilla used 19,442,036 vs 19,963,738. Both candidates fit the size target. Neither met the encode requirement. The unsplit control reproduced the native archive hash for both inputs. [All search configurations](screen.csv), [counter runs](counters.csv), [wire identities](wire.csv), [paired comparisons](paired.csv) and [source and comparator identities](manifest.json) are available. Counter runs used eight full encodes; independent wall-time comparisons used five alternating pairs and seven decodes per measurement, with four workers per codec.
