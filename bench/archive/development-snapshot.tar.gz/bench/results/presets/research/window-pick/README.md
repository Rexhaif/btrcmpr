# One match start chosen from two neighboring bytes

The parser compares two nearby bytes and probes only the chosen start. It can extend a match backwards to recover the unprobed byte. A similar choice seeds the recent match tail so identical contents tend to propose the same starts. The decoder and command representation are unchanged. Mode zero is the six-byte production parser.

| Raw trials | Mode / job KiB | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---:|---:|---:|---:|---|
| [enwik8-0](enwik8-0.csv) | 0 / 384 | 40,432,653 / 40,669,611 | 556.37 / 618.77 | 1455.43 / 1560.58 | No |
| [enwik8-1](enwik8-1.csv) | 8 / 384 | 40,559,439 / 40,669,611 | 452.06 / 615.33 | 1591.28 / 1636.93 | No |
| [enwik8-2](enwik8-2.csv) | 2 / 640 | 40,713,619 / 40,669,611 | 470.28 / 652.44 | 1445.32 / 1668.92 | No |

Paired medians use five alternating full-file trials after warmup, four workers on either codec, and seven decodes per trial. Every finalist was separately restored and compared with the original. [PMU counters](counters.csv), [all screens](screen.csv), [archive identities](paired.csv), [manifest](manifest.json).
