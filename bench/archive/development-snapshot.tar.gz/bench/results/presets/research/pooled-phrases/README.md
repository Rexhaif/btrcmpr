# Learning phrases across workers after local training

The best qualifying research preset passed all three level-18 checks on full enwik8 in [five alternating pairs](paired-18/rounds.csv), after warmup with seven decodes per round. Four workers per encoder and decoder, zstd 1.5.7, all original bytes verified:

| Level 18 | Archive bytes | Original / compressed | Encode MB/s | Decode MB/s |
|---|---:|---:|---:|---:|
| Rust shared dictionary, additional pair training | 27,259,136 | 3.668 | 6.506 | 836.604 |
| zstd | 27,555,559 | 3.629 | 3.224 | 634.632 |

The encoder first learns up to 32,768 adjacent phrase pairs independently in each worker. After assigning the same ID to identical spellings across the four jobs, it counts neighboring IDs across the four streams, without allowing phrases to cross a job boundary. Pairs seen at least twice can become new phrases (a 131,072-pair budget in this run). Their definitions travel with the frame. Decoding still rebuilds a dictionary once and uses four independent direct-spelling streams. The [exact comparison settings](paired-18/manifest.json) contain no pretrained dictionary.

| Alternative on full enwik8 | Archive bytes | Encode MB/s | Decode MB/s |
|---|---:|---:|---:|
| 32,768 local + 65,536 pooled, minimum count 3 | 27,560,079 | 7.09 | 924.61 |
| 65,536 local + 65,536 pooled, minimum count 3 | 27,419,891 | 6.77 | 822.95 |
| 32,768 local + 131,072 pooled, minimum count 2 | 27,259,136 | 6.49 | 836.33 |
| 65,536 local + 32,768 pooled, byte copies at 24 bytes | 27,023,902 | 6.51 | 580.94 |

These [screening rates](screen.csv) come from a single full encode and four decodes per variant. Each archive was also reopened and checked on a different worker count. The sparse byte-copy form was smaller but slower to decode. The best unconditioned direct-spelling archive missed the level-19 size limit by 1,600 bytes. The [standalone native level-19 preflight](../../pooled-18-19/preflight.csv) added conditional coding for the group tags and fits by 6,923 bytes. The native level-18 candidate uses the faster 65,536/65,536 training policy; its results are measured separately.
