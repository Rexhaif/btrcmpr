# Level-1 match search and skipping literal positions

The scratch parser derives a hash index and a fingerprint from one multiply or ARM CRC instruction, probes two positions speculatively, and tries different strides after a long series of misses. It can extend a match backwards into skipped literals. On Mozilla the faster setting traded some of the prior size margin for speed; on enwik8 the fastest size-qualified alternatives retained the original 40,542,760-byte archive.

| Best qualifying candidate by paired encode speed | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---:|---:|---:|
| enwik8, mode 1 (5-byte prefix, checks consecutive positions) | 40,542,760 / 40,669,611 | 493.48 / 612.20 | 1,510.58 / 1,564.21 |
| Mozilla, mode 8 (CRC key, stride, 192 KiB jobs) | 19,591,757 / 19,963,738 | 575.91 / 732.29 | 1,543.28 / 1,683.35 |

Neither beat zstd at level 1 on all three measures. The [screen](screen.csv) ran 31 combinations on each full input, and the [paired comparison](paired.csv) ran the two fastest size-qualified combinations per input for five alternating pairs of complete encodes and seven decodes after warmup. Each codec used four workers in both directions. The [driver](../../../../diagnostics/fast-one.py) separately reopened the selected standalone archives on three workers and checked every restored byte. See also the [bit-packing control](../palette-write/README.md).
