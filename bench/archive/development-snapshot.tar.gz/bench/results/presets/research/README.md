# Text parsing experiments

The [wire-identical two-key scanner](pair-head/README.md) passed twice on Mozilla with the 5% decode allowance. Its [ARM counters](pair-head/counters.csv) also measure enwik8, where fewer branch misses did not yet give a wall-time win. The [alternative match-length scanner](wide-length/README.md) is the other native-compilation finalist.

The [Mozilla level-20 window experiment](object-step/README.md) identifies the section that made its archive larger than level 19 and reconstructs a smaller, independently verified frame. The [16-bit signal predictor study](signal-stride/README.md) measures the spacing and the held-out error distribution before counting complete archive bytes.

The [two-cursor match search](match-lanes/README.md) compares sequential and interleaved lookup on identical archives. [Section sizes](object-windows/README.md) and [bank reconstruction](bank-inverse/README.md) show the separate Mozilla encoder and decoder improvements.

The [fixed-archive level-1 probe comparison](prefix-probes/README.md) measures instructions, cycles and L1 cache refills, then checks whether the cheaper lookup improves paired wall time. A separate [prefix and distance-batch comparison](group-key/README.md) reports the fastest smaller archives from that screen against matched zstd. [Updating several candidate positions before choosing the first match](probe-groups/README.md) reduced the enwik8 command count by 23%, but both full-file finalists still compressed more slowly than zstd.

[Sixteen independent bit buffers](stack-palette/README.md) reduced retired instructions on both inputs without reducing elapsed compression time. Its [sample attribution](stack-palette/sample-lines/README.md) locates the record-pricing cost on Mozilla and the branch misses on enwik8. The [byte-pair transform](pair-fold/README.md) measured the tradeoff from reducing the number of bytes reaching match search. The [exact record-price change](record-cost/README.md) cut Mozilla encoder instructions from 30.20 to 25.37 per original byte without changing its archive. [Combining it with a different parser and job sizes](fastest-mix/README.md) put Mozilla level one close to the encode threshold. On enwik8 the [command-writer comparison](command-cost/README.md) favored the original writer with larger blocks and a cheaper palette planner. The [repeat-distance replay](repeat-opportunities/README.md) explains why testing the last copy distance at every match is unlikely to close the remaining gap. Choosing a [single content-dependent start from two bytes](window-pick/README.md) reduced cache refills but increased branch misses and cycles on enwik8. The [new production counters](../../profiles/enwik8-general/native-fastest-1/README.md) measure the remaining gap in both directions. [Sampling the record predictors](record-pick/README.md) saved at most a small number of instructions per input byte and increased the archive size; its best candidate still encoded more slowly than zstd on repeat. [Deferring exact match-length verification](confirm-match/README.md) also reduced retired instructions without closing the throughput gap in its paired comparison. A [single-word palette lookup](word-palette/README.md) preserved every archive byte; its small reduction in cycles on enwik8 did not yield a repeatable encode win. [Combinations of the three changes](joint-one/README.md) also missed on repeat. An independent [15-pair repeat using the actual release](native-stability-1/README.md) crossed the threshold on Mozilla but not on enwik8; it is reported separately from the five-pair release audit.

The [level-1 prefix and entropy comparison](quick-huff/README.md) reports which candidates can meet a modest decode allowance, and compares cached prefixes using identical archives and hardware counters.

[Suffix match and price comparison](tree-prices-4m.csv) uses a 4 MiB slice of enwik8 starting at byte offset 3,145,728 in one independent job on one Cortex-A76 core. Each encoder wrote a complete archive which the regular decoder expanded and compared with the input. Numbers here are **candidate selection only**. They are not comparable to the four-worker, full-input zstd matrix.

The tree retains the nearest previous occurrence of every repeated prefix represented by a suffix interval. The priced version learns its literal, joint length, offset, and excess-byte costs from the preceding 64 KiB of selected matches. This changes only the encoder's decisions, so it uses the existing decoder. It produced 1,259,271 bytes, compared with 1,273,778 for the same tree and fixed prices, and 1,280,371 for the earlier shortest-path parser. Encoder and decoder throughput against zstd on the complete file still have to be demonstrated before selecting a new high preset.

Reproduce:
```sh
dd if=bench/data/enwik8 iflag=skip_bytes,count_bytes skip=3145728 count=4194304 status=none > /tmp/btrcmpr-enwik8-4m
cargo build --release --features research --example candidate
BLOCK_MIB=4 target/release/examples/candidate 1 22 /tmp/btrcmpr-enwik8-4m tree-priced tree optimal
```

The [full four-worker enwik8 screen](high-text-full.csv), using a 16 MiB job ceiling and level 22, reduced the size to 28,565,779 bytes with the hash parser and the learned prices and 28,280,679 with the suffix-interval parser and learned prices. The zstd reference remained smaller at 26,810,527 bytes. These were single research trials with byte verification, not paired confirmations.

The [level-22 match comparison](parse-comparison.csv) removes block size as a variable by comparing parses on exactly the same 4 MiB slice. Our learned-price suffix parser used 12,522 matches of length 3 or 4 and left 263,574 bytes as literals. Zstd used 50,456 such matches and left 122,831 literal bytes. Both copied similar amounts from more than 1 MiB back (513,372 vs 523,432 bytes). This points to short matches and their encoding cost as a more useful target on this sample than increasing the maximum distance. It does not establish how much of the difference in archive size those choices explain.

To reproduce, set `BTR_TRACE` to an existing empty directory when running the sample command above with just `tree-priced`, then run `python3 bench/diagnostics/match-stats.py "$BTR_TRACE/0.raw" "$BTR_TRACE/0.seq"` with the same variable set. This diagnostic queries libzstd's sequence API solely for comparison; its parse is never fed to the Rust encoder.

For middle presets, the [bounded tree search comparison](middling-search-4m.csv) uses the same slice, one worker, level 12 and ordinary entropy settings. At every insertion the search splits an existing tree path around the incoming suffix. Allowing 32 comparisons per position brought the sample down from 1,385,276 bytes (the level-12 hash parser with learned prices) to 1,264,553, but encoding fell from 3.59 to 1.04 MB/s. The lazy variants skip some insertions inside accepted matches; these trade-offs are measured again on the [full enwik8 file with four workers](lazy-tree-full.csv), level 14 and a 6 MiB job ceiling. Neither set of results is a paired win.

[Word dictionaries on the full enwik8 file](text-representations-full.csv) report four-worker candidate trials. The vocabulary was learned from each block; spelling, token ordering, escape data and all other metadata are included. Words with attached spaces and references counted in tokens gave a 28,577,058-byte file at a 16 MiB job ceiling, with 32.44 MB/s encoding and 333.18 MB/s decoding. Referencing byte ranges instead made the decoder faster but increased the size. The raw byte copy path with a vocabulary grouped by spelling length reached 665.86 MB/s at 31,354,321 bytes. A two-stage LZ representation reached about 785 MB/s but compressed less. These single trials include a full decoded-byte check; none establishes a simultaneous win against a matched zstd level.

In 16 repeated decodes of a saved 8 MiB-ceiling archive, [cycle sampling](lex-direct-profile.txt) placed 65.0% of cycles in the direct variant's literal word expansion, 12.7% in the main LZ decoder and 5.3% in long LZ copies. The decoder read the frame once and compared the restored result before and after timing. The ranked variant uses a small table to derive both the spelling length and the number of index bits from the same head, so it can calculate output positions before loading the spellings.

[Fast parsers with wider position fields](fast-histories-full.csv) keep either two hash tables or one table probed at neighboring input positions. A 25-bit block position and a 7-bit fingerprint share one table entry; a fingerprint match is always verified against the source bytes. Large independent jobs then keep matching across the old 2 MiB boundary. The medium parser also indexes positions inside accepted matches. Wider history helps the ratio, while cold reads from distant positions can slow decoding. The full paired results, where available, are in the [preset report](../README.md).

Reproduce a candidate from the repository root with the research build (ratio and throughput depend on the input and job ceiling):

```sh
cargo build --release --features research --example candidate
BLOCK_MIB=16 target/release/examples/candidate 4 12 bench/data/enwik8 lex lex-ranked lex-offsets
BLOCK_MIB=8 target/release/examples/candidate 4 5 bench/data/enwik8 hwin17 hwin18a
```

[Source-prefetch screening](window-source-prefetch.csv) held the archive fixed and ran each mode twice in shuffled order, with a warmup, six full decodes per process and a full output comparison. Mode 0 disables hints; modes 1, 2 and 3 hint all copies, copies at least 256 bytes back, and copies at least 4 KiB back. For the 4 MiB-ceiling `hwin18a` archive, the medians were 932 MB/s without hints and 1,019 MB/s with the 256-byte cutoff. The shipped policy uses that cutoff when the decoded block exceeds 2 MiB; the separate warmed preset matrix measures the complete codec against zstd.

[Level-6 distance and decode experiments](level6-distance/README.md) compare early source hints, staging reads and a parser that can choose a slightly shorter, cheaper, nearer match. They include fixed-archive ablations and alternating full-file comparisons with zstd.

[Offset, literal and instruction-bank experiments](offsets-and-literals/README.md) include the fixed-archive decoder comparisons, a sampled long-prefix index, a residual-literal context coder, and full-file subword dictionaries.

[Short copies, phrase references, and middle text settings](addressed-matches/README.md) compare copy-loop changes on a fixed archive, block-local short phrase tables, and different search and entropy policies.

[Word and phrase references](word-phrases/README.md) reduce the full enwik8 archive to 26,358,849 bytes, below the four-worker zstd level-22 size. The decoder remains slower. This report includes the phrase-count sweep, alternative decoders, ARM cycle samples and mixed word/byte jobs.
## Pooled training and native follow-up

The [pooled phrase comparison](pooled-phrases/README.md) passed five complete four-worker level-18 enwik8 comparisons. It compares additional shared training against sparse byte copies, which reduced bytes but lost decoding speed.


The [tile matcher](tile-match/README.md) indexes many candidate starts in advance. It bought space at a large encode cost. Keeping the native parser and [changing only compiler code generation](release-codegen/README.md) was more effective: the combined build repeated a small level-one Mozilla win with identical archive bytes. On enwik8 this build still encoded more slowly than its matched zstd reference. [Candidate table with ratios](../level-one-candidates.md).


The [shared symbol models](shared-palette/README.md) reduce encoding work without adding a decoder format; their best size- and decode-qualified candidate still missed the encode threshold. The [16-bit aligned history index](aligned-index/README.md) instead added instructions and cycles. The combined compiler build passed Mozilla and x-ray in a [fresh production comparison](../native-profiled-1/README.md), while missing enwik8 encode by 3.69%. [Cycle and branch-miss samples](release-codegen/samples/README.md) identify the remaining parser hotspots.


A [standalone compiler-profiled build of the regional model](native-regional-1/README.md) cut enwik8 cycles from 14.23 to 13.46 per original byte, against 13.22 for zstd. Its first encode was within 0.72% of zstd and the repeat within 3.79%. [Immediate raw storage of likely uniform fields](field-pilot/README.md) separately saved some instructions, without a paired win.
