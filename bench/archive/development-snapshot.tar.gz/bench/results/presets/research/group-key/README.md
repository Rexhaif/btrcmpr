# Level 1: combining faster match keys with batched distances

The enwik8 finalist uses a six-byte prefix, 32K hash slots and 256 KiB jobs. Both versions produced the same 40,505,104 bytes; buffering 32 distances raised Rust encode throughput from 496.34 to 535.55 MB/s. Both remained behind matched zstd level 1. The Mozilla finalists used seven-byte prefixes, 16K slots, and a direct distance writer.

| Input and finalist | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---:|---:|---:|
| [enwik8, 256 KiB, 32-distance batches](enwik8-1.csv) | 40,505,104 / 40,669,611 | 535.55 / 644.48 | 1672.36 / 1599.33 |
| [enwik8, 256 KiB, direct](enwik8-2.csv) | 40,505,104 / 40,669,611 | 496.34 / 650.55 | 1692.44 / 1650.31 |
| [mozilla, 128 KiB, direct](mozilla-1.csv) | 19,961,918 / 19,963,738 | 603.29 / 743.53 | 1660.39 / 1673.60 |
| [mozilla, 256 KiB, direct](mozilla-2.csv) | 19,915,960 / 19,963,738 | 597.29 / 769.12 | 1602.66 / 1605.71 |

All four met the 5% decode allowance and size requirement in their paired measurements. Each missed on encode speed. The [one-round screen](screen.csv) evaluated 36 settings per input; the finalists then ran five alternating pairs with four workers per codec and seven decodes per time measurement. The [manifest](manifest.json) and [paired archive hashes](paired.csv) identify the experiment.
