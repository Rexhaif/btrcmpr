# Writing short level-one commands without a branch for every empty run

Every accepted match has eight readable source bytes at the literal anchor. The writer can copy those bytes even for an empty literal run, while revealing only the actual initialized run in the stream. It can also write both one-byte overflow lengths into reserved space and advance by the number that the command needs. Longer lengths use the original variable-length encoding.

| enwik8 parser | Planner / writer | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---:|---:|---:|---:|---|
| [prefix, 256 KiB](enwik8-0-0.csv) | 0 / 0 | 40,505,104 / 40,669,611 | 533.56 / 624.63 | 1696.01 / 1642.15 | No |
| [prefix, 256 KiB](enwik8-0-3.csv) | 0 / 3 | 40,505,104 / 40,669,611 | 545.68 / 630.50 | 1656.91 / 1584.00 | No |
| [prefix, 384 KiB](enwik8-1-0.csv) | 1 / 0 | 40,432,653 / 40,669,611 | 571.21 / 620.77 | 1606.24 / 1599.85 | No |
| [prefix, 384 KiB](enwik8-1-3.csv) | 1 / 3 | 40,432,653 / 40,669,611 | 569.19 / 621.67 | 1607.77 / 1591.61 | No |

All writers reproduced the original full archive for a given parser and restored it with three workers. Each paired comparison used four workers per codec, five alternating warmed pairs and seven decodes per measurement. [Counters](counters.csv), [screen](screen.csv), [paired rates](paired.csv), [manifest](manifest.json).
