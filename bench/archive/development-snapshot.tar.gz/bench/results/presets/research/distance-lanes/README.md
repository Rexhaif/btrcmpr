# Variable-width copy distances on enwik8

The same parse can store short distances in a selector and distribute the remaining bytes of longer distances across three streams. All encodings preserve the three repeat-distance codes and their small deltas. The decoder can unpack 16 selectors together with NEON. The earlier format used a variable-length integer for the most distant references.

| Original parse | Layout | Archive bytes | Median decode MB/s |
|---|---|---:|---:|
| Level 9, without pages | Original | 31,137,541 | 741.3 |
| Same | Selector boundaries 63, 180, 253 | 31,101,620 | 778.2 |
| Same | Selector boundaries 60, 188, 253 | 31,098,668 | 779.0 |
| Level 6, 5 MiB jobs | Original | 32,646,471 | 934.0 |
| Same | Selector boundaries 84, 212, 253 | 32,651,288 | 937.4 |

Three shuffled fixed-archive trials per retained variant on the full file, four workers, with exact restoration. The level-6 alternative missed the zstd size limit of 32,648,306 bytes. For level 9 both shown alternatives beat the size of matching zstd. The [raw measurements](fixed-archives.csv) omit encoding time: those experiments rewrote already-compressed files. The integrated encoder now recodes the distance selectors before entropy compression. It does not reconstruct the input or make a second match search. End-to-end paired comparisons are needed to establish an encode-speed win. In a separate [anchor experiment](anchor-sizes.csv), all eight ways of predicting another distance for a repeated source increased the archive size.
