# Encoding the spelling dictionary on enwik8

The level-19 text archive spends 2,895,202 bytes describing its dictionary. The four token streams already decode efficiently. Applying the scratch LZ coder to just three dictionary fields (split lengths, shared-prefix lengths, and remaining spelling bytes) removes 446,192 bytes without changing a single token. Trying a context model on the spelling field saves a further 13,856 bytes. Each archive contains the entire dictionary and restores all 100,000,000 original bytes.

| Fixed level-19 parse | Dictionary bytes | Total archive bytes | Four-worker decode, MB/s |
|---|---:|---:|---:|
| Original | 2,895,202 | 27,250,613 | 717.6 |
| LZ on dictionary fields | 2,449,010 | 26,804,421 | — |
| LZ or context model on dictionary fields | 2,435,154 | 26,790,565 | 697.2 |
| Same packed dictionary, plus page-specific token IDs (1,024 tokens/page) | 2,435,154 | 25,809,959 | 518.3 |

For comparison, four independent zstd level-22 frames total **26,810,527 bytes**. The third row beats that size by 19,962 bytes. The first three rows vary dictionary storage only: the [archive hashes](sizes.csv) confirm that the non-dictionary data is byte-identical. Their [timings](decode.csv) are medians of three shuffled, warmed processes with seven decodes each. The [page experiments](page-aliases.csv) instead change the token streams, timing five decodes in one process per setting. A page-specific ID shortens the archive but adds table lookups during expansion. These fixed-archive measurements exclude encoding; only a paired native run can confirm a preset against zstd on all three metrics.

The [driver](../../../../diagnostics/book-study.py) records the executable and source identities in the [manifest](manifest.json), verifies the repacked streams with three decoder workers, and times with four. A separate child-ID delta representation (method bit 2) produced identical output because the encoder kept the cheaper original representation.
