# Fast instruction field representations on Mozilla

The native level-1 archive groups selected integer tables but compresses machine code as ordinary bytes. This experiment recognizes Alpha instructions in the object sections and separates their upper halfwords and immediates. Counts in the archive partition the low halfwords by opcode and optionally two register bits. Switches select separate byte planes, modular deltas, and the scratch LZ or entropy coder for each field. Every candidate was timed on the complete 51,220,480-byte tar archive.

| Candidate | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---:|---:|---:|
| Earlier bank layout with sparse general parser | 19,570,622 / 19,963,738 | 522.58 / 739.95 | 1,437.99 / 1,623.61 |
| New instruction planes, mode 24 | 19,791,671 / 19,963,738 | 506.67 / 708.28 | 1,311.74 / 1,607.30 |

In the [64-case screen](screen.csv), the smallest archive was **18,314,820 bytes** but decoded at only **1,325 MB/s**. Entropy-only coding could encode faster but often produced files exceeding 24 MB. Neither size-qualified finalist passed the [five alternating pairs](paired.csv); this representation remains experimental. Both codecs used four workers in each direction, with warmup and seven decodes per round. The [driver](../../../../diagnostics/fast-isa.py) also checked the two selected archives using a different decoder worker count.
