# A second speculative match probe at level 1

Four Cortex-A76 workers, full inputs, three shuffled trials per variant and input. The [integrity checks](checks.csv) use the standalone encoder and decoder: all variants produced an identical full archive for each file. The [timing trials](trials.csv) then measured each complete encoder with warmup and five decodes.

| Encoder variant | enwik8 encode MB/s | Mozilla encode MB/s |
|---|---:|---:|
| Original single-position search | 437.55 | 522.71 |
| Probe two positions, emit immediately | 479.10 | 527.18 |
| Collect commands then replay, scalar | 382.96 | 457.63 |
| Collect commands then replay, vector | 382.12 | 467.20 |
| Two probes plus vector replay | 412.15 | 484.22 |

The two-position search keeps the first match when it qualifies. Only on failure does it commit the next position; if the two hash indices coincide, the second position sees the first one's entry. The direct writer was faster than collecting commands for a separate pass. Both best encode rates remain below the [matching level-1 zstd reference](../../palette/README.md); the level-1 goal has not been achieved on these two files.

The direct writer is now the production level-1 parser. The [independent CLI check](native-cli.csv) reproduces the old enwik8 and Mozilla archive hashes and restores every byte without linking zstd.
