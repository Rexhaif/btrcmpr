# A small byte-pair dictionary before level-one match search

Each block samples consecutive source bytes, selects one frequent pair per hash slot, and chooses an uncommon range of byte values to hold their codes. The file contains the complete dictionary and an escape stream for literal bytes that would otherwise look like codes. ARM NEON checks overlapping starts in groups of sixteen; a short lookup selects nonoverlapping pairs. The existing LZ encoder compresses the resulting token sequence.

| Input | Parser and job | Dictionary slots (0 = control) | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---|---:|---:|---:|---:|---|
| [enwik8](enwik8-0.csv) | native, 256 KiB | 0 | 40,887,977 / 40,669,611 | 526.77 / 622.02 | 1603.05 / 1597.82 | No |
| [enwik8](enwik8-32.csv) | native, 256 KiB | 32 | 40,534,705 / 40,669,611 | 477.53 / 607.55 | 1280.65 / 1639.22 | No |
| [mozilla](mozilla-0.csv) | native, 128 KiB | 0 | 19,190,549 / 19,963,738 | 556.36 / 743.51 | 1643.98 / 1630.87 | No |
| [mozilla](mozilla-16.csv) | native, 128 KiB | 16 | 19,625,449 / 19,963,738 | 494.94 / 688.09 | 1331.36 / 1645.81 | No |

Both scalar and vector encoders produced the same finalist archive and both inverse paths restored it on three workers. Controls use the same parser, job size and entropy settings as their finalist. Each timing used four workers per codec, five alternating warmed pairs and seven decodes per measurement. [All full-input screens](screen.csv), [actual transformed bytes, tokens and escapes](fields.csv), [PMU counters](counters.csv), [paired rates](paired.csv), [source and library hashes](manifest.json).
