# Short LZ copies on fixed archives

All nine decoder settings read the same six native archives. The alternatives handle 17–48 byte nonoverlapping matches with two or three vector loads; other settings gather short overlapping matches from the last sixteen output bytes and the new literals with an ARM table lookup. One setting lowers a short copy to an eight-byte load and store. These are changes to how the already validated commands execute. No encoding decision or compressed byte changes.

| Input | Level | Best mode | Decode MB/s, control / best | Instructions per output byte, control / best | CPU cycles per output byte, control / best |
|---|---:|---:|---:|---:|---:|
| enwik8 | 6 | 4 | 935.1 / 989.8 | 9.91 / 7.95 | 7.91 / 7.73 |
| mozilla | 6 | 3 | 1369.8 / 1394.3 | 10.30 / 9.38 | 5.98 / 5.88 |
| mozilla | 17 | 2 | 1141.9 / 1166.8 | 7.80 / 6.89 | 6.81 / 6.83 |
| mozilla | 19 | 5 | 1114.2 / 1125.9 | 7.15 / 6.34 | 7.28 / 7.28 |
| enwik8 | 1 | 5 | 1612.9 / 1646.0 | 8.51 / 6.73 | 5.33 / 5.18 |
| mozilla | 1 | 1 | 1685.6 / 1751.7 | 5.52 / 4.62 | 4.72 / 4.65 |

The speed columns are medians of three shuffled processes per setting, each running six warmed decodes on four workers. Separate perf-stat runs counted sixteen decodes, enabling counters after a verified warmup and disabling them before the final full byte comparison. The fastest setting is selected on this screen, so small leads are provisional. [Individual speeds](trials.csv), [PMU counts](counters.csv), [binary and archive hashes](manifest.json).

Candidates improving fixed-archive decode by more than 1.5% at levels above 1 were then tested against zstd in five warmed alternating pairs. [Absolute rates and sizes](paired.csv).

| Level | Input | Mode | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Passed all three |
|---:|---|---:|---:|---:|---:|:---:|
| 6 | enwik8 | 4 | 32,646,471 / 32,648,306 | 32.417 / 29.885 | 993.111 / 1001.786 | No |
| 6 | mozilla | 3 | 17,207,799 / 17,235,392 | 69.579 / 46.995 | 1361.85 / 1389.999 | No |
| 17 | mozilla | 2 | 15,742,461 / 15,770,886 | 25.707 / 8.408 | 1135.989 / 1140.33 | No |
