# Trading match length for cheaper copy sources at level 6

All results here are for full enwik8 on four Cortex-A76 workers. The research parser uses the standard LZ representation. At the current and next positions, it charges a match for its distance as well as rewarding it for its length. For example, a remote match that saves one literal can lose to a nearer match if the remote distance takes more bytes. Repeated distances are cheap. Matches shorter than the format's four-byte minimum are excluded before scoring.

In the original 32,557,340-byte experimental frame, [perf](decode-cycles.txt) attributed 87% of sampled user cycles to the main LZ reconstruction function. [A fixed-archive test](source-hints.csv) found 625.8 MB/s with source hints disabled and 699.4 MB/s with hints for copies at least 256 bytes back (medians of three processes, six timed decodes each, after warmup, with byte verification). In a second executable, [changing batch size and when to start the reads](copy-batches.csv) produced 819.3 MB/s with 32 commands and an early hint after each 16 prepared commands, versus 750.2 MB/s for 64 commands and late hints in that same executable. These are within-executable comparisons. Mode bit 1 hints early; bit 2 first loads already-produced source bytes into scratch; bit 4 limits that extra load to short copies. The scratch pass did not beat early hints alone.

The paired candidates start prefetching distant sources after their positions have been checked; they also hint the second cache line if a 16-byte load spans a boundary. The parser with a 19-bit long table and 12 MiB block ceiling (b) and the parser with a 20-bit long table and 8 MiB ceiling (c) each beat zstd level 6 on archive size. The full [b](matched-b-12288.csv), [c](matched-c-8192.csv) and [c2](matched-c2-6144.csv) screening runs alternated both codecs for two pairs after warmup, with five decodes and byte verification per round. Two pairs cannot settle a near tie.

The [experimental patch](../../../../diagnostics/level6-distance.patch) applies to the pre-experiment source. To reproduce in a disposable copy, use the repository root of that copy and the original full input:

```sh
git apply bench/diagnostics/level6-distance.patch
cargo build --release --features baseline --bin compare
L6_PARSER=c L6_KIB=8192 ZSTD_LEVEL=6 BTR_LEVEL=6 ZSTD_WIDE=1 DEC_ITERS=7 \
  TRIALS_CSV=/tmp/btrcmpr-level6.csv target/release/compare 4 5 both bench/data/enwik8
```

Parser b uses a 19-bit long table and c a 20-bit long table. Both insert every third position inside a long match in addition to indexing the match boundaries. c2 and c1 use the same 20-bit table as c but insert every second position or every position, respectively. The experiment introduces no new wire format.

In [five warmed pairs for parser b](five-b-12288.csv), the file was 2,200 bytes smaller and compression reached 32.63 versus 30.61 MB/s, but decoding reached 947.95 versus 982.83 MB/s. It fails the simultaneous gate.

The denser [c1 parser at a 6 MiB ceiling](five-c1-6144.csv) saved 20,170 bytes against zstd, but lost both speeds in five warmed pairs: 29.24 vs 30.74 MB/s encoding and 949.76 vs 996.44 MB/s decoding. Neither five-pair candidate was promoted. In the wider representation, a remaining scalar pass visits offset selectors to expand very distant matches; a way to isolate its cost would be to replace just that pass on the same archive.
