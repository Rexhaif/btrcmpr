# Testing several match starts at once

The encoder reads two to four existing hash slots, then updates every slot before choosing the first valid copy. Even a four-byte copy consumes every speculative start. This keeps consecutive hash lookups independent. Sparse versions check every second or third position; a backwards extension can recover skipped literals. All variants use the existing decoder.

| File | Mode (0 = native control) | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---:|---:|---:|---:|---|
| [enwik8](enwik8-0.csv) | 0 | 40,542,760 / 40,669,611 | 483.08 / 565.26 | 1591.07 / 1589.88 | No |
| [enwik8](enwik8-2.csv) | 2 | 40,187,894 / 40,669,611 | 499.81 / 641.25 | 1688.77 / 1664.76 | No |
| [mozilla](mozilla-0.csv) | 0 | 19,121,858 / 19,963,738 | 546.65 / 763.47 | 1650.51 / 1640.20 | No |
| [mozilla](mozilla-8.csv) | 8 | 19,897,676 / 19,963,738 | 593.96 / 766.62 | 1646.57 / 1649.22 | No |

Each finalist and native control used four workers per codec and five alternating pairs after warmup with seven decodes per measurement. The exact compressed archive was also reopened and restored on three workers. Each full input was screened for size and decode throughput before ranking by encode speed. [All cases](screen.csv), [paired medians](paired.csv), [eight-encode ARM hardware counters](counters.csv), [build and data identities](manifest.json), [driver](../../../../diagnostics/probe-groups.py). The accompanying file and mode field directories account for the bytes occupied by commands, distances, and literals.

On enwik8, the [new parse](enwik8-2-fields/wire.csv) cut the command count from 10,557,552 to 8,092,321 (23.35% fewer), while emitting 26,278,893 literal bytes instead of 18,214,874. This saved 354,866 archive bytes against the [native control](enwik8-0-fields/wire.csv), but aggregate cycles/input byte were 17.60 versus 17.45. On Mozilla the measured refills fell from 0.275 to 0.125 per input byte and cycles fell from 16.15 to 14.67. Neither finalist reached matched zstd encoding speed.
