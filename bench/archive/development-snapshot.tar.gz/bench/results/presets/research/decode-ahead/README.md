# Preparing future LZ copies

Positions, lengths and source bounds can be computed before writing output. The experimental decoder therefore tries preparing up to two extra batches, hinting their source addresses while a previous batch is still waiting to execute. Actual copies still execute in the original order. The archive bytes never change.

| Native archive | Current schedule MB/s | Best tested MB/s | Best policy |
|---|---:|---:|---:|
| enwik8 6 | 994.2 | 994.2 | Current |
| Mozilla 6 | 1,409.9 | 1,409.9 | Current |
| Mozilla 17 | 1,145.2 | 1,145.2 | Current |
| Mozilla 19 | 1,062.5 | 1,071.4 | Two additional batches, 32 commands |
| enwik8 1 | 1,611.3 | 1,611.3 | Current |
| Mozilla 1 | 1,740.0 | 1,740.0 | Current |

The [screen](screen.csv) compares 13 policies in three shuffled rounds, six timed decodes per process after warmup, four workers, with byte checks before and after measurement. The [archive identities](checks.csv) match the native sizes; the [234 individual trials](trials.csv) all used the same decoder binary. The 0.84% gain on Mozilla 19 was below the threshold for promotion. These within-codec fixed-archive results do not establish any fresh win against zstd.
