# Sixteen independent bit buffers for palette ranks

The match parser and alphabet planner are unchanged within each pair. The encoder visits groups backwards and packs the residual bits in sixteen independent stacks. A lane sends one byte when its next rank would overflow a 16-bit state. The decoder visits groups forwards and infers which lanes need a byte from their state. No per-group refill mask is stored. ARM NEON updates eight states per vector and compacts or expands selected bytes with a table lookup.

| Input | Parser and job | Packing | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---|---|---:|---:|---:|---|
| [enwik8](enwik8-0.csv) | group, 256 KiB | Native packing | 40,187,894 / 40,669,611 | 486.88 / 630.69 | 1689.32 / 1624.12 | No |
| [enwik8](enwik8-2.csv) | group, 256 KiB | 16 stacks | 40,211,562 / 40,669,611 | 480.06 / 606.31 | 1656.78 / 1623.17 | No |
| [mozilla](mozilla-0.csv) | native, 128 KiB | Native packing | 19,190,549 / 19,963,738 | 564.57 / 743.26 | 1673.42 / 1640.14 | No |
| [mozilla](mozilla-2.csv) | native, 128 KiB | 16 stacks | 19,203,099 / 19,963,738 | 558.23 / 747.62 | 1659.82 / 1683.77 | No |

Each finalist used five alternating full-input pairs with four workers and seven decodes per measurement, after warmup. The scalar and NEON writers reproduced the same complete new-format archive; independent scalar and NEON reads on three workers restored every byte. These are research binaries. [Screen](screen.csv), [paired medians](paired.csv), [eight-encode PMU counts](counters.csv), [Mozilla instruction samples](mozilla-encode-samples.txt), [manifest](manifest.json).

The reduction in instructions did not reduce complete encode time. [Source attribution for retired instructions and branch misses](sample-lines/README.md) identifies the record-width planner on Mozilla and the match loop on enwik8.
