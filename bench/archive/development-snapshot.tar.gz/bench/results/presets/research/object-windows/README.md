# Section sizes and instruction banks on Mozilla

Five warmed alternating pairs on the entire Mozilla tar file at each numeric zstd level, with four workers per codec and seven decodes per time measurement. Plain, record, and instruction sections can have different job sizes. The candidates use the same bank cost rule, which enables the delta representation only if it clears a savings threshold.

| Level | Job sizes in KiB: plain / records / code | Bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Decode vs zstd | Pass at 5% |
|---:|---|---:|---:|---:|---:|---|
| [6](level-6-mozilla.csv) | 112 / 112 / 112 | 17,230,867 / 17,235,392 | 68.72 / 46.41 | 1,242.85 / 1,362.41 | -8.78% | No |
| [17](level-17-mozilla.csv) | 512 / 128 / 352 | 15,709,147 / 15,770,886 | 27.91 / 8.15 | 1,381.90 / 1,065.44 | +29.70% | Yes |
| [19](level-19-mozilla.csv) | 656 / 320 / 656 | 15,212,723 / 15,241,773 | 22.31 / 6.14 | 1,136.99 / 1,098.33 | +3.52% | Yes |
| [21](level-21-mozilla.csv) | 528 / 1408 / 704 | 15,168,330 / 15,231,524 | 21.52 / 5.72 | 1,101.29 / 1,082.06 | +1.78% | Yes |

The level-17 result saved 33,314 bytes relative to the previous native archive as well as improving decode speed. The level-19 and level-21 variants traded extra archive bytes for faster decode. The level-6 candidate used 17,230,867 bytes and looked fast in a [fixed-archive decode](fixed.csv), but it missed the allowance in the matched full comparison. [Every one-run candidate](screen.csv) and [executable identities](manifest.json) are retained. Research results are excluded from the production ledger.
