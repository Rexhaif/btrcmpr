# Can a cheaper match check speed up level 1?

On the four Cortex-A76 cores, removing a redundant length test reduced retired instructions without speeding up the five-pair benchmark. The enwik8 encoder with 32 distances per batch fell from 32.60 to 31.66 instructions per input byte; median throughput went from 506.68 to 497.41 MB/s. On Mozilla it went from 544.80 to 544.35 MB/s. All settings produced the exact same production archive for each file and independently restored it. The new check remains experimental.

| Input, 32 distances per batch | Instructions/input byte | CPU cycles/input byte | L1 data refills/input byte | Encode MB/s, Rust / zstd |
|---|---:|---:|---:|---:|
| enwik8, original check | 32.60 | 16.93 | 0.431 | 506.68 / 633.82 |
| enwik8, shorter check with fingerprint | 31.66 | 16.42 | 0.426 | 497.41 / 622.59 |
| enwik8, shorter check without fingerprint | 31.45 | 18.05 | 0.590 | — |
| Mozilla, original check | 30.40 | 15.73 | 0.281 | 544.80 / 744.27 |
| Mozilla, shorter check with fingerprint | 29.66 | 15.52 | 0.281 | 544.35 / 756.39 |
| Mozilla, shorter check without fingerprint | 29.55 | 16.78 | 0.470 | — |

The hash uses five bytes. If two prefixes have the same first four bytes and land in the same bucket, their fifth bytes agree: changing only the fifth byte changes the top byte of the multiplicative hash. The encoder can therefore rule out a four-byte match in a populated bucket after verifying the first four bytes. Empty buckets need a separate check to preserve the existing parser's behavior at source position zero.

Removing the fingerprint as well saved a few more instructions but increased cache refills and cycles. With no fingerprint the encoder loads source bytes before it knows whether the candidate is plausible. The isolated [PMU runs](counters.csv) counted eight full encodes per setting. The [paired times](paired.csv) came from separate runs: four workers per codec, five alternating pairs after warmup and seven decodes per measurement. Only the best new setting by measured cycles and its matched control advanced to paired timing. [Driver](../../../../diagnostics/fast-probes.py) and [source, library and binary hashes](manifest.json).
