# Level-one Mozilla combinations

Every configuration uses the exact record-width optimizer. The columns in the configuration are key, generic archive job KiB, histogram policy, distance batch, record job KiB and palette planner. Key 10 uses a seven-byte key; key 8 uses the two-position stride parser. Histogram policies were varied independently of the palette planner.

| Raw samples | Configuration | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd | Pass at 5% |
|---|---|---:|---:|---:|---|
| [mozilla-0](mozilla-0.csv) | 10, 128, 1, 0, 128, 0 | 19,961,918 / 19,963,738 | 719.30 / 718.25 | 1624.46 / 1528.94 | Yes |
| [mozilla-1](mozilla-1.csv) | 10, 192, 0, 2, 64, 0 | 19,934,416 / 19,963,738 | 760.47 / 762.36 | 1647.95 / 1655.47 | No |
| [mozilla-2](mozilla-2.csv) | 10, 192, 2, 2, 256, 0 | 19,929,005 / 19,963,738 | 672.61 / 751.43 | 1634.22 / 1615.32 | No |
| [mozilla-3](mozilla-3.csv) | 10, 192, 2, 2, 128, 0 | 19,931,861 / 19,963,738 | 761.55 / 749.36 | 1609.33 / 1636.12 | Yes |
| [mozilla-repeat](mozilla-repeat.csv) | 10, 192, 2, 2, 128, 0 | 19,931,861 / 19,963,738 | 757.98 / 765.06 | 1618.05 / 1657.30 | No |

Five alternating pairs per result, four workers on each side, seven decodes per measurement. The final pair independently repeats the strongest measured configuration. Every finalist was restored with three workers. [All screens](screen.csv), [archive hashes](paired.csv), [manifest](manifest.json).
