# Level 1: how much work does a cached match prefix save?

Caching more bytes of an earlier match in the lookup table made the Cortex-A76 encoder slower. The [wire checks](wire-checks.csv) show that the identity controls made exactly the same complete archives as production. For a five-byte lookup on enwik8 the native table used **17.24 aggregate CPU cycles/input byte**. Caching four bytes raised that to **31.15**; caching five or eight took **22.13** and **21.87**. Mozilla showed the same ordering. The [perf counters](cache-counters.csv) cover ten full-file encodes per setting, excluding setup and verification. These controls establish the runtime effect; they do not isolate a particular cache level as its cause.

Changing the hash prefix, table width and indexing inside a match can instead change which matches are selected. A separate screen also tried a Huffman writer that packs four codes together. The [paired finalists](paired.csv) both retained the original entropy coder:

| Full input | Selected change | Bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---|---:|---:|---:|
| enwik8 | Six-byte prefix, 32K slots, index two positions at the end of a match | 40,505,104 / 40,669,611 | 489.13 / 622.54 | 1,683.99 / 1,615.67 |
| Mozilla | Seven-byte prefix, 16K slots, index one position at the end of a match | 19,961,918 / 19,963,738 | 608.55 / 758.89 | 1,639.10 / 1,656.74 |

Both fit a 5% decode throughput allowance. Compression still trails zstd by **21.4%** and **19.8%** respectively, so neither changes the production preset. Four workers per codec, five alternating full-input pairs after warmup, seven decodes per measurement; [all enwik8 pairs](enwik8.csv), [all Mozilla pairs](mozilla.csv), [candidate screen](screen.csv), [driver](../../../../diagnostics/quick-huff.py).
