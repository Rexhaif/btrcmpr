# Word and phrase references on the full enwik8

The 4,096-phrase encoder produced **26,358,849 bytes** on the full 100,000,000-byte input. The four-frame zstd 1.5.7 level-22 archive is **26,810,527 bytes**. This is a research codec; it has beaten that archive size, but has not beaten the matched decoder. All four workers learn exclusively from their own input, and the transmitted vocabularies and framing are included. No prebuilt word list is used.

| Full-file Rust candidate (four workers) | Archive bytes | Encode MB/s | Decode MB/s |
|---|---:|---:|---:|
| Word references, no phrase merges | 26,902,707 | 26.86 | 391.71 |
| 4,096 merged phrases, references in tokens | 26,358,849 | 17.90 | 461.36 |
| 4,096 merged phrases, references in bytes | 28,842,667 | 17.91 | 450.38 |
| 16,384 merged phrases, literals only | 29,501,982 | 20.55 | 585.86 |
| Two phrase jobs (37% of input); two byte jobs at preset 8 | 29,488,716 | 20.76 | 624.21 |

The first four rows are single-process screens from [the vocabulary sweep](grammar.csv); the last row is from [the mixed-worker sweep](mixed.csv), with six decodes per process. The [paired level-22 results](paired-22/summary.csv) give the 4,096-phrase encoder **18.75 vs 2.51 MB/s encode**, but only **472.02 vs 653.15 MB/s decode**: 7.45× and 0.723× the reference throughput. There were [three alternating paired trials](paired-22/rounds.csv), seven decodes per round, following warmup, on a [frozen benchmark binary](paired-22/manifest.json). Do not count this as a production preset pass.

The phrase encoder starts with runs of letters, digits or punctuation, attaching a trailing space to a word when possible. It counts adjacent tokens and replaces frequent pairs with single tokens. On that smaller sequence a cost-based parser chooses literals or backward references, in units of tokens. The archive only needs to spell tokens actually emitted as literals. For those, it groups by approximate frequency, sorts spellings within a group, and sends the unchanged prefix length plus the new suffix. Each literal then needs only a rank. On decoding, references restore a sequence of spelling descriptors; expanding them restores the exact original bytes.

[Cycle samples](grammar-0-cycles.txt) put 33.13% in spelling expansion, 24.87% in restoring token references, 19.64% in unpacking the vocabulary and literal ranks, and 12.19% in integer unpacking. Testing a successor model [reduced literal-only size](successor.csv) but worsened the full matched archive to 26,365,321 bytes. [Fixed-archive comparisons](wordcopy.csv) tested restoring lengths first and copying output bytes directly: the fastest new version decoded at a median of 314.6 MB/s versus 428.6 for the original. [Fixed-width spelling records](slots.csv) did not improve the median either: 434.7 MB/s with 16-byte records and prefetch versus 438.7 for the original. Each such trial reopens the same archive, checks against the raw bytes, and uses four workers.

The [conditioned byte-parser controls](conditional-verified.csv) are separate, full-file single trials of the byte-oriented encoder. The leading size candidate there reached 30,002,440 bytes but decoded at only 629.40 MB/s. These rows used the indicated entropy settings with tuning enabled.

The [spelling-pipeline experiment](spelling-pipeline.csv) tested six decoders in seeded shuffled order on the same 26,358,849-byte archive. For each policy there were three processes with five timed decodes, and exact warmup and post-timing byte checks. Issuing four independent spelling loads before writing their bytes, with earlier prefetch and vector output positions (pipeline 2), reached a median **449.9 vs 434.7 MB/s**. Vectorizing only the unpack of numeric fields instead reached **420.6 MB/s**. These are fixed-archive comparisons from the same executable, separate from the paired zstd timings.

[Per-job decode timings](balance.csv) show why input share matters for mixed archives. With one phrase job and three preset-10 byte jobs, the 17 MB phrase job took a median 118 ms and the slowest byte job took 149 ms. Increasing the phrase share to 20 MB brought those times to 139 and 148 ms, reduced the archive by 133,870 bytes, and increased total throughput from 625.24 to 660.50 MB/s in the screen. Splitting the byte work further gave 730.23 MB/s but added 588,568 bytes relative to the unsplit 20 MB case. All three runs used four threads.

[Splitting only some byte jobs](intermediate.csv) gave promising screening rates but failed three warmed comparisons. At [level 15](paired-mix-15/summary.csv), two phrase jobs and a 39% phrase share gave **29,486,428 vs 29,594,686 bytes**, **19.64 vs 4.87 MB/s** encode, and **628.72 vs 641.54 MB/s** decode. At [level 14](paired-mix-14/summary.csv), one phrase job and a 21% share gave **29,889,669 vs 29,917,280 bytes**, **12.21 vs 6.09 MB/s** encode, and **676.83 vs 677.50 MB/s** decode. At [level 13](paired-mix-13/summary.csv), the mixture decoded at **681.43 vs 694.69 MB/s** and missed too. All three comparisons used five alternating pairs; a sub-percent miss still fails.

**A dictionary of shorter phrases.** Rather than copy a previously emitted string of tokens, mode 48 stores a phrase as two references to shorter dictionary entries. It sends characters for the original words, and only retains entries reachable from the final token sequence. Entries are arranged by spelling length, so the decoder can expand the whole dictionary in increasing length. A small head then specifies a spelling width and an index range. The index bits directly address the spelling; the decoder need not follow word-level backreferences as each piece of text is produced. All dictionary, grouping, coding and frame bytes are included.

| Phrase cap / maximum bytes | Full enwik8 archive bytes | Encode MB/s | Decode MB/s |
|---|---:|---:|---:|
| 16,384 / 48 | 29,841,962 | 19.45 | 752.64 |
| 65,536 / 64 | 28,999,169 | 14.57 | 782.55 |
| 131,072 / 64 | 28,887,458 | 8.34 | 663.87 |
| 262,144 / 64 (admit pairs seen twice) | 29,345,325 | 7.19 | 577.71 |

The production encoder selects caps of 16,384 / 48 bytes, 32,768 / 64 bytes and 65,536 / 64 bytes for substantial text blocks at levels 13, 14 and 15. It learns every dictionary anew. The [warmed paired comparisons on one executable](../../phrase-levels-13-15/README.md) confirm both the size and the speed gains over the matching zstd levels on all three full inputs.

These are [four-worker screens](dag.csv), including one full compression and four full decodes with byte validation. A larger phrase dictionary eventually costs more than it saves. The [earlier spelling-width grouping](phrase-layout.csv) directly stored each complete phrase spelling. At the 4,096-phrase cap it reduced decode time but increased the 26,358,849-byte matched archive to 26,982,573 bytes.

[Component counts](dag-components.csv) reconcile to every byte of each [matched or independent phrase archive](dag-matched.csv). Rechoosing word boundaries twice reduced a 65,536-phrase archive from 28,999,169 to 28,798,982 bytes ([full-input screens](dag-reparse.csv)), still larger than level-16 zstd. The faster [mixed worker candidate](dag-mixtures.csv), with one grammar worker responsible for 22% of the input and three dictionary workers sharing the remainder, reached **28,416,995 vs 28,577,583 bytes** and **15.512 vs 5.076 MB/s encode**, but only **692.586 vs 757.199 MB/s decode** in [five paired level-16 trials](paired-candidate-16/summary.csv).

[Sharing exact phrase spellings between workers](../phrase-pilot/screen.csv) produced 28,307,584 bytes with two dictionaries and 27,763,104 bytes with one on full enwik8 (four workers in both cases). Each worker trains its phrases locally. The encoder combines identical spellings, serializes one dictionary per group and sends each worker's token stream separately; the decoder expands each shared dictionary inside the timed operation. The [five-pair production runs at levels 16 and 17](../../shared-16-17/README.md) confirmed these sizes and both speed wins on enwik8.

To reproduce the phrase and mixed comparisons from the repository root:

```sh
cargo build --offline --locked --release --features baseline,research --bin compare --example candidate --example decode_loop
python3 bench/diagnostics/phrase-screen.py --out bench/local/phrases.csv
python3 bench/diagnostics/dag-screen.py --out bench/local/phrase-dag.csv
python3 bench/diagnostics/mixed-screen.py --out bench/local/mixed.csv
python3 bench/diagnostics/grammar-pairs.py --level 22 --rounds 3 --out bench/local/paired-phrases
```
