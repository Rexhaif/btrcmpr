# Word-aligned code and short-run text dictionaries

On Mozilla the encoder matches whole four-byte instructions, stores copy lengths in words, and transmits the unmatched words in byte planes. On enwik8 it finds short word and punctuation runs in sixteen-byte groups, assigns frequent runs a short rank and transmits their spellings and literal escapes. Both formats are lossless, learned solely from the input and decoded by the Rust implementation.

| File | Original bytes using the new format | Archive bytes, Rust / zstd | Encode MB/s, Rust / zstd | Decode MB/s, Rust / zstd |
|---|---:|---:|---:|---:|
| enwik8 | 100,000,000 | 40,082,775 / 40,669,611 | 162.89 / 630.93 | 1,016.71 / 1,612.19 |
| mozilla | 24,230,128 | 19,431,649 / 19,963,738 | 557.90 / 735.79 | 1,468.91 / 1,584.84 |

The [screen](screen.csv) contains 174 full-input observations, including the native controls. The finalists both beat the matched zstd level-1 size but lost on both speeds in [five warmed alternating pairs](paired.csv); they remain experimental. Both codecs used four workers in both directions with seven decodes per paired round. The [standalone frame checks](checks.csv) reproduced native control hashes and restored each finalist on three workers. The [manifest](manifest.json) identifies the binaries, source snapshot and corpus.
