# Absolute match distances in byte planes

The parser keeps its match choices; each match transmits one low, one middle and one high distance byte in separate columns. The encoder can use zero for a repeat and condition one column on the length tag. On ARM, the inverse can unpack sixteen distances without first consulting any width selectors. The [95 full-file cases](screen.csv) varied the job size and entropy model.

| Level-1 finalist | Archive bytes, Rust / zstd | Compress MB/s, Rust / zstd | Decompress MB/s, Rust / zstd |
|---|---:|---:|---:|
| enwik8 | 40,634,162 / 40,669,611 | 500.44 / 623.82 | 1,311.32 / 1,581.14 |
| Mozilla | 19,940,535 / 19,963,738 | 555.80 / 761.58 | 1,463.83 / 1,617.74 |

Both finalists restored all bytes on three workers; neither beat zstd on speed in the [five warmed four-worker pairs](paired.csv). At level 6 on enwik8 the smallest new archive was 32,663,159 bytes, already larger than zstd's 32,648,306, so no paired win was possible. Changing the distance layout alone failed on these inputs. The [level-1](1-enwik8-wire/wire.csv) and [level-6](6-enwik8-wire/wire.csv) wire accounts show what each distance column cost.
