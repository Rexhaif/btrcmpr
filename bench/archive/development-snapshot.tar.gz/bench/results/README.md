# Cortex-A76 measurements, 2026-11-21

Raspberry Pi 5 Model B Rev 1.1, four Cortex-A76 cores, 2.4 GHz maximum, ondemand governor. Linux aarch64 6.18.39+rpt-rpi-v8, Rust 1.95.0 / LLVM 22.1.2, system libzstd 1.5.7. Neither codec was given a training corpus. The encoder contains format-specific knowledge about 16-bit signals and Alpha COFF object archives. The default codec used four workers and the same automatic policy on every input.

The confirmation run used one warmup per codec per file, followed by thirteen alternating-order measured rounds. Each round had one encode and four decodes, then a full-output equality check. For each speed below, the denominator is the median time of the thirteen rounds, using uncompressed decimal MB. Files were already resident; timed work includes threads, codec allocations, content classification and restoration into the final contiguous byte buffer, but not outer-file I/O or serialization. The reference compressed and decompressed independent zstd level-3 frames on four worker threads using reusable contexts.

| Input | btrcmpr bytes | zstd bytes | Compress MB/s (ours / zstd) | Decompress MB/s (ours / zstd) | Paired decode wins |
|---|---:|---:|---:|---:|---:|
| enwik8 | 35,103,083 | 35,727,119 | 90.63 / 74.81 | 1,170.22 / 1,069.60 | 13/13 |
| x-ray | 5,842,461 | 6,118,146 | 949.84 / 45.46 | 1,533.09 / 1,069.18 | 13/13 |
| mozilla | 18,262,748 | 18,496,096 | 122.63 / 89.41 | 1,676.76 / 1,612.97 | 11/13 |

The [raw samples](confirmation-trials.csv) and [summary](confirmation-summary.csv) are from the same execution. The [previous nine-round run](paired-9-trials.csv), starting with mozilla, passed the same nine comparisons. Timings vary; the smallest median speed advantage here is 4.0% on mozilla decompression. The larger compression ratio improvement on x-ray is explained by the signal predictor; object-section grouping and integer record coding are specific advantages on mozilla.

A separate size and serialization check compressed the original inputs with the production CLI and with two installed zstd programs. These are actual file lengths without adding the benchmark index to standard zstd files. All btrcmpr files were independently read back through the production CLI and compared with the originals using `cmp`. The standard `zstd` files passed `zstd -t` and the `pzstd` files were also decoded with four threads and compared with the originals.

| Input | btrcmpr | zstd -T4 -3 | pzstd -p 4 -3 |
|---|---:|---:|---:|
| enwik8 | 35,103,083 | 35,445,335 | 35,612,396 |
| x-ray | 5,842,461 | 6,086,002 | 6,087,678 |
| mozilla | 18,262,748 | 18,281,292 | 18,420,084 |

To verify the published timing comparison from the individual trials:

```sh
scripts/check-results.py bench/results/confirmation-trials.csv
```

[Hardware counter captures](profiles/) cover thirty decodes per codec and input, excluding setup through perf control FIFOs. The [cycle sample report](profiles/mozilla-hotspots.txt) identified LZ reconstruction as the largest remaining cost on mozilla (45% of samples in the main LZ decode function). These profile timings are separate from the paired benchmark. [Earlier candidates](candidates.md) show why a better compression ratio alone was insufficient.

The [enwik8 instruction and cycle breakdown](profiles/enwik8-general/README.md) separates compression from decompression and tests individual optimizations with the same input and compressed representation.
