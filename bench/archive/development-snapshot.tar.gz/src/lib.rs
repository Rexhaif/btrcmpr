//! Self-contained frames; parallel jobs can share a transmitted phrase dictionary.
#[cfg(feature = "research")]
mod alias;
#[cfg(feature = "research")]
mod aligned;
mod ans;
#[cfg(feature = "research")]
mod buckets;
#[cfg(feature = "research")]
mod cascade;
mod context;
#[cfg(feature = "research")]
mod fastisa;
mod grammar;
mod mixed;
#[cfg(feature = "research")]
pub use mixed::encode as research_mix;
mod huff;
mod layout;
#[cfg(feature = "research")]
mod lex;
#[cfg(feature = "research")]
mod lexpairs;
mod lexrank;
#[cfg(feature = "research")]
mod lines;
mod lz;
mod object;
#[cfg(feature = "research")]
mod pairfold;
mod palette;
#[cfg(feature = "research")]
mod patch;
#[cfg(feature = "research")]
mod phrases;
mod pixel;
mod prefixtree;
#[cfg(feature = "research")]
mod prices;
mod record;
#[cfg(feature = "research")]
mod runbook;
mod signalgrid;
mod sorted;
#[cfg(feature = "research")]
mod sparse;
mod weight;
mod wordbase;
#[cfg(feature = "research")]
pub use weight::trial as research_weight;
mod words;
use std::{
    io::{Error, ErrorKind},
    sync::Mutex,
};
pub type Result<T> = std::io::Result<T>;
pub(crate) fn bad() -> Error {
    Error::new(ErrorKind::InvalidData, "invalid compressed block")
}
pub(crate) fn take<'a>(p: &mut &'a [u8], n: usize) -> Result<&'a [u8]> {
    let (a, b) = p.split_at_checked(n).ok_or_else(bad)?;
    *p = b;
    Ok(a)
}
pub(crate) fn u32in(p: &mut &[u8]) -> Result<usize> {
    Ok(u32::from_le_bytes(take(p, 4)?.try_into().unwrap()) as usize)
}
pub const MAX_BLOCK: usize = 2 << 20;
pub const MAX_WIDE_BLOCK: usize = 32 << 20;
#[inline]
pub(crate) fn tuning(name: &str, default: usize, min: usize, max: usize) -> usize {
    #[cfg(feature = "research")]
    {
        std::env::var(name)
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(default)
            .clamp(min, max)
    }
    #[cfg(not(feature = "research"))]
    {
        let _ = (name, min, max);
        default
    }
}
pub const MAGIC: &[u8; 8] = b"BTRCMP01";
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Preset(u8);
impl Preset {
    pub fn new(level: u8) -> Result<Self> {
        if (1..=22).contains(&level) {
            Ok(Self(level))
        } else {
            Err(Error::new(
                ErrorKind::InvalidInput,
                "compression level must be 1..=22",
            ))
        }
    }
    pub fn level(self) -> u8 {
        self.0
    }
}
impl Default for Preset {
    fn default() -> Self {
        Self(3)
    }
}
pub fn block_size(size: usize, threads: usize) -> usize {
    if size == 0 {
        return 1;
    }
    // Equal waves avoid leaving three cores idle for the final fraction of an image.
    let blocks = size
        .div_ceil(MAX_BLOCK)
        .next_multiple_of(threads.clamp(1, 256));
    size.div_ceil(blocks).next_multiple_of(64).min(MAX_BLOCK)
}
fn parallel<I: Iterator + Send>(
    threads: usize,
    it: I,
    f: impl Fn(I::Item) -> Result<()> + Sync,
) -> Result<()>
where
    I::Item: Send,
{
    let jobs = Mutex::new(it);
    std::thread::scope(|s| {
        let f = &f;
        let jobs = &jobs;
        let hs: Vec<_> = (0..threads.clamp(1, 256))
            .map(|_| {
                s.spawn(move || -> Result<()> {
                    loop {
                        let job = jobs.lock().unwrap().next();
                        match job {
                            Some(x) => f(x)?,
                            None => return Ok(()),
                        }
                    }
                })
            })
            .collect();
        for h in hs {
            h.join().unwrap()?
        }
        Ok(())
    })
}
pub struct Frame<'a> {
    size: usize,
    block: usize,
    blocks: Vec<std::borrow::Cow<'a, [u8]>>,
    layout: Option<layout::Layout>,
}
impl<'a> Frame<'a> {
    pub fn size(&self) -> usize {
        self.size
    }
    pub fn encoded_size(&self) -> usize {
        20 + self
            .layout
            .as_ref()
            .map_or(0, layout::Layout::serialized_len)
            + self.blocks.iter().map(|v| 4 + v.len()).sum::<usize>()
    }
    pub fn write(&self, mut w: impl std::io::Write) -> Result<()> {
        w.write_all(MAGIC)?;
        w.write_all(&(self.size as u64).to_le_bytes())?;
        let word = self.block as u32 | ((self.layout.is_some() as u32) << 31);
        w.write_all(&word.to_le_bytes())?;
        if let Some(l) = &self.layout {
            l.write(&mut w)?
        }
        for b in &self.blocks {
            w.write_all(&(b.len() as u32).to_le_bytes())?;
            w.write_all(b)?
        }
        w.flush()
    }
    pub fn read(mut p: &'a [u8]) -> Result<Self> {
        if take(&mut p, 8)? != MAGIC {
            return Err(bad());
        }
        let size = usize::try_from(u64::from_le_bytes(take(&mut p, 8)?.try_into().unwrap()))
            .map_err(|_| bad())?;
        let word = u32in(&mut p)?;
        let block = word & 0x7fffffff;
        if !(1..=MAX_WIDE_BLOCK).contains(&block) {
            return Err(bad());
        }
        let layout = if word >> 31 != 0 {
            Some(layout::Layout::read(&mut p, size)?)
        } else {
            None
        };
        let mut blocks = vec![];
        for _ in 0..layout
            .as_ref()
            .map_or_else(|| size.div_ceil(block), |l| l.sizes.len())
        {
            let n = u32in(&mut p)?;
            if n == 0 || n > block + 1 {
                return Err(bad());
            }
            blocks.push(std::borrow::Cow::Borrowed(take(&mut p, n)?))
        }
        if !p.is_empty() {
            return Err(bad());
        }
        Ok(Self {
            size,
            block,
            blocks,
            layout,
        })
    }
}
pub fn compress_with(
    data: &[u8],
    threads: usize,
    f: impl Fn(&[u8]) -> Result<Vec<u8>> + Sync,
) -> Result<Frame<'static>> {
    let block = block_size(data.len(), threads);
    compress_with_block(data, threads, block, f)
}
/// Run independent jobs of a specified size. Benchmark codecs may use their
/// own frame sizes; only native archives are read by `Frame::read`.
pub fn compress_with_block(
    data: &[u8],
    threads: usize,
    block: usize,
    f: impl Fn(&[u8]) -> Result<Vec<u8>> + Sync,
) -> Result<Frame<'static>> {
    if block == 0 || block > 0x7fff_ffff {
        return Err(bad());
    }
    let mut blocks: Vec<_> = data
        .chunks(block)
        .map(|_| std::borrow::Cow::default())
        .collect();
    parallel(
        threads.min(blocks.len()),
        data.chunks(block).zip(&mut blocks),
        |(src, slot)| {
            *slot = std::borrow::Cow::Owned(f(src)?);
            Ok(())
        },
    )?;
    Ok(Frame {
        size: data.len(),
        block,
        blocks,
        layout: None,
    })
}
pub fn decompress_with(
    frame: &Frame,
    threads: usize,
    dst: &mut [u8],
    f: impl Fn(&[u8], &mut [u8]) -> Result<()> + Sync,
) -> Result<()> {
    if dst.len() != frame.size
        || frame.block == 0
        || frame
            .layout
            .as_ref()
            .map_or_else(|| dst.len().div_ceil(frame.block), |l| l.sizes.len())
            != frame.blocks.len()
    {
        return Err(bad());
    }
    if frame.layout.is_some() {
        return layout::restore(frame, threads, dst, false, f);
    }
    parallel(
        threads.min(frame.blocks.len()),
        frame.blocks.iter().zip(dst.chunks_mut(frame.block)),
        |(src, dst)| f(src, dst),
    )
}
pub fn decompress(frame: &Frame, threads: usize, dst: &mut [u8]) -> Result<()> {
    let first = frame.blocks.first().and_then(|b| b.first());
    if first == Some(&50) || (cfg!(any(test, feature = "research")) && first == Some(&52)) {
        return grammar::worddag::shared::decompress(frame, threads, dst);
    }
    if let Some(l) = &frame.layout {
        if dst.len() != frame.size || l.sizes.len() != frame.blocks.len() {
            return Err(bad());
        }
        layout::restore(frame, threads, dst, true, decode)
    } else if ((4 << 20) + 1..=5 << 20).contains(&frame.block) && frame.blocks.len() > threads {
        if dst.len() != frame.size || dst.len().div_ceil(frame.block) != frame.blocks.len() {
            return Err(bad());
        }
        // The first stream declares the number of LZ commands. It is only a
        // scheduling hint: decode still validates every block independently.
        let mut jobs: Vec<_> = frame
            .blocks
            .iter()
            .zip(dst.chunks_mut(frame.block))
            .collect();
        jobs.sort_unstable_by_key(|(src, _)| {
            let commands = if matches!(src.first(), Some(1 | 13 | 16 | 17)) {
                src.get(1..5)
                    .map_or(0, |v| u64::from(u32::from_le_bytes(v.try_into().unwrap())))
            } else {
                0
            };
            std::cmp::Reverse(src.len() as u64 + 4 * commands)
        });
        parallel(threads.min(jobs.len()), jobs.into_iter(), |(src, dst)| {
            decode(src, dst)
        })
    } else {
        decompress_with(frame, threads, dst, decode)
    }
}
pub fn compress(data: &[u8], threads: usize) -> Result<Frame<'static>> {
    compress_preset(data, threads, Preset::default())
}
#[cfg(feature = "research")]
pub fn research_shared(data: &[u8], threads: usize) -> Result<Frame<'static>> {
    grammar::worddag::shared::compress(
        data,
        threads,
        grammar::worddag::shared::Plan::experiment(
            tuning("BTR_DAG_CAP", 32768, 64, 1 << 20),
            tuning("BTR_DAG_WIDTH", 64, 16, 64),
            tuning("BTR_SHARED_JOBS", 4, 1, 64),
        ),
    )
}
#[cfg(feature = "research")]
pub fn research_repack_dictionary(frame: &Frame<'_>, methods: usize) -> Result<Frame<'static>> {
    grammar::worddag::shared::repack(frame, methods)
}
#[cfg(feature = "research")]
pub fn research_page_aliases(
    frame: &Frame<'_>,
    log: usize,
    cap: usize,
    conditional: bool,
) -> Result<Frame<'static>> {
    grammar::worddag::phrasepage::rewrite(frame, log, cap, conditional)
}
pub fn compress_preset(data: &[u8], threads: usize, preset: Preset) -> Result<Frame<'static>> {
    if let Some(layout) = layout::Layout::detect(data, preset.level()) {
        layout::compress(data, threads, layout, preset.level(), |s| {
            encode_archive(s, preset)
        })
    } else {
        let lv = preset.level();
        let large_text = lv >= 5 && words::detect(data);
        if large_text
            && let Some(plan) = grammar::worddag::shared::Plan::preset(lv)
            && threads >= 2
            && data.len() >= 8 << 20
            && !pixel::detect(data)
        {
            if let Ok(frame) = grammar::worddag::shared::compress(data, threads, plan) {
                return Ok(frame);
            }
            // A dictionary can exceed its first block on unusual inputs. The
            // ordinary independent encoders always have a raw-block fallback.
            if lv == 16 {
                return mixed::preset(data, threads, lv);
            }
        }
        let fast_text = lv == 2 && words::detect(data);
        let signal_job = if !cfg!(feature = "research") && lv >= 2 && pixel::detect(data) {
            signalgrid::plan(lv).map(|p| p.kib)
        } else {
            None
        };
        let default_kib = if let Some(kib) = signal_job {
            kib
        } else if fast_text {
            896
        } else if large_text && lv == 5 {
            4096
        } else if large_text && lv == 6 {
            5120
        } else if large_text && lv == 7 {
            12288
        } else if large_text && (8..=15).contains(&lv) {
            24576
        } else if large_text {
            [
                3072, 3584, 4096, 5120, 6144, 7168, 8192, 9216, 10240, 12288, 14336, 16384,
            ][(lv - 11) as usize]
        } else if lv == 1 && !pixel::detect(data) {
            if cfg!(target_arch = "aarch64") {
                384
            } else {
                256
            }
        } else {
            2048
        };
        let limit = tuning(
            "BTR_JOB_KIB",
            default_kib,
            16,
            if large_text { 32768 } else { 2048 },
        ) * 1024;
        let jobs = data
            .len()
            .div_ceil(limit)
            .next_multiple_of(threads.clamp(1, 256))
            .max(1);
        let block = data
            .len()
            .div_ceil(jobs)
            .max(1)
            .next_multiple_of(64)
            .min(limit);
        // The standalone trial learns only the distance and literal palettes.
        // The standard preset and research controls remain separately measurable.
        #[cfg(all(
            feature = "regional-models",
            not(feature = "research"),
            target_arch = "aarch64"
        ))]
        if lv == 1 && data.len() >= 1 << 20 && !pixel::detect(data) {
            return lz::sharedentropy::compress_per(data, threads, block, 6, 128, false);
        }
        #[cfg(all(feature = "research", target_arch = "aarch64"))]
        if lv == 1 && data.len() >= 1 << 20 && !pixel::detect(data) {
            let fields = tuning("BTR_SHARED_FIELDS", 0, 0, 7);
            if fields != 0 {
                return lz::sharedentropy::compress(data, threads, block, fields);
            }
        }
        compress_with_block(data, threads, block, |s| encode_preset(s, preset))
    }
}
pub fn encode(src: &[u8]) -> Result<Vec<u8>> {
    encode_preset(src, Preset::default())
}
pub fn encode_preset(src: &[u8], preset: Preset) -> Result<Vec<u8>> {
    let level = preset.level();
    if src.len() > MAX_WIDE_BLOCK || (src.len() > MAX_BLOCK && matches!(level, 1..=4)) {
        return Err(bad());
    }
    #[cfg(feature = "research")]
    if level == 1 {
        let runbook = tuning("BTR_RUNBOOK", 0, 0, 16);
        if runbook != 0 && words::detect(src) {
            return Ok(runbook::put(
                src,
                runbook - 1,
                tuning("BTR_RUNBOOK_MODEL", 0, 0, 31),
            ));
        }
    }
    let v = if pixel::detect(src) {
        #[cfg(feature = "research")]
        if let mode @ 1..=4 = tuning("BTR_SIGNAL_GRID", 0, 0, 4) {
            return Ok(signalgrid::encode(src, level, mode));
        }
        if !cfg!(feature = "research")
            && let Some(plan) = signalgrid::plan(level)
        {
            signalgrid::encode_plan(src, level, plan)
        } else {
            pixel::encode_level(src, level)
        }
    } else if level == 2 && words::detect(src) {
        lz::paired_cost::<6, 17, 3, true, 21, 2, true, 14>(src)
    } else if level == 5 && (src.len() > MAX_BLOCK || words::detect(src)) {
        lz::legacy_width::<false, 17, 18, false, 4, 0, 25>(src)
    } else if level == 6 && (src.len() > MAX_BLOCK || words::detect(src)) {
        if src.len() <= 1 << 23 {
            lz::history_model::<false, 17, 20, false, 3, 16, 23, true, 4, 0, true, true, 0, false>(
                src,
            )
        } else {
            lz::history_model::<false, 17, 20, false, 3, 16, 25, true, 4, 0, true, true, 0, false>(
                src,
            )
        }
    } else if level == 7 && (src.len() > MAX_BLOCK || words::detect(src)) {
        lz::legacy_policy::<false, 18, 21, false, 1, 16, 25, true, 4>(src)
    } else if level == 8 && (src.len() > MAX_BLOCK || words::detect(src)) {
        lz::eighth_text(src)
    } else if (9..=12).contains(&level) && (src.len() > MAX_BLOCK || words::detect(src)) {
        lz::middle_text(src, level)
    } else if (13..=15).contains(&level) && (src.len() > MAX_BLOCK || words::detect(src)) {
        grammar::worddag::preset(src, level)
    } else if level >= 10 && (src.len() > MAX_BLOCK || words::detect(src)) {
        lz::optimal(src, level)
    } else {
        lz::encode_level::<false>(src, level)
    };
    if v.len() > src.len() {
        let mut raw = vec![0];
        raw.extend(src);
        Ok(raw)
    } else {
        Ok(v)
    }
}
pub(crate) fn archive_parser(level: u8) -> u8 {
    let chosen = [
        1, 2, 3, 2, 2, 4, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 9, 10, 10, 10, 10, 10,
    ][(level - 1) as usize];
    tuning("BTR_ARCH_PARSER", chosen, 1, 22) as u8
}
fn encode_archive(src: &[u8], preset: Preset) -> Result<Vec<u8>> {
    let v = object::archive_lz(src, preset.level());
    if v.len() > src.len() {
        let mut r = vec![0];
        r.extend(src);
        Ok(r)
    } else {
        Ok(v)
    }
}
pub fn decode(src: &[u8], dst: &mut [u8]) -> Result<()> {
    if dst.len() > MAX_WIDE_BLOCK {
        return Err(bad());
    }
    let (&mode, mut p) = src.split_first().ok_or_else(bad)?;
    match mode {
        0 if dst.len() == p.len() => {
            dst.copy_from_slice(p);
            Ok(())
        }
        1 => lz::decode(p, dst),
        41 => lz::pages::decode(p, dst),
        2 => pixel::decode(p, dst),
        6 | 10 => pixel::unadjacent(p, dst, mode == 10),
        7 => words::decode(p, dst),
        8 => object::uninstructions(p, dst),
        9 => object::uncolumns(p, dst),
        11 => sorted::decode(p, dst),
        12 => object::unbanked(p, dst),
        #[cfg(feature = "research")]
        26 => cascade::decode(p, dst),
        #[cfg(feature = "research")]
        34 => lz::addrbook::decode::<false>(p, dst),
        #[cfg(feature = "research")]
        35 => lz::addrbook::decode::<true>(p, dst),
        33 => object::unsmall(p, dst.len(), &mut [(0, dst)]),
        21 => object::unadaptive(p, dst.len(), &mut [(0, dst)]),
        13 => lz::decode_impl::<true>(p, dst),
        16 => lz::decode_min::<false, 3>(p, dst),
        17 => lz::decode_min::<true, 3>(p, dst),
        #[cfg(feature = "research")]
        14 => phrases::decode(p, dst),
        #[cfg(feature = "research")]
        20 => lines::decode(p, dst),
        #[cfg(feature = "research")]
        32 => patch::decode(p, dst),
        #[cfg(feature = "research")]
        31 => alias::decode(p, dst),
        #[cfg(feature = "research")]
        24 => lex::decode(p, dst),
        42 => lz::dspan::read(p, dst),
        43 => grammar::decode(p, dst),
        48 => grammar::worddag::decode::<false>(p, dst),
        #[cfg(feature = "research")]
        49 => grammar::worddag::decode::<true>(p, dst),
        #[cfg(feature = "research")]
        30 => lex::decode_offsets(p, dst),
        4 => record::decode(p, dst),
        #[cfg(feature = "research")]
        57 => fastisa::get(p, dst),
        #[cfg(feature = "research")]
        59 => lz::flatdist::get(p, dst),
        #[cfg(feature = "research")]
        60 => aligned::get(p, dst),
        #[cfg(feature = "research")]
        61 => runbook::get(p, dst),
        #[cfg(feature = "research")]
        62 => pairfold::get(p, dst),
        63 => signalgrid::get(p, dst),
        5 => {
            let mut rest = dst;
            while !p.is_empty() {
                let n = u32in(&mut p)?;
                let len = u32in(&mut p)?;
                let b = take(&mut p, len)?;
                if n == 0 || n > rest.len() || b.first() == Some(&5) {
                    return Err(bad());
                }
                let (d, r) = rest.split_at_mut(n);
                decode(b, d)?;
                rest = r
            }
            if rest.is_empty() { Ok(()) } else { Err(bad()) }
        }
        _ => Err(bad()),
    }
}

#[cfg(feature = "research")]
pub fn research_encode(s: &[u8], preset: Preset, kind: &str) -> Result<Vec<u8>> {
    if s.is_empty()
        || s.len()
            > (if kind.starts_with("optimal")
                || kind.starts_with("bt")
                || kind.starts_with("tree")
                || kind.starts_with("line")
                || kind.starts_with("lex")
                || kind.starts_with("hwin")
                || kind.starts_with("twin")
                || kind.starts_with("patch")
                || kind.starts_with("alias")
                || kind.starts_with("phrases")
                || kind == "words-opt"
            {
                MAX_WIDE_BLOCK
            } else {
                MAX_BLOCK
            })
    {
        return Err(bad());
    }
    let level = preset.level();
    let b = match kind {
        "sorted" => sorted::encode(s, level),
        "words-sorted" | "words-lz" | "words-opt" => words::encode(
            s,
            level,
            match kind {
                "words-sorted" => 1,
                "words-opt" => 2,
                _ => 0,
            },
        )
        .unwrap_or_else(|| lz::encode_level::<false>(s, level)),
        "lz" => lz::encode_level::<false>(s, level),
        "optimal" => lz::optimal(s, level),
        "optimal-priced" => lz::optimal_parse::<true>(s, level),
        "tree" => lz::tree::<false, false>(s, level),
        "tree-priced" => lz::tree::<true, false>(s, level),
        "line-head" => lines::encode(s, level, 0),
        "line-class" => lines::encode(s, level, 1),
        "line-mix" => lines::encode(s, level, 2),
        "line-hash" => lines::encode(s, level, 3),
        "lex-pairs" | "lex-pairs-ranked" | "lex-pairs-offsets" | "lex-pairs-bytes" => {
            let mode = match kind {
                "lex-pairs-ranked" => 42,
                "lex-pairs-offsets" => 45,
                "lex-pairs-bytes" => 6,
                _ => 0,
            };
            let (v, t) = lexpairs::tokenize(
                s,
                tuning("BTR_PAIR_VOCAB", 8192, 384, 32768),
                tuning("BTR_PAIR_INITIAL", 128, 16, 1024),
            );
            lex::encode_tokens(s, level, mode, v, t)
        }
        "lex" => lex::encode(s, level, 0),
        "lex-grammar" => grammar::encode(s, 1),
        "lex-dag" => grammar::worddag::encode(s),
        "lex-grammar-flat" => grammar::encode(s, 0),
        "lex-successor-flat" => grammar::encode(s, 3),
        "lex-successor" => grammar::encode(s, 4),
        "lex-successor-bytes" => grammar::encode(s, 5),
        "lex-grammar-bytes" => grammar::encode(s, 2),
        "lex-sep" => lex::encode(s, level, 1),
        "lex-punct" => lex::encode(s, level, 2),
        "lex-fastlz" => lex::encode(s, level, 12),
        "lex-deeplz" => lex::encode(s, level, 15),
        "lex-optlz" => lex::encode(s, level, 18),
        "lex-smalllz" => lex::encode(s, level, 21),
        "lex-hot192" => lex::encode(s, level, 24),
        "lex-hot704" => lex::encode(s, level, 27),
        "lex-hot2k" => lex::encode(s, level, 30),
        "lex-hot4k" => lex::encode(s, level, 33),
        "lex-hot8k" => lex::encode(s, level, 36),
        k if k.starts_with("alias") => {
            let m = k[5..].parse::<usize>().map_err(|_| bad())?;
            if m >= 15 {
                return Err(bad());
            }
            alias::encode(s, m)
        }
        "lex-offsets" => lex::encode(s, level, 45),
        k if k.starts_with("patch") => {
            let v = k[5..].parse().map_err(|_| bad())?;
            patch::encode(s, level, false, v)
        }
        "lex-ranked" => lex::encode(s, level, 42),
        "lex-strict" => lex::encode(s, level, 3),
        "lex-bytes" => lex::encode(s, level, 6),
        "lex-predict" => lex::encode(s, level, 9),
        "bt4" => lz::optimal_engine::<true, 4>(s, level),
        "bt8" => lz::optimal_engine::<true, 8>(s, level),
        "bt16" => lz::optimal_engine::<true, 16>(s, level),
        "bt32" => lz::optimal_engine::<true, 32>(s, level),
        "bt-lazy8" => prefixtree::lazy::<8, 4, 1>(s),
        "bt-lazy12" => prefixtree::lazy::<12, 3, 1>(s),
        "bt-lazy16" => prefixtree::lazy::<16, 2, 2>(s),
        "bt-lazy24" => prefixtree::lazy::<24, 1, 2>(s),
        "tree-reps" => lz::tree::<true, true>(s, level),
        "sparse0" => sparse::encode::<0, 5, 15, false>(s),
        "sparse1" => sparse::encode::<1, 5, 15, false>(s),
        "sparse2" => sparse::encode::<2, 5, 15, false>(s),
        "sparse3" => sparse::encode::<3, 5, 15, false>(s),
        "sparse16" => sparse::encode::<2, 5, 16, false>(s),
        "sparse6" => sparse::encode::<2, 6, 15, false>(s),
        "sparse-dual" => sparse::encode::<2, 7, 15, true>(s),
        "quick16" => lz::quick_impl::<2, 16, false, 2>(s, false),
        "quick16l" => lz::quick_impl::<2, 16, true, 2>(s, false),
        "quick17l" => lz::quick_impl::<2, 17, true, 3>(s, false),
        "quick17" => lz::quick_impl::<2, 17, false, 3>(s, false),
        "single17" => lz::quick_impl::<1, 17, true, 2>(s, false),
        "prefix12a" => lz::legacy_ext::<false, 16, 16, false, 0, 17>(s),
        "prefix12b" => lz::legacy_ext::<false, 17, 17, false, 0, 17>(s),
        "prefix12c" => lz::legacy_ext::<false, 17, 17, true, 2, 17>(s),
        "prefix12d" => lz::legacy_ext::<false, 17, 18, true, 2, 18>(s),
        "twin17p2" => lz::paired_cost::<5, 17, 2, true, 21, 2, true, 1>(s),
        "twin17p3" => lz::paired_cost::<5, 17, 3, true, 21, 3, true, 9>(s),
        "twin96" => lz::paired_cost::<5, 17, 2, true, 21, 2, true, 5>(s),
        "twin96m" => lz::paired_cost::<5, 17, 3, true, 21, 2, true, 13>(s),
        "twin96s" => lz::paired_cost::<6, 17, 3, true, 21, 2, true, 14>(s),
        "twin64m" => lz::paired_cost::<5, 16, 3, true, 21, 2, true, 9>(s),
        "twin64s" => lz::paired_cost::<6, 16, 3, true, 21, 2, true, 10>(s),
        "twin16" => lz::paired_policy::<5, 16, 2, true, 25, 0, true>(s),
        "twin16p" => lz::paired_policy::<5, 16, 2, true, 25, 1, true>(s),
        "twin16p2" => lz::paired_policy::<5, 16, 2, true, 25, 2, true>(s),
        "twin17" => lz::paired_policy::<5, 17, 2, true, 25, 0, true>(s),
        "twin17p" => lz::paired_policy::<5, 17, 2, true, 25, 1, true>(s),
        "twin6" => lz::paired_policy::<6, 16, 2, true, 25, 1, true>(s),
        "hwin-local6" if s.len() <= 1 << 23 => {
            lz::history_model::<false, 17, 20, false, 3, 16, 23, true, 4, 2, true, true, 0, false>(
                s,
            )
        }
        "hwin-local6" => {
            lz::history_model::<false, 17, 20, false, 3, 16, 25, true, 4, 2, true, true, 0, false>(
                s,
            )
        }
        "hwin-local8" => lz::eighth_text(s),
        "hwin-mid9" => lz::middle_text(s, 9),
        "hwin-mid10" => lz::middle_text(s, 10),
        "hwin-mid11" => lz::middle_text(s, 11),
        "hwin-mid12" => lz::middle_text(s, 12),
        "hwin-sub7" => lz::legacy_policy::<false, 18, 21, false, 1, 16, 25, true, 4>(s),
        "hwin-price6" => lz::legacy_policy::<false, 18, 20, false, 3, 0, 25, true, 0>(s),
        "hwin-price7" => lz::legacy_policy::<false, 18, 21, false, 2, 0, 25, true, 0>(s),
        "hwin-price6d" => lz::legacy_policy::<false, 18, 20, false, 2, 0, 25, true, 0>(s),
        "hwin-price8x" => lz::legacy_policy::<false, 18, 21, false, 1, 20, 25, true, 0>(s),
        "hwin19a" => lz::legacy_width::<false, 17, 19, false, 4, 0, 25>(s),
        "hwin19b" => lz::legacy_width::<false, 18, 19, false, 3, 0, 25>(s),
        "hwin19c" => lz::legacy_width::<false, 18, 19, false, 1, 0, 25>(s),
        "hwin20a" => lz::legacy_width::<false, 18, 20, false, 3, 0, 25>(s),
        "hwin12a" => lz::legacy_width::<false, 17, 17, false, 3, 18, 25>(s),
        "hwin16" => lz::legacy_width::<false, 16, 16, false, 0, 0, 25>(s),
        "hwin17" => lz::legacy_width::<false, 17, 17, false, 0, 0, 25>(s),
        "hwin18" => lz::legacy_width::<false, 17, 18, false, 0, 0, 25>(s),
        "hwin18a" => lz::legacy_width::<false, 17, 18, false, 4, 0, 25>(s),
        "hwin18b" => lz::legacy_width::<false, 17, 18, false, 2, 0, 25>(s),
        "hwin18f" => lz::legacy_width::<false, 17, 18, true, 2, 0, 25>(s),
        "hwin19" => lz::legacy_width::<false, 18, 19, true, 1, 0, 25>(s),
        "wide17" => lz::legacy::<false, 17, 17, false, 0>(s),
        "wide18" => lz::legacy::<false, 17, 18, false, 0>(s),
        "wide18x" => lz::legacy::<false, 17, 18, true, 0>(s),
        "wide18fill" => lz::legacy::<false, 17, 18, true, 2>(s),
        "wide19" => lz::legacy::<false, 18, 19, true, 1>(s),
        "bucket2" => buckets::encode::<2, 2, 16, 1>(s),
        "bucket4" => buckets::encode::<4, 2, 16, 1>(s),
        "bucket4b" => buckets::encode::<4, 4, 17, 2>(s),
        "bucket8" => buckets::encode::<8, 4, 16, 2>(s),
        "bucket8b" => buckets::encode::<8, 4, 17, 2>(s),
        "bucket16" => buckets::encode::<16, 8, 16, 2>(s),
        "cache14" => lz::cached::<14, 1, 5>(s),
        "cache15" => lz::cached::<15, 1, 5>(s),
        "cache16" => lz::cached::<16, 2, 5>(s),
        "cache17" => lz::cached::<17, 2, 5>(s),
        "cache6" => lz::cached::<15, 1, 6>(s),
        "cachefast" => lz::cached::<14, 0, 6>(s),
        "pair4" => lz::paired::<4, 15, 1, false>(s),
        "pair5" => lz::paired::<5, 15, 1, false>(s),
        "pair5lazy" => lz::paired::<5, 15, 1, true>(s),
        "pair5notail" => lz::paired::<5, 15, 0, false>(s),
        "pair5small" => lz::paired::<5, 14, 1, true>(s),
        "pair5large" => lz::paired::<5, 16, 2, true>(s),
        "pair6" => lz::paired::<6, 15, 1, true>(s),
        "phrases" => phrases::encode(s, level, 0),
        "phrases-opt" => phrases::encode(s, level, 2),
        "selected" => encode_preset(s, preset)?,
        _ => return Err(bad()),
    };
    if b.len() > s.len() + 1 {
        let mut raw = vec![0];
        raw.extend(s);
        Ok(raw)
    } else {
        Ok(b)
    }
}

#[cfg(feature = "research")]
pub fn research_address_book(
    frame: &Frame,
    raw: &[u8],
    threads: usize,
    cap: usize,
    base: usize,
    distance: usize,
) -> Result<Frame<'static>> {
    if frame.size != raw.len() || frame.layout.is_some() {
        return Err(bad());
    }
    let mut blocks: Vec<_> = frame
        .blocks
        .iter()
        .map(|_| std::borrow::Cow::default())
        .collect();
    parallel(
        threads.min(blocks.len()),
        frame
            .blocks
            .iter()
            .zip(raw.chunks(frame.block))
            .zip(&mut blocks),
        |((b, s), out)| {
            *out = std::borrow::Cow::Owned(if matches!(b.first(), Some(1 | 13 | 16 | 17)) {
                lz::addrbook::rewrite(
                    b,
                    s,
                    cap,
                    base,
                    distance,
                    tuning("BTR_BOOK_TAGS", 1, 0, 1) != 0,
                )?
            } else {
                b.to_vec()
            });
            Ok(())
        },
    )?;
    Ok(Frame {
        size: frame.size,
        block: frame.block,
        blocks,
        layout: None,
    })
}
