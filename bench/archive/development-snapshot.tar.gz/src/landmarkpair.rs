// Pick one of two adjacent match starts from their contents. Once chosen, the
// start is indexed even on a miss. A successful probe may extend to the left:
// picking the second start doesn't necessarily leave its first byte literal.
use super::{probe, word};
#[inline(always)]
fn choose<const RULE: usize>(w: u64) -> usize {
    let a = w as u8;
    let b = (w >> 8) as u8;
    usize::from(match RULE {
        0 => b < a,
        1 => (b ^ 0x60) < (a ^ 0x60),
        2 => b.wrapping_mul(109) < a.wrapping_mul(109),
        _ => b <= 0x40 && a > 0x40,
    })
}
#[inline(always)]
fn indices<const P: usize, const B: usize>(w: u64) -> (usize, u32) {
    (
        ((w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize,
        (w as u32) << 21,
    )
}
#[inline(always)]
fn run<const RULE: usize, const P: usize, const B: usize, const STEP: usize, const SEED: usize>(
    s: &[u8],
    mut emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    let mut table = vec![0u32; 1 << B];
    let (mut i, mut anchor) = (0, 0);
    while i + 9 <= s.len() {
        let w0 = word(s, i);
        let shift = choose::<RULE>(w0);
        let j = i + shift;
        let w = word(s, j);
        let (k, sig) = indices::<P, B>(w);
        let old = std::mem::replace(&mut table[k], sig | j as u32);
        let (n, q) = probe(s, j, w, old, sig);
        if n < 4 || (n == 4 && j - q > 12000) {
            i += if STEP == 1 { 1 + shift } else { 2 };
            continue;
        }
        let mut back = 0;
        while back < j - anchor && back < q && s[j - back - 1] == s[q - back - 1] {
            back += 1
        }
        emit(anchor, j - back, n + back, j - q);
        i = j + n;
        anchor = i;
        if i + 7 <= s.len() {
            let tail = i - 2;
            let tw = word(s, tail);
            let at = tail + choose::<RULE>(tw);
            let (h, sign) = indices::<P, B>(word(s, at));
            table[h] = sign | at as u32;
            if SEED != 0 {
                let extra = if SEED == 1 {
                    tail + (1 - (at - tail))
                } else {
                    j + 1
                };
                let (h, sign) = indices::<P, B>(word(s, extra));
                table[h] = sign | extra as u32;
            }
        }
    }
    anchor
}
pub(super) fn walk(s: &[u8], mode: usize, emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    macro_rules! m {
        ($r:literal,$p:literal,$b:literal,$s:literal,$f:literal) => {
            run::<$r, $p, $b, $s, $f>(s, emit)
        };
    }
    match mode {
        1 => m!(0, 5, 15, 1, 1),
        2 => m!(0, 6, 15, 1, 1),
        3 => m!(1, 5, 15, 1, 1),
        4 => m!(1, 6, 15, 1, 1),
        5 => m!(2, 5, 15, 1, 1),
        6 => m!(2, 6, 15, 1, 1),
        7 => m!(3, 5, 15, 1, 1),
        8 => m!(3, 6, 15, 1, 1),
        9 => m!(0, 5, 15, 2, 1),
        10 => m!(1, 5, 15, 2, 1),
        11 => m!(2, 5, 15, 2, 1),
        12 => m!(3, 5, 15, 2, 1),
        13 => m!(0, 5, 16, 1, 2),
        14 => m!(1, 6, 16, 1, 2),
        15 => m!(2, 6, 16, 2, 2),
        16 => m!(3, 6, 16, 2, 2),
        17 => m!(0, 5, 15, 1, 0),
        18 => m!(1, 5, 15, 1, 0),
        19 => m!(2, 5, 15, 1, 0),
        _ => m!(3, 5, 15, 1, 0),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn both_window_positions_and_short_endings_restore() {
        let mut s = Vec::new();
        let mut v = 34925u32;
        for i in 0..16000 {
            v = v.wrapping_mul(1664525).wrapping_add(1013904223);
            s.push((v >> 24) as u8);
            if i % 3 == 0 {
                s.extend_from_slice(b" go back a window ")
            }
            if i % 7 == 0 && s.len() > 1024 {
                let j = (v as usize) % (s.len() - 65);
                s.extend_from_within(j..j + 47);
            }
        }
        for m in 1..=20 {
            for n in (0..24).chain([32769, s.len()]) {
                let mut out = Vec::new();
                let end = walk(&s[..n], m, |a, i, len, d| {
                    assert_eq!(a, out.len());
                    out.extend_from_slice(&s[a..i]);
                    for _ in 0..len {
                        out.push(out[out.len() - d]);
                    }
                });
                assert_eq!(end, out.len());
                out.extend_from_slice(&s[end..n]);
                assert_eq!(out, s[..n]);
            }
        }
    }
}
