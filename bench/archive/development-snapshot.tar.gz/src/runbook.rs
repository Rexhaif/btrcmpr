// A level-one text experiment: intern bounded byte runs while scanning once.
// Symbols used only once stay as literal spellings. Repeated symbols trade
// their spelling for a one-, two- or three-byte rank; no match distances.
use crate::{Result, ans, bad, lz, take, u32in};

fn boundaries(s: &[u8], kind: usize, mut emit: impl FnMut(usize, usize)) {
    let mut prev = 0;
    let mut finish = |at: usize| {
        while prev < at {
            let n = (at - prev).min(8);
            emit(prev, n);
            prev += n
        }
    };
    let mut i = 1;
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use core::arch::aarch64::*;
        while i + 16 <= s.len() {
            let a = vld1q_u8(s.as_ptr().add(i));
            let b = vld1q_u8(s.as_ptr().add(i - 1));
            let alpha = |v| {
                vcltq_u8(
                    vsubq_u8(vorrq_u8(v, vdupq_n_u8(32)), vdupq_n_u8(b'a')),
                    vdupq_n_u8(26),
                )
            };
            let digit = |v| vcltq_u8(vsubq_u8(v, vdupq_n_u8(b'0')), vdupq_n_u8(10));
            let group = |v| vorrq_u8(alpha(v), digit(v));
            let mask = match kind {
                0 => vbicq_u8(group(a), group(b)),
                1 => vorrq_u8(vbicq_u8(group(a), group(b)), vceqq_u8(b, vdupq_n_u8(b' '))),
                2 => vorrq_u8(vbicq_u8(alpha(a), alpha(b)), vbicq_u8(digit(a), digit(b))),
                _ => vorrq_u8(veorq_u8(group(a), group(b)), vceqq_u8(b, vdupq_n_u8(b'\n'))),
            };
            let mut m = vget_lane_u64::<0>(vreinterpret_u64_u8(vshrn_n_u16::<4>(
                vreinterpretq_u16_u8(mask),
            ))) & 0x1111111111111111;
            while m != 0 {
                finish(i + m.trailing_zeros() as usize / 4);
                m &= m - 1
            }
            i += 16;
        }
    }
    while i < s.len() {
        let a = s[i];
        let b = s[i - 1];
        let g = u8::is_ascii_alphanumeric;
        let cut = match kind {
            0 => g(&a) && !g(&b),
            1 => (g(&a) && !g(&b)) || b == b' ',
            2 => {
                (a.is_ascii_alphabetic() && !b.is_ascii_alphabetic())
                    || (a.is_ascii_digit() && !b.is_ascii_digit())
            }
            _ => (g(&a) != g(&b)) || b == b'\n',
        };
        if cut {
            finish(i)
        }
        i += 1;
    }
    finish(s.len())
}
#[derive(Clone, Copy)]
struct Spell {
    word: u64,
    n: u8,
    count: u32,
    rank: u32,
}
fn block(s: &[u8], at: usize, n: usize) -> u64 {
    let v = if at + 8 <= s.len() {
        lz::word(s, at)
    } else {
        let mut a = [0; 8];
        a[..n].copy_from_slice(&s[at..at + n]);
        u64::from_le_bytes(a)
    };
    v & (u64::MAX >> ((8 - n) * 8))
}
fn send(v: &[u8], out: &mut Vec<u8>, force: bool) {
    if force {
        out.extend((v.len() as u32).to_le_bytes());
        out.push(0);
        out.extend(v)
    } else {
        ans::put_policy(v, out, 0.982)
    }
}
fn payload(v: &[u8], out: &mut Vec<u8>, lz: bool) {
    if lz && v.len() >= 256 {
        let packed = crate::lz::quick_impl::<1, 13, false, 1>(v, false);
        if packed.len() < v.len() {
            out.push(1);
            out.extend((packed.len() as u32).to_le_bytes());
            out.extend(packed);
            return;
        }
    }
    out.push(0);
    send(v, out, false)
}
pub(crate) fn put(s: &[u8], mode: usize, model: usize) -> Vec<u8> {
    let cap = (s.len() / 5).next_power_of_two().clamp(256, 1 << 19);
    let mask = cap - 1;
    let mut table = vec![u32::MAX; cap];
    let mut list: Vec<Spell> = Vec::new();
    let mut tokens = Vec::with_capacity(s.len() / 4);
    let mut overflow = false;
    boundaries(s, mode % 4, |at, n| {
        if overflow {
            return;
        }
        let w = block(s, at, n);
        let h = (w ^ w.rotate_left(29) ^ (n as u64)).wrapping_mul(0x9e3779b97f4a7c15);
        let mut k = (h ^ (h >> 33)) as usize & mask;
        loop {
            let z = table[k];
            if z == u32::MAX {
                if list.len() >= cap * 7 / 8 {
                    overflow = true;
                    break;
                }
                let id = list.len() as u32;
                table[k] = id;
                list.push(Spell {
                    word: w,
                    n: n as u8,
                    count: 1,
                    rank: 0,
                });
                tokens.push(id);
                break;
            }
            let entry = &mut list[z as usize];
            if entry.word == w && usize::from(entry.n) == n {
                entry.count += 1;
                tokens.push(z);
                break;
            }
            k = (k + 1) & mask;
        }
    });
    let raw = || {
        let mut p = vec![0];
        p.extend(s);
        p
    };
    if overflow {
        return raw();
    }
    // Frequency buckets avoid sorting the whole word table. Ties keep their
    // order of first occurrence, which also keeps the wire deterministic.
    let threshold = [2, 3, 4, 6][(mode >> 2) & 3];
    let mut freq = [0usize; 32];
    for entry in &list {
        if entry.count >= threshold {
            freq[entry.count.ilog2() as usize] += 1
        }
    }
    let mut assigned = 0;
    for f in freq.iter_mut().rev() {
        let n = *f;
        *f = assigned;
        assigned += n
    }
    let count = assigned.min(65536);
    let mut words = vec![0u64; count];
    let mut widths = vec![0u8; count];
    for entry in &mut list {
        entry.rank = u32::MAX;
        if entry.count >= threshold {
            let x = &mut freq[entry.count.ilog2() as usize];
            let r = *x;
            *x += 1;
            if r < count {
                entry.rank = r as u32;
                words[r] = entry.word;
                widths[r] = entry.n
            }
        }
    }
    let direct = [128, 192, 224, 240][model & 3];
    let mut head = Vec::with_capacity(tokens.len());
    let mut ext = Vec::with_capacity(tokens.len() / 3);
    let mut escapes = Vec::new();
    for id in tokens {
        let e = &list[id as usize];
        let r = e.rank as usize;
        if r < direct {
            head.push(r as u8)
        } else if r < direct + (247 - direct) * 256 {
            let k = r - direct;
            head.push((direct + k / 256) as u8);
            ext.push(k as u8)
        } else if r < count {
            head.push(247);
            ext.extend((r as u16).to_le_bytes())
        } else {
            head.push(247 + e.n);
            escapes.extend_from_slice(&e.word.to_le_bytes()[..e.n as usize])
        }
    }
    let mut book = Vec::new();
    for (&word, &n) in words.iter().zip(&widths) {
        book.extend_from_slice(&word.to_le_bytes()[..n as usize])
    }
    let mut out = vec![61, direct as u8];
    out.extend((count as u32).to_le_bytes());
    out.extend((escapes.len() as u32).to_le_bytes());
    send(&widths, &mut out, false);
    payload(&book, &mut out, model & 4 != 0);
    send(&head, &mut out, model & 8 != 0);
    send(&ext, &mut out, model & 16 != 0);
    payload(&escapes, &mut out, model & 4 != 0);
    if out.len() > s.len() { raw() } else { out }
}
fn field<'a>(p: &mut &'a [u8], max: usize) -> Result<std::borrow::Cow<'a, [u8]>> {
    if !matches!(p.get(4), Some(0 | 1 | 2 | 4 | 5)) {
        return Err(bad());
    }
    ans::get(p, max)
}
fn read(p: &mut &[u8], n: usize) -> Result<Vec<u8>> {
    match take(p, 1)?[0] {
        0 => {
            let f = field(p, n)?;
            if f.len() != n {
                return Err(bad());
            }
            Ok(f.into_owned())
        }
        1 => {
            let m = u32in(p)?;
            let s = take(p, m)?;
            let (&tag, body) = s.split_first().ok_or_else(bad)?;
            let mut d = vec![0; n];
            match tag {
                1 => lz::decode_core::<false, 4, false, true>(body, &mut d, &[])?,
                13 => lz::decode_core::<true, 4, false, true>(body, &mut d, &[])?,
                _ => return Err(bad()),
            }
            Ok(d)
        }
        _ => Err(bad()),
    }
}
pub(crate) fn get(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let direct = take(&mut p, 1)?[0];
    if !matches!(direct, 128 | 192 | 224 | 240) {
        return Err(bad());
    }
    let count = u32in(&mut p)?;
    let nes = u32in(&mut p)?;
    if count > 65536 || count > dst.len() || nes > dst.len() {
        return Err(bad());
    }
    let width = field(&mut p, count)?;
    if width.len() != count || width.iter().any(|&v| !(1..=8).contains(&v)) {
        return Err(bad());
    }
    let total: usize = width.iter().map(|&b| usize::from(b)).sum();
    if total > dst.len() {
        return Err(bad());
    }
    let mut packed = read(&mut p, total)?;
    packed.extend([0; 8]);
    let mut offset = 0;
    let words: Vec<u64> = width
        .iter()
        .map(|&n| {
            let w = lz::word(&packed, offset);
            offset += usize::from(n);
            w
        })
        .collect();
    let tags = field(&mut p, dst.len())?;
    let ep = field(&mut p, tags.len() * 2)?;
    let mut ext = &*ep;
    let mut es = read(&mut p, nes)?;
    es.extend([0; 8]);
    if !p.is_empty() {
        return Err(bad());
    }
    let mut emit = 0;
    let mut used = 0;
    for &v in tags.iter() {
        let (w, n) = if v >= 248 {
            let n = usize::from(v - 247);
            if used + n > nes {
                return Err(bad());
            }
            let w = lz::word(&es, used);
            used += n;
            (w, n)
        } else {
            let rank = if v < direct {
                usize::from(v)
            } else if v == 247 {
                u16::from_le_bytes(take(&mut ext, 2)?.try_into().unwrap()) as usize
            } else {
                usize::from(direct)
                    + usize::from(v - direct) * 256
                    + usize::from(take(&mut ext, 1)?[0])
            };
            let w = *words.get(rank).ok_or_else(bad)?;
            (w, usize::from(width[rank]))
        };
        if emit + 8 <= dst.len() {
            unsafe {
                std::ptr::write_unaligned(dst.as_mut_ptr().add(emit).cast::<u64>(), w.to_le())
            }
        } else {
            dst.get_mut(emit..emit + n)
                .ok_or_else(bad)?
                .copy_from_slice(&w.to_le_bytes()[..n])
        }
        emit += n;
    }
    if !ext.is_empty() || used != nes || emit != dst.len() {
        return Err(bad());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ranked_words_full_spellings_and_literal_escapes() {
        let mut src = vec![];
        for i in 0..2300 {
            src.extend(b"zero 123, one... and \0unbrokenlongwordx ");
            src.extend((i as u32).to_be_bytes());
        }
        for k in [0, 1, 2, 3, 7, 13] {
            for model in [0, 3, 4, 24] {
                let a = put(&src, k, model);
                assert_eq!(a[0], 61);
                let mut d = vec![0; src.len()];
                crate::decode(&a, &mut d).unwrap();
                assert_eq!(src, d);
                assert!(crate::decode(&a[..a.len() - 1], &mut d).is_err());
            }
        }
    }
}
