// Cache enough bytes in the index to reject a miss or measure a short match
// without touching a previous location in the input. One control uses the
// exact same position and match decisions as quicktwo.
use super::{Streams, common, probe, word};
trait Slot: Copy + Default {
    const N: usize;
    fn set(w: u64, i: usize) -> Self;
    fn get(self) -> (u64, usize);
}
#[derive(Clone, Copy, Default)]
struct Compact<const W: usize>(u64);
impl<const W: usize> Slot for Compact<W> {
    const N: usize = W;
    #[inline(always)]
    fn set(w: u64, i: usize) -> Self {
        Self((w & ((1u64 << (8 * W)) - 1)) | (((i + 1) as u64) << (8 * W)))
    }
    #[inline(always)]
    fn get(self) -> (u64, usize) {
        (
            self.0 & ((1u64 << (8 * W)) - 1),
            ((self.0 >> (8 * W)) as usize).wrapping_sub(1),
        )
    }
}
#[derive(Clone, Copy, Default)]
struct Full {
    bytes: u64,
    next: usize,
}
impl Slot for Full {
    const N: usize = 8;
    #[inline(always)]
    fn set(w: u64, i: usize) -> Self {
        Self {
            bytes: w,
            next: i + 1,
        }
    }
    #[inline(always)]
    fn get(self) -> (u64, usize) {
        (self.bytes, self.next.wrapping_sub(1))
    }
}
#[inline(always)]
fn entry<S: Slot>(s: &[u8], i: usize, w: u64, slot: S) -> (usize, usize) {
    let (prefix, j) = slot.get();
    if j >= i {
        // The native zero-filled index initially points at position zero if
        // its eleven fingerprint bits match. Preserve that rare case.
        return probe(s, i, w, 0, (w as u32) << 21);
    }
    let d = prefix ^ w;
    if d as u32 != 0 {
        return (0, j);
    }
    let bits = d & (u64::MAX >> (64 - 8 * S::N));
    if bits != 0 {
        (bits.trailing_zeros() as usize / 8, j)
    } else {
        (S::N + common(s, j + S::N, i + S::N), j)
    }
}
#[inline(always)]
fn index<const P: usize, const B: usize>(w: u64) -> usize {
    ((w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize
}
fn parse<
    S: Slot,
    const P: usize,
    const B: usize,
    const PAIR: bool,
    const TAIL: usize,
    const SKIP: bool,
>(
    s: &[u8],
    archive: bool,
) -> Vec<u8> {
    let mut st = Streams::sized(s.len());
    let mut table = vec![S::default(); 1 << B];
    let (mut i, mut anchor) = (0, 0);
    while i + 8 <= s.len() {
        let w = word(s, i);
        let k = index::<P, B>(w);
        let new = S::set(w, i);
        let step = if SKIP {
            1 + usize::from(i - anchor >= 12) + usize::from(i - anchor >= 48)
        } else {
            1
        };
        let (mut n, mut j) = if PAIR && i + step + 8 <= s.len() {
            let b = word(s, i + step);
            let k1 = index::<P, B>(b);
            let a = table[k];
            let a1 = if k1 == k { new } else { table[k1] };
            table[k] = new;
            let (n, j) = entry(s, i, w, a);
            if n > 4 || (n == 4 && i - j <= 12000) {
                (n, j)
            } else {
                i += step;
                table[k1] = S::set(b, i);
                entry(s, i, b, a1)
            }
        } else {
            entry(s, i, w, std::mem::replace(&mut table[k], new))
        };
        if n < 4 || (n == 4 && i - j > 12000) {
            i += step;
            continue;
        }
        let off = i - j;
        while i > anchor && j > 0 && s[i - 1] == s[j - 1] {
            i -= 1;
            j -= 1;
            n += 1
        }
        st.emit(s, anchor, i, n, off);
        i += n;
        anchor = i;
        for pos in i - TAIL..i {
            if pos + 8 <= s.len() {
                let v = word(s, pos);
                table[index::<P, B>(v)] = S::set(v, pos)
            }
        }
    }
    st.finish(s, anchor, archive)
}
pub(super) fn encode(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    macro_rules! variants {
        ($slot:ty,$m:expr) => {
            match $m {
                0 => parse::<$slot, 5, 15, true, 2, false>(s, archive),
                1 => parse::<$slot, 5, 15, false, 2, false>(s, archive),
                2 => parse::<$slot, 5, 14, true, 2, false>(s, archive),
                3 => parse::<$slot, 5, 14, false, 2, false>(s, archive),
                4 => parse::<$slot, 4, 14, true, 2, true>(s, archive),
                5 => parse::<$slot, 6, 14, true, 2, true>(s, archive),
                6 => parse::<$slot, 5, 15, true, 1, true>(s, archive),
                _ => parse::<$slot, 5, 13, false, 2, true>(s, archive),
            }
        };
    }
    match (mode - 1) / 8 {
        0 => variants!(Full, (mode - 1) % 8),
        1 => variants!(Compact<5>, (mode - 1) % 8),
        _ => variants!(Compact<4>, (mode - 1) % 8),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cached_key_reproduces_native_wire_including_initial_slot() {
        let mut r = 103u32;
        let mut buf = vec![0; 512];
        for i in 0..15000 {
            r = r.wrapping_mul(1664525).wrapping_add(1013904223);
            if i % 7 == 0 {
                buf.extend_from_slice(b"twelve plus eight!")
            } else {
                buf.push((r >> 24) as u8)
            }
        }
        for n in [0, 5, 8, 16, 600, buf.len()] {
            for arch in [false, true] {
                let original = super::super::quicktwo::encode(&buf[..n], arch);
                for m in [1, 2, 9, 10, 17, 18] {
                    assert_eq!(encode(&buf[..n], arch, m), original)
                }
            }
        }
    }
}
