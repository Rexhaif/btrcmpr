// Static successors for common literal words. Ranks are block-local; all rows
// travel with the archive. Independent segments let the decoder resolve several
// predecessor chains at once; the paired option has no chain beyond two words.
use super::{Numbers, numbers};
use crate::{Result, ans, bad, take, u32in};
const WIDTH: usize = 8;
const EMPTY: u32 = u32::MAX;
#[derive(Default, Clone, Copy)]
struct Counter {
    key: u64,
    count: u32,
}
pub(super) fn put(ids: &[u32], dict: usize, out: &mut Vec<u8>) {
    let rows = dict.min(crate::tuning("BTR_WORD_ROWS", 8192, 32, 32768));
    let pairs = crate::tuning("BTR_WORD_PAIRED", 0, 0, 1) != 0;
    let mut frequency = vec![0u32; dict];
    for &v in ids {
        frequency[v as usize] += 1;
    }
    let price: Vec<_> = frequency
        .iter()
        .map(|&n| ((ids.len() as f64 / n.max(1) as f64).log2() * 16.).round() as u32)
        .collect();
    let size = (ids.len() / 2).max(1024).next_power_of_two().min(1 << 20);
    let mut bins = vec![Counter::default(); size];
    for pair in ids.windows(2) {
        let [a, b] = [pair[0], pair[1]];
        if a as usize >= rows {
            continue;
        }
        let key = (u64::from(a) << 32) | u64::from(b);
        let c = &mut bins[super::hash(key, size - 1)];
        if c.key == key {
            c.count += 1;
        } else if c.count == 0 {
            *c = Counter { key, count: 1 };
        } else {
            c.count -= 1;
        }
    }
    let mut tables = vec![[EMPTY; WIDTH]; rows + 1];
    let mut gains = vec![[0u64; WIDTH]; rows];
    for c in bins {
        if c.count < 4 {
            continue;
        }
        let ctx = (c.key >> 32) as usize;
        let word = c.key as u32;
        let gain = u64::from(c.count) * u64::from(price[word as usize].saturating_sub(40));
        if gain < 480 {
            continue;
        }
        let slot = gains[ctx].partition_point(|&x| x >= gain);
        if slot < WIDTH {
            gains[ctx].copy_within(slot..WIDTH - 1, slot + 1);
            tables[ctx].copy_within(slot..WIDTH - 1, slot + 1);
            gains[ctx][slot] = gain;
            tables[ctx][slot] = word;
        }
    }
    out.extend((rows as u32).to_le_bytes());
    out.push(u8::from(pairs));
    let mut used = Vec::with_capacity(rows);
    let mut entries = Numbers::default();
    for row in &tables[..rows] {
        let k = row.iter().take_while(|&&v| v != EMPTY).count();
        used.push(k as u8);
        for &v in &row[..k] {
            entries.push(v);
        }
    }
    ans::put_tight(&used, out);
    entries.finish(out);
    let mut data = Numbers::default();
    let width = ids.len().div_ceil(8).max(1);
    for (i, &v) in ids.iter().enumerate() {
        let active = if pairs {
            i & 1 != 0
        } else {
            !i.is_multiple_of(width)
        };
        let c = if active {
            (ids[i - 1] as usize).min(rows)
        } else {
            rows
        };
        let rank = tables[c].iter().position(|&w| w == v);
        data.push(rank.map_or(v + WIDTH as u32, |x| x as u32));
    }
    data.finish(out);
}
pub(super) fn get(p: &mut &[u8], n: usize, dict: usize) -> Result<Vec<u32>> {
    let rows = u32in(p)?;
    let paired = take(p, 1)?[0];
    if rows > 32768 || rows > dict || paired > 1 {
        return Err(bad());
    }
    let used = crate::wordbase::plain(p, rows)?;
    if used.len() != rows || used.iter().any(|&v| usize::from(v) > WIDTH) {
        return Err(bad());
    }
    let need = used.iter().map(|&v| usize::from(v)).sum();
    let words = numbers(p, need)?;
    if words.len() != need || words.iter().any(|&v| v as usize >= dict) {
        return Err(bad());
    }
    let mut source = &words[..];
    let mut tables = vec![[EMPTY; WIDTH]; rows + 1];
    for (row, &k) in tables.iter_mut().zip(used.iter()) {
        let (a, b) = source.split_at(k as usize);
        row[..a.len()].copy_from_slice(a);
        source = b;
    }
    let data = numbers(p, n)?;
    let mut out = vec![0u32; data.len()];
    let resolve = |v: u32, state: usize| -> Result<u32> {
        let word = if v >= WIDTH as u32 {
            v - WIDTH as u32
        } else {
            tables[state.min(rows)][v as usize]
        };
        if word as usize >= dict {
            Err(bad())
        } else {
            Ok(word)
        }
    };
    if paired != 0 {
        for (input, dst) in data.chunks(2).zip(out.chunks_mut(2)) {
            let a = resolve(input[0], rows)?;
            dst[0] = a;
            if input.len() == 2 {
                dst[1] = resolve(input[1], a as usize)?;
            }
        }
    } else {
        let width = data.len().div_ceil(8);
        let mut state = [rows; 8];
        for j in 0..width {
            for (lane, s) in state.iter_mut().enumerate() {
                let at = lane * width + j;
                if at < data.len() {
                    let w = resolve(data[at], *s)?;
                    out[at] = w;
                    *s = w as usize;
                }
            }
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn predictions_across_segments_and_rare_ranks() {
        let mut words = vec![];
        for j in 0..3701 {
            words.extend([0, 3, 7, 8, (j * 7 % 194) as u32]);
        }
        let mut v = vec![];
        put(&words, 194, &mut v);
        let mut p = v.as_slice();
        assert_eq!(get(&mut p, words.len(), 194).unwrap(), words);
        assert!(p.is_empty());
        let end = v.len() - 1;
        assert!(get(&mut &v[..end], words.len(), 194).is_err());
    }
}
