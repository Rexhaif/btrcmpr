// Reorder complete records inside a block. The selector stream preserves
// their original order; records in the same class stay in input order.
use crate::{Result, bad, lz, take, u32in};
fn cp_lz(s: &[u8], level: u8) -> Vec<u8> {
    if level >= 10 {
        lz::optimal(s, level)
    } else {
        lz::encode_level::<false>(s, level)
    }
}
pub(crate) fn encode(src: &[u8], level: u8, kind: u8) -> Vec<u8> {
    let mut groups: [Vec<u8>; 256] = std::array::from_fn(|_| vec![]);
    let mut sel = Vec::with_capacity(src.len() / 58);
    let drop = kind == 0;
    for line in src.split_inclusive(|&c| c == 10) {
        let a = line[0];
        let content = &line[line
            .iter()
            .position(|&b| b != 32 && b != 9)
            .unwrap_or(line.len())..];
        let b = content.first().copied().unwrap_or(32);
        let c = content.get(1).copied().unwrap_or(0);
        let id = match kind {
            0 => a,
            1 => {
                if b.is_ascii_alphanumeric() {
                    0
                } else {
                    b
                }
            }
            2 => {
                if b.is_ascii_alphabetic() && line.len() > 72 {
                    0
                } else {
                    b.wrapping_mul(17) ^ c.rotate_left(3)
                }
            }
            3 => {
                let mut h = 0u32;
                for &v in content.iter().take(5) {
                    h = h.wrapping_mul(257).wrapping_add(v as u32);
                }
                (h.wrapping_mul(0x9e3779b1) >> 26) as u8
            }
            _ => unreachable!(),
        };
        sel.push(id);
        let g = &mut groups[id as usize];
        g.extend(&line[drop as usize..]);
        if !line.ends_with(b"\n") {
            g.push(10);
        }
    }
    let n = sel.len();
    let mut out = vec![20, drop as u8, (!src.ends_with(b"\n")) as u8];
    out.extend((n as u32).to_le_bytes());
    for g in &groups {
        let mut k = g.len();
        while k >= 128 {
            out.push(k as u8 | 128);
            k >>= 7;
        }
        out.push(k as u8);
    }
    for g in groups {
        sel.extend(g);
    }
    let data = cp_lz(&sel, level);
    out.extend((sel.len() as u32).to_le_bytes());
    if data.len() > sel.len() {
        out.push(0);
        out.extend(sel);
    } else {
        out.extend(data);
    }
    out
}
#[inline]
fn lf(s: &[u8]) -> Option<usize> {
    let mut i = 0;
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use std::arch::aarch64::*;
        let delim = vdupq_n_u8(10);
        while i + 16 <= s.len() {
            let a = vceqq_u8(vld1q_u8(s.as_ptr().add(i)), delim);
            let m = vget_lane_u64::<0>(vreinterpret_u64_u8(vshrn_n_u16::<4>(
                vreinterpretq_u16_u8(a),
            )));
            if m != 0 {
                return Some(i + (m.trailing_zeros() as usize / 4));
            }
            i += 16;
        }
    }
    s[i..].iter().position(|&c| c == 10).map(|j| i + j)
}
pub(crate) fn decode(mut p: &[u8], d: &mut [u8]) -> Result<()> {
    let f = take(&mut p, 2)?;
    if f[0] > 1 || f[1] > 1 {
        return Err(bad());
    }
    let drop = f[0] != 0;
    let extra = f[1] != 0;
    let n = u32in(&mut p)?;
    if n > d.len() {
        return Err(bad());
    }
    let mut sizes = [0usize; 256];
    for v in &mut sizes {
        *v = crate::lz::lenin(&mut p)?;
    }
    let total = u32in(&mut p)?;
    if total != d.len() + usize::from(extra) + if drop { 0 } else { n }
        || sizes.iter().sum::<usize>() + n != total
        || total > crate::MAX_WIDE_BLOCK * 2 + 1
    {
        return Err(bad());
    }
    let mut tmp = vec![0; total];
    let (&kind, body) = p.split_first().ok_or_else(bad)?;
    match kind {
        0 if body.len() == total => tmp.copy_from_slice(body),
        1 => lz::decode(body, &mut tmp)?,
        13 => lz::decode_impl::<true>(body, &mut tmp)?,
        16 => lz::decode_min::<false, 3>(body, &mut tmp)?,
        17 => lz::decode_min::<true, 3>(body, &mut tmp)?,
        _ => return Err(bad()),
    }
    let (sel, mut rest) = tmp.split_at(n);
    let mut buckets: [&[u8]; 256] = [&[]; 256];
    for (b, sz) in buckets.iter_mut().zip(sizes) {
        *b = take(&mut rest, sz)?;
    }
    let mut out = d;
    for (i, &id) in sel.iter().enumerate() {
        if drop {
            let (v, r) = out.split_first_mut().ok_or_else(bad)?;
            *v = id;
            out = r;
            if id == 10 {
                continue;
            }
        }
        let b = &mut buckets[id as usize];
        let len = lf(b).ok_or_else(bad)? + 1;
        let rec = take(b, len)?;
        let count = len - usize::from(extra && i + 1 == n);
        let (dst, r) = out.split_at_mut_checked(count).ok_or_else(bad)?;
        dst.copy_from_slice(&rec[..count]);
        out = r;
    }
    if !out.is_empty() || buckets.iter().any(|b| !b.is_empty()) {
        return Err(bad());
    }
    Ok(())
}
