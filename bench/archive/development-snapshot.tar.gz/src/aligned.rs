// One search position per machine word. Literal runs and match lengths count
// whole words, so no alignment bits are spent in either lengths or offsets.
use crate::{Result, ans, bad, lz, take};

#[inline(always)]
fn word(s: &[u8], i: usize) -> u32 {
    u32::from_le_bytes(s[4 * i..4 * i + 4].try_into().unwrap())
}
#[inline(always)]
fn extend(s: &[u8], i: usize, j: usize) -> usize {
    if word(s, i) != word(s, j) {
        0
    } else {
        1 + lz::common(s, 4 * j + 4, 4 * i + 4) / 4
    }
}
fn length(mut n: usize, out: &mut Vec<u8>) {
    while n >= 128 {
        out.push((n as u8) | 128);
        n >>= 7
    }
    out.push(n as u8)
}
fn split(raw: &[u8]) -> [Vec<u8>; 4] {
    let n = raw.len() / 4;
    let mut v: [Vec<u8>; 4] = std::array::from_fn(|_| vec![0; n]);
    let mut i = 0;
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use core::arch::aarch64::*;
        while i + 16 <= n {
            let x = vld4q_u8(raw.as_ptr().add(4 * i));
            for (p, b) in v.iter_mut().zip([x.0, x.1, x.2, x.3]) {
                vst1q_u8(p.as_mut_ptr().add(i), b)
            }
            i += 16;
        }
    }
    for j in i..n {
        for (k, p) in v.iter_mut().enumerate() {
            p[j] = raw[4 * j + k]
        }
    }
    v
}
fn join(v: &[std::borrow::Cow<'_, [u8]>; 4]) -> Vec<u8> {
    let n = v[0].len();
    let mut out = vec![0; 4 * n + 16];
    let mut i = 0;
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use core::arch::aarch64::*;
        while i + 16 <= n {
            let [a, b, c, d] = v.each_ref().map(|p| vld1q_u8(p.as_ptr().add(i)));
            vst4q_u8(out.as_mut_ptr().add(4 * i), uint8x16x4_t(a, b, c, d));
            i += 16
        }
    }
    for j in i..n {
        for k in 0..4 {
            out[4 * j + k] = v[k][j]
        }
    }
    out
}
pub(crate) fn put(s: &[u8], mode: usize, model: usize) -> Vec<u8> {
    let n = s.len() / 4;
    let bits = if mode & 1 != 0 { 15 } else { 13 };
    let mut single = vec![u32::MAX; 1 << bits];
    let use_pair = mode & 2 != 0;
    let mut pair = vec![u32::MAX; if use_pair { 1 << bits } else { 0 }];
    let (mut anchor, mut i, mut prev) = (0, 0, 1);
    let mut tag = Vec::with_capacity(n / 3);
    let mut len = Vec::new();
    let mut low = Vec::with_capacity(n / 3);
    let mut high = Vec::with_capacity(n / 3);
    let mut raw = Vec::with_capacity(s.len() / 2);
    let key = |w: u32| (w.wrapping_mul(0x9e3779b1) >> (32 - bits)) as usize;
    let min1 = if mode & 4 == 0 { 4096 } else { 65536 };
    while i < n {
        let w = word(s, i);
        let k = key(w);
        let mut last = std::mem::replace(&mut single[k], i as u32) as usize;
        let valid = |j: usize| j < i && i - j <= 65536;
        let mut m = if valid(last) { extend(s, i, last) } else { 0 };
        if use_pair && i + 1 < n {
            let key2 = key(w.rotate_left(11) ^ word(s, i + 1));
            let p = std::mem::replace(&mut pair[key2], i as u32) as usize;
            if valid(p) && p != last {
                let l = extend(s, i, p);
                if l > m {
                    m = l;
                    last = p
                }
            }
        }
        if mode & 8 != 0 && i >= prev && i - prev != last {
            let l = extend(s, i, i - prev);
            if l > m {
                m = l;
                last = i - prev
            }
        }
        if m == 0 || (m == 1 && i - last > min1) {
            i += 1;
            continue;
        }
        let dist = i - last;
        let run = i - anchor;
        raw.extend_from_slice(&s[4 * anchor..4 * i]);
        tag.push(((run.min(15) << 4) | (m - 1).min(15)) as u8);
        if run >= 15 {
            length(run - 15, &mut len)
        }
        if m >= 16 {
            length(m - 16, &mut len)
        }
        let off = if model & 1 != 0 {
            if prev == dist {
                0
            } else {
                dist - usize::from(dist > prev)
            }
        } else {
            dist - 1
        };
        low.push(off as u8);
        high.push((off >> 8) as u8);
        prev = dist;
        i += m;
        anchor = i;
        if m >= 2 {
            let end = i - 1;
            single[key(word(s, end))] = end as u32;
            if mode & 16 != 0 {
                for j in (i - m + 1..end).step_by(2) {
                    single[key(word(s, j))] = j as u32
                }
            }
        }
    }
    raw.extend_from_slice(&s[4 * anchor..4 * n]);
    let mut out = vec![60, (model & 1) as u8];
    out.extend(&s[4 * n..]);
    let enc = |v: &[u8], out: &mut Vec<u8>, force: bool| {
        if force {
            out.extend((v.len() as u32).to_le_bytes());
            out.push(0);
            out.extend(v)
        } else {
            ans::put_policy(v, out, 0.985)
        }
    };
    enc(&tag, &mut out, false);
    enc(&len, &mut out, false);
    enc(&low, &mut out, model & 2 != 0);
    enc(&high, &mut out, false);
    for (j, col) in split(&raw).iter().enumerate() {
        enc(col, &mut out, model & 4 != 0 && j == 0)
    }
    if out.len() > s.len() {
        out.clear();
        out.push(0);
        out.extend(s)
    }
    out
}
fn field<'a>(p: &mut &'a [u8], max: usize) -> Result<std::borrow::Cow<'a, [u8]>> {
    if !matches!(p.get(4), Some(0 | 1 | 2 | 4 | 5)) {
        return Err(bad());
    }
    ans::get(p, max)
}
#[inline(always)]
fn copy(dst: &mut [u8], d: usize, src: usize, ml: usize) {
    let mut k = (d - src).min(ml);
    dst.copy_within(src..src + k, d);
    while k < ml {
        let m = k.min(ml - k);
        dst.copy_within(d..d + m, d + k);
        k += m
    }
}
pub(crate) fn get(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let repeat = take(&mut p, 1)?[0];
    if repeat > 1 {
        return Err(bad());
    }
    let n = dst.len() / 4;
    let tail = take(&mut p, dst.len() % 4)?;
    let tag = field(&mut p, n)?;
    let lens = field(&mut p, n + 1)?;
    let mut lens = &*lens;
    let low = field(&mut p, tag.len())?;
    let high = field(&mut p, tag.len())?;
    if low.len() != tag.len() || high.len() != tag.len() {
        return Err(bad());
    }
    let planes = [
        field(&mut p, n)?,
        field(&mut p, n)?,
        field(&mut p, n)?,
        field(&mut p, n)?,
    ];
    let literals = planes[0].len();
    if !p.is_empty() || planes.iter().any(|x| x.len() != literals) {
        return Err(bad());
    }
    let raw = join(&planes);
    let (mut at, mut li, mut prev) = (0, 0, 1);
    for (j, &t) in tag.iter().enumerate() {
        let mut ll = usize::from(t >> 4);
        let mut ml = usize::from(t & 15) + 1;
        if ll == 15 {
            ll += lz::lenin(&mut lens)?
        }
        if ml == 16 {
            ml += lz::lenin(&mut lens)?
        }
        let d = at + ll;
        let end = d + ml;
        let v = usize::from(low[j]) | (usize::from(high[j]) << 8);
        let off = if repeat == 0 {
            v + 1
        } else if v == 0 {
            prev
        } else {
            v + usize::from(v >= prev)
        };
        prev = off;
        if end > n || off > d || li + ll > literals {
            return Err(bad());
        }
        let src = 4 * (d - off);
        let mut fast = false;
        #[cfg(target_arch = "aarch64")]
        if end + 4 <= n && ll <= 4 && ml <= 4 && off >= ml {
            use core::arch::aarch64::*;
            unsafe {
                if ll != 0 {
                    vst1q_u8(
                        dst.as_mut_ptr().add(4 * at),
                        vld1q_u8(raw.as_ptr().add(4 * li)),
                    )
                }
                let x = vld1q_u8(dst.as_ptr().add(src));
                vst1q_u8(dst.as_mut_ptr().add(4 * d), x);
            }
            fast = true
        }
        if !fast {
            dst[4 * at..4 * d].copy_from_slice(&raw[4 * li..4 * (li + ll)]);
            copy(dst, 4 * d, src, 4 * ml)
        }
        li += ll;
        at = end;
    }
    if !lens.is_empty() || n - at != literals - li {
        return Err(bad());
    }
    dst[4 * at..4 * n].copy_from_slice(&raw[4 * li..4 * literals]);
    dst[4 * n..].copy_from_slice(tail);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn whole_word_offsets_literal_planes_and_unaligned_file_tail() {
        let mut seed = 109u32;
        let mut data = Vec::new();
        for k in 0..24000 {
            seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
            let w = if k % 13 == 0 {
                seed
            } else if k % 5 == 0 {
                0xabef3333
            } else {
                0x98420000 | ((k % 23) as u32)
            };
            data.extend(w.to_le_bytes())
        }
        data.extend_from_within(128..831);
        data.extend([27, 63]);
        for len in [0, 1, 5, 128, 8193, data.len()] {
            for mode in [0, 2, 4, 8, 17, 31] {
                for model in [0, 1, 6] {
                    let frame = put(&data[..len], mode, model);
                    let mut dst = vec![99; len];
                    crate::decode(&frame, &mut dst).unwrap();
                    assert_eq!(dst, data[..len]);
                    if frame[0] == 60 {
                        assert!(get(&frame[1..frame.len() - 1], &mut dst).is_err())
                    }
                    if len > 8000 {
                        assert_eq!(frame[0], 60)
                    }
                }
            }
        }
    }
}
