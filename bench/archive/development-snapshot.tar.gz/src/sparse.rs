// The selection rule depends on input bytes, not the byte address: a repeated
// sequence has the same anchor points even when it moves. Build the references
// a tile ahead so the hash lookup is independent of greedy match decisions.
use crate::lz::{Streams, common, word};
#[inline(always)]
fn mask<const RULE: u8>(s: &[u8], at: usize) -> u64 {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use std::arch::aarch64::*;
        let p = s.as_ptr().add(at);
        let prev = vld1q_u8(p.sub(1));
        let c = vld1q_u8(p);
        let next = vld1q_u8(p.add(1));
        let mut yes = vcleq_u8(prev, vdupq_n_u8(32));
        let mix = veorq_u8(c, vshrq_n_u8::<1>(next));
        if RULE == 0 {
            yes = vorrq_u8(yes, vcltq_u8(c, vdupq_n_u8(65)));
        }
        if RULE == 1 || RULE == 2 {
            yes = vorrq_u8(
                yes,
                vceqq_u8(
                    vandq_u8(mix, vdupq_n_u8(if RULE == 1 { 7 } else { 3 })),
                    vdupq_n_u8(0),
                ),
            );
            yes = vorrq_u8(yes, vcltq_u8(c, vdupq_n_u8(48)));
        }
        if RULE == 3 {
            yes = vceqq_u8(vandq_u8(mix, vdupq_n_u8(1)), vdupq_n_u8(0));
        }
        vget_lane_u64::<0>(vreinterpret_u64_u8(vshrn_n_u16::<4>(vreinterpretq_u16_u8(
            yes,
        )))) & 0x1111111111111111
    }
    #[cfg(not(target_arch = "aarch64"))]
    {
        let mut out = 0u64;
        for j in 0..16 {
            let p = at + j;
            let c = s[p];
            let h = c ^ (s[p + 1] >> 1);
            let yes = match RULE {
                0 => s[p - 1] <= 32 || c < 65,
                1 => s[p - 1] <= 32 || h & 7 == 0 || c < 48,
                2 => s[p - 1] <= 32 || h & 3 == 0 || c < 48,
                _ => h & 1 == 0,
            };
            out |= u64::from(yes) << (4 * j);
        }
        out
    }
}
#[derive(Copy, Clone, Default)]
struct Hit {
    a: u32,
    b: u32,
}
pub(crate) fn encode<const RULE: u8, const W: u32, const B: u32, const EXTRA: bool>(
    s: &[u8],
) -> Vec<u8> {
    let mut table = vec![0u64; 1 << B];
    let mut short = if EXTRA { vec![0u64; 1 << B] } else { vec![] };
    let mut hits = [Hit::default(); 256];
    let mut st = Streams::sized(s.len());
    let mut anchor = 0;
    let mut pos = 1;
    while pos + 24 <= s.len() {
        let mut count = 0;
        for _ in 0..16 {
            if pos + 24 > s.len() {
                break;
            }
            let mut marks = mask::<RULE>(s, pos);
            while marks != 0 {
                let i = pos + marks.trailing_zeros() as usize / 4;
                marks &= marks - 1;
                let w = word(s, i);
                let key =
                    ((w << (64 - 8 * W)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize;
                let val = ((i as u64 + 1) << 32) | w as u32 as u64;
                let old = std::mem::replace(&mut table[key], val);
                let long_ok = (old ^ val) as u32 == 0 && old >> 32 != 0;
                let candidate = if EXTRA {
                    let k = (w as u32).wrapping_mul(0x9e3779b1) >> (32 - B);
                    let sh = std::mem::replace(&mut short[k as usize], val);
                    if long_ok {
                        old
                    } else if (sh ^ val) as u32 == 0 {
                        sh
                    } else {
                        0
                    }
                } else if long_ok {
                    old
                } else {
                    0
                };
                if candidate >> 32 != 0 {
                    hits[count] = Hit {
                        a: i as u32,
                        b: (candidate >> 32) as u32 - 1,
                    };
                    count += 1;
                }
            }
            pos += 16;
        }
        for h in &hits[..count] {
            let mut i = h.a as usize;
            if i < anchor {
                continue;
            }
            let mut p = h.b as usize;
            let off = i - p;
            let mut l = 4 + common(s, p + 4, i + 4);
            if l == 4 && off > 12000 {
                continue;
            }
            while i > anchor && p > 0 && s[i - 1] == s[p - 1] {
                i -= 1;
                p -= 1;
                l += 1;
            }
            st.emit(s, anchor, i, l, off);
            anchor = i + l;
        }
    }
    st.finish(s, anchor, false)
}
