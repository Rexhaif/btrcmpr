// At most four consecutive bytes can be speculatively inserted before a
// match decision: even a four-byte copy consumes every speculative start.
// Old entries are loaded before any writes. An intra-group bucket collision
// can hide a newer candidate, but can never produce a forward reference.
use super::{Streams, common, word};

#[inline(always)]
fn hash<const P: usize, const B: usize>(w: u64) -> usize {
    ((w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize
}
#[inline(always)]
fn length(s: &[u8], i: usize, w: u64, slot: u32) -> (usize, usize) {
    let pos = slot as usize & super::MASK;
    if pos >= i {
        return (0, 0);
    }
    // The caller has a complete word at i and pos is earlier.
    let d = unsafe { s.as_ptr().add(pos).cast::<u64>().read_unaligned() }.to_le() ^ w;
    let len = if d == 0 {
        8 + common(s, pos + 8, i + 8)
    } else {
        d.trailing_zeros() as usize / 8
    };
    if len < 4 || (len == 4 && i - pos > 12_000) {
        (0, 0)
    } else {
        (len, pos)
    }
}

#[inline(always)]
fn parse<const N: usize, const STRIDE: usize, const P: usize, const B: usize, const TAIL: usize>(
    s: &[u8],
    mut emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    const { assert!(N > 0 && (N - 1) * STRIDE < 4 && TAIL <= 2) };
    let mut table = vec![0u32; 1 << B];
    let (mut i, mut anchor) = (0, 0);
    while i + 8 + (N - 1) * STRIDE <= s.len() {
        let mut words = [0; N];
        let mut bucket = [0; N];
        let mut old = [0; N];
        let mut packed = [0; N];
        let mut mask = 0u32;
        for t in 0..N {
            let j = i + STRIDE * t;
            let w = word(s, j);
            let k = hash::<P, B>(w);
            words[t] = w;
            bucket[t] = k;
            old[t] = table[k];
            let sig = (w as u32) << 21;
            packed[t] = sig | j as u32;
            mask |= u32::from((old[t] ^ sig) <= super::MASK as u32) << t;
        }
        for t in 0..N {
            table[bucket[t]] = packed[t];
        }
        let mut accepted = false;
        while mask != 0 {
            let t = mask.trailing_zeros() as usize;
            mask &= mask - 1;
            let mut at = i + t * STRIDE;
            let (mut n, mut src) = length(s, at, words[t], old[t]);
            if n == 0 {
                continue;
            }
            let off = at - src;
            while at > anchor && src > 0 && s[at - 1] == s[src - 1] {
                at -= 1;
                src -= 1;
                n += 1;
            }
            emit(anchor, at, n, off);
            i = at + n;
            anchor = i;
            for j in i - TAIL..i {
                if j + 8 <= s.len() {
                    let w = word(s, j);
                    table[hash::<P, B>(w)] = (w as u32) << 21 | j as u32;
                }
            }
            accepted = true;
            break;
        }
        if !accepted {
            i += N * STRIDE;
        }
    }
    anchor
}
#[inline(always)]
pub(super) fn walk(s: &[u8], mode: usize, e: impl FnMut(usize, usize, usize, usize)) -> usize {
    match mode {
        1 => parse::<2, 1, 5, 15, 2>(s, e),
        2 => parse::<2, 1, 6, 15, 2>(s, e),
        3 => parse::<3, 1, 6, 15, 2>(s, e),
        4 => parse::<4, 1, 6, 15, 2>(s, e),
        5 => parse::<2, 2, 6, 15, 2>(s, e),
        6 => parse::<2, 2, 6, 15, 1>(s, e),
        7 => parse::<2, 3, 6, 15, 1>(s, e),
        8 => parse::<2, 1, 7, 14, 1>(s, e),
        9 => parse::<3, 1, 7, 14, 1>(s, e),
        10 => parse::<4, 1, 7, 14, 1>(s, e),
        11 => parse::<2, 2, 7, 14, 1>(s, e),
        _ => parse::<2, 3, 7, 14, 1>(s, e),
    }
}
pub(super) fn encode(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    let mut st = Streams::sized(s.len());
    let end = walk(s, mode, |a, i, n, o| st.emit(s, a, i, n, o));
    st.finish(s, end, archive)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn all_forward_insertions_precede_the_next_command() {
        let mut data = vec![0; 73];
        let mut r = 3353u32;
        for i in 0..26_000 {
            r = r.wrapping_mul(1664525).wrapping_add(1013904223);
            if i % 7 == 0 {
                data.extend_from_within(i / 8..i / 8 + i % 19 + 3);
            } else {
                data.push((r >> 24) as u8);
            }
        }
        data.extend_from_within(..23_000);
        for end in (0..=33).chain([301, 33001, data.len()]) {
            let s = &data[..end];
            for mode in 1..=12 {
                let mut prev = 0;
                let anchor = walk(s, mode, |a, i, n, off| {
                    assert_eq!(a, prev);
                    assert!(i >= a && n >= 4 && off > 0 && off <= i);
                    assert_eq!(s[i..i + n], s[i - off..i - off + n]);
                    prev = i + n;
                });
                assert_eq!(prev, anchor);
            }
        }
    }
}
