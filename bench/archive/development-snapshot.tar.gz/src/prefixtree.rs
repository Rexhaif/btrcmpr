// Each new suffix becomes its bucket's root. Repartition the old search path
// around it; untouched subtrees retain their lexicographic order.
pub(crate) struct Tree {
    roots: Vec<u32>,
    links: Vec<u32>,
}
impl Tree {
    pub(crate) fn new(n: usize) -> Self {
        Self {
            roots: vec![0; 1 << 17],
            links: vec![0; 2 * n],
        }
    }
    #[inline]
    pub(crate) fn insert<const DEPTH: usize>(&mut self, s: &[u8], p: usize) -> [u32; 2] {
        let w = crate::lz::word(s, p);
        let key = ((w << 40).wrapping_mul(0x9e3779b97f4a7c15) >> 47) as usize;
        let mut cur = std::mem::replace(&mut self.roots[key], p as u32 + 1);
        let mut left = 2 * p;
        let mut right = left + 1;
        let (mut lower, mut upper) = (0usize, 0usize);
        let (mut best, mut out) = (2, [u32::MAX; 2]);
        let cap = (s.len() - p).min(64);
        for _ in 0..DEPTH {
            if cur == 0 {
                break;
            }
            let q = (cur - 1) as usize;
            let mut l = lower.min(upper);
            while l + 8 <= cap {
                let diff = crate::lz::word(s, p + l) ^ crate::lz::word(s, q + l);
                l += diff.trailing_zeros() as usize / 8;
                if diff != 0 {
                    break;
                }
            }
            while l < cap && s[p + l] == s[q + l] {
                l += 1;
            }
            if l > best {
                out = [cur - 1, out[0]];
                best = l;
            }
            if l == cap {
                self.links[left] = self.links[2 * q];
                self.links[right] = self.links[2 * q + 1];
                return out;
            }
            if s[q + l] < s[p + l] {
                self.links[left] = cur;
                left = 2 * q + 1;
                cur = self.links[left];
                lower = l;
            } else {
                self.links[right] = cur;
                right = 2 * q;
                cur = self.links[right];
                upper = l;
            }
        }
        self.links[left] = 0;
        self.links[right] = 0;
        out
    }
}

// The shortest-path parser indexes every position. For the middle settings,
// try keeping only a stride of suffixes inside accepted matches and a short
// lookahead at each decision. This trades search coverage for fewer tree walks.
#[cfg(feature = "research")]
pub(crate) fn lazy<const D: usize, const STRIDE: usize, const AHEAD: usize>(s: &[u8]) -> Vec<u8> {
    use crate::lz::{Streams, common, word};
    #[inline(always)]
    fn probe<const D: usize>(
        tree: &mut Tree,
        s: &[u8],
        i: usize,
        recent: usize,
    ) -> (usize, usize, isize) {
        let w = word(s, i);
        let pair = tree.insert::<D>(s, i);
        let repeat = i.checked_sub(recent).map_or(u32::MAX, |x| x as u32);
        let mut best = (0, 0, 0);
        for j in [pair[0], pair[1], repeat] {
            if j >= i as u32 {
                continue;
            }
            let j = j as usize;
            let d = i - j;
            let diff = w ^ word(s, j);
            let n = if diff == 0 {
                8 + common(s, j + 8, i + 8)
            } else {
                diff.trailing_zeros() as usize / 8
            };
            if n < 4 || (n == 4 && d > 16_384 && d != recent) {
                continue;
            }
            let score = 6 * n as isize
                - if d == recent {
                    0
                } else {
                    d.ilog2() as isize + 2
                };
            if score > best.2 {
                best = (n, d, score);
            }
        }
        best
    }
    let mut t = Tree::new(s.len());
    let mut st = Streams::sized(s.len());
    let (mut i, mut anchor) = (0, 0);
    while i + 8 <= s.len() {
        let base = i;
        let (mut n, mut d, mut value) = probe::<D>(&mut t, s, i, st.rep[0]);
        i += 1;
        if n == 0 {
            continue;
        }
        let mut at = base;
        if n < 48 {
            for k in 1..=AHEAD {
                if i + 8 > s.len() {
                    break;
                }
                let (len, off, price) = probe::<D>(&mut t, s, i, st.rep[0]);
                if price - 6 * k as isize > value {
                    (at, n, d, value) = (i, len, off, price - 6 * k as isize);
                }
                i += 1;
            }
        }
        let end = at + n;
        while at > anchor && at > d && s[at - 1] == s[at - d - 1] {
            at -= 1;
            n += 1;
        }
        st.emit(s, anchor, at, n, d);
        let cap = end.min(s.len() - 7);
        let tail = cap.saturating_sub(2).max(i);
        for j in (i..tail).step_by(STRIDE) {
            t.insert::<D>(s, j);
        }
        for j in tail..cap {
            t.insert::<D>(s, j);
        }
        (i, anchor) = (end, end);
    }
    st.finish(s, anchor, false)
}
