// Restore word widths first. A word match then becomes one byte copy from the
// final output, even when the spellings contain different numbers of bytes.
use super::Vocabulary;
use crate::{Result, bad};

#[derive(Clone, Copy, Default)]
struct Command {
    begin: u32,
    start: u32,
    end: u32,
    src: u32,
    li: u32,
}
fn each(
    tags: &[u8],
    mut ex: &[u8],
    dist: &[u32],
    nt: usize,
    nlit: usize,
    mut run: impl FnMut(&[Command]) -> Result<()>,
) -> Result<(usize, usize)> {
    if dist.len() != tags.len() {
        return Err(bad());
    }
    let (mut at, mut li) = (0usize, 0usize);
    let mut commands = [Command::default(); 32];
    for (ts, ds) in tags.chunks(32).zip(dist.chunks(32)) {
        for (k, (&t, &off)) in ts.iter().zip(ds).enumerate() {
            let mut ll = usize::from(t >> 4);
            let mut ml = usize::from(t & 15) + 2;
            if ll == 15 {
                ll += crate::lz::lenin(&mut ex)?;
            }
            if ml == 17 {
                ml += crate::lz::lenin(&mut ex)?;
            }
            let d = off as usize + 1;
            if ll + ml > nt - at || ll > nlit - li || d > at + ll {
                return Err(bad());
            }
            let start = at + ll;
            let end = start + ml;
            commands[k] = Command {
                begin: at as u32,
                start: start as u32,
                end: end as u32,
                src: (start - d) as u32,
                li: li as u32,
            };
            at = end;
            li += ll;
        }
        run(&commands[..ts.len()])?;
    }
    if !ex.is_empty() || nt - at != nlit - li {
        return Err(bad());
    }
    Ok((at, li))
}
#[inline]
fn hint(p: *const u8) {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        core::arch::asm!("prfm pldl1keep, [{s}]",s=in(reg)p,options(readonly,nostack,preserves_flags));
    }
    #[cfg(not(target_arch = "aarch64"))]
    let _ = p;
}
struct Positions<const COMPACT: bool> {
    base: Vec<u32>,
    small: Vec<u8>,
}
impl<const COMPACT: bool> Positions<COMPACT> {
    fn build(width: &[u8]) -> (Self, usize) {
        let mut v = Self {
            base: Vec::with_capacity(if COMPACT {
                width.len().div_ceil(4) + 1
            } else {
                width.len() + 1
            }),
            small: vec![],
        };
        let mut sum = 0u32;
        if COMPACT {
            v.small = vec![0; width.len() + 1];
            for (i, group) in width.chunks(4).enumerate() {
                let beg = sum;
                v.base.push(beg);
                for (j, &n) in group.iter().enumerate() {
                    v.small[4 * i + j] = (sum - beg) as u8;
                    sum += u32::from(n);
                }
                if 4 * i + group.len() == width.len() && group.len() < 4 {
                    v.small[width.len()] = (sum - beg) as u8;
                }
            }
            if width.len().is_multiple_of(4) {
                v.base.push(sum);
            }
        } else {
            v.base.resize(width.len() + 1, 0);
            let mut j = 0;
            #[cfg(target_arch = "aarch64")]
            unsafe {
                use std::arch::aarch64::*;
                while j + 8 <= width.len() {
                    let mut a = vmovl_u8(vld1_u8(width.as_ptr().add(j)));
                    let z = vdupq_n_u16(0);
                    a = vaddq_u16(a, vextq_u16::<7>(z, a));
                    a = vaddq_u16(a, vextq_u16::<6>(z, a));
                    a = vaddq_u16(a, vextq_u16::<4>(z, a));
                    let base = vdupq_n_u32(sum);
                    let p = v.base.as_mut_ptr().add(j + 1);
                    vst1q_u32(p, vaddq_u32(base, vmovl_u16(vget_low_u16(a))));
                    vst1q_u32(p.add(4), vaddq_u32(base, vmovl_high_u16(a)));
                    sum += u32::from(vgetq_lane_u16::<7>(a));
                    j += 8;
                }
            }
            for (i, &w) in width.iter().enumerate().skip(j) {
                sum += u32::from(w);
                v.base[i + 1] = sum;
            }
        }
        (v, sum as usize)
    }
    #[inline(always)]
    fn at(&self, i: u32) -> usize {
        let i = i as usize;
        if COMPACT {
            self.base[i / 4] as usize + usize::from(self.small[i])
        } else {
            self.base[i] as usize
        }
    }
}
pub(super) fn decode<const COMPACT: bool>(
    dst: &mut [u8],
    nt: usize,
    tags: &[u8],
    ex: &[u8],
    dist: &[u32],
    v: &Vocabulary,
) -> Result<()> {
    let nl = v.tokens.len();
    let mut literal_widths: Vec<u8> = v.tokens.iter().map(|&d| (d as u8 & 63) + 1).collect();
    let rawlen = literal_widths
        .iter()
        .map(|&v| usize::from(v))
        .sum::<usize>();
    if rawlen > dst.len() {
        return Err(bad());
    }
    let mut raw = vec![0; rawlen + 16];
    super::expand(&v.tokens, &v.spell, &mut raw[..rawlen])?;
    literal_widths.extend([0; 16]);
    let mut widths = vec![0u8; nt + 16];
    let (at, li) = each(tags, ex, dist, nt, nl, |cs| {
        for c in cs {
            hint(unsafe { widths.as_ptr().add(c.src as usize) });
        }
        for c in cs {
            let a = c.begin as usize;
            let m = c.start as usize;
            let e = c.end as usize;
            let q = c.src as usize;
            let l = c.li as usize;
            if m != a {
                if m - a <= 16 {
                    unsafe {
                        crate::lz::copy16(
                            literal_widths.as_ptr().add(l),
                            widths.as_mut_ptr().add(a),
                        );
                    }
                } else {
                    widths[a..m].copy_from_slice(&literal_widths[l..l + m - a]);
                }
            }
            let n = e - m;
            let d = m - q;
            if n <= 16 && d >= n {
                unsafe {
                    crate::lz::copy16(widths.as_ptr().add(q), widths.as_mut_ptr().add(m));
                }
            } else {
                unsafe {
                    crate::lz::long_match(widths.as_mut_ptr().add(m), d, n);
                }
            }
        }
        Ok(())
    })?;
    widths[at..nt].copy_from_slice(&literal_widths[li..nl]);
    let (pos, size) = Positions::<COMPACT>::build(&widths[..nt]);
    if size != dst.len() {
        return Err(bad());
    }
    let mut raw_at = 0;
    let (last, _) = each(tags, ex, dist, nt, nl, |cs| {
        let mut spans = [(0usize, 0usize, 0usize, 0usize); 32];
        for (j, c) in cs.iter().enumerate() {
            let a = pos.at(c.begin);
            let m = pos.at(c.start);
            let q = pos.at(c.src);
            let e = pos.at(c.end);
            spans[j] = (a, m, q, e);
            if m - q >= 128 {
                hint(unsafe { dst.as_ptr().add(q) });
            }
        }
        for &(a, m, q, e) in &spans[..cs.len()] {
            let ll = m - a;
            let ml = e - m;
            let off = m - q;
            if ll > rawlen - raw_at || off == 0 {
                return Err(bad());
            }
            if e + 16 <= dst.len() {
                unsafe {
                    if ll != 0 {
                        if ll <= 16 {
                            crate::lz::copy16(raw.as_ptr().add(raw_at), dst.as_mut_ptr().add(a));
                        } else {
                            std::ptr::copy_nonoverlapping(
                                raw.as_ptr().add(raw_at),
                                dst.as_mut_ptr().add(a),
                                ll,
                            );
                        }
                    }
                    let d = dst.as_mut_ptr().add(m);
                    if ml <= 16 && off >= ml {
                        crate::lz::copy16(dst.as_ptr().add(q), d);
                    } else {
                        crate::lz::long_match(d, off, ml);
                    }
                }
            } else {
                dst[a..m].copy_from_slice(&raw[raw_at..raw_at + ll]);
                let k = ml.min(off);
                dst.copy_within(q..q + k, m);
                let mut have = k;
                while have < ml {
                    let k = (ml - have).min(have);
                    dst.copy_within(m..m + k, m + have);
                    have += k;
                }
            }
            raw_at += ll;
        }
        Ok(())
    })?;
    let at = pos.at(last as u32);
    if dst.len() - at != rawlen - raw_at {
        return Err(bad());
    }
    dst[at..].copy_from_slice(&raw[raw_at..rawlen]);
    Ok(())
}
// Read several previous word ends in parallel and translate all of them by the
// same byte displacement. Both arrays have eight initialized padding entries.
// If n<=8, trailing overstores are overwritten by later commands.
#[inline(always)]
unsafe fn shifted(src: *const u32, dst: *mut u32, n: usize, bias: u32) {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use std::arch::aarch64::*;
        let v = vdupq_n_u32(bias);
        if n <= 4 {
            vst1q_u32(dst, vaddq_u32(vld1q_u32(src), v));
            return;
        }
        if n <= 8 {
            let a = vaddq_u32(vld1q_u32(src), v);
            let b = vaddq_u32(vld1q_u32(src.add(4)), v);
            vst1q_u32(dst, a);
            vst1q_u32(dst.add(4), b);
            return;
        }
        let mut j = 0;
        while j + 4 <= n {
            let x = vaddq_u32(vld1q_u32(src.add(j)), v);
            vst1q_u32(dst.add(j), x);
            j += 4;
        }
        while j < n {
            *dst.add(j) = (*src.add(j)).wrapping_add(bias);
            j += 1;
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    unsafe {
        for j in 0..n {
            *dst.add(j) = (*src.add(j)).wrapping_add(bias);
        }
    }
}
pub(super) fn direct(
    dst: &mut [u8],
    nt: usize,
    tags: &[u8],
    ex: &[u8],
    dist: &[u32],
    v: &Vocabulary,
) -> Result<()> {
    let widths: Vec<_> = v.tokens.iter().map(|&b| (b as u8 & 63) + 1).collect();
    let (p, rawlen) = Positions::<false>::build(&widths);
    if rawlen > dst.len() {
        return Err(bad());
    }
    let mut limits = p.base;
    limits.extend([0; 8]);
    let mut raw = vec![0; rawlen + 16];
    super::expand(&v.tokens, &v.spell, &mut raw[..rawlen])?;
    let mut pos = vec![0u32; nt + 9];
    let (at, li) = each(tags, ex, dist, nt, v.tokens.len(), |cs| {
        for cmd in cs {
            hint(unsafe { pos.as_ptr().add(cmd.src as usize).cast() });
        }
        let mut spans = [(0usize, 0usize, 0usize, 0usize, 0usize); 32];
        for (j, c) in cs.iter().enumerate() {
            let (a, m, e, q, l) = (
                c.begin as usize,
                c.start as usize,
                c.end as usize,
                c.src as usize,
                c.li as usize,
            );
            let start = pos[a];
            let rawat = limits[l];
            let ll = m - a;
            if ll > 0 {
                unsafe {
                    shifted(
                        limits.as_ptr().add(l + 1),
                        pos.as_mut_ptr().add(a + 1),
                        ll,
                        start.wrapping_sub(rawat),
                    );
                }
            }
            let begin = pos[m];
            let source = pos[q];
            let bias = begin - source;
            let n = e - m;
            let off = m - q;
            if off >= n {
                unsafe {
                    shifted(
                        pos.as_ptr().add(q + 1),
                        pos.as_mut_ptr().add(m + 1),
                        n,
                        bias,
                    );
                }
            } else {
                // Copy one full period at a time so every loaded logical word
                // end belongs to a previously established part of the output.
                let mut k = 0;
                while k < n {
                    let step = off.min(n - k);
                    unsafe {
                        shifted(
                            pos.as_ptr().add(q + 1 + k),
                            pos.as_mut_ptr().add(m + 1 + k),
                            step,
                            bias,
                        );
                    }
                    k += step;
                }
            }
            let end = pos[e];
            if end as usize > dst.len() || source >= begin {
                return Err(bad());
            }
            if bias >= 128 {
                hint(unsafe { dst.as_ptr().add(source as usize) });
            }
            spans[j] = (
                start as usize,
                rawat as usize,
                begin as usize,
                source as usize,
                end as usize,
            );
        }
        for &(a, l, m, q, e) in &spans[..cs.len()] {
            let (ll, ml, off) = (m - a, e - m, m - q);
            if e + 16 <= dst.len() {
                unsafe {
                    if ll != 0 {
                        if ll <= 16 {
                            crate::lz::copy16(raw.as_ptr().add(l), dst.as_mut_ptr().add(a));
                        } else {
                            std::ptr::copy_nonoverlapping(
                                raw.as_ptr().add(l),
                                dst.as_mut_ptr().add(a),
                                ll,
                            );
                        }
                    }
                    let d = dst.as_mut_ptr().add(m);
                    if ml <= 16 && off >= ml {
                        crate::lz::copy16(dst.as_ptr().add(q), d);
                    } else {
                        crate::lz::long_match(d, off, ml);
                    }
                }
            } else {
                dst[a..m].copy_from_slice(&raw[l..l + ll]);
                let k = ml.min(off);
                dst.copy_within(q..q + k, m);
                let mut have = k;
                while have < ml {
                    let k = have.min(ml - have);
                    dst.copy_within(m..m + k, m + have);
                    have += k;
                }
            }
        }
        Ok(())
    })?;
    let a = pos[at] as usize;
    let l = limits[li] as usize;
    if dst.len() - a != rawlen - l {
        return Err(bad());
    }
    dst[a..].copy_from_slice(&raw[l..rawlen]);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn mixed_width_and_partial_groups() {
        let w = [
            64, 64, 64, 64, 1, 15, 7, 1, 64, 64, 64, 63, 53, 1, 1, 2, 32, 32, 23,
        ];
        for n in 0..=w.len() {
            let (a, sz) = Positions::<true>::build(&w[..n]);
            let (b, s2) = Positions::<false>::build(&w[..n]);
            assert_eq!(sz, s2);
            for i in 0..=n {
                assert_eq!(a.at(i as u32), b.at(i as u32));
            }
        }
    }

    #[test]
    fn copies_overlapping_token_periods_with_different_byte_widths() {
        let mut spell = Vec::from(&b"AabcdefXYZ"[..]);
        spell.extend([0; 64]);
        let v = super::super::Vocabulary {
            dict: vec![],
            spell,
            tokens: vec![0, (1 << 6) | 5, (7 << 6) | 2],
        };
        let mut expected = b"Aabcdef".repeat(13);
        expected.extend(b"XYZ");
        let mut buf = vec![0; expected.len()];
        for mode in 0..3 {
            let apply = |out: &mut [u8], distance: &[u32]| match mode {
                0 => decode::<false>(out, 27, &[0x2f], &[7], distance, &v),
                1 => decode::<true>(out, 27, &[0x2f], &[7], distance, &v),
                _ => direct(out, 27, &[0x2f], &[7], distance, &v),
            };
            buf.fill(0xdb);
            apply(&mut buf, &[1]).unwrap();
            assert_eq!(buf, expected);
            assert!(apply(&mut buf, &[2]).is_err());
        }
    }
}
