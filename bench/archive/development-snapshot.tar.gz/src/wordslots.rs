// A rank indexes the spelling directly. Common short words and their lengths
// share a fixed-width record; long words address the original spelling arena.
use super::Vocabulary;
use crate::{Result, bad};
#[inline]
fn hint(p: *const u8) {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        core::arch::asm!("prfm pldl1keep, [{p}]",p=in(reg)p,options(readonly,nostack,preserves_flags));
    }
    #[cfg(not(target_arch = "aarch64"))]
    let _ = p;
}
pub(super) fn expand<const N: usize, const AHEAD: usize>(
    v: &Vocabulary,
    ids: &[u32],
    dst: &mut [u8],
) -> Result<()> {
    let mut table = vec![[0u8; N]; v.dict.len()];
    for (&d, record) in v.dict.iter().zip(&mut table) {
        let n = 1 + (d as usize & 63);
        let q = (d >> 6) as usize;
        if n < N {
            record[..n].copy_from_slice(&v.spell[q..q + n]);
        } else {
            record[..4].copy_from_slice(&(q as u32).to_le_bytes());
        }
        record[N - 1] = n as u8;
    }
    let mut written = 0;
    for (part, tile) in ids.chunks(16).enumerate() {
        if AHEAD != 0 {
            let next = part * 16 + AHEAD;
            if next + 16 <= ids.len() {
                for &rank in &ids[next..next + 16] {
                    // All ranks were checked before token runs were restored.
                    hint(unsafe { table.as_ptr().add(rank as usize).cast() });
                }
            }
        }
        let mut loaded = [[0u8; N]; 16];
        let mut pos = [0u32; 16];
        let mut end = written;
        for (i, &rank) in tile.iter().enumerate() {
            // The token LZ inverse copies already validated literal ranks.
            let rec = unsafe { *table.get_unchecked(rank as usize) };
            let n = usize::from(rec[N - 1]);
            pos[i] = end as u32;
            end += n;
            if AHEAD != 0 && n >= N {
                let q = u32::from_le_bytes(rec[..4].try_into().unwrap());
                hint(unsafe { v.spell.as_ptr().add(q as usize) });
            }
            loaded[i] = rec;
        }
        if end > dst.len() {
            return Err(bad());
        }
        if end + 64 <= dst.len() {
            unsafe {
                for (record, &at) in loaded[..tile.len()].iter().zip(&pos) {
                    let n = usize::from(record[N - 1]);
                    let d = dst.as_mut_ptr().add(at as usize);
                    if n < N {
                        std::ptr::copy_nonoverlapping(record.as_ptr(), d, N);
                    } else {
                        let s = v
                            .spell
                            .as_ptr()
                            .add(u32::from_le_bytes(record[..4].try_into().unwrap()) as usize);
                        crate::lz::copy16(s, d);
                        if n > 16 {
                            crate::lz::copy16(s.add(16), d.add(16));
                        }
                        if n > 32 {
                            crate::lz::copy16(s.add(32), d.add(32));
                            if n > 48 {
                                crate::lz::copy16(s.add(48), d.add(48));
                            }
                        }
                    }
                }
            }
        } else {
            for (record, &at) in loaded[..tile.len()].iter().zip(&pos) {
                let n = usize::from(record[N - 1]);
                let raw = if n < N {
                    &record[..n]
                } else {
                    let q = u32::from_le_bytes(record[..4].try_into().unwrap()) as usize;
                    &v.spell[q..q + n]
                };
                dst[at as usize..at as usize + n].copy_from_slice(raw);
            }
        }
        written = end;
    }
    if written != dst.len() {
        Err(bad())
    } else {
        Ok(())
    }
}
pub(super) fn policy(v: &Vocabulary, ids: &[u32], dst: &mut [u8], mode: usize) -> Result<()> {
    match mode {
        4 => expand::<16, 0>(v, ids, dst),
        5 => expand::<32, 0>(v, ids, dst),
        6 => expand::<16, 64>(v, ids, dst),
        7 => expand::<32, 64>(v, ids, dst),
        8 => expand::<16, 192>(v, ids, dst),
        _ => Err(bad()),
    }
}
