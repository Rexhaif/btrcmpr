// Only long repeated passages become byte copies. Other tokens retain the fast
// direct-spelling format. The copy lists are separate from the literal stream.
use super::super::super::{Numbers, Term, hash, numbers};
use super::super::{DecodeBook, read_root};
use crate::{Result, bad, u32in};
pub(super) fn choose(ids: &mut Vec<u32>, terms: &[Term], minimum: usize) -> Vec<u8> {
    let n = ids.len();
    if n < 8 || minimum == 0 {
        return vec![];
    }
    let mut pos = Vec::with_capacity(n + 1);
    pos.push(0u32);
    for &id in ids.iter() {
        pos.push(pos.last().unwrap() + u32::from(terms[id as usize].len));
    }
    let mask = (n / 2).next_power_of_two().clamp(2048, 1 << 20) - 1;
    let mut table = vec![[u32::MAX; 2]; mask + 1];
    let mut triples = vec![u32::MAX; mask + 1];
    let keys = |i: usize| {
        let pair = (u64::from(ids[i]) << 32) | u64::from(ids[i + 1]);
        (
            hash(pair, mask),
            hash(
                pair.rotate_left(19) ^ u64::from(ids[i + 2]).wrapping_mul(0x9e3779b97f4a7c15),
                mask,
            ),
        )
    };
    let (mut ll, mut ml, mut dist) = (Numbers::default(), Numbers::default(), Numbers::default());
    let (mut anchor, mut i, mut literals, mut count) = (0, 0, vec![], 0);
    let mut literal_bytes = 0u32;
    while i + 2 < n {
        let (a, b) = keys(i);
        let prior = table[a];
        table[a] = [i as u32, prior[0]];
        let t = std::mem::replace(&mut triples[b], i as u32);
        let (mut best, mut src) = (0usize, 0usize);
        for q in [prior[0], prior[1], t] {
            let q = q as usize;
            if q >= i || ids[q] != ids[i] || ids[q + 1] != ids[i + 1] {
                continue;
            }
            let mut k = 2;
            while k < 512 && i + k < n && ids[i + k] == ids[q + k] {
                k += 1
            }
            if k > best || (k == best && q > src) {
                best = k;
                src = q
            }
        }
        if best < 2 || (pos[i + best] - pos[i]) < minimum as u32 {
            i += 1;
            continue;
        }
        let l = pos[i] - pos[anchor];
        literal_bytes += l;
        ll.push(l);
        ml.push(pos[i + best] - pos[i] - 4);
        dist.push(pos[i] - pos[src] - 1);
        literals.extend_from_slice(&ids[anchor..i]);
        count += 1;
        let end = i + best;
        for j in i + 1..end.min(n.saturating_sub(2)) {
            let (a, b) = keys(j);
            table[a] = [j as u32, table[a][0]];
            triples[b] = j as u32;
        }
        i = end;
        anchor = i;
    }
    if count == 0 {
        return vec![];
    }
    literal_bytes += pos[n] - pos[anchor];
    literals.extend_from_slice(&ids[anchor..]);
    *ids = literals;
    let mut wire = literal_bytes.to_le_bytes().to_vec();
    ll.finish(&mut wire);
    ml.finish(&mut wire);
    dist.finish(&mut wire);
    wire
}
fn replay(mut plan: &[u8], literal: &[u8], dst: &mut [u8]) -> Result<()> {
    let limit = dst.len() / 4;
    let ll = numbers(&mut plan, limit)?;
    let ml = numbers(&mut plan, limit)?;
    let off = numbers(&mut plan, limit)?;
    if !plan.is_empty() || ll.is_empty() || ll.len() != ml.len() || ll.len() != off.len() {
        return Err(bad());
    }
    let (mut p, mut d) = (0, 0);
    for ((l, m), dist) in ll.into_iter().zip(ml).zip(off) {
        let l = l as usize;
        let m = (m as usize).checked_add(4).ok_or_else(bad)?;
        let back = (dist as usize).checked_add(1).ok_or_else(bad)?;
        if l > literal.len() - p || l > dst.len() - d {
            return Err(bad());
        }
        dst[d..d + l].copy_from_slice(&literal[p..p + l]);
        p += l;
        d += l;
        if back > d || m > dst.len() - d {
            return Err(bad());
        }
        let first = m.min(back);
        dst.copy_within(d - back..d - back + first, d);
        let mut done = first;
        while done < m {
            let step = done.min(m - done);
            dst.copy_within(d..d + step, d + done);
            done += step
        }
        d += m;
    }
    if dst.len() - d != literal.len() - p {
        return Err(bad());
    }
    dst[d..].copy_from_slice(&literal[p..]);
    Ok(())
}
pub(super) fn decode(
    mut plan: &[u8],
    root: &[u8],
    nt: usize,
    book: &DecodeBook,
    dst: &mut [u8],
) -> Result<()> {
    let n = u32in(&mut plan)?;
    if n == 0 || n > dst.len() {
        return Err(bad());
    }
    let mut literal = vec![0; n];
    read_root::<false>(root, nt, book, &mut literal)?;
    replay(plan, &literal, dst)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn long_sparse_copies_keep_the_literal_stream_and_allow_overlaps() {
        let mut raw = vec![];
        for i in 0..500 {
            raw.extend_from_slice(b"abcdeabcdeabcde0123456789");
            raw.push((i % 13) as u8);
        }
        raw.extend(vec![b'x'; 1500]);
        let (v, mut ids) = crate::wordbase::tokenize(&raw, 0);
        let terms: Vec<_> = v
            .iter()
            .map(|t| Term {
                pos: t.pos,
                len: t.len,
            })
            .collect();
        let wire = choose(&mut ids, &terms, 24);
        assert!(!wire.is_empty());
        let mut literals = vec![];
        for id in ids {
            let t = terms[id as usize];
            literals.extend_from_slice(&raw[t.pos as usize..t.pos as usize + usize::from(t.len)])
        }
        let mut p = wire.as_slice();
        assert_eq!(u32in(&mut p).unwrap(), literals.len());
        let mut out = vec![0; raw.len()];
        replay(p, &literals, &mut out).unwrap();
        assert_eq!(out, raw);
        assert!(replay(&p[..p.len() - 1], &literals, &mut out).is_err());
    }
}
