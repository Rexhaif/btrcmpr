// Try issuing independent lookups from two parts of a block before resolving
// either parse. There is still just one native LZ/literal stream on disk.
use super::{MASK, Streams, common, probe, word};

#[derive(Copy, Clone, Default)]
struct Command {
    at: usize,
    len: usize,
    off: usize,
}

#[derive(Copy, Clone)]
struct Probe {
    w: u64,
    w1: u64,
    old: u32,
    old1: u32,
    sig: u32,
    sig1: u32,
    k1: usize,
}

struct Lane<'a, const RIGHT: bool> {
    src: &'a [u8],
    table: Box<[u32]>,
    st: Streams,
    at: usize,
    anchor: usize,
    head: [Command; 3],
    count: usize,
}

#[inline(always)]
fn key<const PREFIX: usize, const BITS: usize>(w: u64) -> (usize, u32) {
    (
        ((w << (64 - 8 * PREFIX)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - BITS)) as usize,
        (w as u32).wrapping_mul(0x9e3779b1) << 21,
    )
}

impl<'a, const RIGHT: bool> Lane<'a, RIGHT> {
    fn new(s: &'a [u8], start: usize, bits: usize) -> Self {
        Self {
            src: s,
            table: vec![0; 1 << bits].into_boxed_slice(),
            st: Streams::sized(s.len() - start),
            at: start,
            anchor: start,
            head: [Command::default(); 3],
            count: 0,
        }
    }
    fn seed<const P: usize, const B: usize>(&mut self, step: usize, reach: usize) {
        if step == 0 {
            return;
        }
        for i in (self.at.saturating_sub(reach)..self.at.min(self.src.len().saturating_sub(7)))
            .step_by(step)
        {
            let (k, sig) = key::<P, B>(word(self.src, i));
            self.table[k] = sig | i as u32;
        }
    }
    #[inline(always)]
    fn prepare<const P: usize, const B: usize>(&mut self) -> Probe {
        let i = self.at;
        let w = word(self.src, i);
        let w1 = word(self.src, i + 1);
        let (k, sig) = key::<P, B>(w);
        let (k1, sig1) = key::<P, B>(w1);
        let here = sig | i as u32;
        let old = self.table[k];
        let old1 = if k1 == k { here } else { self.table[k1] };
        self.table[k] = here;
        Probe {
            w,
            w1,
            old,
            old1,
            sig,
            sig1,
            k1,
        }
    }
    #[inline(always)]
    fn diff(&self, g: Probe) -> (u64, usize) {
        let q = g.old as usize & MASK;
        if (g.old ^ g.sig) > MASK as u32 || q >= self.at {
            (u64::MAX, 0)
        } else {
            // q < at and prepare checked that at+9 <= src.len().
            let prev = unsafe { self.src.as_ptr().add(q).cast::<u64>().read_unaligned() }.to_le();
            (prev ^ g.w, q)
        }
    }
    #[inline(always)]
    fn hint(&self, g: Probe) {
        #[cfg(target_arch = "aarch64")]
        for (slot, sig) in [(g.old, g.sig), (g.old1, g.sig1)] {
            let q = slot as usize & MASK;
            if (slot ^ sig) <= MASK as u32 && q < self.at {
                unsafe {
                    core::arch::asm!("prfm pldl1keep, [{p}]",p=in(reg) self.src.as_ptr().add(q),options(nostack,readonly,preserves_flags));
                }
            }
        }
        #[cfg(not(target_arch = "aarch64"))]
        let _ = g;
    }
    #[inline(always)]
    fn apply<const P: usize, const B: usize, const T: usize>(
        &mut self,
        g: Probe,
        (diff, old): (u64, usize),
    ) {
        let i = self.at;
        let n = if diff != 0 {
            (diff.trailing_zeros() / 8) as usize
        } else {
            8 + common(self.src, old + 8, i + 8)
        };
        if n > 4 || (n == 4 && i - old <= 12000) {
            self.commit::<P, B, T>(n, old);
        } else {
            self.at = i + 1;
            self.table[g.k1] = g.sig1 | self.at as u32;
            let (n, q) = probe(self.src, self.at, g.w1, g.old1, g.sig1);
            self.commit::<P, B, T>(n, q);
        }
    }
    #[inline(always)]
    fn commit<const P: usize, const B: usize, const T: usize>(
        &mut self,
        mut len: usize,
        mut q: usize,
    ) {
        let mut i = self.at;
        if len < 4 || (len == 4 && i - q > 12000) {
            self.at = i + 1;
            return;
        }
        let off = i - q;
        while i > self.anchor && q > 0 && self.src[i - 1] == self.src[q - 1] {
            i -= 1;
            q -= 1;
            len += 1;
        }
        if RIGHT && self.count < 3 {
            self.head[self.count] = Command { at: i, len, off };
            self.count += 1;
            self.st.rep = [off, self.st.rep[0], self.st.rep[1]];
        } else {
            self.st.emit(self.src, self.anchor, i, len, off);
        }
        self.at = i + len;
        self.anchor = self.at;
        for j in self.at - T..self.at {
            if j + 8 <= self.src.len() {
                let (k, sig) = key::<P, B>(word(self.src, j));
                self.table[k] = sig | j as u32;
            }
        }
    }
    fn drain<const P: usize, const B: usize, const T: usize>(&mut self) {
        while self.at + 9 <= self.src.len() {
            let g = self.prepare::<P, B>();
            let d = self.diff(g);
            self.apply::<P, B, T>(g, d);
        }
        if self.at + 8 == self.src.len() {
            let w = word(self.src, self.at);
            let (k, sig) = key::<P, B>(w);
            let (n, q) = probe(self.src, self.at, w, self.table[k], sig);
            self.commit::<P, B, T>(n, q);
        }
    }
}

fn inner<const P: usize, const B: usize, const T: usize>(
    s: &[u8],
    archive: bool,
    mode: usize,
    step: usize,
    reach: usize,
) -> Vec<u8> {
    let mid = if mode == 1 { s.len() } else { s.len() / 2 };
    let mut a = Lane::<false>::new(&s[..mid], 0, B);
    if mode == 1 {
        a.drain::<P, B, T>();
        return a.st.finish(s, a.anchor, archive);
    }
    let mut b = Lane::<true>::new(s, mid, B);
    b.seed::<P, B>(step, reach);
    if mode >= 3 {
        while a.at + 9 <= mid && b.at + 9 <= s.len() {
            let ga = a.prepare::<P, B>();
            let gb = b.prepare::<P, B>();
            if mode == 4 {
                a.hint(ga);
                b.hint(gb);
            }
            if mode == 5 {
                let da = a.diff(ga);
                a.apply::<P, B, T>(ga, da);
                let db = b.diff(gb);
                b.apply::<P, B, T>(gb, db);
            } else {
                let da = a.diff(ga);
                let db = b.diff(gb);
                a.apply::<P, B, T>(ga, da);
                b.apply::<P, B, T>(gb, db);
            }
        }
    }
    a.drain::<P, B, T>();
    b.drain::<P, B, T>();
    // The first right literal run must include the left trailing literals.
    // Re-emitting three distances also makes subsequent repeat/delta codes
    // independent of the initial right-lane history.
    let mut last = a.anchor;
    for c in &b.head[..b.count] {
        a.st.emit(s, last, c.at, c.len, c.off);
        last = c.at + c.len;
    }
    if !b.st.tag.is_empty() {
        a.st.tag.append(&mut b.st.tag);
        a.st.offs.append(&mut b.st.offs);
        a.st.lits.append(&mut b.st.lits);
        a.st.lens.append(&mut b.st.lens);
        a.st.low.append(&mut b.st.low);
        a.st.mid.append(&mut b.st.mid);
        a.st.far.append(&mut b.st.far);
        last = b.anchor;
    }
    a.st.finish(s, last, archive)
}

pub(super) fn encode(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    let step = crate::tuning("BTR_LANE_STEP", 0, 0, 64);
    let reach = crate::tuning("BTR_LANE_REACH", 64, 1, 512) * 1024;
    match crate::tuning("BTR_LANE_KEY", 0, 0, 3) {
        1 => inner::<6, 15, 2>(s, archive, mode, step, reach),
        2 => inner::<7, 14, 1>(s, archive, mode, step, reach),
        3 => inner::<5, 14, 1>(s, archive, mode, step, reach),
        _ => inner::<5, 15, 2>(s, archive, mode, step, reach),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn merging_two_match_histories_restores_every_byte() {
        let mut z = 9317u32;
        let mut v = Vec::new();
        for i in 0..16000 {
            z = z.wrapping_mul(1664525).wrapping_add(1013904223);
            v.push((z >> 24) as u8);
            if i % 8 == 0 {
                v.extend_from_slice(b"abc_from_xyz_from_foo_");
            }
        }
        v.extend_from_within(..19001);
        let mut zeros = vec![0u8; 1000];
        zeros.extend(0..=255);
        for s in [&v[..], &zeros] {
            for n in (0..20).chain([23, 75, 429, s.len()]) {
                for archive in [false, true] {
                    let s = &s[..n];
                    assert_eq!(
                        inner::<5, 15, 2>(s, archive, 1, 0, 1024),
                        super::super::quicktwo::encode(s, archive)
                    );
                    for step in [0, 3, 8] {
                        let frame = inner::<5, 15, 2>(s, archive, 2, step, 65536);
                        let mut dst = vec![0x7c; s.len()];
                        crate::decode(&frame, &mut dst).unwrap();
                        assert_eq!(dst, s);
                        for mode in 3..=5 {
                            assert_eq!(frame, inner::<5, 15, 2>(s, archive, mode, step, 65536));
                        }
                    }
                }
            }
        }
    }
}
