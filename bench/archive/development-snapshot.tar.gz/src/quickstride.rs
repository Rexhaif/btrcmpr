// Research level-1 parser: use one hash for both bucket and fingerprint.
// After a long literal run, skip positions instead of paying for two misses
// on every pair of bytes. A match still extends backwards into skipped bytes.
use super::{Streams, common, probe, word};
pub(super) fn flat(data: &[u8], archive: bool, policy: usize) -> bool {
    if data.len() < 8192 || policy == 0 {
        return false;
    }
    let cutoff = match (archive, policy) {
        (true, 1) => 166,
        (true, _) => 145,
        (false, 1) => 240,
        (false, _) => 212,
    };
    let limit = 1024 * 1023 / (2 * cutoff);
    let mut hist = [0usize; 256];
    let mut pairs = 0usize;
    for j in 0..32 {
        let at = j * (data.len() - 32) / 31;
        for &v in &data[at..at + 32] {
            pairs += hist[v as usize];
            hist[v as usize] += 1
        }
        if pairs > limit {
            return false;
        }
    }
    true
}
#[inline(always)]
fn key<const B: usize, const CRC: bool>(v: u64) -> (usize, u32) {
    #[cfg(all(target_arch = "aarch64", target_feature = "crc"))]
    if CRC {
        let z = unsafe { core::arch::aarch64::__crc32cd(0, v & 0x00ff_ffff_ffff) };
        return ((z >> (32 - B)) as usize, (z & 2047) << 21);
    }
    let z = (v << 24).wrapping_mul(0x9e3779b97f4a7c15);
    (
        (z >> (64 - B)) as usize,
        (((z >> (53 - B)) as u32) & 2047) << 21,
    )
}
#[inline(always)]
fn encode<const B: usize, const T: usize, const TAIL: usize, const CRC: bool, const REP: bool>(
    s: &[u8],
    archive: bool,
) -> Vec<u8> {
    let mut st = Streams::sized(s.len());
    let mut tab = vec![0u32; 1 << B];
    let (mut i, mut anchor) = (0usize, 0usize);
    while i + 8 <= s.len() {
        let v = word(s, i);
        let back = st.rep[0];
        let (mut n, mut q) = if REP && i == anchor && i >= back && word(s, i - back) == v {
            (8 + common(s, i - back + 8, i + 8), i - back)
        } else {
            let step = if T == usize::MAX {
                1
            } else {
                1 + usize::from(i - anchor >= T) + usize::from(i - anchor >= T.saturating_mul(4))
            };
            let (k, sig) = key::<B, CRC>(v);
            let next = i + step;
            let here = sig | i as u32;
            if next + 8 <= s.len() {
                let b = word(s, next);
                let (j, h) = key::<B, CRC>(b);
                let a = tab[k];
                let c = if k == j { here } else { tab[j] };
                tab[k] = here;
                let (l, pos) = probe(s, i, v, a, sig);
                if l > 4 || (l == 4 && i - pos <= 12000) {
                    (l, pos)
                } else {
                    i = next;
                    tab[j] = h | i as u32;
                    let (l, pos) = probe(s, i, b, c, h);
                    if l < 4 || (l == 4 && i - pos > 12000) {
                        i += step;
                        continue;
                    }
                    (l, pos)
                }
            } else {
                let old = std::mem::replace(&mut tab[k], here);
                probe(s, i, v, old, sig)
            }
        };
        if n < 4 || (n == 4 && i - q > 12000) {
            i += 1;
            continue;
        }
        let off = i - q;
        while i > anchor && q > 0 && s[i - 1] == s[q - 1] {
            i -= 1;
            q -= 1;
            n += 1
        }
        st.emit(s, anchor, i, n, off);
        i += n;
        anchor = i;
        for j in i - TAIL..i {
            if j + 8 <= s.len() {
                let (k, sig) = key::<B, CRC>(word(s, j));
                tab[k] = sig | j as u32
            }
        }
    }
    st.finish(s, anchor, archive)
}
pub(super) fn trial(s: &[u8], archive: bool, policy: usize) -> Vec<u8> {
    match policy {
        1 => encode::<15, { usize::MAX }, 2, false, false>(s, archive),
        2 => encode::<16, 8, 2, false, false>(s, archive),
        3 => encode::<16, 4, 1, false, false>(s, archive),
        4 => encode::<16, 4, 1, true, false>(s, archive),
        5 => encode::<17, 8, 2, true, true>(s, archive),
        6 => encode::<16, 2, 1, true, true>(s, archive),
        7 => encode::<16, 8, 2, true, false>(s, archive),
        8 => encode::<15, 4, 1, true, false>(s, archive),
        9 => encode::<17, 4, 1, false, false>(s, archive),
        _ => encode::<17, 4, 2, false, true>(s, archive),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn literal_skips_overlapping_matches_and_tiny_tails_all_roundtrip() {
        let mut raw = vec![];
        let mut state = 19u32;
        for j in 0..1800 {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            raw.push((state >> 24) as u8);
            if j % 21 == 0 {
                raw.extend([b'p'; 46])
            }
        }
        for p in 1..=10 {
            for end in (0..17).chain([raw.len()]) {
                let v = trial(&raw[..end], false, p);
                let mut out = vec![0; end];
                crate::decode(&v, &mut out).unwrap();
                assert_eq!(out, raw[..end]);
            }
        }
    }
}
