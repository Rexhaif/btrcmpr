// Store an aligned source position in 16 bits. Every query is on an arbitrary
// byte boundary: match confirmation restores the unaligned prefix backwards.
// Indexing the previous tile has no dependency on the current parse.
use super::{common, word};
#[inline(always)]
fn key<const P: usize, const B: usize>(w: u64) -> usize {
    ((w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize
}
#[inline(always)]
fn tag(w: u64) -> u8 {
    (w ^ (w >> 27)) as u8
}
struct Table<const B: usize, const S: usize, const TAG: bool> {
    slot: Vec<u16>,
    tag: Vec<u8>,
}
impl<const B: usize, const S: usize, const TAG: bool> Table<B, S, TAG> {
    fn new() -> Self {
        Self {
            slot: vec![0; 1 << B],
            tag: if TAG { vec![0; 1 << B] } else { vec![] },
        }
    }
    #[inline(always)]
    fn set<const P: usize>(&mut self, s: &[u8], at: usize) {
        let w = word(s, at);
        let h = key::<P, B>(w);
        self.slot[h] = (at >> S) as u16;
        if TAG {
            self.tag[h] = tag(w)
        }
    }
    #[inline(always)]
    fn get<const P: usize>(&self, at: usize, w: u64) -> (usize, bool) {
        let h = key::<P, B>(w);
        let raw = self.slot[h] as usize;
        let units = ((at >> S).wrapping_sub(raw)) & 65535;
        let d = (units << S) | (at & ((1 << S) - 1));
        (
            at.wrapping_sub(d),
            d != 0 && d <= at && (!TAG || self.tag[h] == tag(w)),
        )
    }
}
#[inline(always)]
fn verify<const MIN: usize>(s: &[u8], i: usize, w: u64, h: (usize, bool)) -> Option<(usize, u64)> {
    if !h.1 {
        return None;
    }
    let d = word(s, h.0) ^ w;
    if d << (64 - 8 * MIN) != 0 || (MIN == 4 && (d >> 32) & 255 != 0 && i - h.0 > 12000) {
        None
    } else {
        Some((h.0, d))
    }
}
fn parse<
    const P: usize,
    const B: usize,
    const S: usize,
    const TILE: usize,
    const TAG: bool,
    const SKIP: usize,
    const MIN: usize,
>(
    s: &[u8],
    mut emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    let mut tab = Table::<B, S, TAG>::new();
    let mut i = 0usize;
    let mut anchor = 0usize;
    let mut seeded = 0usize;
    let mut boundary = 0usize;
    while i + 9 <= s.len() {
        if i >= boundary {
            let front = i & !(TILE - 1);
            let start = if SKIP == 2 {
                seeded.max(front.saturating_sub(2 * TILE))
            } else {
                seeded
            };
            for pos in (start..front).step_by(1 << S) {
                tab.set::<P>(s, pos)
            }
            seeded = front;
            boundary = front + TILE;
        }
        let w = word(s, i);
        let w1 = word(s, i + 1);
        let first = tab.get::<P>(i, w);
        let next = tab.get::<P>(i + 1, w1);
        let found = if let Some(h) = verify::<MIN>(s, i, w, first) {
            Some((i, h))
        } else {
            verify::<MIN>(s, i + 1, w1, next).map(|h| (i + 1, h))
        };
        let Some((at, (q, d))) = found else {
            i += if SKIP == 1 && i - anchor >= 12 { 3 } else { 2 };
            continue;
        };
        let n = if d != 0 {
            d.trailing_zeros() as usize / 8
        } else {
            8 + common(s, q + 8, at + 8)
        };
        let mut back = 0;
        while back < at - anchor && back < q && s[at - back - 1] == s[q - back - 1] {
            back += 1
        }
        emit(anchor, at - back, n + back, at - q);
        i = at + n;
        anchor = i;
    }
    anchor
}
pub(super) fn walk(s: &[u8], mode: usize, emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    macro_rules! x {
        ($p:literal,$b:literal,$s:literal,$t:literal,$f:literal,$q:literal,$m:literal) => {
            parse::<$p, $b, $s, $t, $f, $q, $m>(s, emit)
        };
    }
    match mode {
        1 => x!(5, 14, 1, 32, false, 0, 4),
        2 => x!(5, 14, 1, 32, true, 0, 4),
        3 => x!(6, 14, 1, 32, false, 0, 4),
        4 => x!(6, 14, 1, 32, true, 0, 4),
        5 => x!(5, 14, 2, 32, false, 0, 4),
        6 => x!(5, 14, 2, 32, true, 0, 4),
        7 => x!(6, 14, 2, 32, false, 0, 4),
        8 => x!(6, 14, 2, 32, true, 0, 4),
        9 => x!(6, 13, 2, 32, true, 0, 4),
        10 => x!(6, 15, 2, 32, true, 0, 4),
        11 => x!(5, 15, 2, 16, true, 0, 4),
        12 => x!(5, 15, 2, 64, true, 0, 4),
        13 => x!(6, 15, 2, 64, true, 1, 5),
        14 => x!(6, 15, 2, 64, true, 2, 5),
        15 => x!(6, 15, 3, 32, true, 0, 4),
        16 => x!(7, 14, 1, 16, true, 2, 5),
        17 => x!(7, 14, 2, 16, true, 0, 4),
        18 => x!(7, 13, 2, 32, false, 0, 4),
        19 => x!(6, 15, 1, 16, false, 2, 5),
        _ => x!(6, 15, 1, 16, true, 2, 5),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arbitrary_query_alignment_wraps_prior_positions_and_restores_full_data() {
        let mut s = Vec::new();
        let mut r = 912343u32;
        for i in 0..283_097 {
            r = r.wrapping_mul(1664525).wrapping_add(1013904223);
            let b = if i > 65_561 && i % 301 < 210 {
                s[i - 65_561]
            } else if i > 38 && i % 119 < 83 {
                s[i - 37]
            } else {
                (r >> 24) as u8
            };
            s.push(b)
        }
        for mode in 1..=20 {
            let mut v = Vec::with_capacity(s.len());
            let mut copied = 0;
            let end = walk(&s, mode, |a, i, n, d| {
                assert_eq!(v.len(), a);
                v.extend_from_slice(&s[a..i]);
                assert!(d > 0 && d <= i);
                for _ in 0..n {
                    v.push(v[v.len() - d])
                }
                copied += n;
            });
            v.extend_from_slice(&s[end..]);
            assert!(copied > s.len() / 4);
            assert_eq!(v, s);
        }
    }
}
