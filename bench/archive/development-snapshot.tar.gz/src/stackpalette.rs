// Each position modulo 16 has its own bit stack. A stack always has a leading
// one at bit 8..15. When a push would overflow u16, save the low byte before
// pushing the next rank. The reader can tell when to refill from its state
// alone. Bytes flushed by a group are contiguous, in increasing lane order.
use super::Code;
use crate::{Result, bad, take, u32in};

fn scalar_push(state: &mut u16, c: Code) -> Option<u8> {
    let mut st = u32::from(*state);
    let digit = (st << c.width >= 65536).then_some(st as u8);
    if digit.is_some() {
        st >>= 8
    }
    *state = ((st << c.width) | u32::from(c.rank)) as u16;
    digit
}
fn partial<const K: usize>(
    data: &[u8],
    map: &[Code; 256],
    heads: &mut [u8],
    digits: &mut [u8],
    mut pos: usize,
    st: &mut [u16; 16],
) -> usize {
    let mut buf = [0; 16];
    let mut count = 0;
    for (j, &s) in data.iter().enumerate() {
        let c = map[s as usize];
        let p = j * K;
        heads[p / 8] |= c.head << (p % 8);
        if (p % 8) + K > 8 {
            heads[p / 8 + 1] |= c.head >> (8 - p % 8);
        }
        if let Some(b) = scalar_push(&mut st[j], c) {
            buf[count] = b;
            count += 1;
        }
    }
    pos -= count;
    digits[pos..pos + count].copy_from_slice(&buf[..count]);
    pos
}
fn encode<const K: usize>(
    data: &[u8],
    map: &[Code; 256],
    heads: &mut [u8],
    digits: &mut [u8],
    vector: bool,
) -> ([u16; 16], usize) {
    let full = data.len() / 16 * 16;
    let mut st = [256; 16];
    let mut p = partial::<K>(
        &data[full..],
        map,
        &mut heads[full * K / 8..],
        digits,
        digits.len(),
        &mut st,
    );
    #[cfg(target_arch = "aarch64")]
    if vector {
        p = unsafe { neon::encode::<K>(&data[..full], map, heads, digits, p, &mut st) };
        return (st, p);
    }
    let _ = vector;
    for i in (0..full).step_by(16).rev() {
        p = partial::<K>(
            &data[i..i + 16],
            map,
            &mut heads[i * K / 8..],
            digits,
            p,
            &mut st,
        );
    }
    (st, p)
}
pub(super) fn put(
    data: &[u8],
    out: &mut Vec<u8>,
    syms: &[u8],
    widths: &[u8],
    map: &[Code; 256],
    bits: u32,
    vector: bool,
) {
    let k = widths.len().ilog2() as usize;
    out.extend([60, k as u8, (syms.len() - 1) as u8]);
    out.extend(widths);
    out.extend(syms);
    let start = out.len();
    let h = (data.len() * k).div_ceil(8) + 16;
    // Sum(floor(bits in lane / 8)) <= floor(sum(bits) / 8);
    // eight extra bytes let the reverse writer use an overlapping full store.
    let cap = bits as usize / 8 + 8;
    out.resize(start + h + 36 + cap + 8, 0);
    let (heads, rest) = out[start..].split_at_mut(h);
    let (meta, digits) = rest.split_at_mut(36);
    let (st, p) = match k {
        1 => encode::<1>(data, map, heads, &mut digits[..cap], vector),
        2 => encode::<2>(data, map, heads, &mut digits[..cap], vector),
        3 => encode::<3>(data, map, heads, &mut digits[..cap], vector),
        4 => encode::<4>(data, map, heads, &mut digits[..cap], vector),
        _ => encode::<5>(data, map, heads, &mut digits[..cap], vector),
    };
    let n = cap - p;
    meta[..4].copy_from_slice(&(n as u32).to_le_bytes());
    for (dst, v) in meta[4..].chunks_exact_mut(2).zip(st) {
        dst.copy_from_slice(&v.to_le_bytes())
    }
    digits.copy_within(p..cap, 0);
    digits[n..n + 8].fill(0);
    out.truncate(start + h + 36 + n + 8);
}
struct Reader<'a> {
    heads: &'a [u8],
    digits: &'a [u8],
    limit: usize,
    state: [u16; 16],
    width: [u8; 32],
    base: [u8; 32],
    symbols: [u8; 256],
}
impl Reader<'_> {
    fn decode<const K: usize>(&mut self, dst: &mut [u8], vector: bool) -> Result<()> {
        let (mut i, mut p) = (0, 0);
        #[cfg(target_arch = "aarch64")]
        if vector {
            (i, p) = unsafe { neon::decode::<K>(self, dst) }?
        }
        let _ = vector;
        while i < dst.len() {
            let j = i % 16;
            let bit = i * K;
            let h = (u16::from_le_bytes(self.heads[bit / 8..bit / 8 + 2].try_into().unwrap())
                >> (bit % 8)) as usize
                & ((1 << K) - 1);
            let w = self.width[h];
            let st = self.state[j];
            let index = self.base[h].wrapping_add((st & ((1u16 << w) - 1)) as u8);
            dst[i] = self.symbols[index as usize];
            let mut value = st >> w;
            if value < 256 {
                if p >= self.limit {
                    return Err(bad());
                }
                value = (value << 8) | u16::from(self.digits[p]);
                p += 1;
            }
            self.state[j] = value;
            i += 1;
        }
        if p != self.limit || self.state.iter().any(|&st| st != 256) {
            return Err(bad());
        }
        Ok(())
    }
}
pub(crate) fn get(src: &mut &[u8], n: usize, vector: bool) -> Result<Vec<u8>> {
    let k = take(src, 1)?[0] as usize;
    if !(1..=5).contains(&k) {
        return Err(bad());
    }
    let count = take(src, 1)?[0] as usize + 1;
    let mut width = [0; 32];
    let mut base = [0; 32];
    let mut top = 0usize;
    for (j, &w) in take(src, 1 << k)?.iter().enumerate() {
        if w > 8 {
            return Err(bad());
        }
        width[j] = w;
        base[j] = top.min(255) as u8;
        top += 1 << w;
    }
    if top < count {
        return Err(bad());
    }
    let mut symbols = [0; 256];
    symbols[..count].copy_from_slice(take(src, count)?);
    let h = n
        .checked_mul(k)
        .and_then(|v| v.div_ceil(8).checked_add(16))
        .ok_or_else(bad)?;
    let heads = take(src, h)?;
    let limit = u32in(src)?;
    if limit > n {
        return Err(bad());
    }
    let mut state = [0; 16];
    for (v, s) in state.iter_mut().zip(take(src, 32)?.chunks_exact(2)) {
        *v = u16::from_le_bytes(s.try_into().unwrap());
        if *v < 256 {
            return Err(bad());
        }
    }
    let digits = take(src, limit.checked_add(8).ok_or_else(bad)?)?;
    let mut rd = Reader {
        heads,
        digits,
        limit,
        state,
        width,
        base,
        symbols,
    };
    let mut dst = vec![0; n];
    match k {
        1 => rd.decode::<1>(&mut dst, vector),
        2 => rd.decode::<2>(&mut dst, vector),
        3 => rd.decode::<3>(&mut dst, vector),
        4 => rd.decode::<4>(&mut dst, vector),
        _ => rd.decode::<5>(&mut dst, vector),
    }?;
    Ok(dst)
}

#[cfg(target_arch = "aarch64")]
mod neon {
    use super::{Code, Reader, Result, bad};
    use core::arch::aarch64::*;
    const fn shuffles(reverse: bool) -> [[u8; 8]; 256] {
        let mut lut = [[255; 8]; 256];
        let mut mask = 0usize;
        while mask < 256 {
            let mut j = 0;
            let mut at = 0;
            let off = 8 - mask.count_ones() as usize;
            while j < 8 {
                if mask >> j & 1 != 0 {
                    if reverse {
                        lut[mask][off + at] = j as u8
                    } else {
                        lut[mask][j] = at as u8
                    }
                    at += 1;
                }
                j += 1;
            }
            mask += 1;
        }
        lut
    }
    static PUSH: [[u8; 8]; 256] = shuffles(true);
    static POP: [[u8; 8]; 256] = shuffles(false);
    const WT: [u8; 8] = [1, 2, 4, 8, 16, 32, 64, 128];
    #[inline(always)]
    unsafe fn mask(v: uint16x8_t) -> usize {
        unsafe { vaddv_u8(vand_u8(vmovn_u16(v), vld1_u8(WT.as_ptr()))) as usize }
    }
    #[inline(always)]
    unsafe fn lookup(v: uint8x16_t, t: &[u8; 256]) -> uint8x16_t {
        unsafe {
            let mut s = vqtbl4q_u8(vld1q_u8_x4(t.as_ptr()), v);
            for j in [64, 128, 192] {
                s = vqtbx4q_u8(
                    s,
                    vld1q_u8_x4(t.as_ptr().add(j)),
                    vsubq_u8(v, vdupq_n_u8(j as u8)),
                )
            }
            s
        }
    }
    #[inline(always)]
    unsafe fn push(
        st: &mut uint16x8_t,
        ww: uint8x8_t,
        r: uint8x8_t,
        data: &mut [u8],
        pos: usize,
    ) -> usize {
        unsafe {
            let w = vreinterpretq_s16_u16(vmovl_u8(ww));
            let flush = vcgeq_u16(
                vshlq_u16(*st, vsubq_s16(w, vdupq_n_s16(8))),
                vdupq_n_u16(256),
            );
            let m = mask(flush);
            let bytes = vtbl1_u8(vmovn_u16(*st), vld1_u8(PUSH.get_unchecked(m).as_ptr()));
            // pos never drops below eight, due to the leading encoder guard.
            debug_assert!(pos >= 8 && pos <= data.len());
            vst1_u8(data.as_mut_ptr().add(pos - 8), bytes);
            let rem = vbslq_u16(flush, vshrq_n_u16::<8>(*st), *st);
            *st = vorrq_u16(vshlq_u16(rem, w), vmovl_u8(r));
            pos - m.count_ones() as usize
        }
    }
    #[inline(always)]
    unsafe fn heads<const K: usize>(v: uint8x16_t, to: &mut [u8]) {
        unsafe {
            let v = vreinterpretq_u16_u8(v);
            let a = vreinterpretq_u32_u16(vorrq_u16(
                vandq_u16(v, vdupq_n_u16(255)),
                vshlq_u16(vshrq_n_u16::<8>(v), vdupq_n_s16(K as i16)),
            ));
            let b = vreinterpretq_u64_u32(vorrq_u32(
                vandq_u32(a, vdupq_n_u32(65535)),
                vshlq_u32(vshrq_n_u32::<16>(a), vdupq_n_s32((2 * K) as i32)),
            ));
            let h = vorrq_u64(
                vandq_u64(b, vdupq_n_u64(u32::MAX as u64)),
                vshlq_u64(vshrq_n_u64::<32>(b), vdupq_n_s64((4 * K) as i64)),
            );
            to[..K].copy_from_slice(&vgetq_lane_u64::<0>(h).to_le_bytes()[..K]);
            to[K..2 * K].copy_from_slice(&vgetq_lane_u64::<1>(h).to_le_bytes()[..K]);
        }
    }
    pub(super) unsafe fn encode<const K: usize>(
        s: &[u8],
        codes: &[Code; 256],
        h: &mut [u8],
        digits: &mut [u8],
        mut p: usize,
        state: &mut [u16; 16],
    ) -> usize {
        unsafe {
            let mut hh = [0; 256];
            let mut rr = [0; 256];
            let mut ww = [0; 32];
            for (i, c) in codes.iter().enumerate() {
                hh[i] = c.head;
                rr[i] = c.rank;
            }
            // Unused entries in the encoder map all have width zero; do not let
            // them shadow a genuine nonzero width of group zero.
            for c in codes {
                ww[c.head as usize] = ww[c.head as usize].max(c.width);
            }
            let wtab = vld1q_u8_x2(ww.as_ptr());
            let mut a = vld1q_u16(state.as_ptr());
            let mut b = vld1q_u16(state.as_ptr().add(8));
            for i in (0..s.len()).step_by(16).rev() {
                let v = vld1q_u8(s.as_ptr().add(i));
                let head = lookup(v, &hh);
                let rank = lookup(v, &rr);
                let w = if K == 5 {
                    vqtbl2q_u8(wtab, head)
                } else {
                    vqtbl1q_u8(wtab.0, head)
                };
                heads::<K>(head, &mut h[i * K / 8..]);
                p = push(&mut b, vget_high_u8(w), vget_high_u8(rank), digits, p);
                p = push(&mut a, vget_low_u8(w), vget_low_u8(rank), digits, p);
            }
            vst1q_u16(state.as_mut_ptr(), a);
            vst1q_u16(state.as_mut_ptr().add(8), b);
            p
        }
    }
    #[inline(always)]
    unsafe fn pop(
        st: &mut uint16x8_t,
        w: uint8x8_t,
        d: &Reader<'_>,
        p: usize,
    ) -> Result<(usize, uint8x8_t)> {
        unsafe {
            let sw = vreinterpretq_s16_u16(vmovl_u8(w));
            let code = vandq_u16(
                *st,
                vsubq_u16(vshlq_u16(vdupq_n_u16(1), sw), vdupq_n_u16(1)),
            );
            let rem = vshlq_u16(*st, vnegq_s16(sw));
            let fill = vcltq_u16(rem, vdupq_n_u16(256));
            let m = mask(fill);
            let end = p + m.count_ones() as usize;
            if end > d.limit {
                return Err(bad());
            }
            // p <= limit and the payload has eight checked guard bytes.
            let src = vtbl1_u8(
                vld1_u8(d.digits.as_ptr().add(p)),
                vld1_u8(POP.get_unchecked(m).as_ptr()),
            );
            *st = vbslq_u16(fill, vorrq_u16(vshlq_n_u16::<8>(rem), vmovl_u8(src)), rem);
            Ok((end, vmovn_u16(code)))
        }
    }
    pub(super) unsafe fn decode<const K: usize>(
        d: &mut Reader<'_>,
        out: &mut [u8],
    ) -> Result<(usize, usize)> {
        unsafe {
            let idx: [u8; 16] = std::array::from_fn(|j| (j * K / 8) as u8);
            let shift: [i8; 16] = std::array::from_fn(|j| -((j * K % 8) as i8));
            let ix = vld1q_u8(idx.as_ptr());
            let sh = vld1q_s8(shift.as_ptr());
            let wt = vld1q_u8_x2(d.width.as_ptr());
            let bt = vld1q_u8_x2(d.base.as_ptr());
            let mut a = vld1q_u16(d.state.as_ptr());
            let mut b = vld1q_u16(d.state.as_ptr().add(8));
            let mut p = 0;
            let full = out.len() / 16 * 16;
            for i in (0..full).step_by(16) {
                let raw = vld1q_u8(d.heads.as_ptr().add(i * K / 8));
                let mut h = vshlq_u8(vqtbl1q_u8(raw, ix), sh);
                if K == 3 || K == 5 {
                    h = vorrq_u8(
                        h,
                        vshlq_u8(
                            vqtbl1q_u8(raw, vaddq_u8(ix, vdupq_n_u8(1))),
                            vaddq_s8(sh, vdupq_n_s8(8)),
                        ),
                    )
                }
                h = vandq_u8(h, vdupq_n_u8(((1 << K) - 1) as u8));
                let w = if K == 5 {
                    vqtbl2q_u8(wt, h)
                } else {
                    vqtbl1q_u8(wt.0, h)
                };
                let base = if K == 5 {
                    vqtbl2q_u8(bt, h)
                } else {
                    vqtbl1q_u8(bt.0, h)
                };
                let (mid, lo) = pop(&mut a, vget_low_u8(w), d, p)?;
                let (end, hi) = pop(&mut b, vget_high_u8(w), d, mid)?;
                p = end;
                let bytes = lookup(vaddq_u8(base, vcombine_u8(lo, hi)), &d.symbols);
                vst1q_u8(out.as_mut_ptr().add(i), bytes);
            }
            vst1q_u16(d.state.as_mut_ptr(), a);
            vst1q_u16(d.state.as_mut_ptr().add(8), b);
            Ok((full, p))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn scalar_and_vector_share_streams_and_reject_truncation() {
        let mut r = 381u32;
        for k in 1..=5 {
            let groups = 1usize << k;
            // Exercise zero-width, eight-width, and mixed flushes independently.
            for variant in 0..3 {
                let mut widths = vec![0u8; groups];
                let mut codes = [Code::default(); 256];
                let mut used = 0;
                for (g, w) in widths.iter_mut().enumerate() {
                    *w = if variant == 0 {
                        if g == 0 { 0 } else { 8 }
                    } else if variant == 1 {
                        4
                    } else {
                        (g % 7) as u8
                    };
                    let n = (1usize << *w).min(256 - used);
                    for (j, c) in codes[used..used + n].iter_mut().enumerate() {
                        *c = Code {
                            head: g as u8,
                            rank: j as u8,
                            width: *w,
                        }
                    }
                    used += n;
                }
                let sy: Vec<u8> = (0..used).map(|i| i as u8).collect();
                let data: Vec<u8> = (0..1579)
                    .map(|_| {
                        r = r.wrapping_mul(1664525).wrapping_add(1013904223);
                        ((r >> 16) as usize % used) as u8
                    })
                    .collect();
                for n in (1..=33).chain([1579]) {
                    let data = &data[..n];
                    let nb = data
                        .iter()
                        .map(|&s| u32::from(codes[s as usize].width))
                        .sum();
                    let mut scalar = Vec::new();
                    put(data, &mut scalar, &sy, &widths, &codes, nb, false);
                    let mut vec = Vec::new();
                    put(data, &mut vec, &sy, &widths, &codes, nb, true);
                    assert_eq!(scalar, vec, "width {k} length {n}");
                    for vector in [false, true] {
                        let mut p = &vec[1..];
                        assert_eq!(get(&mut p, n, vector).unwrap(), data);
                        assert!(p.is_empty());
                        assert!(get(&mut &vec[1..vec.len() - 1], n, vector).is_err());
                    }
                }
            }
        }
    }
    #[test]
    fn digit_underflow_and_invalid_start_state_are_rejected() {
        let mut m = [Code::default(); 256];
        m[1] = Code {
            head: 1,
            rank: 0,
            width: 7,
        };
        let mut stream = vec![];
        put(&[1; 33], &mut stream, &[0, 1], &[0, 7], &m, 231, true);
        let p = 3 + 2 + 2 + 33usize.div_ceil(8) + 16;
        let mut no_digits = stream.clone();
        no_digits[p..p + 4].fill(0);
        let mut bad_state = stream.clone();
        bad_state[p + 4..p + 6].fill(0);
        for vector in [true, false] {
            assert!(get(&mut &no_digits[1..], 33, vector).is_err());
            assert!(get(&mut &bad_state[1..], 33, vector).is_err());
        }
    }
}
