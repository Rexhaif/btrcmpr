// At a low preset, test a fixed table of whole prefixes at content-defined
// landmarks. One vector comparison finds up to 16 landmarks. Remembering
// positions even inside matches makes the anchor independent of the parse.
use super::{Streams, common, quicktwo, word};

struct Sink {
    streams: Streams,
    commands: usize,
    lows: usize,
    mids: usize,
    literals: usize,
}
impl Sink {
    fn new(n: usize) -> Self {
        let c = n / 4 + 2;
        let mut streams = Streams::new();
        streams.tag = Vec::with_capacity(c);
        streams.offs = Vec::with_capacity(c);
        streams.low = Vec::with_capacity(c + 16);
        streams.mid = Vec::with_capacity(c + 16);
        streams.lits = Vec::with_capacity(n + 16);
        Self {
            streams,
            commands: 0,
            lows: 0,
            mids: 0,
            literals: 0,
        }
    }
    // The trusted parser emits one nonoverlapping match of at least four
    // bytes per command. c therefore bounds selectors and both payload lanes.
    // Only the initialized prefix is exposed by finish(). Literals have 16
    // spare bytes for short writes. No compressed input enters this writer.
    #[inline(always)]
    fn emit(&mut self, s: &[u8], a: usize, i: usize, n: usize, off: usize) {
        debug_assert!(a <= i && n >= 4 && i + n <= s.len() && off >= 1 && off <= i);
        let count = self.commands;
        let ll = i - a;
        let ml = n - 4;
        let v = off + 19;
        let st = &mut self.streams;
        let code = if off == st.rep[0] {
            0
        } else if off == st.rep[1] {
            1
        } else if off == st.rep[2] {
            2
        } else if off.wrapping_sub(st.rep[0]).wrapping_add(8) <= 16 {
            3 + off.wrapping_sub(st.rep[0]).wrapping_add(8)
        } else if off <= 64 {
            19 + off
        } else if v < 32768 {
            84 + (v >> 8)
        } else {
            212 + (v >> 16)
        };
        debug_assert!(
            code < 255
                && count < st.tag.capacity()
                && self.lows < st.low.capacity()
                && self.mids < st.mid.capacity()
                && self.literals + ll <= s.len()
        );
        unsafe {
            st.tag
                .as_mut_ptr()
                .add(count)
                .write(((ll.min(15) << 4) | ml.min(15)) as u8);
            st.offs.as_mut_ptr().add(count).write(code as u8);
            st.low.as_mut_ptr().add(self.lows).write(v as u8);
            st.mid.as_mut_ptr().add(self.mids).write((v >> 8) as u8);
            let to = st.lits.as_mut_ptr().add(self.literals);
            if ll <= 8 && a + 8 <= s.len() {
                std::ptr::copy_nonoverlapping(s.as_ptr().add(a), to, 8);
            } else {
                std::ptr::copy_nonoverlapping(s.as_ptr().add(a), to, ll);
            }
        }
        self.commands += 1;
        self.lows += usize::from(code >= 84);
        self.mids += usize::from(code >= 212);
        self.literals += ll;
        if ll >= 15 {
            super::lenout(ll - 15, &mut st.lens)
        }
        if ml >= 15 {
            super::lenout(ml - 15, &mut st.lens)
        }
        st.rep = [off, st.rep[0], st.rep[1]];
    }
    fn finish(mut self, s: &[u8], anchor: usize, archive: bool) -> Vec<u8> {
        let st = &mut self.streams;
        unsafe {
            st.tag.set_len(self.commands);
            st.offs.set_len(self.commands);
            st.low.set_len(self.lows);
            st.mid.set_len(self.mids);
            st.lits.set_len(self.literals);
        }
        self.streams.finish(s, anchor, archive)
    }
}
#[inline(always)]
fn scalar<const KIND: usize>(a: u8, b: u8) -> bool {
    match KIND {
        0 => a <= 64,
        1 => a <= 64 || (a | 32) == b'e',
        2 => a.is_ascii_alphabetic() != b.is_ascii_alphabetic(),
        3 => a.wrapping_mul(109) ^ b.wrapping_mul(73) < 96,
        4 => a.wrapping_mul(109) ^ b.wrapping_mul(73) < 144,
        _ => true,
    }
}
#[inline(always)]
fn marks<const KIND: usize>(s: &[u8], i: usize) -> u64 {
    if KIND == 5 {
        return 0x1111111111111111;
    }
    #[cfg(target_arch = "aarch64")]
    if i + 17 <= s.len() {
        use core::arch::aarch64::*;
        unsafe {
            let a = vld1q_u8(s.as_ptr().add(i));
            let b = vld1q_u8(s.as_ptr().add(i + 1));
            let close = vcleq_u8(a, vdupq_n_u8(64));
            let alpha = |v| {
                vcltq_u8(
                    vsubq_u8(vorrq_u8(v, vdupq_n_u8(32)), vdupq_n_u8(b'a')),
                    vdupq_n_u8(26),
                )
            };
            let v = match KIND {
                0 => close,
                1 => vorrq_u8(
                    close,
                    vceqq_u8(vorrq_u8(a, vdupq_n_u8(32)), vdupq_n_u8(b'e')),
                ),
                2 => veorq_u8(alpha(a), alpha(b)),
                _ => vcltq_u8(
                    veorq_u8(vmulq_u8(a, vdupq_n_u8(109)), vmulq_u8(b, vdupq_n_u8(73))),
                    vdupq_n_u8(if KIND == 3 { 96 } else { 144 }),
                ),
            };
            return vget_lane_u64::<0>(vreinterpret_u64_u8(vshrn_n_u16::<4>(
                vreinterpretq_u16_u8(v),
            ))) & 0x1111111111111111;
        }
    }
    (0..16.min(s.len().saturating_sub(i + 1))).fold(0, |m, k| {
        m | ((scalar::<KIND>(s[i + k], s[i + k + 1]) as u64) << (4 * k))
    })
}
#[inline(always)]
fn backward(s: &[u8], mut i: usize, mut q: usize, anchor: usize) -> usize {
    let original = i;
    let max = (i - anchor).min(q);
    while original - i + 8 <= max {
        let d = word(s, i - 8) ^ word(s, q - 8);
        if d != 0 {
            return original - i + d.leading_zeros() as usize / 8;
        }
        i -= 8;
        q -= 8;
    }
    while original - i < max && s[i - 1] == s[q - 1] {
        i -= 1;
        q -= 1
    }
    original - i
}
fn walk<const KIND: usize, const B: usize, const FILL: bool>(s: &[u8], out: &mut Sink) -> usize {
    let mut tab = vec![0u64; 1 << B];
    let mut anchor = 0;
    let mut base = 0;
    while base + 8 <= s.len() {
        let mut mask = marks::<KIND>(s, base);
        let end = (s.len() - 7 - base).min(16);
        if end < 16 {
            mask &= (1u64 << (end * 4)) - 1
        }
        if !FILL && anchor > base {
            let skip = (anchor - base).min(16);
            mask = if skip == 16 {
                0
            } else {
                mask & (!0u64 << (skip * 4))
            };
        }
        while mask != 0 {
            let j = base + mask.trailing_zeros() as usize / 4;
            mask &= mask - 1;
            let w = word(s, j);
            let key = w as u32;
            let bucket = ((w << 24).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize;
            let slot =
                std::mem::replace(&mut tab[bucket], (u64::from(key) << 32) | ((j + 1) as u64));
            if j < anchor || (slot >> 32) as u32 != key || slot as u32 == 0 {
                continue;
            }
            let q = slot as u32 as usize - 1;
            let d = word(s, q) ^ w;
            let n = if d == 0 {
                8 + common(s, q + 8, j + 8)
            } else {
                d.trailing_zeros() as usize / 8
            };
            let back = backward(s, j, q, anchor);
            let dist = j - q;
            if n + back == 4 && dist > 12000 {
                continue;
            }
            out.emit(s, anchor, j - back, n + back, dist);
            anchor = j + n;
            if !FILL {
                let skip = (anchor - base).min(16);
                mask = if skip == 16 {
                    0
                } else {
                    mask & (!0u64 << (skip * 4))
                };
            }
        }
        if !FILL && anchor >= base + 16 {
            base = anchor
        } else {
            base += 16
        }
    }
    anchor
}
pub(super) fn encode(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    let mut out = Sink::new(s.len());
    let anchor = if mode == 1 {
        quicktwo::walk(s, |a, i, n, d| out.emit(s, a, i, n, d))
    } else {
        let variant = (mode - 2) / 6;
        macro_rules! go {
            ($k:literal) => {
                match variant {
                    0 => walk::<$k, 14, false>(s, &mut out),
                    1 => walk::<$k, 15, false>(s, &mut out),
                    2 => walk::<$k, 15, true>(s, &mut out),
                    _ => walk::<$k, 16, true>(s, &mut out),
                }
            };
        }
        match (mode - 2) % 6 {
            0 => go!(0),
            1 => go!(1),
            2 => go!(2),
            3 => go!(3),
            4 => go!(4),
            _ => go!(5),
        }
    };
    out.finish(s, anchor, archive)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn landmarks_and_unchecked_writer_roundtrip_short_offsets_long_literals_and_misses() {
        let mut data = vec![];
        let mut r = 199u32;
        for j in 0..1700 {
            r = r.wrapping_mul(1664525).wrapping_add(1013904223);
            data.push((r >> 24) as u8);
            if j % 13 == 0 {
                data.extend_from_slice(b"the remarkable quick brown fox.")
            }
            if j % 47 == 0 {
                data.extend([0u8; 36]);
            }
        }
        for n in (0..32).chain([data.len()]) {
            for mode in 1..=25 {
                let x = encode(&data[..n], false, mode);
                if mode == 1 {
                    assert_eq!(x, quicktwo::encode(&data[..n], false))
                }
                let mut y = vec![0; n];
                crate::decode(&x, &mut y).unwrap();
                assert_eq!(y, data[..n]);
            }
        }
    }
    #[test]
    fn vector_anchor_mask_matches_scalar() {
        let s: Vec<_> = (0..=255).map(|i| (i as u8).wrapping_mul(157)).collect();
        macro_rules! check {
            ($k:literal) => {
                for i in 0..s.len() - 16 {
                    let expected = (0..16).fold(0, |a, j| {
                        a | ((scalar::<$k>(s[i + j], s[i + j + 1]) as u64) << (4 * j))
                    });
                    assert_eq!(marks::<$k>(&s, i), expected)
                }
            };
        }
        check!(0);
        check!(1);
        check!(2);
        check!(3);
        check!(4);
        check!(5)
    }
}
