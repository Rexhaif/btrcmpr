// Bridge nearby exact runs at the same distance. The ordinary LZ decoder
// restores a normalized block; a small, ordered list then restores the
// differing bytes. Future references may safely address normalized history.
use crate::{Result, ans, bad, cascade, lz, u32in};
#[cfg(feature = "research")]
pub(crate) fn encode(s: &[u8], level: u8, archive: bool, policy: usize) -> Vec<u8> {
    let normal = |b: &[u8]| {
        if archive {
            lz::encode_level::<true>(b, level)
        } else if level >= 10 {
            lz::optimal(b, level)
        } else {
            lz::encode_level::<false>(b, level)
        }
    };
    if s.len() < 64 {
        return normal(s);
    }
    let mut data = s.to_vec();
    let mut pos = Vec::new();
    let mut vals = Vec::new();
    let nb = if archive { 16 } else { 17 };
    let mut table = vec![u32::MAX; 1 << nb];
    let hash = |b: &[u8], i| {
        ((lz::word(b, i) << 16).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - nb)) as usize
    };
    let env = policy.saturating_sub(1) % 6;
    let (hole, need) = [(1, 5), (2, 7), (3, 8), (4, 8), (2, 4), (1, 3)][env];
    let mut i = 0;
    let mut old = 0usize;
    while i + 16 <= s.len() {
        let h = hash(&data, i);
        let q = std::mem::replace(&mut table[h], i as u32) as usize;
        if q >= i {
            i += 1;
            continue;
        }
        let cap = (i - q).min(s.len() - i).min(1024);
        let run = |at: usize| {
            let mut k = at;
            while k + 8 <= cap {
                let x = lz::word(&data, i + k) ^ lz::word(&data, q + k);
                k += x.trailing_zeros() as usize / 8;
                if x != 0 {
                    return k;
                }
            }
            while k < cap && data[i + k] == data[q + k] {
                k += 1;
            }
            k
        };
        let first = run(0);
        if first < 6 {
            i += 1;
            continue;
        }
        let mut end = first;
        let mut diffs = [0u16; 48];
        let mut count = 0;
        while end + need < cap && count + hole <= diffs.len() {
            let mut choice = None;
            for gap in 1..=hole {
                if end + gap + need > cap {
                    break;
                }
                let next = run(end + gap);
                if next >= end + gap + need
                    && (next - end - gap >= need * gap || (count > 0 && gap == 1))
                {
                    choice = Some((gap, next));
                    break;
                }
            }
            let Some((gap, next)) = choice else {
                break;
            };
            for j in end..end + gap {
                if data[i + j] != data[q + j] {
                    diffs[count] = j as u16;
                    count += 1;
                }
            }
            end = next;
        }
        if count != 0 {
            for &k in &diffs[..count] {
                let at = i + k as usize;
                let diff = data[at] ^ data[q + k as usize];
                data[at] ^= diff;
                let mut step = at - old;
                while step >= 128 {
                    pos.push((step as u8) | 128);
                    step >>= 7;
                }
                pos.push(step as u8);
                vals.push(diff);
                old = at + 1;
            }
        }
        let jump = if count == 0 {
            first.saturating_sub(5).max(1)
        } else {
            end
        };
        for j in (i + 1..(i + jump).min(s.len() - 7)).step_by(3) {
            let h = hash(&data, j);
            table[h] = j as u32;
        }
        i += jump;
    }
    if vals.is_empty() {
        return normal(s);
    }
    let mut out = vec![32];
    out.extend((vals.len() as u32).to_le_bytes());
    ans::put_tight(&pos, &mut out);
    ans::put_tight(&vals, &mut out);
    out.extend(normal(&data));
    if policy >= 7 {
        let old = normal(s);
        if old.len() < out.len() {
            return old;
        }
    }
    out
}
pub(crate) fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let n = u32in(&mut p)?;
    if n > dst.len() {
        return Err(bad());
    }
    let pos = crate::lex::plain(&mut p, n * 4)?;
    let mut pos = &*pos;
    let vals = crate::lex::plain(&mut p, n)?;
    if vals.len() != n {
        return Err(bad());
    }
    let (&m, b) = p.split_first().ok_or_else(bad)?;
    cascade::expand_leaf(m, b, dst)?;
    let mut at = 0;
    for &v in vals.iter() {
        at += lz::lenin(&mut pos)?;
        let x = dst.get_mut(at).ok_or_else(bad)?;
        *x ^= v;
        at += 1;
    }
    if !pos.is_empty() {
        return Err(bad());
    }
    Ok(())
}
