// Every accepted candidate already has one full word at either end. Count
// short copies on both sides with straight-line word comparisons before the
// slow path. Confirmed endpoints and all emitted bytes remain unchanged.
use super::{common, word};
#[inline(always)]
pub(super) fn forward<const MODE: usize>(s: &[u8], q: usize, i: usize, d: u64) -> usize {
    if MODE & 3 == 0 || s.len() - i < 16 {
        return if d == 0 {
            8 + common(s, q + 8, i + 8)
        } else {
            d.trailing_zeros() as usize / 8
        };
    }
    let n = d.trailing_zeros() as usize / 8;
    let e = word(s, q + 8) ^ word(s, i + 8);
    let m = e.trailing_zeros() as usize / 8;
    let short = if n == 8 { 8 + m } else { n };
    if MODE & 3 == 2 && s.len() - i >= 24 {
        let z = word(s, q + 16) ^ word(s, i + 16);
        let k = z.trailing_zeros() as usize / 8;
        let n = if short == 16 { 16 + k } else { short };
        return if n == 24 {
            24 + common(s, q + 24, i + 24)
        } else {
            n
        };
    }
    if short == 16 {
        16 + common(s, q + 16, i + 16)
    } else {
        short
    }
}
#[inline(always)]
pub(super) fn backward<const MODE: usize>(s: &[u8], anchor: usize, q: usize, i: usize) -> usize {
    let max = (i - anchor).min(q);
    if MODE & 4 != 0 && q >= 8 && i >= 8 {
        let mut a = q;
        let mut b = i;
        let mut rem = max;
        loop {
            let n = (word(s, a - 8) ^ word(s, b - 8)).leading_zeros() as usize / 8;
            if n < 8 || rem <= 8 {
                return max - rem + n.min(rem);
            }
            a -= 8;
            b -= 8;
            rem -= 8;
            if a < 8 {
                break;
            }
        }
        let at = max - rem;
        for j in 0..rem {
            if s[i - at - j - 1] != s[q - at - j - 1] {
                return at + j;
            }
        }
        return max;
    }
    let mut n = 0;
    while n < max && s[i - n - 1] == s[q - n - 1] {
        n += 1
    }
    n
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn speculative_reads_handle_nearby_sources_partial_words_and_arbitrary_anchors() {
        let mut s: Vec<u8> = (0..300).map(|i| b"abcabcxyzxy"[i % 11]).collect();
        for phase in [0, 1, 8, 17] {
            if phase != 0 {
                s[200 + phase] ^= 37
            }
            for i in 8..=s.len() - 8 {
                for q in [0, 1, i / 2, i - 1] {
                    let d = word(&s, i) ^ word(&s, q);
                    let n = s[q..]
                        .iter()
                        .zip(&s[i..])
                        .take_while(|(a, b)| a == b)
                        .count();
                    assert_eq!(forward::<1>(&s, q, i, d), n);
                    assert_eq!(forward::<2>(&s, q, i, d), n);
                    for anchor in [0, i / 3, i - 1, i] {
                        let bound = (i - anchor).min(q);
                        let m = (0..bound)
                            .take_while(|&j| s[i - j - 1] == s[q - j - 1])
                            .count();
                        assert_eq!(backward::<4>(&s, anchor, q, i), m);
                    }
                }
            }
        }
    }
}
