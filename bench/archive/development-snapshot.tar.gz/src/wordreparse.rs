// Reparse the original word sequence against all phrases learned by merging.
// A phrase blocked by an earlier greedy merge can still win at this stage.
use super::super::{Term, hash};
#[derive(Clone, Copy, Default)]
struct Edge {
    key: u64,
    child: u32,
}
struct Trie {
    edges: Vec<Edge>,
    term: Vec<u32>,
    filled: usize,
}
impl Trie {
    fn new(leaves: usize, estimate: usize) -> Self {
        Self {
            edges: vec![Edge::default(); (estimate * 2).next_power_of_two().max(64)],
            term: (0..leaves as u32).collect(),
            filled: 0,
        }
    }
    #[inline]
    fn lookup(&self, key: u64) -> usize {
        let mask = self.edges.len() - 1;
        let mut i = hash(key, mask);
        loop {
            let e = self.edges[i];
            if e.child == 0 || e.key == key {
                return i;
            }
            i = (i + 1) & mask;
        }
    }
    fn grow(&mut self) {
        let size = self.edges.len() * 2;
        let old = std::mem::replace(&mut self.edges, vec![Edge::default(); size]);
        for e in old {
            if e.child != 0 {
                let i = self.lookup(e.key);
                self.edges[i] = e;
            }
        }
    }
    fn child(&mut self, parent: u32, tok: u32) -> u32 {
        if 10 * self.filled >= 7 * self.edges.len() {
            self.grow();
        }
        let key = (u64::from(parent) << 32) | u64::from(tok);
        let i = self.lookup(key);
        if self.edges[i].child != 0 {
            return self.edges[i].child;
        }
        let id = self.term.len() as u32;
        self.term.push(u32::MAX);
        self.edges[i] = Edge { key, child: id };
        self.filled += 1;
        id
    }
    #[inline]
    fn get(&self, parent: u32, tok: u32) -> Option<u32> {
        let key = (u64::from(parent) << 32) | u64::from(tok);
        let e = self.edges[self.lookup(key)];
        (e.child != 0).then_some(e.child)
    }
}
pub(super) fn parse(
    src: &[u8],
    terms: &[Term],
    rules: &[(u32, u32)],
    mut old: Vec<u32>,
    rounds: usize,
) -> Vec<u32> {
    let nleaf = terms.len() - rules.len();
    if rules.is_empty() || old.len() < 512 {
        return old;
    }
    let (_, raw) = crate::wordbase::phrase_tokens::<true>(src);
    let mut trie = Trie::new(nleaf, rules.len());
    let mut length = vec![1u8; terms.len()];
    let mut freq = vec![0u32; terms.len()];
    for &id in &old {
        freq[id as usize] += 1;
    }
    for (j, &(a, b)) in rules.iter().enumerate() {
        let id = nleaf + j;
        length[id] = length[a as usize] + length[b as usize];
        if terms[id].pos == u32::MAX {
            continue;
        }
        let mut stack = [0u32; 65];
        let mut sp = 1;
        stack[0] = id as u32;
        let mut node = u32::MAX;
        while sp != 0 {
            sp -= 1;
            let v = stack[sp];
            if (v as usize) < nleaf {
                node = if node == u32::MAX {
                    v
                } else {
                    trie.child(node, v)
                }
            } else {
                let (a, b) = rules[v as usize - nleaf];
                stack[sp] = b;
                stack[sp + 1] = a;
                sp += 2;
            }
        }
        let current = trie.term[node as usize];
        if current == u32::MAX || freq[id] > freq[current as usize] {
            trie.term[node as usize] = id as u32;
        }
    }
    let penalty = crate::tuning("BTR_DAG_PENALTY", 10, 0, 128) as u64;
    let mut back = vec![0u32; raw.len() + 1];
    for _ in 0..rounds {
        let n = old.len() as f64;
        let fees: Vec<u64> = freq
            .iter()
            .map(|&f| ((n / (f.max(1) as f64)).log2() * 16.).round().max(1.) as u64 + penalty)
            .collect();
        let mut best = [u64::MAX; 128];
        best[0] = 0;
        for (i, &v) in raw.iter().enumerate() {
            let start = std::mem::replace(&mut best[i & 127], u64::MAX);
            let mut node = v;
            let mut end = i + 1;
            loop {
                let word = trie.term[node as usize];
                if word != u32::MAX {
                    let cost = start + fees[word as usize];
                    let p = &mut best[end & 127];
                    if cost < *p {
                        *p = cost;
                        back[end] = word
                    }
                }
                let Some(&next) = raw.get(end) else { break };
                let Some(found) = trie.get(node, next) else {
                    break;
                };
                node = found;
                end += 1;
            }
        }
        old.clear();
        freq.fill(0);
        let mut at = raw.len();
        while at > 0 {
            let v = back[at];
            old.push(v);
            freq[v as usize] += 1;
            at -= usize::from(length[v as usize]);
        }
        old.reverse();
    }
    old
}
