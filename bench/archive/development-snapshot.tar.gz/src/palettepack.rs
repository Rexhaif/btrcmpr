// Encode 16 fixed-width selectors and 16 variable-width ranks together.
// The packed bytes match the existing palette decoder exactly.
use super::Code;
use core::arch::aarch64::*;

#[inline(always)]
unsafe fn lookup<const BANKS: usize>(s: uint8x16_t, t: &[u8; 256]) -> uint8x16_t {
    unsafe {
        let v = vqtbl4q_u8(vld1q_u8_x4(t.as_ptr()), s);
        let v = if BANKS > 1 {
            vqtbx4q_u8(
                v,
                vld1q_u8_x4(t.as_ptr().add(64)),
                vsubq_u8(s, vdupq_n_u8(64)),
            )
        } else {
            v
        };
        let v = if BANKS > 2 {
            vqtbx4q_u8(
                v,
                vld1q_u8_x4(t.as_ptr().add(128)),
                vsubq_u8(s, vdupq_n_u8(128)),
            )
        } else {
            v
        };
        if BANKS > 3 {
            vqtbx4q_u8(
                v,
                vld1q_u8_x4(t.as_ptr().add(192)),
                vsubq_u8(s, vdupq_n_u8(192)),
            )
        } else {
            v
        }
    }
}
#[inline(always)]
unsafe fn vector<const K: usize, const BANKS: usize>(
    s: &[u8],
    map: &[Code; 256],
    h: &[u8; 256],
    r: &[u8; 256],
    w: &[u8; 32],
    heads: &mut [u8],
    tail: &mut [u8],
) {
    unsafe {
        let ww = vld1q_u8_x2(w.as_ptr());
        let (mut bit, mut carry, mut off) = (0usize, 0u64, 0);
        let mut tiles = s.chunks_exact(16);
        for t in &mut tiles {
            let v = vld1q_u8(t.as_ptr());
            let head = lookup::<BANKS>(v, h);
            let width = if K == 5 {
                vqtbl2q_u8(ww, head)
            } else {
                vqtbl1q_u8(ww.0, head)
            };
            let rank = vreinterpretq_u16_u8(lookup::<BANKS>(v, r));
            let hw = vreinterpretq_u16_u8(head);
            let w2 = vreinterpretq_u16_u8(width);
            let m = vdupq_n_u16(255);
            let a = vandq_u16(w2, m);
            let b = vshrq_n_u16::<8>(w2);
            let w4 = vreinterpretq_u32_u16(vaddq_u16(a, b));
            let r4 = vreinterpretq_u32_u16(vorrq_u16(
                vandq_u16(rank, m),
                vshlq_u16(vshrq_n_u16::<8>(rank), vreinterpretq_s16_u16(a)),
            ));
            let h4 = vreinterpretq_u32_u16(vorrq_u16(
                vandq_u16(hw, m),
                vshlq_u16(vshrq_n_u16::<8>(hw), vdupq_n_s16(K as i16)),
            ));
            let m = vdupq_n_u32(65535);
            let a = vandq_u32(w4, m);
            let b = vshrq_n_u32::<16>(w4);
            let bits = vaddq_u32(a, b);
            let payload = vorrq_u32(
                vandq_u32(r4, m),
                vshlq_u32(vshrq_n_u32::<16>(r4), vreinterpretq_s32_u32(a)),
            );
            let grouped = vorrq_u32(
                vandq_u32(h4, m),
                vshlq_u32(vshrq_n_u32::<16>(h4), vdupq_n_s32(2 * K as i32)),
            );
            let mut words = [0u32; 4];
            let mut spans = [0u32; 4];
            let mut hh = [0u32; 4];
            vst1q_u32(words.as_mut_ptr(), payload);
            vst1q_u32(spans.as_mut_ptr(), bits);
            vst1q_u32(hh.as_mut_ptr(), grouped);
            for j in 0..4 {
                let combined = carry | (u64::from(words[j]) << (bit & 7));
                tail[bit / 8..bit / 8 + 8].copy_from_slice(&combined.to_le_bytes());
                carry = combined >> (((bit & 7) + spans[j] as usize) & !7);
                bit += spans[j] as usize;
            }
            for j in [0, 2] {
                let x = u64::from(hh[j]) | (u64::from(hh[j + 1]) << (K * 4));
                heads[off..off + 8].copy_from_slice(&x.to_le_bytes());
                off += K;
            }
        }
        for part in tiles.remainder().chunks(8) {
            let mut h = 0u64;
            for (j, &v) in part.iter().enumerate() {
                let a = map[v as usize];
                h |= u64::from(a.head) << (K * j);
                let x = carry | (u64::from(a.rank) << (bit & 7));
                tail[bit / 8..bit / 8 + 2].copy_from_slice(&(x as u16).to_le_bytes());
                carry = x >> (((bit & 7) + a.width as usize) & !7);
                bit += a.width as usize;
            }
            heads[off..off + 8].copy_from_slice(&h.to_le_bytes());
            off += K;
        }
        debug_assert_eq!(tail.len(), bit.div_ceil(8) + 17);
    }
}
pub(super) fn encode<const K: usize>(
    data: &[u8],
    map: &[Code; 256],
    heads: &mut [u8],
    tail: &mut [u8],
) {
    let mut hh = [0; 256];
    let mut rr = [0; 256];
    let mut ww = [0; 32];
    let mut last = 0;
    for (j, c) in map.iter().enumerate() {
        if c.head | c.rank | c.width != 0 {
            hh[j] = c.head;
            rr[j] = c.rank;
            ww[usize::from(c.head)] = c.width;
            last = j;
        }
    }
    unsafe {
        match last / 64 {
            0 => vector::<K, 1>(data, map, &hh, &rr, &ww, heads, tail),
            1 => vector::<K, 2>(data, map, &hh, &rr, &ww, heads, tail),
            2 => vector::<K, 3>(data, map, &hh, &rr, &ww, heads, tail),
            _ => vector::<K, 4>(data, map, &hh, &rr, &ww, heads, tail),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn check<const K: usize>() {
        let mut seed = 87411u32;
        for banks in 1..=4 {
            let mut table = [Code::default(); 256];
            for (i, t) in table.iter_mut().enumerate().take(banks * 64) {
                let h = (i * 13) % (1 << K);
                let width = (h * 3 + 2) % 9;
                *t = Code {
                    head: h as u8,
                    width: width as u8,
                    rank: ((i * 31) & ((1 << width) - 1)) as u8,
                };
            }
            let source: Vec<_> = (0..272)
                .map(|_| {
                    seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
                    ((seed >> 16) as usize % (64 * banks)) as u8
                })
                .collect();
            for n in (0..32).chain(240..=271) {
                let v = &source[..n];
                let nb: usize = v
                    .iter()
                    .map(|&x| usize::from(table[x as usize].width))
                    .sum();
                let mut h = vec![0; (v.len() * K).div_ceil(8) + 17];
                let mut t = vec![0; nb.div_ceil(8) + 17];
                let (mut expected_h, mut expected_t) = (h.clone(), t.clone());
                super::super::pack_scalar::<K>(v, &table, &mut expected_h, &mut expected_t);
                encode::<K>(v, &table, &mut h, &mut t);
                assert_eq!(h, expected_h);
                assert_eq!(t, expected_t);
            }
        }
    }
    #[test]
    fn every_selector_width_and_partial_tile_matches_the_scalar_wire() {
        check::<1>();
        check::<2>();
        check::<3>();
        check::<4>();
        check::<5>();
    }
}
