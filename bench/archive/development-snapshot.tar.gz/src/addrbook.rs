// An entry spells up to sixteen bytes; shorter entries are zero-padded. Mode
// 34 inserts the book into the distance space. Mode 35 reserves explicit
// selectors and leaves real distances alone. Repeat codes can name either.
use super::{Streams, lenin};
use crate::{Result, ans, bad, take};

#[derive(Clone, Copy, Default)]
struct Entry {
    key: u64,
    at: u32,
    count: u32,
    len: u8,
    rank: u16,
}
#[derive(Clone, Copy)]
struct Cmd {
    at: u32,
    len: u32,
    off: u32,
}

struct Parts<'a> {
    min: usize,
    tags: std::borrow::Cow<'a, [u8]>,
    offs: std::borrow::Cow<'a, [u8]>,
    lens: std::borrow::Cow<'a, [u8]>,
    lits: std::borrow::Cow<'a, [u8]>,
    lo: std::borrow::Cow<'a, [u8]>,
    mi: std::borrow::Cow<'a, [u8]>,
    far: std::borrow::Cow<'a, [u8]>,
    kept: [&'a [u8]; 3],
}
fn parts(s: &[u8], n: usize) -> Result<Parts<'_>> {
    let (&mode, mut p) = s.split_first().ok_or_else(bad)?;
    let min = match mode {
        1 | 13 => 4,
        16 | 17 => 3,
        _ => return Err(bad()),
    };
    let start = p;
    let tags = ans::get(&mut p, n / min)?;
    let tag_wire = &start[..start.len() - p.len()];
    let offs = ans::get_context(&mut p, tags.len(), Some(&tags))?;
    if tags.len() != offs.len() {
        return Err(bad());
    }
    let start = p;
    let lens = ans::get(&mut p, n)?;
    let len_wire = &start[..start.len() - p.len()];
    let start = p;
    let lits = ans::get(&mut p, n)?;
    let lit_wire = &start[..start.len() - p.len()];
    let lo = ans::get(&mut p, tags.len() + 16)?;
    let mi = ans::get(&mut p, tags.len() + 16)?;
    let far = if mode == 13 || mode == 17 {
        ans::get(&mut p, 3 * tags.len())?
    } else {
        std::borrow::Cow::Borrowed(&[][..])
    };
    if !p.is_empty() || lo.len() < 16 || mi.len() < 16 {
        return Err(bad());
    }
    Ok(Parts {
        min,
        tags,
        offs,
        lens,
        lits,
        lo,
        mi,
        far,
        kept: [tag_wire, len_wire, lit_wire],
    })
}
fn visit<F: FnMut(usize, usize, usize, usize) -> Result<()>>(
    p: &Parts,
    n: usize,
    codes: Option<super::BookTags>,
    mut f: F,
) -> Result<()> {
    let mut lens = &*p.lens;
    let mut far = &*p.far;
    let (mut a, mut b, mut at, mut lit) = (0, 0, 0, 0);
    let mut rep = [1usize, 4, 8];
    for (&t, &c) in p.tags.iter().zip(&*p.offs) {
        let ll = (t >> 4) as usize;
        let ml = (t & 15) as usize;
        let ll = ll + if ll == 15 { lenin(&mut lens)? } else { 0 };
        let ml = ml + p.min + if ml == 15 { lenin(&mut lens)? } else { 0 };
        let off = match c {
            0..=2 => rep[c as usize],
            3..=19 => rep[0]
                .checked_add(c as usize)
                .and_then(|x| x.checked_sub(11))
                .ok_or_else(bad)?,
            20..=83 => c as usize - 19,
            _ => {
                let lo = *p.lo.get(a).ok_or_else(bad)? as usize;
                a += 1;
                if c < 212 {
                    ((c as usize - 84) * 256 + lo)
                        .checked_sub(19)
                        .ok_or_else(bad)?
                } else {
                    let mid = *p.mi.get(b).ok_or_else(bad)? as usize;
                    b += 1;
                    let hi = c as usize - 212 + if c == 255 { lenin(&mut far)? } else { 0 };
                    if hi > 514 {
                        return Err(bad());
                    }
                    ((hi << 16) + (mid << 8) + lo)
                        .checked_sub(19)
                        .ok_or_else(bad)?
                }
            }
        };
        let off = if let Some(codes) = codes {
            codes.mapped(c, (off + 19) as u32) as usize - 19
        } else {
            off
        };
        if off == 0 || ll + ml > n - at || ll > p.lits.len() - lit {
            return Err(bad());
        }
        at += ll;
        f(at, ll, ml, off)?;
        at += ml;
        lit += ll;
        rep = [off, rep[0], rep[1]];
    }
    if !lens.is_empty()
        || !far.is_empty()
        || a + 16 != p.lo.len()
        || b + 16 != p.mi.len()
        || p.lits.len() - lit != n - at
    {
        return Err(bad());
    }
    Ok(())
}
#[inline(always)]
fn key(s: &[u8]) -> u64 {
    let mut a = [0; 8];
    let mut b = [0; 8];
    let n = s.len().min(8);
    a[..n].copy_from_slice(&s[..n]);
    b[..n].copy_from_slice(&s[s.len() - n..]);
    (u64::from_le_bytes(a)
        .wrapping_mul(0x9e3779b97f4a7c15)
        .rotate_left(23)
        ^ u64::from_le_bytes(b)
        ^ s.len() as u64)
        .wrapping_mul(0x94d049bb133111eb)
}
pub(crate) fn rewrite(
    s: &[u8],
    raw: &[u8],
    cap: usize,
    base: usize,
    threshold: usize,
    tagged: bool,
) -> Result<Vec<u8>> {
    if !(1..=16384).contains(&cap)
        || if tagged {
            base > 64
        } else {
            !(1..=65).contains(&base)
        }
    {
        return Err(bad());
    }
    let p = parts(s, raw.len())?;
    let mut cmds = Vec::with_capacity(p.tags.len());
    let mut slots = vec![Entry::default(); 1 << 17];
    visit(&p, raw.len(), None, |at, _, len, off| {
        if off > at {
            return Err(bad());
        }
        cmds.push(Cmd {
            at: at as u32,
            len: len as u32,
            off: off as u32,
        });
        if len <= 16 && off >= threshold {
            let h = key(&raw[at..at + len]);
            let e = &mut slots[(h >> 47) as usize];
            if e.key == h && e.len as usize == len {
                e.count += 1;
            } else if e.count == 0 {
                *e = Entry {
                    key: h,
                    at: at as u32,
                    count: 1,
                    len: len as u8,
                    rank: 0,
                };
            } else {
                e.count -= 1;
            }
        }
        Ok(())
    })?;
    let mut winners = (0..slots.len())
        .filter(|&i| slots[i].count >= 3)
        .collect::<Vec<_>>();
    let score = |&i: &usize| (std::cmp::Reverse(slots[i].count), i);
    if winners.len() > cap {
        winners.select_nth_unstable_by_key(cap, score);
        winners.truncate(cap);
    }
    winners.sort_unstable_by_key(score);
    let k = winners.len();
    if k == 0 {
        return Ok(s.to_vec());
    }
    let mut out = vec![if tagged { 35 } else { 34 }, base as u8];
    let codes = super::BookTags::new(k, base);
    let virt = if tagged { codes.base() } else { base };
    out.extend((k as u16).to_le_bytes());
    for (id, &i) in winners.iter().enumerate() {
        let e = &mut slots[i];
        e.rank = (id + 1) as u16;
        out.push(e.len);
        out.extend(&raw[e.at as usize..e.at as usize + e.len as usize]);
    }
    let mut st = Streams::new();
    for c in cmds {
        let (at, l, d) = (c.at as usize, c.len as usize, c.off as usize);
        let norm = if !tagged && d >= base { d + k } else { d };
        let mut address = norm;
        if l <= 16 && d >= threshold && !st.rep.contains(&norm) {
            let h = key(&raw[at..at + l]);
            let e = &slots[(h >> 47) as usize];
            if e.rank != 0
                && e.key == h
                && e.len as usize == l
                && raw[at..at + l] == raw[e.at as usize..e.at as usize + l]
            {
                address = virt + e.rank as usize - 1;
            }
        }
        if !tagged {
            st.offset(address);
        } else if address == norm {
            st.offset(norm);
            let c = st.offs.last_mut().unwrap();
            if codes.direct_id(*c) {
                *c = 84;
                st.low.push((d + 19) as u8);
            } else if codes.extra_id(*c) {
                *c = 212;
                st.mid.push(((d + 19) >> 8) as u8);
            }
        } else if st.rep.contains(&address) || address.wrapping_sub(st.rep[0]).wrapping_add(8) <= 16
        {
            st.offset(address);
        } else {
            let id = address - virt;
            if id < base.min(k) {
                st.offs.push(codes.direct + id as u8);
            } else {
                let pos = id - base.min(k);
                st.offs.push(codes.ext + (pos >> 8) as u8);
                st.low.push(pos as u8);
            }
            st.rep = [address, st.rep[0], st.rep[1]];
        }
    }
    st.low.extend([0; 16]);
    st.mid.extend([0; 16]);
    out.push(match (p.min, st.far.is_empty()) {
        (3, true) => 16,
        (3, false) => 17,
        (_, true) => 1,
        (_, false) => 13,
    });
    out.extend(p.kept[0]);
    ans::put_policy(&st.offs, &mut out, 0.985);
    out.extend(p.kept[1]);
    out.extend(p.kept[2]);
    ans::put_policy(&st.low, &mut out, 0.985);
    ans::put_policy(&st.mid, &mut out, 0.985);
    if !st.far.is_empty() {
        ans::put_policy(&st.far, &mut out, 0.985);
    }
    Ok(out)
}
pub(crate) fn decode<const TAGGED: bool>(p: &[u8], dst: &mut [u8]) -> Result<()> {
    if crate::tuning("BTR_ADDR_SCALAR", 0, 0, 1) == 0 {
        decode_inner::<TAGGED, false>(p, dst)
    } else {
        decode_inner::<TAGGED, true>(p, dst)
    }
}
fn decode_inner<const TAGGED: bool, const SCALAR: bool>(
    mut p: &[u8],
    dst: &mut [u8],
) -> Result<()> {
    let header = take(&mut p, 3)?;
    let base = header[0] as usize;
    let k = u16::from_le_bytes([header[1], header[2]]) as usize;
    if (if TAGGED {
        base > 64
    } else {
        base == 0 || base > 65
    }) || k == 0
        || k > 16384
    {
        return Err(bad());
    }
    let codes = super::BookTags::new(k, base);
    let base = if TAGGED { codes.base() } else { base };
    let mut dict = vec![[0u8; 16]; k];
    for d in &mut dict {
        let n = take(&mut p, 1)?[0] as usize;
        if !(3..=16).contains(&n) {
            return Err(bad());
        }
        d[..n].copy_from_slice(take(&mut p, n)?);
    }
    if !SCALAR {
        let (&mode, p) = p.split_first().ok_or_else(bad)?;
        return match mode {
            1 => super::decode_books::<false, 4, false, false, true, TAGGED>(
                p,
                dst,
                &[],
                &dict,
                base as u32,
                codes,
            ),
            13 => super::decode_books::<true, 4, false, false, true, TAGGED>(
                p,
                dst,
                &[],
                &dict,
                base as u32,
                codes,
            ),
            16 => super::decode_books::<false, 3, false, false, true, TAGGED>(
                p,
                dst,
                &[],
                &dict,
                base as u32,
                codes,
            ),
            17 => super::decode_books::<true, 3, false, false, true, TAGGED>(
                p,
                dst,
                &[],
                &dict,
                base as u32,
                codes,
            ),
            _ => Err(bad()),
        };
    }
    let p = parts(p, dst.len())?;
    let (mut prev, mut lit) = (0, 0);
    visit(&p, dst.len(), TAGGED.then_some(codes), |at, ll, ml, off| {
        dst[prev..at].copy_from_slice(&p.lits[lit..lit + ll]);
        lit += ll;
        if (base..base + k).contains(&off) {
            if ml > 16 {
                return Err(bad());
            }
            dst[at..at + ml].copy_from_slice(&dict[off - base][..ml]);
        } else {
            let d = if off >= base + k { off - k } else { off };
            if d > at {
                return Err(bad());
            }
            let mut piece = ml.min(d);
            dst.copy_within(at - d..at - d + piece, at);
            while piece < ml {
                let n = piece.min(ml - piece);
                dst.copy_within(at..at + n, at + piece);
                piece += n;
            }
        }
        prev = at + ml;
        Ok(())
    })?;
    dst[prev..].copy_from_slice(&p.lits[lit..]);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn both<const TAGGED: bool>(wire: &[u8], n: usize, expected: Option<&[u8]>) {
        for scalar in [false, true] {
            let mut raw = vec![0xcc; n];
            let r = if scalar {
                decode_inner::<TAGGED, true>(wire, &mut raw)
            } else {
                decode_inner::<TAGGED, false>(wire, &mut raw)
            };
            if let Some(want) = expected {
                r.unwrap();
                assert_eq!(raw, want);
            } else {
                assert!(r.is_err(), "scalar={scalar}, tagged={TAGGED}");
            }
        }
    }

    #[test]
    fn preserves_existing_parse_across_vector_groups_and_tail() {
        let mut raw: Vec<_> = (0..180).map(|i| (i * 67 + 17) as u8).collect();
        let mut st = Streams::new();
        let mut anchor = 0;
        // Variable literal runs, three different dictionary lengths, and
        // direct as well as repeat and delta distances on both sides of a batch.
        for i in 0..99 {
            let id = [0, 0, 1, 1, 0, 2, 0][i % 7];
            let n = 4 + id;
            let from = id * 19;
            let at = raw.len();
            raw.extend_from_within(from..from + n);
            st.emit(&raw, anchor, at, n, at - from);
            anchor = raw.len();
            raw.extend(std::iter::repeat_n(i as u8, 1 + i % 9));
        }
        raw.extend([0xfd; 49]);
        let original = st.finish(&raw, anchor, false);
        for (tagged, direct) in [(false, 32), (true, 0), (true, 1), (true, 64)] {
            let encoded = rewrite(&original, &raw, 256, direct, 32, tagged).unwrap();
            assert_eq!(encoded[0], if tagged { 35 } else { 34 });
            assert_eq!(u16::from_le_bytes([encoded[2], encoded[3]]), 3);
            if tagged {
                both::<true>(&encoded[1..], raw.len(), Some(&raw));
            } else {
                both::<false>(&encoded[1..], raw.len(), Some(&raw));
            }
        }
    }
    #[test]
    fn invalid_book_records_fail_in_vector_groups_and_tail() {
        for where_bad in [0, 15, 16, 32] {
            for bad_id in [false, true] {
                // One extension selector, actual id zero; selector 211 + low
                // byte 1 would reference the first unused slot in this bank.
                let mut encoded = vec![0, 1, 0, 4, b't', b'e', b's', b't', 1];
                let mut tags = [0u8; 33];
                let mut low = [0u8; 49];
                if bad_id {
                    low[where_bad] = 1
                } else {
                    tags[where_bad] = 13
                }
                for stream in [
                    &tags[..],
                    &[211; 33][..],
                    &[],
                    &[4; 64][..],
                    &low[..],
                    &[0; 16][..],
                ] {
                    ans::put_policy(stream, &mut encoded, 0.985);
                }
                both::<true>(&encoded, 33 * 4 + 64 + if bad_id { 0 } else { 13 }, None);
            }
        }
        both::<true>(&[0, 1, 0, 17], 128, None);
        both::<false>(&[32, 1, 0, 8, 0], 128, None);
        both::<true>(&[65, 1, 0], 128, None);
    }
}
