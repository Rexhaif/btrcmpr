// Verify just the qualifying prefix at each candidate. Measure its exact
// length only after choosing the position; no failed candidate needs CLZ.
use super::{MASK, common, word};
#[inline(always)]
fn index<const P: usize, const B: usize>(w: u64) -> (usize, u32) {
    (
        ((w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15) >> (64 - B)) as usize,
        (w as u32) << 21,
    )
}
#[inline(always)]
fn hit<const MIN: usize>(s: &[u8], i: usize, w: u64, old: u32, sig: u32) -> Option<(usize, u64)> {
    let p = old as usize & MASK;
    if (old ^ sig) > MASK as u32 || p >= i {
        return None;
    }
    let d = word(s, p) ^ w;
    if MIN == 4 {
        if d as u32 != 0 || ((d >> 32) as u8 != 0 && i - p > 12000) {
            return None;
        }
    } else if d << (64 - 8 * MIN) != 0 {
        return None;
    }
    Some((p, d))
}
#[inline(always)]
fn single<const MIN: usize, const P: usize, const B: usize>(
    s: &[u8],
    t: &mut [u32],
    i: usize,
) -> Option<(usize, u64)> {
    let w = word(s, i);
    let (k, sig) = index::<P, B>(w);
    let old = std::mem::replace(&mut t[k], sig | i as u32);
    hit::<MIN>(s, i, w, old, sig)
}
fn walk_impl<
    const MIN: usize,
    const SINGLE: usize,
    const P: usize,
    const B: usize,
    const TAIL: usize,
    const EXT: usize,
>(
    s: &[u8],
    mut emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    let mut t = vec![0u32; 1 << B];
    let (mut i, mut anchor) = (0, 0);
    while i + 8 <= s.len() {
        let at_end = SINGLE == 2 || (SINGLE == 1 && i == anchor) || i + 9 > s.len();
        let found = if at_end {
            let h = single::<MIN, P, B>(s, &mut t, i);
            if h.is_none() {
                i += 1;
                continue;
            }
            h
        } else {
            let w = word(s, i);
            let (k, sig) = index::<P, B>(w);
            let w1 = word(s, i + 1);
            let (k1, sig1) = index::<P, B>(w1);
            let here = sig | i as u32;
            let old = t[k];
            let next = if k == k1 { here } else { t[k1] };
            t[k] = here;
            if let Some(a) = hit::<MIN>(s, i, w, old, sig) {
                Some(a)
            } else {
                i += 1;
                t[k1] = sig1 | i as u32;
                let h = hit::<MIN>(s, i, w1, next, sig1);
                if h.is_none() {
                    i += 1;
                    continue;
                }
                h
            }
        };
        let (q, d) = found.unwrap();
        let len = if EXT == 0 {
            if d == 0 {
                8 + common(s, q + 8, i + 8)
            } else {
                d.trailing_zeros() as usize / 8
            }
        } else {
            super::lengthword::forward::<EXT>(s, q, i, d)
        };
        let back = if EXT == 0 {
            let mut back = 0;
            while back < i - anchor && back < q && s[i - back - 1] == s[q - back - 1] {
                back += 1
            }
            back
        } else {
            super::lengthword::backward::<EXT>(s, anchor, q, i)
        };
        emit(anchor, i - back, len + back, i - q);
        i += len;
        anchor = i;
        for pos in i - TAIL..i {
            if pos + 8 <= s.len() {
                let (k, sig) = index::<P, B>(word(s, pos));
                t[k] = sig | pos as u32;
            }
        }
    }
    anchor
}
#[cfg(any(test, feature = "research"))]
pub(super) fn walk(s: &[u8], mode: usize, emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    macro_rules! m {
        ($min:literal,$single:literal,$p:literal,$b:literal,$tail:literal) => {
            walk_impl::<$min, $single, $p, $b, $tail, 0>(s, emit)
        };
    }
    match mode {
        1 => m!(4, 0, 6, 15, 2),
        2 => m!(5, 0, 6, 15, 2),
        3 => m!(6, 0, 6, 15, 2),
        4 => m!(4, 1, 6, 15, 2),
        5 => m!(5, 1, 6, 15, 2),
        6 => m!(6, 1, 6, 15, 2),
        7 => m!(4, 2, 6, 15, 2),
        8 => m!(5, 2, 6, 15, 2),
        9 => m!(6, 2, 6, 15, 2),
        10 => m!(4, 0, 7, 14, 1),
        11 => m!(6, 0, 7, 14, 1),
        12 => m!(6, 1, 7, 14, 1),
        13 => m!(5, 2, 7, 14, 1),
        14 => m!(6, 2, 7, 14, 1),
        15 => m!(7, 2, 7, 14, 1),
        16 => m!(6, 0, 6, 16, 1),
        17 => m!(6, 1, 6, 16, 1),
        18 => m!(6, 2, 6, 16, 1),
        19 => m!(6, 0, 7, 15, 1),
        _ => m!(6, 2, 7, 15, 1),
    }
}
pub(super) fn wide(
    s: &[u8],
    key: usize,
    mode: usize,
    emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    macro_rules! w {
        ($min:literal,$p:literal,$b:literal,$tail:literal,$ext:literal) => {
            walk_impl::<$min, 0, $p, $b, $tail, $ext>(s, emit)
        };
    }
    macro_rules! choose {
        ($p:literal,$b:literal,$tail:literal) => {
            match mode {
                1 => w!(4, $p, $b, $tail, 1),
                2 => w!(4, $p, $b, $tail, 2),
                3 => w!(4, $p, $b, $tail, 4),
                4 => w!(4, $p, $b, $tail, 5),
                5 => w!(4, $p, $b, $tail, 6),
                6 => w!(6, $p, $b, $tail, 5),
                7 => w!(6, $p, $b, $tail, 6),
                _ => w!(8, $p, $b, $tail, 5),
            }
        };
    }
    if key == 10 {
        choose!(7, 14, 1)
    } else {
        choose!(6, 15, 2)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn single_and_paired_confirmation_recover_the_same_native_commands() {
        let mut data = Vec::new();
        let mut rand = 381271u32;
        for i in 0..44000 {
            rand = rand.wrapping_mul(1664525).wrapping_add(1013904223);
            data.push((rand >> 24) as u8);
            if i % 3 == 0 {
                data.extend_from_slice(b"abcdefgAAAAaaaa");
            }
            if i % 7 == 0 && data.len() > 900 {
                let at = (rand as usize) % (data.len() - 61);
                data.extend_from_within(at..at + 61);
            }
        }
        for n in (0..20).chain([17002, data.len()]) {
            let s = &data[..n];
            let mut orig = vec![];
            let end =
                super::super::quicktwo::walk_grouped(s, 5, |a, i, l, d| orig.push((a, i, l, d)));
            for mode in [1, 4, 7] {
                let mut cmd = Vec::new();
                let new = walk(s, mode, |a, i, l, d| cmd.push((a, i, l, d)));
                assert_eq!(end, new);
                assert_eq!(cmd, orig);
            }
            for mode in 1..=20 {
                let mut at = 0;
                let end = walk(s, mode, |a, i, l, d| {
                    assert_eq!(a, at);
                    assert!(i >= a && l >= 4 && d > 0 && d <= i);
                    assert_eq!(s[i..i + l], s[i - d..i - d + l]);
                    at = i + l;
                });
                assert_eq!(at, end);
            }
        }
    }
}
