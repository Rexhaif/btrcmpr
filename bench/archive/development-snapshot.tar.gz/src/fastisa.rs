// Separate the upper instruction halfword from the immediate. Upper fields
// stay in program order; two low-byte planes are grouped by the opcode and
// optionally two register bits. Every stream carries its own model.
use crate::{Result, ans, bad, lz, take, u32in};

fn bank(h: u16, wide: bool) -> usize {
    let op = usize::from(h >> 10);
    if wide {
        (op << 2) | usize::from(h & 3)
    } else {
        op
    }
}
fn field(out: &mut Vec<u8>, data: &[u8], match_bytes: bool) {
    let payload = if match_bytes {
        let v = lz::quick_impl::<1, 14, false, 1>(data, true);
        if v.len() < data.len() {
            v
        } else {
            let mut raw = vec![0];
            raw.extend(data);
            raw
        }
    } else {
        let mut v = vec![58];
        ans::put_policy(data, &mut v, 0.985);
        v
    };
    out.extend((payload.len() as u32).to_le_bytes());
    out.extend(payload);
}
pub(crate) fn put(src: &[u8], mode: usize) -> Vec<u8> {
    let (split, delta, wide) = (mode & 1 != 0, mode & 2 != 0, mode & 16 != 0);
    let n = src.len() / 4;
    let mut counts = [0usize; 256];
    let upper = |v: &[u8]| u16::from_le_bytes([v[2], v[3]]);
    let mut hi = vec![0u8; n * 2];
    for (i, v) in src.chunks_exact(4).enumerate() {
        counts[bank(upper(v), wide)] += 1;
        if split {
            hi[i] = v[2];
            hi[n + i] = v[3]
        } else {
            hi[2 * i..2 * i + 2].copy_from_slice(&v[2..])
        }
    }
    let mut out = vec![
        57,
        (usize::from(split) | usize::from(delta) << 1 | usize::from(wide) << 2) as u8,
    ];
    out.extend(&src[n * 4..]);
    let mut curs = [0; 256];
    let mut last = [0u16; 256];
    let mut start = 0;
    for (b, &count) in counts[..if wide { 256 } else { 64 }].iter().enumerate() {
        out.extend((count as u32).to_le_bytes());
        curs[b] = start;
        start += count;
    }
    let mut low = vec![0; n * 2];
    for v in src.chunks_exact(4) {
        let b = bank(upper(v), wide);
        let x = u16::from_le_bytes([v[0], v[1]]);
        let d = if delta {
            x.wrapping_sub(std::mem::replace(&mut last[b], x))
        } else {
            x
        };
        let j = curs[b];
        curs[b] += 1;
        low[j] = d as u8;
        low[n + j] = (d >> 8) as u8;
    }
    if split {
        field(&mut out, &hi[..n], mode & 4 != 0);
        field(&mut out, &hi[n..], mode & 4 != 0)
    } else {
        field(&mut out, &hi, mode & 4 != 0)
    }
    field(&mut out, &low[..n], mode & 8 != 0);
    field(&mut out, &low[n..], mode & 8 != 0);
    out
}
fn read<'a>(p: &mut &'a [u8], n: usize) -> Result<std::borrow::Cow<'a, [u8]>> {
    use std::borrow::Cow;
    let len = u32in(p)?;
    let mut s = take(p, len)?;
    let tag = take(&mut s, 1)?[0];
    match tag {
        0 if s.len() == n => Ok(Cow::Borrowed(s)),
        1 | 13 => {
            let mut d = vec![0; n];
            if tag == 1 {
                lz::decode_core::<false, 4, false, true>(s, &mut d, &[])?
            } else {
                lz::decode_core::<true, 4, false, true>(s, &mut d, &[])?
            };
            Ok(Cow::Owned(d))
        }
        58 if matches!(s.get(4), Some(0 | 1 | 2 | 4 | 5)) => {
            let d = ans::get(&mut s, n)?;
            if d.len() != n || !s.is_empty() {
                return Err(bad());
            }
            Ok(d)
        }
        _ => Err(bad()),
    }
}
pub(crate) fn get(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let flags = take(&mut p, 1)?[0];
    if flags > 7 {
        return Err(bad());
    }
    let (split, delta, wide) = (flags & 1 != 0, flags & 2 != 0, flags & 4 != 0);
    let n = dst.len() / 4;
    let end = n * 4;
    let tail = dst.len() - end;
    dst[end..].copy_from_slice(take(&mut p, tail)?);
    let mut offsets = [0usize; 256];
    let mut end_at = [0usize; 256];
    let mut count = 0;
    for b in 0..if wide { 256 } else { 64 } {
        let m = u32in(&mut p)?;
        if m > n - count {
            return Err(bad());
        }
        offsets[b] = count;
        count += m;
        end_at[b] = count;
    }
    if count != n {
        return Err(bad());
    }
    let upper = read(&mut p, if split { n } else { 2 * n })?;
    let high = if split {
        read(&mut p, n)?
    } else {
        std::borrow::Cow::Borrowed(&[][..])
    };
    let lo = read(&mut p, n)?;
    let mi = read(&mut p, n)?;
    if !p.is_empty() {
        return Err(bad());
    }
    let mut last = [0u16; 256];
    for (j, word) in dst[..end].chunks_exact_mut(4).enumerate() {
        let h = if split {
            [upper[j], high[j]]
        } else {
            [upper[j * 2], upper[j * 2 + 1]]
        };
        let b = bank(u16::from_le_bytes(h), wide);
        let i = offsets[b];
        if i >= end_at[b] {
            return Err(bad());
        }
        offsets[b] += 1;
        let x = u16::from_le_bytes([lo[i], mi[i]]);
        let v = if delta {
            last[b] = last[b].wrapping_add(x);
            last[b]
        } else {
            x
        };
        word[..2].copy_from_slice(&v.to_le_bytes());
        word[2..].copy_from_slice(&h);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn planes_restore_trailing_bytes_and_reject_bad_counts() {
        let mut s = vec![];
        for i in 0u32..4096 {
            let h = (0x9082 + i % 19) as u16;
            s.extend(((i * 7) as u16).to_le_bytes());
            s.extend(h.to_le_bytes())
        }
        s.extend([53, 81, 27]);
        for mode in [0, 1, 2, 5, 8, 15, 16, 18, 29, 31] {
            let mut v = put(&s, mode);
            let mut raw = vec![0; s.len()];
            get(&v[1..], &mut raw).unwrap();
            assert_eq!(raw, s);
            assert!(get(&v[1..v.len() - 1], &mut raw).is_err());
            v[5..9].copy_from_slice(&u32::MAX.to_le_bytes());
            assert!(get(&v[1..], &mut raw).is_err());
        }
    }
}
