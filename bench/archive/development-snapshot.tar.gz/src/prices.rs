// Empirical prices for a high-effort parse. Learn the cost of the literal,
// tag, and offset streams from a prefix that has already been parsed.
use crate::lz::offset_code;
pub(crate) struct Prices {
    counts: [[u32; 256]; 4],
    cost: [[u32; 256]; 4],
    lengths: [[u32; 256]; 16],
}
impl Prices {
    pub fn new() -> Self {
        Self {
            counts: [[1; 256]; 4],
            cost: [[128; 256]; 4],
            lengths: [[128; 256]; 16],
        }
    }
    fn excess(&mut self, mut x: usize) {
        while x >= 128 {
            self.counts[3][128 + (x & 127)] += 1;
            x >>= 7;
        }
        self.counts[3][x] += 1;
    }
    pub fn learn(&mut self, at: usize, s: &[u8], step: &[(u32, u32)]) {
        let end = at.saturating_sub(65536);
        for stream in &mut self.counts {
            for p in stream {
                *p = (*p / 2).max(1);
            }
        }
        let mut j = at;
        let mut seq = Vec::with_capacity(8192);
        while j > end {
            let (len, off) = step[j];
            if len == 0 {
                j -= 1;
                self.counts[0][s[j] as usize] += 1;
            } else {
                j -= len as usize;
                seq.push((j, len as usize, off as usize));
            }
        }
        let mut anchor = j;
        let mut rep = [1, 4, 8];
        for &(i, len, off) in seq.iter().rev() {
            let ll = i - anchor;
            let ml = len - 3;
            self.counts[1][ll.min(15) * 16 + ml.min(15)] += 1;
            let (code, _) = offset_code(off, rep);
            self.counts[2][code] += 1;
            if ml >= 15 {
                self.excess(ml - 15);
            }
            if ll >= 15 {
                self.excess(ll - 15);
            }
            rep = [off, rep[0], rep[1]];
            anchor = i + len;
        }
        for (c, fees) in self.counts.iter().zip(&mut self.cost) {
            let total: u32 = c.iter().sum();
            for (q, f) in c.iter().zip(fees) {
                *f = ((total as f64 / *q as f64).log2().clamp(0.25, 15.) * 16.).round() as u32;
            }
        }
        for (ll, prices) in self.lengths.iter_mut().enumerate() {
            for (ml, price) in prices.iter_mut().enumerate() {
                *price = self.cost[1][ll * 16 + ml.min(15)];
                if ml >= 15 {
                    let mut x = ml - 15;
                    while x >= 128 {
                        *price += self.cost[3][128 + (x & 127)];
                        x >>= 7;
                    }
                    *price += self.cost[3][x];
                }
            }
        }
    }
    #[inline]
    pub fn literal(&self, b: u8, gap: u8) -> u32 {
        self.cost[0][b as usize] + if gap == 14 { self.cost[3][0] } else { 0 }
    }
    #[inline]
    pub fn length(&self, gap: u8, len: usize) -> u32 {
        self.lengths[gap as usize][(len - 3).min(255)]
    }
    #[inline]
    pub fn distance(&self, off: u32, rep: u32) -> u32 {
        self.distance_history(off, [rep, 0, 0])
    }
    #[inline]
    pub fn distance_history(&self, off: u32, rep: [u32; 3]) -> u32 {
        let (c, bits) = offset_code(off as usize, rep.map(|x| x as usize));
        self.cost[2][c] + 16 * bits
    }
}
