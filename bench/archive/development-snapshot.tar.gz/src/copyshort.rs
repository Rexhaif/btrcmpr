// Experimental execution of a validated batch. The native small-copy kernel
// is the control; both see exactly the same literals, distances and lengths.
use super::{Fields, Ready, SHUF, copy16, long_literals, long_match};
use std::arch::aarch64::*;

// Up to sixteen new literals, followed by a repeating string at most sixteen
// bytes back. For each result byte, select from the new literals (indices
// 0..15) or the sixteen previous output bytes (indices 16..31). References
// into the match itself repeat the same source period. No output is read
// before its original value is known.
const NEAR: [[[[u8; 16]; 2]; 17]; 17] = {
    let mut tab = [[[[0; 16]; 2]; 17]; 17];
    let mut l = 0;
    while l <= 16 {
        let mut off = 1;
        while off <= 16 {
            let mut j = 0;
            while j < 32 {
                let q = if j < l {
                    j as isize
                } else {
                    l as isize - off as isize + ((j - l) % off) as isize
                };
                tab[l][off][j / 16][j % 16] = if q < 0 { (32 + q) as u8 } else { q as u8 };
                j += 1;
            }
            off += 1;
        }
        l += 1;
    }
    tab
};
#[inline(always)]
unsafe fn execute<const LARGE: usize, const OVERLAP: usize, const NARROW: bool>(
    dst: &mut [u8],
    literals: &[u8],
    f: &Fields,
    run: Ready,
) {
    unsafe {
        for i in 0..run.count {
            let ll = f.ll[i] as usize;
            let ml = f.ml[i] as usize;
            let total = ll + ml;
            let pos = f.dst[i] as usize;
            let origin = f.src[i] as usize;
            let off = pos - origin;
            let start = pos - ll;
            let d = dst.as_mut_ptr().add(pos);
            let s = dst.as_ptr().add(origin);
            let l = literals.as_ptr().add(f.lit[i] as usize);
            if NARROW && ll == 0 && ml <= 8 && off >= ml {
                let x = std::ptr::read_unaligned(s.cast::<u64>());
                std::ptr::write_unaligned(d.cast::<u64>(), x);
                continue;
            }
            if total <= 16 && off >= total {
                let v = uint8x16x2_t(vld1q_u8(l), vld1q_u8(s));
                vst1q_u8(d.sub(ll), vqtbl2q_u8(v, vld1q_u8(SHUF[ll].as_ptr())));
                continue;
            }
            if OVERLAP > 0 && total <= OVERLAP && ll <= 16 && off <= 16 && start >= 16 {
                let ix = &NEAR[ll][off];
                let p = dst.as_mut_ptr().add(start);
                let inputs = uint8x16x2_t(vld1q_u8(l), vld1q_u8(p.sub(16)));
                vst1q_u8(p, vqtbl2q_u8(inputs, vld1q_u8(ix[0].as_ptr())));
                if OVERLAP > 16 && total > 16 {
                    vst1q_u8(p.add(16), vqtbl2q_u8(inputs, vld1q_u8(ix[1].as_ptr())));
                }
                continue;
            }
            if ll != 0 {
                copy16(l, d.sub(ll));
                if ll > 16 {
                    long_literals(l.add(16), d.sub(ll).add(16), ll - 16)
                }
            }
            if ml <= 16 && off >= ml {
                copy16(s, d);
            } else if LARGE >= 32 && ml <= 32 && off >= ml {
                // Exactly ml initialized source bytes cover both unaligned
                // loads. Their matching destination stores may overlap.
                let a = vld1q_u8(s);
                let b = vld1q_u8(s.add(ml - 16));
                vst1q_u8(d, a);
                vst1q_u8(d.add(ml - 16), b);
            } else if LARGE >= 48 && ml <= 48 && off >= ml {
                let a = vld1q_u8(s);
                let b = vld1q_u8(s.add(16));
                let c = vld1q_u8(s.add(ml - 16));
                vst1q_u8(d, a);
                vst1q_u8(d.add(16), b);
                vst1q_u8(d.add(ml - 16), c);
            } else {
                long_match(d, off, ml);
            }
        }
    }
}
// Caller has validated positions, source distances, and at least sixteen
// bytes after the last output and literal range.
#[inline(never)]
pub(super) unsafe fn run(dst: &mut [u8], lits: &[u8], f: &Fields, r: Ready, mode: usize) {
    unsafe {
        match mode {
            1 => execute::<32, 0, false>(dst, lits, f, r),
            2 => execute::<48, 0, false>(dst, lits, f, r),
            3 => execute::<16, 16, false>(dst, lits, f, r),
            4 => execute::<16, 32, false>(dst, lits, f, r),
            5 => execute::<32, 32, false>(dst, lits, f, r),
            6 => execute::<48, 32, false>(dst, lits, f, r),
            7 => execute::<16, 0, true>(dst, lits, f, r),
            _ => execute::<32, 32, true>(dst, lits, f, r),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn copy_choices_include_self_overlap_and_literals_at_all_boundaries() {
        let mut f = Fields::new();
        let mut lits = [0u8; 128];
        for (i, b) in lits.iter_mut().enumerate() {
            *b = (i * 31 + 17) as u8
        }
        for ll in [0, 1, 3, 7, 8, 15, 16, 17, 32] {
            for ml in [4, 7, 8, 9, 15, 16, 17, 22, 30, 31, 32, 33, 47, 48, 49, 65] {
                for off in (1..=18).chain([30, 32, 40, 48, 64]) {
                    let start = 64;
                    let pos = start + ll;
                    let end = pos + ml;
                    let src = pos - off;
                    let mut seed = [0x51u8; 256];
                    for (k, b) in seed[..start].iter_mut().enumerate() {
                        *b = (k * 109 + 33) as u8
                    }
                    let mut expected = seed;
                    expected[start..pos].copy_from_slice(&lits[5..5 + ll]);
                    for k in 0..ml {
                        expected[pos + k] = expected[src + k]
                    }
                    let r = Ready {
                        start,
                        lstart: 5,
                        at: end,
                        lit: 5 + ll,
                        count: 1,
                    };
                    f.ll[0] = ll as u32;
                    f.ml[0] = ml as u32;
                    f.src[0] = src as u32;
                    f.dst[0] = pos as u32;
                    f.lit[0] = 5;
                    for mode in 1..=8 {
                        let mut actual = seed;
                        unsafe { run(&mut actual, &lits, &f, r, mode) }
                        assert_eq!(actual[..end], expected[..end], "{ll} {ml} {off} {mode}");
                        assert_eq!(actual[end + 16..], seed[end + 16..]);
                    }
                }
            }
        }
    }
}
