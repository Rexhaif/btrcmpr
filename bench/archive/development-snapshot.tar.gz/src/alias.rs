// Leave ASCII literals alone and use the high half of the alphabet for
// frequent strings learned in this block. Original high bytes use an escape
// and a separate stream. Every table entry expands to at most seven bytes.
use crate::{Result, ans, bad, lz, take, u32in};
#[derive(Clone, Copy, Default)]
struct Piece {
    word: u64,
    len: u8,
}
#[inline]
fn mask(n: u8) -> u64 {
    (1u64 << (8 * n)) - 1
}
fn train(s: &[u8], limit: usize) -> Vec<Piece> {
    let mut book: Vec<_> = (0..128).map(|v| Piece { word: v, len: 1 }).collect();
    let sample = s.len().min(73728);
    let blocks = sample.div_ceil(1024);
    let mut seq = Vec::with_capacity(sample + blocks);
    for k in 0..blocks {
        let len = (sample - k * 1024).min(1024);
        let at = (s.len() - len) * k / blocks.saturating_sub(1).max(1);
        seq.extend(
            s[at..at + len]
                .iter()
                .map(|&c| if c < 128 { c } else { 255 }),
        );
        seq.push(255);
    }
    let mut counts = vec![0u32; 65536];
    let mut repl = vec![0u8; 65536];
    while book.len() < 128 + limit {
        counts.fill(0);
        repl.fill(0);
        for t in seq.windows(2) {
            let a = t[0] as usize;
            let b = t[1] as usize;
            if a != 255 && b != 255 && book[a].len + book[b].len <= 7 {
                counts[a * 256 + b] += 1;
            }
        }
        let mut rr: Vec<_> = (0..65536).filter(|&v| counts[v] > 3).collect();
        let take_n = if book.len() == 128 { 22 } else { 12 };
        let cap = (128 + limit - book.len()).min(take_n).min(rr.len());
        if cap == 0 {
            break;
        }
        if cap < rr.len() {
            rr.select_nth_unstable_by_key(cap, |&v| (std::cmp::Reverse(counts[v]), v));
        }
        rr.truncate(cap);
        rr.sort_unstable_by_key(|&v| (std::cmp::Reverse(counts[v]), v));
        for p in rr {
            let a = book[p >> 8];
            let b = book[p & 255];
            let x = Piece {
                word: a.word | (b.word << (a.len * 8)),
                len: a.len + b.len,
            };
            if book[128..]
                .iter()
                .any(|q| q.word == x.word && q.len == x.len)
            {
                continue;
            }
            repl[p] = book.len() as u8;
            book.push(x);
        }
        if repl.iter().all(|&b| b == 0) {
            break;
        }
        let mut i = 0;
        let mut j = 0;
        while i < seq.len() {
            let a = seq[i];
            let code = if i + 1 < seq.len() {
                repl[a as usize * 256 + seq[i + 1] as usize]
            } else {
                0
            };
            seq[j] = if code == 0 { a } else { code };
            i += 1 + usize::from(code != 0);
            j += 1;
        }
        seq.truncate(j);
    }
    book
}
pub(crate) fn encode(s: &[u8], kind: usize) -> Vec<u8> {
    let limit = [30, 62, 126][kind % 3];
    let book = train(s, limit);
    let mut order: Vec<_> = (128..book.len()).collect();
    order.sort_unstable_by_key(|&v| book[v].len);
    let mut table = vec![0u8; 65536];
    let mut prev = [0u8; 256];
    for v in order {
        let key = book[v].word as u16 as usize;
        prev[v] = table[key];
        table[key] = v as u8;
    }
    let mut codes = Vec::with_capacity(s.len());
    let mut extra = vec![];
    let mut i = 0;
    while i < s.len() {
        let raw = s[i];
        if raw >= 128 {
            codes.push(255);
            extra.push(raw);
            i += 1;
            continue;
        }
        let rem = s.len() - i;
        let w = if rem >= 8 {
            lz::word(s, i)
        } else {
            let mut x = [0; 8];
            x[..rem].copy_from_slice(&s[i..]);
            u64::from_le_bytes(x)
        };
        let mut code = table[w as u16 as usize];
        while code != 0 {
            let t = book[code as usize];
            if t.len as usize <= rem && w & mask(t.len) == t.word {
                break;
            }
            code = prev[code as usize];
        }
        if code == 0 {
            codes.push(raw);
            i += 1;
        } else {
            codes.push(code);
            i += book[code as usize].len as usize;
        }
    }
    let mut out = vec![31, (book.len() - 128) as u8];
    for p in &book[128..] {
        out.push(p.len);
        out.extend(&p.word.to_le_bytes()[..p.len as usize]);
    }
    ans::put_tight(&extra, &mut out);
    out.extend((codes.len() as u32).to_le_bytes());
    for b in codes.chunks(1 << 21) {
        let packed = match kind / 3 {
            0 => lz::encode_level::<false>(b, 2),
            1 => lz::encode_level::<false>(b, 3),
            2 => lz::legacy::<false, 17, 17, false, 0>(b),
            3 => lz::legacy::<false, 17, 17, true, 2>(b),
            _ => lz::optimal(b, 14),
        };
        out.extend((packed.len() as u32).to_le_bytes());
        out.extend(packed);
    }
    out
}
pub(crate) fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let entries = take(&mut p, 1)?[0] as usize;
    if entries > 127 {
        return Err(bad());
    }
    let mut dict = [0u64; 256];
    for (i, v) in dict[..128].iter_mut().enumerate() {
        *v = i as u64 | (1 << 56);
    }
    for d in &mut dict[128..128 + entries] {
        let n = take(&mut p, 1)?[0] as usize;
        if !(2..=7).contains(&n) {
            return Err(bad());
        }
        let mut x = [0; 8];
        x[..n].copy_from_slice(take(&mut p, n)?);
        x[7] = n as u8;
        *d = u64::from_le_bytes(x);
    }
    let extra = crate::lex::plain(&mut p, dst.len())?;
    let nt = u32in(&mut p)?;
    if nt > dst.len() {
        return Err(bad());
    }
    let mut codes = vec![0; nt];
    for d in codes.chunks_mut(1 << 21) {
        let n = u32in(&mut p)?;
        let (&m, s) = take(&mut p, n)?.split_first().ok_or_else(bad)?;
        crate::cascade::expand_leaf(m, s, d)?;
    }
    if !p.is_empty() {
        return Err(bad());
    }
    let mut at = 0;
    let mut ex = 0;
    for chunk in codes.chunks(8) {
        let mut w = [0u64; 8];
        let mut pos = [0usize; 8];
        for (k, &c) in chunk.iter().enumerate() {
            let mut word = dict[c as usize];
            if c == 255 {
                word = *extra.get(ex).ok_or_else(bad)? as u64 | (1 << 56);
                ex += 1;
            }
            if word >> 56 == 0 {
                return Err(bad());
            }
            w[k] = word;
            pos[k] = at;
            at += (word >> 56) as usize;
        }
        if at > dst.len() {
            return Err(bad());
        }
        if at + 8 <= dst.len() {
            for j in 0..chunk.len() {
                unsafe {
                    dst.as_mut_ptr()
                        .add(pos[j])
                        .cast::<u64>()
                        .write_unaligned(w[j].to_le());
                }
            }
        } else {
            for j in 0..chunk.len() {
                let n = (w[j] >> 56) as usize;
                dst[pos[j]..pos[j] + n].copy_from_slice(&w[j].to_le_bytes()[..n]);
            }
        }
    }
    if at != dst.len() || ex != extra.len() {
        return Err(bad());
    }
    Ok(())
}
