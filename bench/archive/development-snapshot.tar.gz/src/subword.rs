// Price rare word spellings as sequences of recurring byte pieces. The decoder
// still receives ordinary phrase entries; the statistical sketch is encoder-only.
use super::Term;
use std::collections::{HashMap, hash_map::Entry};

#[inline]
fn bucket(word: u64, len: usize, mask: usize) -> usize {
    let x = (word ^ (len as u64).wrapping_mul(0x9e3779b97f4a7c15)).wrapping_mul(0xa24baed4963ee407);
    ((x ^ (x >> 31)) as usize) & mask
}
pub(super) fn split(
    s: &[u8],
    terms: Vec<Term>,
    ids: Vec<u32>,
    rare: u32,
    rent: u32,
) -> (Vec<Term>, Vec<u32>) {
    if rare == 0 || terms.is_empty() {
        return (terms, ids);
    }
    let bins = (terms.len() * 8).next_power_of_two().clamp(1024, 1 << 21);
    let mut freq = vec![0u32; bins];
    let mut mass = 0u64;
    for t in &terms {
        let pos = t.pos as usize;
        let v = &s[pos..pos + usize::from(t.len)];
        let f = t.count.min(8);
        mass += u64::from(f) * v.len() as u64;
        for i in 0..v.len() {
            let mut w = 0u64;
            for (j, &b) in v[i..].iter().take(8).enumerate() {
                w = (w << 8) | u64::from(b);
                let h = bucket(w, j + 1, bins - 1);
                freq[h] = freq[h].saturating_add(f);
            }
        }
    }
    let base = (mass.max(4) / 4) as f64;
    let price: Vec<u32> = (0..=65535)
        .map(|n| ((base / f64::from(n.max(1))).log2() * 16.).round().max(3.) as u32)
        .collect();
    let mut pool = Vec::<Term>::with_capacity(terms.len() / 2);
    let mut by_spelling = HashMap::<&[u8], u32>::with_capacity(terms.len() / 2);
    let mut map = Vec::with_capacity(terms.len() + 1);
    let mut parts = Vec::with_capacity(terms.len() * 2);
    for &t in &terms {
        let n = usize::from(t.len);
        let p = t.pos as usize;
        let v = &s[p..p + n];
        let mut mask = 0u16;
        if n >= 3 && t.count <= rare {
            let mut dp = [u32::MAX; 17];
            let mut cuts = [0u16; 17];
            dp[0] = 0;
            for i in 0..n {
                let mut w = 0u64;
                for j in i..(i + 8).min(n) {
                    w = (w << 8) | u64::from(v[j]);
                    if i == 0 && j + 1 == n {
                        continue;
                    }
                    let len = j + 1 - i;
                    let f = freq[bucket(w, len, bins - 1)].max(1);
                    let fee = price[f.min(65535) as usize] + 12 + (rent * len as u32).div_ceil(f);
                    let c = dp[i] + fee;
                    if c < dp[j + 1] {
                        dp[j + 1] = c;
                        cuts[j + 1] = cuts[i] | (1u16 << j);
                    }
                }
            }
            let whole =
                price[t.count.min(65535) as usize] + 12 + (rent * n as u32).div_ceil(t.count);
            if dp[n] < whole {
                mask = cuts[n]
            }
        }
        mask |= 1u16 << (n - 1);
        map.push(parts.len() as u32);
        let mut i = 0;
        while mask != 0 {
            let end = (mask.trailing_zeros() + 1) as usize;
            let id = match by_spelling.entry(&v[i..end]) {
                Entry::Occupied(e) => *e.get(),
                Entry::Vacant(e) => {
                    let id = pool.len() as u32;
                    pool.push(Term {
                        pos: (p + i) as u32,
                        len: (end - i) as u8,
                        count: 0,
                    });
                    e.insert(id);
                    id
                }
            };
            pool[id as usize].count += t.count;
            parts.push(id);
            i = end;
            mask &= mask - 1;
        }
    }
    map.push(parts.len() as u32);
    let n = pool.iter().map(|t| t.count as usize).sum();
    let mut stream = Vec::with_capacity(n);
    for id in ids {
        let i = id as usize;
        stream.extend_from_slice(&parts[map[i] as usize..map[i + 1] as usize]);
    }
    (pool, stream)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rare_pieces_share_spelling_and_restore_arbitrary_bytes() {
        let mut s = Vec::new();
        for i in 0..800 {
            s.extend_from_slice(
                format!(
                    "preparing riverboats {} {} ",
                    i % 19,
                    ["whistleboats", "riverboatmen", "waterside", "winterwater"][i % 4]
                )
                .as_bytes(),
            );
            s.extend_from_slice(&[0, 0x91, i as u8]);
        }
        for t in 0..48u8 {
            s.extend_from_slice(&[
                b'w',
                b'a',
                b't',
                b'e',
                b'r',
                b'a' + t / 10,
                b'a' + t % 10,
                b' ',
            ]);
        }
        let (base, ids) = super::super::tokenize(&s, 0);
        let original = ids.len();
        let (dict, plan) = split(&s, base, ids, 4, 88);
        let mut raw = vec![];
        for id in &plan {
            let t = dict[*id as usize];
            raw.extend_from_slice(&s[t.pos as usize..t.pos as usize + usize::from(t.len)]);
        }
        assert_eq!(raw, s);
        assert!(plan.len() > original);
        assert_eq!(
            plan.len(),
            dict.iter().map(|t| t.count as usize).sum::<usize>()
        );
    }
}
