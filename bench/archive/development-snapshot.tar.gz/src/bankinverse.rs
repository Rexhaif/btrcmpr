// Alternate inverses of the existing instruction-bank wire format.
use super::{BANKS, bank};
use crate::{Result, bad};
#[inline(always)]
fn half(v: &[u8], k: usize) -> u16 {
    u16::from_le_bytes([v[k], v[k + 1]])
}
#[allow(clippy::too_many_arguments)]
pub(super) fn stream<const B: usize, const DELTA: bool, const PACKED: bool>(
    t: &[u8],
    rows: usize,
    spans: &mut [(usize, &mut [u8])],
    mut loc: [u32; BANKS],
    ends: [u32; BANKS],
    tail: &[u8],
    mask: Option<&[u8]>,
) -> Result<()> {
    let n = rows * 4;
    let mut row = 0;
    let mut previous = [0u16; BANKS];
    let mut deltas = [0u16; BANKS];
    let mut state = [0u64; BANKS];
    for (i, &pos) in loc[..64 << B].iter().enumerate() {
        let m = if DELTA && mask.is_none_or(|m| m[i / 8] >> (i % 8) & 1 != 0) {
            u16::MAX
        } else {
            0
        };
        if PACKED {
            state[i] = u64::from(pos) << 32 | u64::from(m) << 16
        } else {
            deltas[i] = m
        }
    }
    for (offset, d) in spans {
        if *offset != row * 4 || (d.len() % 4 != 0 && *offset + d.len() != n + tail.len()) {
            return Err(bad());
        }
        for out in d.chunks_exact_mut(4) {
            let upper = half(t, row * 2);
            let id = bank::<B>(upper);
            let pos = if PACKED {
                (state[id] >> 32) as u32
            } else {
                loc[id]
            };
            if pos as usize >= n {
                return Err(bad());
            }
            // Bank cursors and n are even. Every successful load therefore
            // leaves room for both bytes, including on a malformed archive.
            let raw = unsafe {
                t.as_ptr()
                    .add(pos as usize)
                    .cast::<u16>()
                    .read_unaligned()
                    .to_le()
            };
            let lower = if PACKED {
                let x = state[id];
                let prev = x as u16;
                let m = (x >> 16) as u16;
                let low = raw.wrapping_add(prev & m);
                state[id] = (u64::from(pos + 2) << 32) | (x & 0xffff0000) | u64::from(low);
                low
            } else {
                loc[id] = pos + 2;
                if DELTA {
                    let low = raw.wrapping_add(previous[id] & deltas[id]);
                    previous[id] = low;
                    low
                } else {
                    raw
                }
            };
            out.copy_from_slice(&(u32::from(upper) << 16 | u32::from(lower)).to_le_bytes());
            row += 1;
        }
        if d.len() % 4 != 0 {
            let at = d.len() / 4 * 4;
            d[at..].copy_from_slice(tail)
        }
    }
    if row != rows {
        return Err(bad());
    }
    if PACKED {
        for (i, v) in loc[..64 << B].iter_mut().enumerate() {
            *v = (state[i] >> 32) as u32
        }
    }
    if loc != ends {
        return Err(bad());
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub(super) fn pairs<const B: usize, const TILE: usize, const HINT: bool>(
    t: &[u8],
    rows: usize,
    spans: &mut [(usize, &mut [u8])],
    mut loc: [u32; BANKS],
    ends: [u32; BANKS],
    tail: &[u8],
) -> Result<()> {
    let n = 4 * rows;
    let mut row = 0;
    let mut slots = [0u32; TILE];
    for (offset, d) in spans {
        if *offset != 4 * row || (d.len() % 4 != 0 && *offset + d.len() != n + tail.len()) {
            return Err(bad());
        }
        let full = d.len() / 4;
        for chunk in d[..full * 4].chunks_mut(4 * TILE) {
            let k = chunk.len() / 4;
            let hi = &t[2 * row..2 * (row + k)];
            let mut max = 0u32;
            for (i, pos) in slots[..k].iter_mut().enumerate() {
                let id = bank::<B>(half(hi, 2 * i));
                let at = loc[id];
                loc[id] = at + 2;
                *pos = at;
                max = max.max(at);
                #[cfg(target_arch = "aarch64")]
                if HINT {
                    unsafe {
                        core::arch::asm!("prfm pldl1keep, [{p}]",p=in(reg)t.as_ptr().wrapping_add(at as usize),options(readonly,nostack,preserves_flags))
                    }
                }
            }
            if max as usize >= n {
                return Err(bad());
            }
            let mut i = 0;
            while i + 2 <= k {
                unsafe {
                    let h = u64::from(
                        hi.as_ptr()
                            .add(2 * i)
                            .cast::<u32>()
                            .read_unaligned()
                            .to_le(),
                    );
                    let u = ((h | (h << 16)) & 0xffff0000ffff) << 16;
                    let lo = |pos: u32| {
                        u64::from(
                            t.as_ptr()
                                .add(pos as usize)
                                .cast::<u16>()
                                .read_unaligned()
                                .to_le(),
                        )
                    };
                    let word = u | lo(slots[i]) | (lo(slots[i + 1]) << 32);
                    chunk
                        .as_mut_ptr()
                        .add(4 * i)
                        .cast::<u64>()
                        .write_unaligned(word.to_le());
                }
                i += 2;
            }
            if i < k {
                let v = u32::from(half(hi, 2 * i)) << 16 | u32::from(half(t, slots[i] as usize));
                chunk[4 * i..4 * i + 4].copy_from_slice(&v.to_le_bytes())
            }
            row += k;
        }
        if d.len() % 4 != 0 {
            d[4 * full..].copy_from_slice(tail)
        }
    }
    if row != rows || loc != ends {
        return Err(bad());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn adaptive_bank_deltas_and_two_span_word_restoration() {
        const B: usize = 3;
        let n = 1063;
        let mut raw = Vec::new();
        let mut groups = vec![vec![]; 64 << B];
        let mut state = 731u32;
        let mut upper = Vec::new();
        let mut m = [0u8; 64];
        for i in 0..n {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            let hi = if i % 3 == 0 { 0xa133 } else { state as u16 };
            let lo = (state >> 16) as u16;
            let id = bank::<B>(hi);
            groups[id].push(lo);
            m[id / 8] |= u8::from(!id.is_multiple_of(3)) << (id % 8);
            upper.extend(hi.to_le_bytes());
            raw.extend(lo.to_le_bytes());
            raw.extend(hi.to_le_bytes());
        }
        let tail = [11, 125, 127];
        raw.extend(tail);
        let mut loc = [0u32; BANKS];
        let mut end = loc;
        for mask in [None, Some(&m[..]), Some(&[0u8; 64][..])] {
            let mut t = upper.clone();
            let mut abs = upper.clone();
            for (id, g) in groups.iter().enumerate() {
                loc[id] = t.len() as u32;
                let mut prev = 0;
                for &x in g {
                    let v = if mask.is_none_or(|m| m[id / 8] >> (id % 8) & 1 != 0) {
                        x.wrapping_sub(prev)
                    } else {
                        x
                    };
                    prev = x;
                    t.extend(v.to_le_bytes());
                    abs.extend(x.to_le_bytes())
                }
                end[id] = t.len() as u32;
            }
            for method in 0..5 {
                let mut result = vec![0; raw.len()];
                let (a, b) = result.split_at_mut(188);
                let mut spans = [(0, a), (188, b)];
                match method {
                    0 => stream::<B, true, false>(&t, n, &mut spans, loc, end, &tail, mask),
                    1 => stream::<B, true, true>(&t, n, &mut spans, loc, end, &tail, mask),
                    2 => stream::<B, false, false>(&abs, n, &mut spans, loc, end, &tail, None),
                    3 => pairs::<B, 16, false>(&abs, n, &mut spans, loc, end, &tail),
                    _ => pairs::<B, 32, true>(&abs, n, &mut spans, loc, end, &tail),
                }
                .unwrap();
                assert_eq!(raw, result);
            }
        }
        let mut bad_loc = loc;
        bad_loc[bank::<B>(u16::from_le_bytes([upper[0], upper[1]]))] = (4 * n) as u32;
        let mut result = vec![0; raw.len()];
        assert!(
            pairs::<B, 16, false>(
                &raw[..n * 4],
                n,
                &mut [(0, &mut result)],
                bad_loc,
                end,
                &tail
            )
            .is_err()
        );
    }
}
