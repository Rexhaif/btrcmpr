// With the low four bytes fixed, changing byte five by x shifts the
// multiplicative hash by 2^56 * (odd * x) modulo 2^64. Its top byte is
// therefore different. Populated 15-bit buckets can never produce a match
// of exactly four bytes. A never-written slot has different semantics: the
// original index may allow it to reference input position zero.
use super::{MASK, Streams, common, word};

#[inline(always)]
fn key(w: u64) -> usize {
    ((w << 24).wrapping_mul(0x9e3779b97f4a7c15) >> 49) as usize
}
#[inline(always)]
fn entry<const M: usize>(w: u64, i: usize) -> u32 {
    if M >= 3 {
        i as u32 + 1
    } else {
        (w as u32) << 21 | i as u32
    }
}
// Return the XOR only for a qualifying copy, so failed probes never need
// a length. With this trusted encoder index a populated position precedes i.
#[inline(always)]
fn check<const M: usize>(s: &[u8], i: usize, w: u64, slot: u32) -> (u64, usize) {
    let sig = (w as u32) << 21;
    let pos = if M >= 3 {
        slot.saturating_sub(1) as usize
    } else {
        slot as usize & MASK
    };
    if (M == 1 && (slot ^ sig) > MASK as u32) || i == 0 {
        return (u64::MAX, 0);
    }
    if M == 4 && slot == 0 && sig != 0 {
        return (u64::MAX, 0);
    }
    debug_assert!(pos < i && i + 8 <= s.len());
    let v = unsafe { s.as_ptr().add(pos).cast::<u64>().read_unaligned() }.to_le() ^ w;
    if v as u32 != 0 {
        return (u64::MAX, 0);
    }
    // Also covers a real position zero with a zero fingerprint in the
    // packed table. Four-byte far matches remain ineligible for empty slots.
    if slot == 0 && (sig != 0 || (v >> 32) as u8 != 0 && i > 12000) {
        return (u64::MAX, 0);
    }
    (v, pos)
}

#[inline(always)]
fn parse<const M: usize>(s: &[u8], mut emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    let mut tab = vec![0u32; 32768];
    let mut i = 0;
    let mut anchor = 0;
    while i + 8 <= s.len() {
        let w = word(s, i);
        let k = key(w);
        let here = entry::<M>(w, i);
        let (d, mut q) = if i + 9 <= s.len() {
            let next = word(s, i + 1);
            let j = key(next);
            let old = tab[k];
            let next_pos = if j == k { here } else { tab[j] };
            tab[k] = here;
            let a = check::<M>(s, i, w, old);
            if a.0 != u64::MAX {
                a
            } else {
                i += 1;
                tab[j] = entry::<M>(next, i);
                check::<M>(s, i, next, next_pos)
            }
        } else {
            let old = std::mem::replace(&mut tab[k], here);
            check::<M>(s, i, w, old)
        };
        if d == u64::MAX {
            i += 1;
            continue;
        }
        let mut n = if d != 0 {
            (d.trailing_zeros() / 8) as usize
        } else {
            8 + common(s, q + 8, i + 8)
        };
        let off = i - q;
        while i > anchor && q > 0 && s[i - 1] == s[q - 1] {
            i -= 1;
            q -= 1;
            n += 1;
        }
        emit(anchor, i, n, off);
        i += n;
        anchor = i;
        for j in i - 2..i {
            if j + 8 <= s.len() {
                let tail = word(s, j);
                tab[key(tail)] = entry::<M>(tail, j);
            }
        }
    }
    anchor
}
#[inline(always)]
pub(super) fn walk(s: &[u8], mode: usize, emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    match mode {
        1 => parse::<1>(s, emit),
        2 => parse::<2>(s, emit),
        3 => parse::<3>(s, emit),
        _ => parse::<4>(s, emit),
    }
}
pub(super) fn encode(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    let mut st = Streams::sized(s.len());
    let last = walk(s, mode, |a, i, n, o| st.emit(s, a, i, n, o));
    st.finish(s, last, archive)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn changing_the_fifth_byte_cannot_preserve_the_bucket() {
        for p in [0, 0xffff_ffffu64, 0x5352_5171, 0x7468_6520] {
            let mut seen = [false; 32768];
            for x in 0u64..256 {
                let k = key(p | (x << 32));
                assert!(!seen[k]);
                seen[k] = true;
            }
        }
    }
    #[test]
    fn prefix_checks_preserve_implicit_zero_and_populated_buckets() {
        let mut state = 637u32;
        let mut data = vec![0; 9];
        for n in 0..45_000 {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            data.push((state >> 24) as u8);
            if n % 31 == 0 {
                data.extend_from_slice(b"\0\0\x19\x27\x82repeat repeated short prefix");
            }
        }
        data[..8].copy_from_slice(&[0, 0, 25, 39, 7, 6, 5, 4]);
        data[381..389].copy_from_slice(&[0, 0, 25, 39, 8, 3, 2, 1]);
        data[16023..16031].copy_from_slice(&[0, 0, 25, 39, 9, 3, 2, 1]);
        for n in (0..21).chain([533, 16040, data.len()]) {
            let s = &data[..n];
            let mut expected = Vec::new();
            let end = super::super::quicktwo::walk(s, |a, i, n, o| expected.push((a, i, n, o)));
            for m in 1..=4 {
                let mut out = Vec::new();
                assert_eq!(walk(s, m, |a, i, n, o| out.push((a, i, n, o))), end);
                assert_eq!(out, expected);
            }
        }
    }
}
