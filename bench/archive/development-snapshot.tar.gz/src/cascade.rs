// Literal runs become adjacent after the first parser removes matches. Compress
// that residual in independent LZ pages; the outer distances still address
// the original byte stream. The decoder allows exactly these two LZ stages.
use crate::{Result, bad, lz, take, u32in};
#[cfg(feature = "research")]
pub(crate) fn pack(raw: &[u8], outer: Vec<u8>, method: usize) -> Vec<u8> {
    let mut out = vec![26];
    out.extend((raw.len() as u32).to_le_bytes());
    let shift = if method == 3 { 18 } else { 21 };
    out.push(shift);
    for page in raw.chunks(1 << shift) {
        let b = match method {
            0 | 3 => lz::legacy::<false, 16, 16, false, 0>(page),
            1 => lz::legacy::<false, 17, 17, true, 2>(page),
            _ => lz::optimal(page, 14),
        };
        if b.len() <= page.len() {
            out.extend((b.len() as u32).to_le_bytes());
            out.extend(b);
        } else {
            out.extend(((page.len() + 1) as u32).to_le_bytes());
            out.push(0);
            out.extend(page);
        }
    }
    out.extend(outer);
    out
}
pub(crate) fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let n = u32in(&mut p)?;
    let shift = take(&mut p, 1)?[0];
    if n > dst.len() || !(14..=23).contains(&shift) {
        return Err(bad());
    }
    let mut literals = vec![0; n];
    for d in literals.chunks_mut(1 << shift) {
        let len = u32in(&mut p)?;
        let (mode, s) = take(&mut p, len)?.split_first().ok_or_else(bad)?;
        expand_leaf(*mode, s, d)?;
    }
    let (outer, s) = p.split_first().ok_or_else(bad)?;
    match outer {
        1 => lz::decode_core::<false, 4, true, false>(s, dst, &literals),
        13 => lz::decode_core::<true, 4, true, false>(s, dst, &literals),
        16 => lz::decode_core::<false, 3, true, false>(s, dst, &literals),
        17 => lz::decode_core::<true, 3, true, false>(s, dst, &literals),
        _ => Err(bad()),
    }
}
pub(crate) fn expand_leaf(mode: u8, s: &[u8], d: &mut [u8]) -> Result<()> {
    match mode {
        0 if s.len() == d.len() => {
            d.copy_from_slice(s);
            Ok(())
        }
        1 => lz::decode_core::<false, 4, false, true>(s, d, &[]),
        13 => lz::decode_core::<true, 4, false, true>(s, d, &[]),
        16 => lz::decode_core::<false, 3, false, true>(s, d, &[]),
        17 => lz::decode_core::<true, 3, false, true>(s, d, &[]),
        _ => Err(bad()),
    }
}
