// For bit width w, every value with more than w bits needs a position byte
// and an initial 7-bit digit. Each further group of 7 high bits adds a byte.
use super::{N, WIDTHS};
#[inline]
pub(super) fn width(values: &[u32; N], n: usize) -> (usize, usize, usize) {
    let mut suffix = [0u16; 64];
    for &v in &values[..n] {
        suffix[(32 - v.leading_zeros()) as usize] += 1;
    }
    let mut above = 0;
    for x in suffix[..33].iter_mut().rev() {
        let c = *x;
        *x = above;
        above += c
    }
    let mut best = (usize::MAX, 0, 0);
    for &w in WIDTHS {
        if 16 * w >= best.0 {
            break;
        }
        let ex = suffix[w];
        let bytes = 16 * w
            + usize::from(
                2 * ex + suffix[w + 7] + suffix[w + 14] + suffix[w + 21] + suffix[w + 28],
            );
        if bytes < best.0 {
            best = (bytes, w, usize::from(ex))
        }
    }
    best
}
// A small sample can distinguish wide monotone counters from tightly bounded
// absolute fields. Only discard the other predictor when its sampled residuals
// cost distinctly more bits. A discarded option may increase size; the chosen
// predictor and every exception still describe the original words exactly.
#[cfg(feature = "research")]
pub(super) fn predictors<const MODE: u8>(
    raw: &[u32; N],
    delta: &[u32; N],
    n: usize,
) -> ((usize, usize, usize), (usize, usize, usize)) {
    // The two prices include no common header. The raw candidate may need
    // four additional bytes for its base; a sentinel must leave room for it.
    const SKIP: (usize, usize, usize) = (usize::MAX - 8, 0, 0);
    if n < 32 {
        return (width(raw, n), width(delta, n));
    }
    let step = if MODE >= 8 { 8 } else { 16 };
    let mut score = 0i32;
    let mut samples = 0;
    for i in (step / 2..n).step_by(step) {
        score += delta[i].leading_zeros() as i32 - raw[i].leading_zeros() as i32;
        samples += 1;
    }
    let threshold = match MODE {
        4 | 8 => 0,
        5 | 9 => 1,
        6 | 10 => 2,
        _ => 4,
    };
    // A positive score means delta has fewer sampled residual bits.
    if score > threshold * samples {
        return (SKIP, width(delta, n));
    }
    if score < -(threshold * samples) {
        return (width(raw, n), SKIP);
    }
    (width(raw, n), width(delta, n))
}
// Preserve the tie rule (prefer a base) and byte order of the generic writer.
pub(super) fn constant(x: u32, prev: u32, out: &mut Vec<u8>) {
    if x == 0 {
        out.extend([0, 0]);
    } else if x == prev {
        out.extend([64, 0]);
    } else {
        let d = x.wrapping_sub(prev);
        let z = (d << 1) ^ ((d as i32 >> 31) as u32);
        if z < 128 {
            out.extend([64, 1, 0, z as u8]);
        } else if z < 16384 {
            out.extend([64, 1, 0, (z as u8) | 128, (z >> 7) as u8]);
        } else {
            out.extend([128, 0]);
            out.extend(x.to_le_bytes());
        }
    }
}
#[cfg(all(
    feature = "research",
    target_arch = "aarch64",
    target_endian = "little"
))]
unsafe fn pack<const W: usize>(v: &[u32; N], p: *mut u8) {
    use core::arch::aarch64::*;
    unsafe {
        let mut buf = vdupq_n_u32(0);
        let mask = vdupq_n_u32(((1u64 << W) - 1) as u32);
        macro_rules! one {
            ($i:literal) => {{
                let sh = $i * W % 32;
                let x = vandq_u32(vld1q_u32(v.as_ptr().add(4 * $i)), mask);
                let shifted = if sh == 0 {
                    x
                } else {
                    vshlq_u32(x, vdupq_n_s32(sh as i32))
                };
                buf = vorrq_u32(buf, shifted);
                if sh + W >= 32 {
                    vst1q_u32(p.add(($i * W / 32) * 16).cast(), buf);
                    buf = if sh + W > 32 {
                        vshlq_u32(x, vdupq_n_s32(sh as i32 - 32))
                    } else {
                        vdupq_n_u32(0)
                    };
                }
            }};
        }
        macro_rules! all {($($i:literal),*)=>{$(one!($i);)*}}
        all!(
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23,
            24, 25, 26, 27, 28, 29, 30, 31
        );
        let _ = buf;
    }
}
#[cfg(all(
    feature = "research",
    target_arch = "aarch64",
    target_endian = "little"
))]
pub(super) fn packed(v: &[u32; N], w: usize, out: &mut Vec<u8>) {
    let start = out.len();
    out.reserve(16 * w);
    unsafe {
        let p = out.as_mut_ptr().add(start);
        macro_rules! cases {($($w:literal),*)=>{match w {$($w=>pack::<$w>(v,p),)*_=>unreachable!()}}}
        cases!(
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 26, 28, 30, 32
        );
        // Each group of 32 rows writes exactly W complete 16-byte words.
        out.set_len(start + 16 * w);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn same_width_and_full_record_for_all_inputs() {
        let mut r = 219938u32;
        let mut v = [0; 128];
        let mut data = Vec::new();
        for j in 0..211 {
            for (i, value) in v.iter_mut().enumerate() {
                r = r.wrapping_mul(1664525).wrapping_add(1013904223);
                *value = match j % 8 {
                    0 => 0,
                    1 => i as u32 % 3,
                    2 => r >> (j % 32),
                    3 => 1 << (r % 32),
                    4 => {
                        if i % 13 == 0 {
                            r
                        } else {
                            0
                        }
                    }
                    5 => j as u32,
                    6 => u32::MAX - (r % 97),
                    _ => r,
                };
                data.extend(value.to_le_bytes());
            }
            for n in [1, 2, 5, 32, 99, 127, 128] {
                assert_eq!(width(&v, n), super::super::width(&v, n))
            }
        }
        for n in [1, 4, 799, 1559, 2123, 16533, data.len()] {
            for w in [1, 2, 3, 4, 6, 8] {
                let a = super::super::encode_impl::<0>(&data[..n], w, 3);
                for m in 1..=3 {
                    assert_eq!(super::super::fast(&data[..n], w, 3, m), a)
                }
            }
        }
        #[cfg(feature = "research")]
        for n in [12, 127, 387, 6667, data.len()] {
            for w in [1, 3, 8] {
                for policy in 4..=11 {
                    let out = super::super::fast(&data[..n], w, 3, policy);
                    let mut restored = vec![0; n];
                    super::super::decode(&out[1..], &mut restored).unwrap();
                    assert_eq!(restored, data[..n]);
                }
            }
        }
        for p in [0, 1, 88, 166, 8192, 8193, 84531, u32::MAX] {
            for x in [0, 1, 64, 88, 8191, 8192, 84532, u32::MAX] {
                let a = [x; 128];
                let mut s = Vec::new();
                super::super::field::<0>(&a, 39, p, &mut s);
                let mut f = Vec::new();
                constant(x, p, &mut f);
                assert_eq!(s, f);
            }
        }
    }
}
