// Store absolute copy distances in aligned planes with one element per
// command. This removes both the variable-width selectors and their
// dependency on the preceding three commands. The parse is unchanged.
use super::{BATCH, Fields, Ready, lenin, lenout, quicktwo, restore_ready};
use crate::{Result, ans, bad, take};

pub(super) fn put(s: &[u8], archive: bool, mode: usize) -> Vec<u8> {
    let max = s.len() / 4 + 1;
    let mut tags = Vec::with_capacity(max);
    let mut lo = Vec::with_capacity(max);
    let mut hi = Vec::with_capacity(max);
    let mut upper = Vec::with_capacity(max);
    let mut lens = Vec::new();
    let mut lits: Vec<u8> = Vec::with_capacity(s.len() + 16);
    let repeat = mode & 1 != 0;
    let mut prev = 1usize;
    let anchor = quicktwo::walk(s, |a, i, n, dist| {
        let ll = i - a;
        let ml = n - 4;
        tags.push(((ll.min(15) << 4) | ml.min(15)) as u8);
        if ll >= 15 {
            lenout(ll - 15, &mut lens)
        }
        if ml >= 15 {
            lenout(ml - 15, &mut lens)
        }
        let v = if repeat {
            if dist == prev {
                0
            } else {
                dist - usize::from(dist > prev)
            }
        } else {
            dist - 1
        };
        prev = dist;
        lo.push(v as u8);
        hi.push((v >> 8) as u8);
        upper.push((v >> 16) as u8);
        let start = lits.len();
        // Literal ranges are disjoint subsets of s; capacity includes eight
        // bytes of padding for the fixed short copy. Publish only ll bytes.
        unsafe {
            let take = if ll <= 8 && a + 8 <= s.len() { 8 } else { ll };
            std::ptr::copy_nonoverlapping(s.as_ptr().add(a), lits.as_mut_ptr().add(start), take);
            lits.set_len(start + ll);
        }
    });
    lits.extend(&s[anchor..]);
    fields([&tags, &lens, &lits, &lo, &hi, &upper], archive, mode, None)
}
fn fields(streams: [&[u8]; 6], archive: bool, mode: usize, literal: Option<&[u8]>) -> Vec<u8> {
    let mut out = vec![59, (mode & 1) as u8];
    let cut = if archive { 0.90 } else { 0.985 };
    for (id, v) in streams.into_iter().enumerate() {
        if id == 2
            && let Some(literal) = literal
        {
            out.extend(literal)
        } else if id == 2 && mode & 2 != 0 && !archive && v.len() >= 2048 {
            out.extend(crate::context::candidate(v, None))
        } else if id == 3 && mode & 4 != 0 {
            out.extend((v.len() as u32).to_le_bytes());
            out.push(0);
            out.extend(v)
        } else if id == 4 && mode & 8 != 0 && v.len() >= 2048 {
            out.extend(crate::context::candidate(v, Some(streams[0])))
        } else {
            ans::put_policy(v, &mut out, cut)
        }
    }
    out
}
// Reuse a middle preset's validated parser and its transmitted literal model.
// This adapts the command list, without searching for any matches a second time.
pub(super) fn convert(st: &super::Streams, mode: usize, literal: Option<&[u8]>) -> Vec<u8> {
    let count = st.offs.len();
    let mut lo = Vec::with_capacity(count);
    let mut hi = Vec::with_capacity(count);
    let mut top = Vec::with_capacity(count);
    let (mut ix, mut jx) = (0, 0);
    let mut far = &*st.far;
    let mut rep = [1usize, 4, 8];
    for &c in &st.offs {
        let c = c as usize;
        let off = if c < 3 {
            rep[c]
        } else if c < 20 {
            rep[0].wrapping_add(c).wrapping_sub(11)
        } else if c < 84 {
            c - 19
        } else {
            let low = st.low[ix] as usize;
            ix += 1;
            if c < 212 {
                (((c - 84) << 8) | low) - 19
            } else {
                let mid = st.mid[jx] as usize;
                jx += 1;
                let high = if c == 255 {
                    43 + lenin(&mut far).expect("parser far lane")
                } else {
                    c - 212
                };
                ((high << 16) | (mid << 8) | low) - 19
            }
        };
        let v = if mode & 1 == 0 {
            off - 1
        } else if off == rep[0] {
            0
        } else {
            off - usize::from(off > rep[0])
        };
        lo.push(v as u8);
        hi.push((v >> 8) as u8);
        top.push((v >> 16) as u8);
        rep = [off, rep[0], rep[1]];
    }
    debug_assert!(far.is_empty() && ix == st.low.len() && jx == st.mid.len());
    fields(
        [&st.tag, &st.lens, &st.lits, &lo, &hi, &top],
        false,
        mode,
        literal,
    )
}
fn field<'a>(
    p: &mut &'a [u8],
    limit: usize,
    context: Option<&[u8]>,
    internal: bool,
) -> Result<std::borrow::Cow<'a, [u8]>> {
    let ty = *p.get(4).ok_or_else(bad)?;
    if !(matches!(ty, 0 | 1 | 2 | 4 | 5)
        || (internal && ty == 22)
        || (context.is_some() && ty == 23))
    {
        return Err(bad());
    }
    ans::get_context(p, limit, context)
}
#[inline(always)]
fn expand(lo: &[u8], hi: &[u8], top: &[u8], dst: &mut [u32], repeat: bool, prev: &mut u32) {
    let mut i = 0;
    #[cfg(target_arch = "aarch64")]
    {
        use core::arch::aarch64::*;
        unsafe {
            while i + 16 <= dst.len() {
                let a = vld1q_u8(lo.as_ptr().add(i));
                let b = vld1q_u8(hi.as_ptr().add(i));
                let c = vld1q_u8(top.as_ptr().add(i));
                macro_rules! half {
                    ($ab:expr,$c:expr,$start:expr) => {{
                        let low = vreinterpretq_u16_u8($ab);
                        let high = vmovl_u8($c);
                        let ptr = dst.as_mut_ptr().add($start);
                        let x = vorrq_u32(
                            vmovl_u16(vget_low_u16(low)),
                            vshlq_n_u32::<16>(vmovl_u16(vget_low_u16(high))),
                        );
                        let y =
                            vorrq_u32(vmovl_high_u16(low), vshlq_n_u32::<16>(vmovl_high_u16(high)));
                        vst1q_u32(ptr, x);
                        vst1q_u32(ptr.add(4), y);
                    }};
                }
                half!(vzip1q_u8(a, b), vget_low_u8(c), i);
                half!(vzip2q_u8(a, b), vget_high_u8(c), i + 8);
                i += 16;
            }
        }
    }
    for j in i..dst.len() {
        dst[j] = u32::from(lo[j]) | (u32::from(hi[j]) << 8) | (u32::from(top[j]) << 16)
    }
    if repeat {
        for v in dst {
            let x = *v;
            let off = if x == 0 {
                *prev
            } else {
                x + u32::from(x >= *prev)
            };
            *prev = off;
            *v = off + 19
        }
    } else {
        for v in dst {
            *v += 20
        }
    }
}
pub(crate) fn get(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let flags = take(&mut p, 1)?[0];
    if flags > 1 {
        return Err(bad());
    }
    let repeat = flags != 0;
    let n = dst.len();
    let tags = field(&mut p, n / 4, None, false)?;
    let count = tags.len();
    let lens = field(&mut p, n, None, false)?;
    let mut lens = &*lens;
    let lits = field(&mut p, n, None, true)?;
    let lo = field(&mut p, count, None, false)?;
    let hi = field(&mut p, count, Some(&tags), false)?;
    let upper = field(&mut p, count, None, false)?;
    if !p.is_empty() || lo.len() != count || hi.len() != count || upper.len() != count {
        return Err(bad());
    }
    let (mut at, mut lit, mut prev) = (0usize, 0usize, 1u32);
    let mut f = Fields::new();
    for start in (0..count).step_by(BATCH) {
        let m = (count - start).min(BATCH);
        let end = start + m;
        let mut abs = [0u32; BATCH + 3];
        expand(
            &lo[start..end],
            &hi[start..end],
            &upper[start..end],
            &mut abs[3..3 + m],
            repeat,
            &mut prev,
        );
        let a0 = at;
        let l0 = lit;
        let mut j = 0;
        #[cfg(target_arch = "aarch64")]
        while j + 16 <= m {
            unsafe {
                super::prep16::<4, false>(
                    &mut f,
                    j,
                    tags.as_ptr().add(start + j),
                    [20u8; 16].as_ptr(),
                    &mut abs,
                    &mut lens,
                    &mut at,
                    &mut lit,
                    n,
                    0,
                    0,
                )?
            }
            j += 16;
        }
        while j < m {
            let t = tags[start + j];
            let mut ll = usize::from(t >> 4);
            let mut ml = 4 + usize::from(t & 15);
            if ll == 15 {
                ll += lenin(&mut lens)?
            }
            if ml == 19 {
                ml += lenin(&mut lens)?
            }
            let dest = at + ll;
            let off = (abs[j + 3] - 19) as usize;
            if off == 0 || off > dest || dest + ml > n {
                return Err(bad());
            }
            f.dst[j] = dest as u32;
            f.lit[j] = lit as u32;
            f.ll[j] = ll as u32;
            f.ml[j] = ml as u32;
            f.src[j] = (dest - off) as u32;
            lit += ll;
            at = dest + ml;
            j += 1;
        }
        if at > n || lit > lits.len() {
            return Err(bad());
        }
        let run = Ready {
            start: a0,
            lstart: l0,
            at,
            lit,
            count: m,
        };
        restore_ready::<false>(dst, &lits, &[], &f, run, 0, false, 0)
    }
    if !lens.is_empty() || n - at != lits.len() - lit {
        return Err(bad());
    }
    dst[at..].copy_from_slice(&lits[lit..]);
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn direct_distances_cover_repeat_far_and_nonvector_tail() {
        let mut raw = Vec::new();
        let mut state = 149u32;
        for k in 0..91000 {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            if k % 17 == 0 {
                raw.extend(b"row #017abc ")
            } else {
                raw.push((state >> 24) as u8)
            }
        }
        raw.extend_from_within(37..9074);
        for n in [0, 3, 11, 175, 4096, raw.len()] {
            for mode in [0, 1, 2, 4, 7, 8, 15] {
                let wire = put(&raw[..n], false, mode);
                let mut out = vec![0; n];
                get(&wire[1..], &mut out).unwrap();
                assert_eq!(out, raw[..n]);
                assert!(get(&wire[1..wire.len() - 1], &mut out).is_err());
            }
        }
    }
}
