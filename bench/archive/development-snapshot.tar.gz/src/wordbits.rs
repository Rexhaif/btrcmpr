// Unpack eight independently described integers with two 16-byte NEON table
// reads. Prefix sums of the widths locate all fields before any is decoded.
#[cfg(target_arch = "aarch64")]
#[inline]
pub(super) unsafe fn eight(
    head: *const u8,
    payload: *const u8,
    offset: u8,
    dst: *mut u32,
) -> Option<usize> {
    use core::arch::aarch64::*;
    unsafe {
        let h = vld1_u8(head);
        let w = vqsub_u8(vshr_n_u8::<3>(h), vdup_n_u8(1));
        if vmaxv_u8(w) > 25 {
            return None;
        }
        let z = vdup_n_u8(0);
        let mut ends = w;
        ends = vadd_u8(ends, vext_u8::<7>(z, ends));
        ends = vadd_u8(ends, vext_u8::<6>(z, ends));
        ends = vadd_u8(ends, vext_u8::<4>(z, ends));
        let at = vadd_u8(vsub_u8(ends, w), vdup_n_u8(offset));
        let oct = vmovl_u8(vshr_n_u8::<3>(at));
        let shift = vmovl_u8(vand_u8(at, vdup_n_u8(7)));
        let width = vmovl_u8(w);
        let high = vmovl_u8(vbsl_u8(
            vceq_u8(w, z),
            h,
            vorr_u8(vand_u8(h, vdup_n_u8(7)), vdup_n_u8(8)),
        ));
        let words = uint8x16x2_t(vld1q_u8(payload), vld1q_u8(payload.add(16)));
        let delta = vreinterpretq_u8_u32(vdupq_n_u32(0x03020100));
        #[inline(always)]
        unsafe fn four(
            a: uint16x4_t,
            b: uint16x4_t,
            c: uint16x4_t,
            top: uint16x4_t,
            words: uint8x16x2_t,
            delta: uint8x16_t,
        ) -> uint32x4_t {
            unsafe {
                let ix = vaddq_u8(
                    vreinterpretq_u8_u32(vmulq_n_u32(vmovl_u16(a), 0x01010101)),
                    delta,
                );
                let src = vreinterpretq_u32_u8(vqtbl2q_u8(words, ix));
                let bits = vreinterpretq_s32_u32(vmovl_u16(c));
                let one = vdupq_n_u32(1);
                let mask = vsubq_u32(vshlq_u32(one, bits), one);
                let low = vshlq_u32(src, vnegq_s32(vreinterpretq_s32_u32(vmovl_u16(b))));
                vorrq_u32(vandq_u32(low, mask), vshlq_u32(vmovl_u16(top), bits))
            }
        }
        vst1q_u32(
            dst,
            four(
                vget_low_u16(oct),
                vget_low_u16(shift),
                vget_low_u16(width),
                vget_low_u16(high),
                words,
                delta,
            ),
        );
        vst1q_u32(
            dst.add(4),
            four(
                vget_high_u16(oct),
                vget_high_u16(shift),
                vget_high_u16(width),
                vget_high_u16(high),
                words,
                delta,
            ),
        );
        Some(usize::from(vget_lane_u8::<7>(ends)))
    }
}
