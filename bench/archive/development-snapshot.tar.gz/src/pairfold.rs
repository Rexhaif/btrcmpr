// Train a small pair dictionary from the current block. Its index is a byte
// hash; both source bytes must match the recorded pair. An uncommon interval
// in the literal alphabet supplies the codes and one escape. Greedy matches
// cannot overlap; the selection for eight starts fits in a 256-entry table.
use crate::{Result, bad, take, u32in};
struct Book {
    a: [u8; 64],
    b: [u8; 64],
    base: u8,
}
#[inline(always)]
fn hash<const N: usize>(a: u8, b: u8) -> usize {
    ((a ^ (a >> 4))
        .wrapping_mul(19)
        .wrapping_add((b ^ (b >> 3)).wrapping_mul(43)) as usize)
        & (N - 1)
}
fn train<const N: usize>(s: &[u8], rows: usize, cutoff: usize) -> Option<Book> {
    if s.len() < 64 {
        return None;
    }
    let mut count = vec![0u16; 65536];
    let mut freq = [0u32; 256];
    let mut best = [0u16; 64];
    let mut book = Book {
        a: [0; 64],
        b: [0; 64],
        base: 0,
    };
    for j in 0..rows {
        let off = (s.len() - 33) * j / (rows - 1);
        for p in s[off..off + 33].windows(2) {
            let (a, b) = (p[0], p[1]);
            freq[a as usize] += 1;
            let cnt = &mut count[usize::from(u16::from_le_bytes([a, b]))];
            *cnt += 1;
            let k = hash::<N>(a, b);
            if *cnt > best[k] {
                best[k] = *cnt;
                book.a[k] = a;
                book.b[k] = b
            }
        }
    }
    let mut sum: u32 = freq[..=N].iter().sum();
    let mut least = sum;
    for start in 1..256 - N {
        sum = sum - freq[start - 1] + freq[start + N];
        if sum < least {
            least = sum;
            book.base = start as u8;
        }
    }
    let found = best[..N].iter().map(|&n| u32::from(n)).sum::<u32>();
    (100 * found.saturating_sub(least) >= ((rows * 32 * cutoff) as u32)).then_some(book)
}
fn tail<const N: usize>(s: &[u8], book: &Book, out: &mut Vec<u8>, side: &mut Vec<u8>) {
    let mut i = 0;
    while i < s.len() {
        let a = s[i];
        if let Some(&b) = s.get(i + 1) {
            let k = hash::<N>(a, b);
            if book.a[k] == a && book.b[k] == b {
                out.push(book.base + k as u8);
                i += 2;
                continue;
            }
        }
        if a.wrapping_sub(book.base) as usize <= N {
            side.push(a);
            out.push(book.base + N as u8)
        } else {
            out.push(a)
        }
        i += 1
    }
}
fn fold<const N: usize>(s: &[u8], book: &Book, vector: bool) -> (Vec<u8>, Vec<u8>) {
    #[cfg(target_arch = "aarch64")]
    if vector {
        return unsafe { neon::fold::<N>(s, book) };
    }
    let _ = vector;
    let mut data = Vec::with_capacity(s.len());
    let mut side = Vec::new();
    tail::<N>(s, book, &mut data, &mut side);
    (data, side)
}
fn unfold_tail<const N: usize>(s: &[u8], b: &Book, side: &[u8], out: &mut [u8]) -> Result<()> {
    let (mut pos, mut esc) = (0, 0);
    for &t in s {
        let k = t.wrapping_sub(b.base) as usize;
        if k < N {
            out.get_mut(pos..pos + 2)
                .ok_or_else(bad)?
                .copy_from_slice(&[b.a[k], b.b[k]]);
            pos += 2
        } else {
            let v = if k == N {
                let v = *side.get(esc).ok_or_else(bad)?;
                esc += 1;
                v
            } else {
                t
            };
            *out.get_mut(pos).ok_or_else(bad)? = v;
            pos += 1
        }
    }
    if pos != out.len() || esc != side.len() {
        return Err(bad());
    }
    Ok(())
}
fn unfold<const N: usize>(
    s: &[u8],
    b: &Book,
    side: &[u8],
    out: &mut [u8],
    vector: bool,
) -> Result<()> {
    #[cfg(target_arch = "aarch64")]
    if vector {
        return unsafe { neon::unfold::<N>(s, b, side, out) };
    }
    let _ = vector;
    unfold_tail::<N>(s, b, side, out)
}
fn put<const N: usize>(
    s: &[u8],
    vector: bool,
    inner: impl FnOnce(&[u8]) -> Vec<u8>,
) -> Option<Vec<u8>> {
    let cutoff = crate::tuning("BTR_PAIR_CUTOFF", 8, 0, 50);
    let b = train::<N>(s, crate::tuning("BTR_PAIR_SAMPLES", 32, 8, 256), cutoff)?;
    let (y, side) = fold::<N>(s, &b, vector);
    if y.len() + side.len() + 2 * N >= s.len() {
        return None;
    }
    let v = inner(&y);
    if !v.first().is_some_and(|v| matches!(v, 0 | 1 | 13)) {
        return None;
    }
    let mut out = Vec::with_capacity(11 + 2 * N + side.len() + v.len());
    out.extend([62, N as u8, b.base]);
    out.extend((y.len() as u32).to_le_bytes());
    out.extend((side.len() as u32).to_le_bytes());
    out.extend(&b.a[..N]);
    out.extend(&b.b[..N]);
    out.extend(side);
    out.extend(v);
    Some(out)
}
pub(crate) fn encode(
    s: &[u8],
    mode: usize,
    inner: impl FnOnce(&[u8]) -> Vec<u8>,
) -> Option<Vec<u8>> {
    match mode {
        1 => put::<32>(s, false, inner),
        2 => put::<32>(s, true, inner),
        3 => put::<64>(s, false, inner),
        4 => put::<64>(s, true, inner),
        5 => put::<16>(s, false, inner),
        _ => put::<16>(s, true, inner),
    }
}
pub(crate) fn get(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let n = take(&mut p, 1)?[0] as usize;
    let base = take(&mut p, 1)?[0];
    if ![16, 32, 64].contains(&n) || base as usize + n >= 256 || dst.len() > crate::MAX_BLOCK {
        return Err(bad());
    }
    let t = u32in(&mut p)?;
    let e = u32in(&mut p)?;
    if t < dst.len().div_ceil(2) || t > dst.len() || e > t {
        return Err(bad());
    }
    let mut b = Book {
        a: [0; 64],
        b: [0; 64],
        base,
    };
    b.a[..n].copy_from_slice(take(&mut p, n)?);
    b.b[..n].copy_from_slice(take(&mut p, n)?);
    let side = take(&mut p, e)?;
    if !p.first().is_some_and(|v| matches!(v, 0 | 1 | 13)) {
        return Err(bad());
    }
    let mut tokens = vec![0; t];
    crate::decode(p, &mut tokens)?;
    let vector = crate::tuning("BTR_PAIR_SCALAR_READ", 0, 0, 1) == 0;
    match n {
        16 => unfold::<16>(&tokens, &b, side, dst, vector),
        32 => unfold::<32>(&tokens, &b, side, dst, vector),
        _ => unfold::<64>(&tokens, &b, side, dst, vector),
    }
}
#[cfg(target_arch = "aarch64")]
mod neon {
    use super::{Book, Result, bad, tail, unfold_tail};
    use core::arch::aarch64::*;
    const WT: [u8; 8] = [1, 2, 4, 8, 16, 32, 64, 128];
    const fn tables(mode: usize) -> [[u8; 16]; 256] {
        let mut table = [[255; 16]; 256];
        let mut m = 0usize;
        while m < 256 {
            let mut j = 0;
            let mut count = 0;
            let mut prev = false;
            let mut select = 0u8;
            while j < 8 {
                let hit = (m >> j) & 1 != 0;
                match mode {
                    0 => {
                        if hit {
                            table[m][count] = j as u8;
                            count += 1;
                        }
                    }
                    1 => {
                        if hit {
                            table[m][j] = count as u8;
                            count += 1;
                        }
                    }
                    2 => {
                        table[m][count] = j as u8;
                        count += 1;
                        if hit {
                            table[m][count] = (8 + j) as u8;
                            count += 1;
                        }
                    }
                    _ => {
                        let yes = hit && !prev;
                        if yes {
                            select |= 1 << j
                        }
                        prev = yes;
                    }
                }
                j += 1;
            }
            if mode == 3 {
                table[m][0] = select
            }
            m += 1;
        }
        table
    }
    static COMPACT: [[u8; 16]; 256] = tables(0);
    static ESCAPE: [[u8; 16]; 256] = tables(1);
    static EXPAND: [[u8; 16]; 256] = tables(2);
    static SELECT: [u8; 256] = {
        let t = tables(3);
        let mut v = [0; 256];
        let mut i = 0;
        while i < 256 {
            v[i] = t[i][0];
            i += 1;
        }
        v
    };
    #[inline(always)]
    unsafe fn mask(v: uint8x8_t) -> u8 {
        unsafe { vaddv_u8(vand_u8(v, vld1_u8(WT.as_ptr()))) }
    }
    #[inline(always)]
    unsafe fn table<const N: usize>(t: uint8x16x4_t, k: uint8x16_t) -> uint8x16_t {
        unsafe {
            if N == 16 {
                vqtbl1q_u8(t.0, k)
            } else if N == 32 {
                vqtbl2q_u8(uint8x16x2_t(t.0, t.1), k)
            } else {
                vqtbl4q_u8(t, k)
            }
        }
    }
    struct Sink {
        data: Vec<u8>,
        extra: Vec<u8>,
        at: usize,
        ep: usize,
        prev: u8,
    }
    impl Sink {
        #[inline(always)]
        unsafe fn eight(&mut self, sy: uint8x8_t, raw: uint8x8_t, matchbits: u8, esc: u8) {
            unsafe {
                let selected = SELECT[(matchbits & !self.prev) as usize];
                let keep = !((selected << 1) | self.prev);
                self.prev = selected >> 7;
                let em = esc & keep;
                let wh = keep as usize;
                let ex = em as usize;
                vst1_u8(
                    self.data.as_mut_ptr().add(self.at),
                    vtbl1_u8(sy, vld1_u8(COMPACT[wh].as_ptr())),
                );
                self.at += keep.count_ones() as usize;
                if em != 0 {
                    vst1_u8(
                        self.extra.as_mut_ptr().add(self.ep),
                        vtbl1_u8(raw, vld1_u8(COMPACT[ex].as_ptr())),
                    );
                    self.ep += em.count_ones() as usize;
                }
            }
        }
    }
    pub(super) unsafe fn fold<const N: usize>(s: &[u8], b: &Book) -> (Vec<u8>, Vec<u8>) {
        unsafe {
            let mut v = Sink {
                data: Vec::with_capacity(s.len() + 16),
                extra: Vec::with_capacity(s.len() + 16),
                at: 0,
                ep: 0,
                prev: 0,
            };
            let aa = vld1q_u8_x4(b.a.as_ptr());
            let bb = vld1q_u8_x4(b.b.as_ptr());
            let mut i = 0;
            while i + 17 <= s.len() {
                let a = vld1q_u8(s.as_ptr().add(i));
                let next = vld1q_u8(s.as_ptr().add(i + 1));
                let ha = vmulq_u8(veorq_u8(a, vshrq_n_u8::<4>(a)), vdupq_n_u8(19));
                let hb = vmulq_u8(veorq_u8(next, vshrq_n_u8::<3>(next)), vdupq_n_u8(43));
                let key = vandq_u8(vaddq_u8(ha, hb), vdupq_n_u8((N - 1) as u8));
                let matched = vandq_u8(
                    vceqq_u8(a, table::<N>(aa, key)),
                    vceqq_u8(next, table::<N>(bb, key)),
                );
                let e = vbicq_u8(
                    vcleq_u8(vsubq_u8(a, vdupq_n_u8(b.base)), vdupq_n_u8(N as u8)),
                    matched,
                );
                let out = vbslq_u8(
                    matched,
                    vaddq_u8(key, vdupq_n_u8(b.base)),
                    vbslq_u8(e, vdupq_n_u8(b.base + N as u8), a),
                );
                v.eight(
                    vget_low_u8(out),
                    vget_low_u8(a),
                    mask(vget_low_u8(matched)),
                    mask(vget_low_u8(e)),
                );
                v.eight(
                    vget_high_u8(out),
                    vget_high_u8(a),
                    mask(vget_high_u8(matched)),
                    mask(vget_high_u8(e)),
                );
                i += 16;
            }
            // Each input contributes at most one token and one escaped byte.
            v.data.set_len(v.at);
            v.extra.set_len(v.ep);
            tail::<N>(&s[i + v.prev as usize..], b, &mut v.data, &mut v.extra);
            (v.data, v.extra)
        }
    }
    pub(super) unsafe fn unfold<const N: usize>(
        s: &[u8],
        b: &Book,
        side: &[u8],
        out: &mut [u8],
    ) -> Result<()> {
        unsafe {
            let (mut i, mut p, mut e) = (0, 0, 0);
            let aa = vld1q_u8_x4(b.a.as_ptr());
            let bb = vld1q_u8_x4(b.b.as_ptr());
            while i + 8 <= s.len() && p + 16 <= out.len() {
                let tok = vld1_u8(s.as_ptr().add(i));
                let k = vsub_u8(tok, vdup_n_u8(b.base));
                let pair = vclt_u8(k, vdup_n_u8(N as u8));
                let em = vceq_u8(k, vdup_n_u8(N as u8));
                let e_mask = mask(em);
                let idx = vcombine_u8(k, k);
                let first = vget_low_u8(table::<N>(aa, idx));
                let second = vget_low_u8(table::<N>(bb, idx));
                let mut initial = vbsl_u8(pair, first, tok);
                if e_mask != 0 {
                    let n = e_mask.count_ones() as usize;
                    if n > side.len() - e {
                        return Err(bad());
                    }
                    let x = if side.len() - e >= 8 {
                        vld1_u8(side.as_ptr().add(e))
                    } else {
                        let mut buf = [0; 8];
                        buf[..n].copy_from_slice(&side[e..e + n]);
                        vld1_u8(buf.as_ptr())
                    };
                    initial = vbsl_u8(
                        em,
                        vtbl1_u8(x, vld1_u8(ESCAPE[e_mask as usize].as_ptr())),
                        initial,
                    );
                    e += n;
                }
                let m = mask(pair);
                let v = vqtbl1q_u8(
                    vcombine_u8(initial, second),
                    vld1q_u8(EXPAND[m as usize].as_ptr()),
                );
                vst1q_u8(out.as_mut_ptr().add(p), v);
                p += 8 + m.count_ones() as usize;
                i += 8;
            }
            unfold_tail::<N>(&s[i..], b, &side[e..], &mut out[p..])
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn check<const N: usize>(s: &[u8], book: &Book) {
        let (a, x) = fold::<N>(s, book, false);
        let (b, y) = fold::<N>(s, book, true);
        assert_eq!((&a, &x), (&b, &y));
        for v in [false, true] {
            let mut out = vec![0; s.len()];
            unfold::<N>(&a, book, &x, &mut out, v).unwrap();
            assert_eq!(out, s)
        }
    }
    #[test]
    fn overlapping_starts_and_escape_runs_cross_vector_boundaries() {
        let mut s = vec![65; 129];
        s.extend(0..=255);
        s.extend_from_within(..);
        s.extend_from_slice(
            b" repeating the original bytes and the same words again "
                .repeat(81)
                .as_slice(),
        );
        let mut state = 201u32;
        for _ in 0..16000 {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            s.push((state >> 24) as u8)
        }
        for base in [0, 62, 137, 190] {
            let mut b = train::<64>(&s, 32, 0).unwrap();
            b.base = base;
            let k = hash::<64>(65, 65);
            b.a[k] = 65;
            b.b[k] = 65;
            for n in (0..128).chain([713, 4099, s.len()]) {
                check::<64>(&s[..n], &b)
            }
        }
        let b = train::<16>(&s, 16, 0).unwrap();
        check::<16>(&s, &b);
        let b = train::<32>(&s, 32, 0).unwrap();
        check::<32>(&s, &b);
    }
    #[test]
    fn rejects_trailing_escapes_and_nested_block() {
        let b = Book {
            a: [0; 64],
            b: [0; 64],
            base: 32,
        };
        for vec in [false, true] {
            assert!(unfold::<16>(&[48; 33], &b, &[1; 31], &mut [0; 33], vec).is_err());
            assert!(unfold::<16>(&[49; 33], &b, &[1; 1], &mut [0; 33], vec).is_err());
        }
        let mut p = vec![16, 32];
        p.extend(32u32.to_le_bytes());
        p.extend(0u32.to_le_bytes());
        p.extend([0; 32]);
        p.push(62);
        assert!(get(&p, &mut [0; 32]).is_err());
    }
}
