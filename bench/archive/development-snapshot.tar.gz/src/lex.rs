// A word-domain parser. Its vocabulary is rebuilt for each block and sent in
// the archive. References count tokens; spelling is expanded in a final pass.
use crate::{Result, ans, bad, take, u32in};

pub(crate) use crate::wordbase::{Term, plain, tokenize};
struct WriteBits {
    out: Vec<u8>,
    acc: u64,
    bits: u32,
}
impl WriteBits {
    fn new() -> Self {
        Self {
            out: vec![],
            acc: 0,
            bits: 0,
        }
    }
    fn integer(&mut self, heads: &mut Vec<u8>, v: u32) {
        if v < 16 {
            heads.push(v as u8);
            return;
        }
        let n = v.ilog2() - 3;
        heads.push((n * 8 + (v >> n)) as u8);
        self.acc |= ((v as u64) & ((1u64 << n) - 1)) << self.bits;
        self.bits += n;
        while self.bits >= 8 {
            self.out.push(self.acc as u8);
            self.acc >>= 8;
            self.bits -= 8;
        }
    }
    fn finish(mut self, out: &mut Vec<u8>) {
        if self.bits > 0 {
            self.out.push(self.acc as u8);
        }
        out.extend((self.out.len() as u32).to_le_bytes());
        out.extend(self.out);
    }
}
struct ReadBits<'a> {
    s: &'a [u8],
    p: usize,
    acc: u64,
    bits: u32,
}
impl<'a> ReadBits<'a> {
    fn from(p: &mut &'a [u8]) -> Result<Self> {
        let n = u32in(p)?;
        Ok(Self {
            s: take(p, n)?,
            p: 0,
            acc: 0,
            bits: 0,
        })
    }
    #[inline]
    fn integer(&mut self, h: u8) -> Result<u32> {
        if h < 16 {
            return Ok(h as u32);
        }
        let n = (h as u32 / 8) - 1;
        if n > 25 {
            return Err(bad());
        }
        while self.bits < n {
            self.acc |= (*self.s.get(self.p).ok_or_else(bad)? as u64) << self.bits;
            self.p += 1;
            self.bits += 8;
        }
        let v = (((h as u32 & 7) + 8) << n) | (self.acc as u32 & ((1u32 << n) - 1));
        self.acc >>= n;
        self.bits -= n;
        Ok(v)
    }
    fn done(&self) -> bool {
        self.p == self.s.len() && self.acc == 0
    }
}
fn lengths(mut k: usize, ex: &mut Vec<u8>) {
    while k >= 128 {
        ex.push((k as u8) | 128);
        k >>= 7;
    }
    ex.push(k as u8);
}
#[inline]
fn next(hist: &mut [u32; 4], id: u32) {
    if hist[0] != id {
        hist[3] = hist[2];
        hist[2] = hist[1];
        hist[1] = hist[0];
        hist[0] = id;
    }
}
#[cfg(feature = "research")]
pub(crate) fn encode(s: &[u8], level: u8, kind: usize) -> Vec<u8> {
    let (terms, ids) = tokenize(s, kind % 3);
    encode_tokens(s, level, kind, terms, ids)
}
#[cfg(feature = "research")]
pub(crate) fn encode_tokens(
    s: &[u8],
    level: u8,
    kind: usize,
    terms: Vec<Term>,
    mut ids: Vec<u32>,
) -> Vec<u8> {
    let mut order: Vec<_> = (0..terms.len()).collect();
    let spelling = |id: usize| {
        let v = terms[id];
        &s[v.pos as usize..v.pos as usize + v.len as usize]
    };
    order.sort_unstable_by(|&a, &b| {
        terms[b]
            .count
            .ilog2()
            .cmp(&terms[a].count.ilog2())
            .then_with(|| spelling(a).cmp(spelling(b)))
    });
    let mut map = vec![0u32; terms.len()];
    let mut prev = &[][..];
    let mut ds = vec![];
    let mut ds2 = vec![];
    let mut dna = vec![];
    for (j, &id) in order.iter().enumerate() {
        let w = spelling(id);
        let shared = w.iter().zip(prev).take_while(|(a, b)| a == b).count();
        ds.push(shared as u8);
        ds2.push((w.len() - shared) as u8);
        dna.extend(&w[shared..]);
        prev = w;
        map[id] = j as u32;
    }
    for v in &mut ids {
        *v = map[*v as usize];
    }
    let mut out = vec![24];
    out.extend((terms.len() as u32).to_le_bytes());
    out.extend((ids.len() as u32).to_le_bytes());
    for d in [&ds, &ds2, &dna] {
        ans::put_tight(d, &mut out);
    }
    let mut heads = vec![];
    let mut lh = vec![];
    let mut oh = vec![];
    let mut lb = WriteBits::new();
    let mut ob = WriteBits::new();
    let mut ex = vec![];
    let mut hist = vec![[u32::MAX; 4]; terms.len() + 1];
    let mut seek = vec![[u32::MAX; 4]; (ids.len() / 4).max(4096).next_power_of_two().min(1 << 20)];
    let mut longs = vec![u32::MAX; seek.len()];
    fn key(ids: &[u32], i: usize, mask: usize) -> (usize, usize) {
        let a = ids[i].wrapping_mul(0x9e3779b1) ^ ids[i + 1].wrapping_mul(0x85ebca6b);
        let b = a ^ ids[i + 2].wrapping_mul(0xc2b2ae35);
        (
            ((a ^ (a >> 17)) as usize) & mask,
            ((b ^ (b >> 15)) as usize) & mask,
        )
    }
    let mut anchor = 0;
    let mut i = 0;
    let mut seq = vec![];
    while i + 3 <= ids.len() {
        let (a, b) = key(&ids, i, seek.len() - 1);
        let c = seek[a];
        let last = longs[b];
        let mut best = 0;
        let mut off = 0;
        let mut value = 0;
        for q in [last, c[0], c[1], c[2], c[3]]
            .into_iter()
            .take(if level < 8 { 2 } else { 5 })
        {
            if q as usize >= i {
                continue;
            }
            let q = q as usize;
            let mut l = 0;
            while i + l < ids.len() && ids[i + l] == ids[q + l] {
                l += 1;
            }
            let d = i - q;
            if l >= 2 {
                let gain = l as isize * 10 - d.ilog2() as isize;
                if gain > value {
                    (best, off, value) = (l, d, gain);
                }
            }
        }
        let hit = best >= 2 && value >= if kind >= 3 { 16 } else { 12 };
        let n = if hit { best } else { 1 };
        for j in i..(i + n).min(ids.len() - 2) {
            let (a, b) = key(&ids, j, seek.len() - 1);
            let row = &mut seek[a];
            row.copy_within(0..3, 1);
            row[0] = j as u32;
            longs[b] = j as u32;
        }
        if hit && kind >= 6 {
            seq.push((i, best, off));
            i += n;
            continue;
        }
        if hit {
            let ll = i - anchor;
            let ml = best - 2;
            heads.push((ll.min(15) * 16 + ml.min(15)) as u8);
            if ll >= 15 {
                lengths(ll - 15, &mut ex);
            }
            if ml >= 15 {
                lengths(ml - 15, &mut ex);
            }
            ob.integer(&mut oh, off as u32);
            for j in anchor..i {
                let id = ids[j];
                let ctx = if j == 0 {
                    terms.len()
                } else {
                    ids[j - 1] as usize
                };
                let hist = &mut hist[ctx];
                if let Some(k) = hist.iter().position(|&v| v == id) {
                    lh.push(248 + k as u8);
                } else {
                    lb.integer(&mut lh, id);
                }
                next(hist, id);
            }
            anchor = i + best;
        }
        i += n;
    }
    if kind >= 45 {
        let mut literals = vec![];
        for (at, len, off) in seq {
            let ll = at - anchor;
            let ml = len - 2;
            heads.push((ll.min(15) * 16 + ml.min(15)) as u8);
            if ll >= 15 {
                lengths(ll - 15, &mut ex);
            }
            if ml >= 15 {
                lengths(ml - 15, &mut ex);
            }
            ob.integer(&mut oh, off as u32);
            literals.extend_from_slice(&ids[anchor..at]);
            anchor = at + len;
        }
        literals.extend_from_slice(&ids[anchor..]);
        let raw = literals
            .iter()
            .map(|&j| spelling(order[j as usize]).len())
            .sum();
        let mut wire = vec![30];
        wire.extend((ids.len() as u32).to_le_bytes());
        for stream in [&heads, &ex, &oh] {
            ans::put_tight(stream, &mut wire);
        }
        ob.finish(&mut wire);
        wire.extend(crate::lexrank::pack(&literals, &order, &spelling, raw));
        return wire;
    }
    if kind >= 6 {
        let mut byte = Vec::with_capacity(ids.len() + 1);
        byte.push(0usize);
        for &v in &ids {
            byte.push(byte.last().unwrap() + terms[order[v as usize]].len as usize);
        }
        let mut st = crate::lz::Streams::sized(s.len());
        let mut litids = vec![];
        for (i, n, off) in seq {
            let m = byte[i + n] - byte[i];
            if m < 4 {
                continue;
            }
            litids.extend_from_slice(&ids[anchor..i]);
            st.emit(s, byte[anchor], byte[i], m, byte[i] - byte[i - off]);
            anchor = i + n;
        }
        litids.extend_from_slice(&ids[anchor..]);
        let raw_len = litids
            .iter()
            .map(|&v| terms[order[v as usize]].len as usize)
            .sum::<usize>();
        if kind == 42 {
            let payload = crate::lexrank::pack(&litids, &order, &spelling, raw_len);
            return st.finish_literals(s, byte[anchor], false, false, Some(&payload));
        }
        if kind >= 24 {
            let cap = match (kind - 24) / 3 {
                0 => 192,
                1 => 704,
                2 => 1984,
                3 => 4288,
                _ => 8192,
            };
            let packed = hot_words(&litids, &order, &spelling, raw_len, cap);
            return st.finish_literals(s, byte[anchor], false, false, Some(&packed));
        }
        if kind >= 12 {
            let mut raw = Vec::with_capacity(raw_len);
            for &v in &litids {
                raw.extend(spelling(order[v as usize]));
            }
            let outer = st.finish_literals(s, byte[anchor], false, false, Some(&[0; 5]));
            return crate::cascade::pack(&raw, outer, (kind - 12) / 3);
        }
        let mut payload = vec![];
        payload.extend((raw_len as u32).to_le_bytes());
        payload.extend([25, (kind >= 9) as u8]);
        payload.extend((terms.len() as u32).to_le_bytes());
        payload.extend((litids.len() as u32).to_le_bytes());
        payload.extend(&out[9..]);
        let mut previous = terms.len();
        for id in litids {
            if kind >= 9
                && let Some(k) = hist[previous].iter().position(|&v| v == id)
            {
                lh.push(248 + k as u8);
            } else {
                lb.integer(&mut lh, id);
            }
            if kind >= 9 {
                next(&mut hist[previous], id);
                previous = id as usize;
            }
        }
        ans::put_tight(&lh, &mut payload);
        lb.finish(&mut payload);
        return st.finish_literals(s, byte[anchor], false, false, Some(&payload));
    }
    for j in anchor..ids.len() {
        let id = ids[j];
        let ctx = if j == 0 {
            terms.len()
        } else {
            ids[j - 1] as usize
        };
        let hist = &mut hist[ctx];
        if let Some(k) = hist.iter().position(|&v| v == id) {
            lh.push(248 + k as u8);
        } else {
            lb.integer(&mut lh, id);
        }
        next(hist, id);
    }
    for d in [&heads, &ex, &lh, &oh] {
        ans::put_tight(d, &mut out);
    }
    lb.finish(&mut out);
    ob.finish(&mut out);
    out
}
pub(crate) fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let dict = u32in(&mut p)?;
    let nt = u32in(&mut p)?;
    if dict == 0 || dict > nt || nt > dst.len() {
        return Err(bad());
    }
    let Vocabulary { ws, ns } = vocabulary(&mut p, dict, dst.len())?;
    let heads = ans::get(&mut p, nt / 2)?;
    let ex = ans::get(&mut p, nt)?;
    let mut ex = &*ex;
    let lits = ans::get(&mut p, nt)?;
    let offs = ans::get(&mut p, heads.len())?;
    if heads.len() != offs.len() {
        return Err(bad());
    }
    let mut lb = ReadBits::from(&mut p)?;
    let mut ob = ReadBits::from(&mut p)?;
    if !p.is_empty() {
        return Err(bad());
    }
    let mut hist = vec![[u32::MAX; 4]; dict + 1];
    let mut ids = vec![0u32; nt];
    let mut at = 0;
    let mut li = &*lits;
    let mut prev = dict;
    for index in 0..=heads.len() {
        let tail = index == heads.len();
        let t = if tail { 0 } else { heads[index] };
        let mut ll = if tail { nt - at } else { (t >> 4) as usize };
        let mut ml = (t & 15) as usize + 2;
        if !tail && ll == 15 {
            ll += crate::lz::lenin(&mut ex)?;
        }
        if !tail && ml == 17 {
            ml += crate::lz::lenin(&mut ex)?;
        }
        if ll > nt - at {
            return Err(bad());
        }
        for (&h, d) in take(&mut li, ll)?.iter().zip(&mut ids[at..at + ll]) {
            let history = &mut hist[prev];
            let id = if (248..252).contains(&h) {
                history[(h - 248) as usize]
            } else {
                lb.integer(h)?
            };
            if id as usize >= dict {
                return Err(bad());
            }
            *d = id;
            prev = id as usize;
            next(history, id);
        }
        at += ll;
        if !tail {
            let off = ob.integer(offs[index])? as usize;
            if off == 0 || off > at || ml > nt - at {
                return Err(bad());
            }
            let k = ml.min(off);
            ids.copy_within(at - off..at - off + k, at);
            let mut k = k;
            while k < ml {
                let j = k.min(ml - k);
                ids.copy_within(at..at + j, at + k);
                k += j;
            }
            at += ml;
            prev = ids[at - 1] as usize;
        }
    }
    if !li.is_empty() || !ex.is_empty() || !lb.done() || !ob.done() {
        return Err(bad());
    }
    expand_words(&ids, &ws, &ns, dst)
}

#[inline(never)]
fn expand_words(ids: &[u32], ws: &[[u8; 16]], ns: &[u8], dst: &mut [u8]) -> Result<()> {
    let mut at = 0usize;
    for tile in ids.chunks(96) {
        let mut widths = [0u8; 96];
        for (&id, w) in tile.iter().zip(&mut widths) {
            let j = id as usize;
            *w = *ns.get(j).ok_or_else(bad)?;
            #[cfg(target_arch = "aarch64")]
            unsafe {
                core::arch::asm!("prfm pldl1keep, [{p}]",p=in(reg)ws.as_ptr().add(j),options(nostack,readonly,preserves_flags));
            }
        }
        let mut base = [0usize; 96];
        let mut end = at;
        for (o, &w) in base.iter_mut().zip(&widths[..tile.len()]) {
            *o = end;
            end += w as usize;
        }
        if end > dst.len() {
            return Err(bad());
        }
        if end + 16 <= dst.len() {
            for (i, &id) in tile.iter().enumerate() {
                unsafe {
                    std::ptr::copy_nonoverlapping(
                        ws.get_unchecked(id as usize).as_ptr(),
                        dst.as_mut_ptr().add(base[i]),
                        16,
                    );
                }
            }
        } else {
            for (i, &id) in tile.iter().enumerate() {
                let k = widths[i] as usize;
                let off = base[i];
                dst[off..off + k].copy_from_slice(&ws[id as usize][..k]);
            }
        }
        at = end;
    }
    if at != dst.len() {
        return Err(bad());
    }
    Ok(())
}

// Only leaf entropy encodings are legal inside this representation.
struct Vocabulary {
    ws: Vec<[u8; 16]>,
    ns: Vec<u8>,
}
fn vocabulary(p: &mut &[u8], dict: usize, max: usize) -> Result<Vocabulary> {
    let ds = plain(p, dict)?;
    let dl = plain(p, dict)?;
    let text = plain(p, max)?;
    if ds.len() != dict || dl.len() != dict {
        return Err(bad());
    }
    let mut ws = Vec::with_capacity(dict);
    let mut ns = Vec::with_capacity(dict);
    let mut raw = &*text;
    let mut row = [0u8; 16];
    let mut old = 0;
    for (&shared, &tail) in ds.iter().zip(dl.iter()) {
        let (k, add) = (shared as usize, tail as usize);
        let n = k + add;
        if k > old || n == 0 || n > 16 {
            return Err(bad());
        }
        row[k..n].copy_from_slice(take(&mut raw, add)?);
        ws.push(row);
        ns.push(n as u8);
        old = n;
    }
    if !raw.is_empty() {
        return Err(bad());
    }
    Ok(Vocabulary { ws, ns })
}
pub(crate) fn literal_bytes(p: &mut &[u8], n: usize) -> Result<Vec<u8>> {
    let mode = take(p, 1)?[0];
    let dict = u32in(p)?;
    let nt = u32in(p)?;
    if mode > 1 || dict == 0 || dict > nt || nt > n {
        return Err(bad());
    }
    let Vocabulary { ws, ns } = vocabulary(p, dict, n)?;
    let heads = plain(p, nt)?;
    if heads.len() != nt {
        return Err(bad());
    }
    let bits = ReadBits::from(p)?;
    let mut padded = Vec::with_capacity(bits.s.len() + 8);
    padded.extend(bits.s);
    padded.extend([0u8; 8]);
    let mut history = if mode != 0 {
        vec![[u32::MAX; 4]; dict + 1]
    } else {
        vec![]
    };
    let mut prev = dict;
    let mut bit = 0usize;
    let mut ids = Vec::with_capacity(nt);
    for &h in heads.iter() {
        let id = if mode != 0 && (248..252).contains(&h) {
            history[prev][(h - 248) as usize]
        } else {
            let k = (h as u32 >> 3).saturating_sub(1);
            if k > 25 || bit / 8 > bits.s.len() {
                return Err(bad());
            }
            let word =
                unsafe { padded.as_ptr().add(bit / 8).cast::<u32>().read_unaligned() }.to_le();
            let extra = (word >> (bit & 7)) & ((1 << k) - 1);
            bit += k as usize;
            let base = if h < 16 {
                h as u32
            } else {
                (8 + (h as u32 & 7)) << k
            };
            base + extra
        };
        if id as usize >= dict {
            return Err(bad());
        }
        if mode != 0 {
            next(&mut history[prev], id);
            prev = id as usize;
        }
        ids.push(id);
    }
    if bit.div_ceil(8) != bits.s.len()
        || (!bit.is_multiple_of(8) && bits.s[bit / 8] >> (bit & 7) != 0)
    {
        return Err(bad());
    }
    let mut out = vec![0; n];
    expand_words(&ids, &ws, &ns, &mut out)?;
    Ok(out)
}

#[cfg(feature = "research")]
fn hot_words<'a>(
    ids: &[u32],
    order: &[usize],
    spelling: &impl Fn(usize) -> &'a [u8],
    raw_len: usize,
    cap: usize,
) -> Vec<u8> {
    let mut counts = vec![0u32; order.len()];
    for &v in ids {
        counts[v as usize] += 1;
    }
    let mut sel: Vec<_> = (0..order.len()).filter(|&j| counts[j] >= 2).collect();
    sel.sort_unstable_by_key(|&v| (std::cmp::Reverse(counts[v]), v));
    sel.truncate(cap);
    let mut map = vec![u16::MAX; order.len()];
    let mut out = vec![];
    out.extend((raw_len as u32).to_le_bytes());
    out.push(27);
    out.extend((ids.len() as u32).to_le_bytes());
    out.extend((sel.len() as u32).to_le_bytes());
    for (j, &v) in sel.iter().enumerate() {
        let t = spelling(order[v]);
        out.push(t.len() as u8);
        out.extend(t);
        map[v] = j as u16;
    }
    let mut heads = Vec::with_capacity(ids.len());
    let mut lo = vec![];
    let mut rare = vec![];
    for &v in ids {
        let rank = map[v as usize] as usize;
        if rank < 192 {
            heads.push(rank as u8);
        } else if rank != 65535 {
            heads.push((192 + ((rank - 192) >> 8)) as u8);
            lo.push((rank - 192) as u8);
        } else {
            let t = spelling(order[v as usize]);
            heads.push(223 + t.len() as u8);
            rare.extend(t);
        }
    }
    ans::put_tight(&heads, &mut out);
    ans::put_tight(&lo, &mut out);
    out.extend((rare.len() as u32).to_le_bytes());
    for piece in rare.chunks(1 << 19) {
        let z = crate::lz::legacy::<false, 16, 16, false, 0>(piece);
        if z.len() <= piece.len() {
            out.extend((z.len() as u32).to_le_bytes());
            out.extend(z);
        } else {
            out.extend(((piece.len() + 1) as u32).to_le_bytes());
            out.push(0);
            out.extend(piece);
        }
    }
    out
}
pub(crate) fn hot_literals(p: &mut &[u8], n: usize) -> Result<Vec<u8>> {
    let nt = u32in(p)?;
    let k = u32in(p)?;
    if nt > n || k > 8384 || k > nt {
        return Err(bad());
    }
    let mut ws = vec![[0u8; 16]; k];
    let mut ns = vec![0u8; k];
    for (w, n) in ws.iter_mut().zip(&mut ns) {
        *n = take(p, 1)?[0];
        if !(1..=16).contains(n) {
            return Err(bad());
        }
        w[..*n as usize].copy_from_slice(take(p, *n as usize)?);
    }
    let h = plain(p, nt)?;
    let lows = plain(p, nt)?;
    let len = u32in(p)?;
    if h.len() != nt || len > n {
        return Err(bad());
    }
    let mut rare = vec![0; len + 16];
    for d in rare[..len].chunks_mut(1 << 19) {
        let nb = u32in(p)?;
        let (mode, s) = take(p, nb)?.split_first().ok_or_else(bad)?;
        crate::cascade::expand_leaf(*mode, s, d)?;
    }
    let mut out = vec![0; n + 16];
    let mut lit = 0;
    let mut at = 0;
    let mut l = 0;
    let mut ptrs = [std::ptr::null(); 64];
    let mut starts = [0usize; 64];
    for tile in h.chunks(64) {
        for (i, &head) in tile.iter().enumerate() {
            starts[i] = at;
            if head >= 224 {
                if head >= 240 {
                    return Err(bad());
                }
                let w = (head - 223) as usize;
                if w > len - lit {
                    return Err(bad());
                }
                ptrs[i] = unsafe { rare.as_ptr().add(lit) };
                lit += w;
                at += w;
            } else {
                let j = if head < 192 {
                    head as usize
                } else {
                    let rem = *lows.get(l).ok_or_else(bad)? as usize;
                    l += 1;
                    192 + (head as usize - 192) * 256 + rem
                };
                at += *ns.get(j).ok_or_else(bad)? as usize;
                ptrs[i] = ws[j].as_ptr();
            }
        }
        if at > n {
            return Err(bad());
        }
        for (&word, &pos) in ptrs[..tile.len()].iter().zip(&starts) {
            unsafe {
                std::ptr::copy_nonoverlapping(word, out.as_mut_ptr().add(pos), 16);
            }
        }
    }
    if lit != len || at != n || l != lows.len() {
        return Err(bad());
    }
    out.truncate(n);
    Ok(out)
}

// Move a substring in token units without looking up the spelling of any word
// inside it. End positions for the copied run differ by one constant.
pub(crate) fn decode_offsets(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let nt = u32in(&mut p)?;
    if nt == 0 || nt > dst.len() {
        return Err(bad());
    }
    let tags = plain(&mut p, nt / 2)?;
    let lens = plain(&mut p, nt)?;
    let mut ex = &*lens;
    let offs = plain(&mut p, tags.len())?;
    if tags.len() != offs.len() {
        return Err(bad());
    }
    let mut bits = ReadBits::from(&mut p)?;
    let n = u32in(&mut p)?;
    if n > dst.len() || take(&mut p, 1)?[0] != 29 {
        return Err(bad());
    }
    let (raw, limits) = crate::lexrank::expand::<true>(&mut p, n)?;
    if !p.is_empty() {
        return Err(bad());
    }
    if crate::tuning("BTR_TOKEN_STAGES", 0, 0, 1) != 0 {
        return staged(dst, nt, &tags, &mut ex, &offs, bits, &raw, &limits);
    }
    let literals = limits.len() - 1;
    let mut pos = vec![0u32; nt + 1];
    let mut at = 0usize;
    let mut li = 0usize;
    let mut w = 0usize;
    for i in 0..=tags.len() {
        let tail = i == tags.len();
        let tag = if tail { 0 } else { tags[i] };
        let mut ll = if tail { nt - at } else { (tag >> 4) as usize };
        let mut ml = (tag & 15) as usize + 2;
        if !tail && ll == 15 {
            ll += crate::lz::lenin(&mut ex)?;
        }
        if !tail && ml == 17 {
            ml += crate::lz::lenin(&mut ex)?;
        }
        if ll > nt - at || ll > literals - li {
            return Err(bad());
        }
        if ll != 0 {
            let start = limits[li] as usize;
            let len = limits[li + ll] as usize - start;
            if len > dst.len() - w {
                return Err(bad());
            }
            let bias = (w - start) as u32;
            for (o, &q) in pos[at + 1..at + ll + 1]
                .iter_mut()
                .zip(&limits[li + 1..li + ll + 1])
            {
                *o = bias + q;
            }
            dst[w..w + len].copy_from_slice(&raw[start..start + len]);
            at += ll;
            li += ll;
            w += len;
        }
        if tail {
            break;
        }
        let off = bits.integer(offs[i])? as usize;
        if off == 0 || off > at || ml > nt - at {
            return Err(bad());
        }
        let mut from = at - off;
        let mut have = off;
        let mut left = ml;
        while left > 0 {
            let k = left.min(have);
            let begin = pos[from] as usize;
            let bytes = pos[from + k] as usize - begin;
            if bytes > dst.len() - w {
                return Err(bad());
            }
            let bias = (w - begin) as u32;
            let (old, new) = pos.split_at_mut(at + 1);
            for (d, &q) in new[..k].iter_mut().zip(&old[from + 1..from + 1 + k]) {
                *d = bias + q;
            }
            dst.copy_within(begin..begin + bytes, w);
            if left == ml {
                from = at;
                have = k;
            } else {
                have += k;
            }
            at += k;
            w += bytes;
            left -= k;
        }
    }
    if w != dst.len() || li != literals || !bits.done() || !ex.is_empty() {
        return Err(bad());
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn staged(
    dst: &mut [u8],
    nt: usize,
    tags: &[u8],
    ex: &mut &[u8],
    offs: &[u8],
    mut bits: ReadBits<'_>,
    raw: &[u8],
    limits: &[u32],
) -> Result<()> {
    #[derive(Clone, Copy)]
    struct Cmd {
        beg: u32,
        start: u32,
        source: u32,
        end: u32,
        lit: u32,
    }
    let mut widths = vec![0u8; nt + 16];
    let mut commands = Vec::with_capacity(tags.len() + 1);
    let mut at = 0usize;
    let mut li = 0usize;
    for i in 0..=tags.len() {
        let tail = i == tags.len();
        let tag = if tail { 0 } else { tags[i] };
        let mut ll = if tail { nt - at } else { (tag >> 4) as usize };
        let mut ml = (tag & 15) as usize + 2;
        if !tail && ll == 15 {
            ll += crate::lz::lenin(ex)?;
        }
        if !tail && ml == 17 {
            ml += crate::lz::lenin(ex)?;
        }
        if ll > nt - at || ll > limits.len() - 1 - li {
            return Err(bad());
        }
        let beg = at;
        let lp = li;
        for (j, o) in widths[at..at + ll].iter_mut().enumerate() {
            *o = (limits[li + j + 1] - limits[li + j]) as u8;
        }
        at += ll;
        li += ll;
        if tail {
            commands.push(Cmd {
                beg: beg as u32,
                start: at as u32,
                source: at as u32,
                end: at as u32,
                lit: limits[lp],
            });
            break;
        }
        let off = bits.integer(offs[i])? as usize;
        if off == 0 || off > at || ml > nt - at {
            return Err(bad());
        }
        let src = at - off;
        if ml <= 16 && off >= ml {
            // All valid widths have already been written. An overcopy is inside
            // the padded buffer and later commands overwrite the unused tail.
            unsafe {
                let a = widths.as_ptr().add(src).cast::<[u8; 16]>().read_unaligned();
                widths
                    .as_mut_ptr()
                    .add(at)
                    .cast::<[u8; 16]>()
                    .write_unaligned(a);
            }
        } else {
            let k = ml.min(off);
            widths.copy_within(src..src + k, at);
            let mut k = k;
            while k < ml {
                let n = k.min(ml - k);
                widths.copy_within(at..at + n, at + k);
                k += n;
            }
        }
        commands.push(Cmd {
            beg: beg as u32,
            start: at as u32,
            source: src as u32,
            end: (at + ml) as u32,
            lit: limits[lp],
        });
        at += ml;
    }
    if !bits.done() || !ex.is_empty() || li + 1 != limits.len() {
        return Err(bad());
    }
    let mut positions = vec![0u32; nt + 1];
    let mut bytes = 0u32;
    let mut j = 0;
    #[cfg(target_arch = "aarch64")]
    unsafe {
        use std::arch::aarch64::*;
        let z = vdupq_n_u8(0);
        while j + 16 <= nt {
            let v = vld1q_u8(widths.as_ptr().add(j));
            let a = vaddq_u8(v, vextq_u8::<15>(z, v));
            let a = vaddq_u8(a, vextq_u8::<14>(z, a));
            let a = vaddq_u8(a, vextq_u8::<12>(z, a));
            let a = vaddq_u8(a, vextq_u8::<8>(z, a));
            // 16 words of length 16 produce 256, which wraps only the final lane.
            let carry = vdupq_n_u32(bytes);
            let low = vmovl_u8(vget_low_u8(a));
            let high = vmovl_high_u8(a);
            let dest = positions.as_mut_ptr().add(j + 1);
            vst1q_u32(dest, vaddq_u32(carry, vmovl_u16(vget_low_u16(low))));
            vst1q_u32(dest.add(4), vaddq_u32(carry, vmovl_high_u16(low)));
            vst1q_u32(dest.add(8), vaddq_u32(carry, vmovl_u16(vget_low_u16(high))));
            vst1q_u32(dest.add(12), vaddq_u32(carry, vmovl_high_u16(high)));
            let inc = vgetq_lane_u8::<15>(a) as u32;
            bytes += if inc == 0 { 256 } else { inc };
            positions[j + 16] = bytes;
            j += 16;
        }
    }
    for i in j..nt {
        bytes += widths[i] as u32;
        positions[i + 1] = bytes;
    }
    if bytes as usize != dst.len() {
        return Err(bad());
    }
    for c in commands {
        let beg = positions[c.beg as usize] as usize;
        let start = positions[c.start as usize] as usize;
        let end = positions[c.end as usize] as usize;
        let src = positions[c.source as usize] as usize;
        let l = c.lit as usize;
        let ll = start - beg;
        let ml = end - start;
        if ll != 0 {
            if ll <= 16 && l + 16 <= raw.len() && beg + 16 <= dst.len() {
                unsafe {
                    std::ptr::copy_nonoverlapping(
                        raw.as_ptr().add(l),
                        dst.as_mut_ptr().add(beg),
                        16,
                    );
                }
            } else {
                dst[beg..start].copy_from_slice(&raw[l..l + ll]);
            }
        }
        if ml == 0 {
            continue;
        }
        let off = start - src;
        if end + 16 <= dst.len() {
            unsafe {
                if ml <= 16 && off >= ml {
                    crate::lz::copy16(dst.as_ptr().add(src), dst.as_mut_ptr().add(start));
                } else {
                    crate::lz::long_match(dst.as_mut_ptr().add(start), off, ml);
                }
            }
        } else {
            let k = ml.min(off);
            dst.copy_within(src..src + k, start);
            let mut k = k;
            while k < ml {
                let v = k.min(ml - k);
                dst.copy_within(start..start + v, start + k);
                k += v;
            }
        }
    }
    Ok(())
}
