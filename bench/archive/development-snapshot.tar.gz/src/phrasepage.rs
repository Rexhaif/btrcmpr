// Share a small list of locally frequent root phrases within each token page.
// The list and all escapes use the existing full-dictionary code. A byte tag
// can then refer to a local spelling many times within one article or passage.
use super::{DecodeBook, EncodeBook, Group, put_root, read_book, read_root, width};
use crate::{Frame, Result, ans, bad, parallel, take, u32in, wordbase::plain};
use std::borrow::Cow;

pub(super) fn put(
    ids: &[u32],
    book: &EncodeBook,
    out: &mut Vec<u8>,
    log: usize,
    cap: usize,
    conditional: bool,
) {
    let len = 1usize << log;
    let total: u64 = book.groups.iter().map(|g| g.freq).sum();
    let prices: Vec<_> = book
        .groups
        .iter()
        .map(|g| {
            ((width(g.hi - g.lo) as f64 + (total as f64 / g.freq as f64).log2()) * 16.).round()
                as i32
        })
        .collect();
    let mut counts = vec![0u32; book.heads.len()];
    let mut aliases = vec![255u8; book.heads.len()];
    let (mut sizes, mut tags, mut globals, mut used) = (
        Vec::new(),
        Vec::with_capacity(ids.len()),
        Vec::new(),
        Vec::new(),
    );
    for part in ids.chunks(len) {
        for &id in part {
            let n = &mut counts[id as usize];
            if *n == 0 {
                used.push(id)
            }
            *n += 1;
        }
        let mut ranks: Vec<_> = used
            .iter()
            .copied()
            .filter_map(|id| {
                let count = counts[id as usize] as i32;
                let h = book.heads[id as usize];
                let g = book.groups[h as usize];
                let rank = book.global[id as usize] as usize - (g.lo - book.rows[g.w].0);
                let price = prices[h as usize];
                let gain = (count - 1) * price - count * 88;
                (count >= 2 && gain > 16).then_some((
                    std::cmp::Reverse(gain),
                    std::cmp::Reverse(count),
                    (h, rank),
                    id,
                ))
            })
            .collect();
        if ranks.len() > cap {
            ranks.select_nth_unstable(cap);
            ranks.truncate(cap)
        }
        ranks.sort_unstable_by_key(|&(_, count, code, _)| (count, code));
        sizes.push(ranks.len() as u8);
        for (rank, &(_, _, _, id)) in ranks.iter().enumerate() {
            aliases[id as usize] = rank as u8;
            globals.push(id)
        }
        for &id in part {
            let t = aliases[id as usize];
            tags.push(t);
            if t == 255 {
                globals.push(id)
            }
        }
        for id in used.drain(..) {
            counts[id as usize] = 0;
            aliases[id as usize] = 255;
        }
    }
    out.extend((ids.len() as u32).to_le_bytes());
    out.extend([54, log as u8]);
    ans::put_tight(&sizes, out);
    ans::put_tight(&tags, out);
    out.extend((globals.len() as u32).to_le_bytes());
    put_root(&globals, book, out, conditional);
}

pub(super) fn decode(mut p: &[u8], nt: usize, book: &DecodeBook, dst: &mut [u8]) -> Result<()> {
    if u32in(&mut p)? != nt || take(&mut p, 1)? != [54] {
        return Err(bad());
    }
    let log = usize::from(take(&mut p, 1)?[0]);
    if !(7..=16).contains(&log) {
        return Err(bad());
    }
    let page = 1usize << log;
    let sizes = plain(&mut p, nt.div_ceil(page))?;
    let tags = plain(&mut p, nt)?;
    if tags.len() != nt || sizes.len() != nt.div_ceil(page) {
        return Err(bad());
    }
    let ng = u32in(&mut p)?;
    if ng == 0 || ng > nt {
        return Err(bad());
    }
    // MATCHED only returns validated spelling offsets and widths. Do not
    // recursively interpret a local page stream in the escape stream.
    let mut global = read_root::<true>(p, ng, book, dst)?;
    global.push(0);
    let mut at = 0usize;
    let mut complete = Vec::with_capacity(nt);
    let mut table = [0u32; 256];
    for (part, &count) in tags.chunks(page).zip(sizes.iter()) {
        let count = usize::from(count);
        if count == 255 || count > ng - at {
            return Err(bad());
        }
        table[..count].copy_from_slice(&global[at..at + count]);
        at += count;
        let escapes = part.iter().filter(|&&t| t == 255).count();
        if escapes > ng - at {
            return Err(bad());
        }
        let mut invalid = 0u8;
        for &tag in part {
            let escape = tag == 255;
            invalid |= u8::from(!escape && tag as usize >= count);
            // The full page's escape count was checked; the final padded
            // descriptor keeps the unconditional lookahead in bounds.
            let g = unsafe { *global.get_unchecked(at) };
            complete.push(if escape { g } else { table[tag as usize] });
            at += usize::from(escape);
        }
        if invalid != 0 {
            return Err(bad());
        }
    }
    if at != ng {
        return Err(bad());
    }
    #[cfg(target_arch = "aarch64")]
    {
        super::super::wordpipe::expand(&complete, &book.spell, dst)
    }
    #[cfg(not(target_arch = "aarch64"))]
    {
        let mut i = 0;
        for v in complete {
            let q = (v >> 6) as usize;
            let w = (v as usize & 63) + 1;
            dst.get_mut(i..i + w)
                .ok_or_else(bad)?
                .copy_from_slice(&book.spell[q..q + w]);
            i += w;
        }
        if i != dst.len() {
            return Err(bad());
        }
        Ok(())
    }
}

// Reconstruct the emitted ranks from an already verified, single-dictionary
// frame. This can benchmark alternative token codes without retraining phrases.
pub(crate) fn rewrite(
    f: &Frame<'_>,
    log: usize,
    cap: usize,
    conditional: bool,
) -> Result<Frame<'static>> {
    if !(7..=16).contains(&log)
        || !(1..=254).contains(&cap)
        || f.layout.is_some()
        || f.blocks.is_empty()
    {
        return Err(bad());
    }
    let mut p = f.blocks[0].as_ref();
    if take(&mut p, 1)? != [50] {
        return Err(bad());
    }
    let count = usize::from(take(&mut p, 1)?[0]);
    if count != f.blocks.len() || count > 64 {
        return Err(bad());
    }
    let n = u32in(&mut p)?;
    let dict = take(&mut p, n)?;
    let mut data = dict;
    let (nt, dec) = read_book(&mut data, f.size)?;
    if !data.is_empty() {
        return Err(bad());
    }
    let mut jobs = vec![];
    for i in 0..count {
        if i != 0 {
            p = &f.blocks[i];
            if take(&mut p, 1)? != [51] {
                return Err(bad());
            }
        }
        let k = u32in(&mut p)?;
        jobs.push((p, k, (f.size - i * f.block).min(f.block)));
    }
    if jobs.iter().map(|j| j.1).sum::<usize>() != nt {
        return Err(bad());
    }
    let mut groups = Vec::new();
    let mut heads = vec![];
    let mut starts = [u32::MAX; 65];
    let mut first = [0usize; 65];
    let mut sizes = [0usize; 65];
    for m in dec.meta.iter().take_while(|m| m.n != 0) {
        let w = m.w as usize;
        let lo = heads.len();
        if starts[w] == u32::MAX {
            starts[w] = m.start;
            first[w] = lo;
        }
        let head = groups.len() as u8;
        let hi = lo + m.n as usize;
        heads.resize(hi, head);
        sizes[w] += m.n as usize;
        groups.push(Group { w, lo, hi, freq: 0 });
    }
    let mut roots = vec![Vec::new(); count];
    parallel(
        count.min(4),
        jobs.into_iter().zip(&mut roots),
        |((s, k, n), ids)| {
            let mut scratch = vec![0; n];
            *ids = read_root::<true>(s, k, &dec, &mut scratch)?;
            for v in ids.iter_mut() {
                let w = (*v as usize & 63) + 1;
                let q = *v >> 6;
                let delta = q.checked_sub(starts[w]).ok_or_else(bad)? as usize;
                if !delta.is_multiple_of(w) || delta / w >= sizes[w] {
                    return Err(bad());
                }
                *v = (first[w] + delta / w) as u32;
            }
            Ok(())
        },
    )?;
    for part in &roots {
        for &id in part {
            groups[heads[id as usize] as usize].freq += 1
        }
    }
    let book = EncodeBook {
        groups,
        global: (0..heads.len() as u32).collect(),
        entries: heads.len(),
        heads,
        rows: [(0, 0, 0); 65],
    };
    let mut blocks: Vec<_> = f.blocks.iter().map(|_| Cow::Owned(Vec::new())).collect();
    parallel(
        count.min(4),
        roots.iter().zip(&mut blocks).enumerate(),
        |(i, (ids, out))| {
            let mut data = Vec::new();
            if i == 0 {
                data.extend([50, count as u8]);
                data.extend((dict.len() as u32).to_le_bytes());
                data.extend(dict)
            } else {
                data.push(51)
            }
            data.extend((ids.len() as u32).to_le_bytes());
            put(ids, &book, &mut data, log, cap, conditional);
            *out = Cow::Owned(data);
            Ok(())
        },
    )?;
    Ok(Frame {
        size: f.size,
        block: f.block,
        layout: None,
        blocks,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn page_definitions_and_escapes_recover_the_shared_spellings() {
        let mut raw = Vec::new();
        for i in 0..5000 {
            raw.extend_from_slice(
                format!(
                    "The stream in district {} joins river {} at mile {}. ",
                    i / 250,
                    i % 19,
                    i % 103
                )
                .as_bytes(),
            );
        }
        let (terms, ids, rules) = super::super::merge_rules::<true>(&raw, 128, 32, 3);
        let mut freq = vec![0; terms.len()];
        for &id in &ids {
            freq[id as usize] += 1
        }
        let mut book_wire = vec![];
        let enc = super::super::build_book(&raw, &terms, &rules, freq, ids.len(), &mut book_wire)
            .unwrap();
        let (nt, dec) = super::super::read_book(&mut book_wire.as_slice(), raw.len()).unwrap();
        for (log, cap) in [(7, 1), (9, 64), (12, 254)] {
            let mut wire = vec![];
            put(&ids, &enc, &mut wire, log, cap, false);
            let mut dst = vec![0; raw.len()];
            read_root::<false>(&wire, nt, &dec, &mut dst).unwrap();
            assert_eq!(dst, raw);
            assert!(read_root::<false>(&wire[..wire.len() - 1], nt, &dec, &mut dst).is_err());
            wire[5] = 17;
            assert!(read_root::<false>(&wire, nt, &dec, &mut dst).is_err());
        }
    }
}
