// A whole table entry fits in a native 32-bit load. The low six bits are
// the shift itself; adding two entries leaves their summed widths there.
use super::Code;
#[inline(always)]
fn fetch<const ASM: bool>(t: &[u32; 256], s: u8) -> u32 {
    #[cfg(target_arch = "aarch64")]
    if ASM {
        let out: u32;
        // s is a byte, so p points at a complete, aligned, initialized u32.
        unsafe {
            core::arch::asm!("ldr {value:w}, [{base}, {index}, lsl #2]",value=out(reg)out,base=in(reg)t.as_ptr(),index=in(reg)usize::from(s),options(pure,readonly,nostack,preserves_flags));
        }
        return out;
    }
    t[s as usize]
}
#[inline(always)]
fn four<const K: usize, const ASM: bool>(t: &[u32; 256], s: &[u8]) -> (u32, u32, u32) {
    let a = fetch::<ASM>(t, s[0]);
    let b = fetch::<ASM>(t, s[1]);
    let c = fetch::<ASM>(t, s[2]);
    let d = fetch::<ASM>(t, s[3]);
    let rank = |v: u32| (v >> 8) & 255;
    let ab = rank(a) | rank(b).wrapping_shl(a);
    let cd = rank(c) | rank(d).wrapping_shl(c);
    let ha = a >> 16 | (b >> 16) << K | (c >> 16) << (2 * K) | (d >> 16) << (3 * K);
    (ha, ab | cd.wrapping_shl(a + b), (a + b + c + d) & 63)
}
fn write<const K: usize, const ASM: bool, const WIDE: bool>(
    s: &[u8],
    t: &[u32; 256],
    heads: &mut [u8],
    tail: &mut [u8],
) {
    let (mut bit, mut carry, mut at) = (0usize, 0u64, 0usize);
    let mut chunks = s.chunks_exact(8);
    for src in &mut chunks {
        let (h0, p0, n0) = four::<K, ASM>(t, &src[..4]);
        let (h1, p1, n1) = four::<K, ASM>(t, &src[4..]);
        let h = u64::from(h0) | (u64::from(h1) << (4 * K));
        heads[at..at + 8].copy_from_slice(&h.to_le_bytes());
        at += K;
        if WIDE {
            let payload = u64::from(p0) | (u64::from(p1) << n0);
            let full = ((u128::from(payload)) << (bit & 7)) | u128::from(carry);
            let base = bit / 8;
            tail[base..base + 9].copy_from_slice(&full.to_le_bytes()[..9]);
            let shift = ((bit & 7) + n0 as usize + n1 as usize) & !7;
            carry = (full >> shift) as u64;
            bit += n0 as usize + n1 as usize;
        } else {
            for (p, n) in [(p0, n0), (p1, n1)] {
                let x = carry | (u64::from(p) << (bit & 7));
                tail[bit / 8..bit / 8 + 8].copy_from_slice(&x.to_le_bytes());
                carry = x >> (((bit & 7) + n as usize) & !7);
                bit += n as usize;
            }
        }
    }
    let mut h = 0u64;
    for (j, &b) in chunks.remainder().iter().enumerate() {
        let c = t[b as usize];
        let n = (c & 63) as usize;
        h |= u64::from(c >> 16) << (j * K);
        let x = carry | (u64::from((c >> 8) & 255) << (bit & 7));
        tail[bit / 8..bit / 8 + 2].copy_from_slice(&(x as u16).to_le_bytes());
        carry = x >> (((bit & 7) + n) & !7);
        bit += n;
    }
    heads[at..at + 8].copy_from_slice(&h.to_le_bytes());
    debug_assert_eq!(tail.len(), bit.div_ceil(8) + 17);
}
pub(super) fn pack<const K: usize>(
    s: &[u8],
    map: &[Code; 256],
    heads: &mut [u8],
    tail: &mut [u8],
    mode: usize,
) {
    let table = std::array::from_fn(|i| {
        u32::from(map[i].head) << 16 | u32::from(map[i].rank) << 8 | u32::from(map[i].width)
    });
    match mode {
        1 => write::<K, false, false>(s, &table, heads, tail),
        2 => write::<K, true, false>(s, &table, heads, tail),
        3 => write::<K, false, true>(s, &table, heads, tail),
        _ => write::<K, true, true>(s, &table, heads, tail),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn layout_matches_with_zero_widths_full_widths_and_partial_carries() {
        fn check<const K: usize>(s: &[u8], map: &[Code; 256]) {
            let n = s
                .iter()
                .map(|&b| usize::from(map[b as usize].width))
                .sum::<usize>()
                .div_ceil(8)
                + 17;
            let mut h = vec![0u8; (s.len() * K).div_ceil(8) + 17];
            let mut t = vec![0u8; n];
            super::super::pack_scalar::<K>(s, map, &mut h, &mut t);
            for mode in 1..5 {
                let (mut a, mut b) = (vec![0u8; h.len()], vec![0u8; n]);
                pack::<K>(s, map, &mut a, &mut b, mode);
                assert_eq!(a, h);
                assert_eq!(b, t);
            }
        }
        let s: Vec<u8> = (0..995).map(|i| ((i * 157) ^ (i >> 3)) as u8).collect();
        for t in 0..3 {
            let map = std::array::from_fn(|i| {
                let w = if t == 0 {
                    i % 9
                } else if t == 1 {
                    8
                } else {
                    0
                };
                Code {
                    head: (i % 2) as u8,
                    rank: (i & ((1usize << w) - 1)) as u8,
                    width: w as u8,
                }
            });
            for n in (0..40).chain([126, 127, 128, 997.min(s.len())]) {
                check::<1>(&s[..n], &map);
                check::<3>(&s[..n], &map);
                check::<5>(&s[..n], &map);
            }
        }
    }
}
