// Learn short variable-length phrases on a stratified sample, then parse the
// whole job with read-only tables. Decoder entries contain up to eight bytes.
use crate::{Result, ans, bad, lz, take, u32in};
use std::collections::HashMap;
use std::hash::{BuildHasherDefault, Hasher};
#[derive(Default)]
struct Mix(u64);
impl Hasher for Mix {
    fn write(&mut self, b: &[u8]) {
        for &v in b {
            self.0 = (self.0 ^ v as u64).wrapping_mul(0x9e3779b97f4a7c15);
        }
    }
    fn write_u32(&mut self, x: u32) {
        self.0 = (x as u64).wrapping_mul(0x9e3779b97f4a7c15);
        self.0 ^= self.0 >> 31;
    }
    fn finish(&self) -> u64 {
        self.0
    }
}
type Map = HashMap<u32, u16, BuildHasherDefault<Mix>>;
#[derive(Clone, Copy, Default)]
struct Word {
    v: u64,
    n: u8,
}
const DIRECT: usize = 192;
const LIMIT: usize = DIRECT + 64 * 256;
fn learn(s: &[u8], level: u8) -> Vec<Word> {
    let sample = (if level <= 3 {
        32768
    } else if level < 10 {
        131072
    } else {
        393216
    })
    .min(s.len());
    let mut tokens = Vec::with_capacity(sample);
    let pieces = 64.min(sample);
    let width = sample / pieces;
    for j in 0..pieces {
        let at = (s.len() - width) * j / (pieces - 1).max(1);
        tokens.extend(s[at..at + width].iter().map(|&x| x as u16));
    }
    let mut words: Vec<Word> = (0..=255).map(|v| Word { v, n: 1 }).collect();
    let cap = (1024 + 768 * level as usize).min(LIMIT);
    for stage in 0..16 {
        let mut pairs = Vec::with_capacity(tokens.len());
        for e in tokens.windows(2) {
            if words[e[0] as usize].n + words[e[1] as usize].n <= 8 {
                pairs.push((e[0] as u32) << 16 | e[1] as u32);
            }
        }
        pairs.sort_unstable();
        let mut scores = vec![];
        let mut i = 0;
        while i < pairs.len() {
            let k = pairs[i];
            let start = i;
            i += 1;
            while i < pairs.len() && pairs[i] == k {
                i += 1;
            }
            if i - start >= 3 {
                scores.push(((i - start) as u32, k));
            }
        }
        scores.sort_unstable_by(|a, b| b.cmp(a));
        scores.truncate((64usize << stage.min(6)).min(cap - words.len()));
        if scores.is_empty() {
            break;
        }
        let mut new = Map::default();
        new.reserve(scores.len());
        for (_, pair) in scores {
            let a = words[(pair >> 16) as usize];
            let b = words[(pair & 65535) as usize];
            let id = words.len() as u16;
            words.push(Word {
                v: a.v | (b.v << (a.n * 8)),
                n: a.n + b.n,
            });
            new.insert(pair, id);
        }
        let mut k = 0;
        let mut i = 0;
        while i < tokens.len() {
            let a = tokens[i];
            if i + 1 < tokens.len()
                && let Some(&id) = new.get(&((a as u32) << 16 | tokens[i + 1] as u32))
            {
                tokens[k] = id;
                i += 2;
            } else {
                tokens[k] = a;
                i += 1;
            }
            k += 1;
        }
        tokens.truncate(k);
        if words.len() == cap {
            break;
        }
    }
    words
}
fn parse(s: &[u8], words: &[Word]) -> Vec<u16> {
    let mut ct = [0usize; 9];
    for w in words {
        ct[w.n as usize] += 1;
    }
    let mut tables: Vec<Vec<(u64, u16)>> = ct
        .iter()
        .map(|&c| vec![(0, 0); (c * 4).max(16).next_power_of_two()])
        .collect();
    const M: u64 = 0xa24baed4963ee407;
    for (id, w) in words.iter().enumerate().skip(256) {
        let t = &mut tables[w.n as usize];
        let mask = t.len() - 1;
        let h = (w.v.wrapping_mul(M) ^ (w.v.wrapping_mul(M) >> 32)) as usize & mask;
        let mut k = h;
        while t[k].1 != 0 && t[k].0 != w.v {
            k = (k + 1) & mask;
        }
        t[k] = (w.v, id as u16);
    }
    let mut ids = Vec::with_capacity(s.len() / 2);
    let mut i = 0;
    while i < s.len() {
        let avail = (s.len() - i).min(8);
        let w = if avail == 8 {
            u64::from_le_bytes(s[i..i + 8].try_into().unwrap())
        } else {
            let mut z = [0; 8];
            z[..avail].copy_from_slice(&s[i..]);
            u64::from_le_bytes(z)
        };
        let mut id = s[i] as u16;
        let mut n = 1;
        for j in (2..=avail).rev() {
            let t = &tables[j];
            let mask = t.len() - 1;
            let key = w & (u64::MAX >> (64 - j * 8));
            let hash = key.wrapping_mul(M);
            let mut h = (hash ^ (hash >> 32)) as usize & mask;
            while t[h].1 != 0 {
                if t[h].0 == key {
                    id = t[h].1;
                    n = j;
                    break;
                }
                h = (h + 1) & mask;
            }
            if n != 1 {
                break;
            }
        }
        ids.push(id);
        i += n;
    }
    ids
}
pub fn encode(s: &[u8], level: u8, method: u8) -> Vec<u8> {
    let words = learn(s, level);
    let tokens = parse(s, &words);
    let mut counts = vec![0u32; words.len()];
    for &id in &tokens {
        counts[id as usize] += 1;
    }
    let mut order: Vec<_> = (0..words.len()).filter(|&i| counts[i] > 0).collect();
    order.sort_unstable_by_key(|&i| (std::cmp::Reverse(counts[i]), i));
    let mut map = vec![0u16; words.len()];
    let mut dict = vec![];
    for (i, &old) in order.iter().enumerate() {
        map[old] = i as u16;
        let w = words[old];
        dict.push(w.n);
        dict.extend(&w.v.to_le_bytes()[..w.n as usize]);
    }
    let mut hdr = vec![14, method];
    hdr.extend((order.len() as u16).to_le_bytes());
    hdr.extend((tokens.len() as u32).to_le_bytes());
    ans::put_policy(&dict, &mut hdr, 0.995);
    let mut head = Vec::with_capacity(tokens.len());
    let mut low = vec![];
    let mut both = vec![];
    for id in tokens {
        let rank = map[id as usize] as usize;
        let v = if rank < DIRECT {
            rank as u8
        } else {
            DIRECT as u8 + ((rank - DIRECT) >> 8) as u8
        };
        head.push(v);
        if method != 0 {
            both.push(v);
        }
        if rank >= DIRECT {
            let l = (rank - DIRECT) as u8;
            low.push(l);
            if method != 0 {
                both.push(l);
            }
        }
    }
    if method == 0 {
        ans::put_policy(&head, &mut hdr, 0.995);
        ans::put_policy(&low, &mut hdr, 0.995);
    } else {
        hdr.extend((both.len() as u32).to_le_bytes());
        let enc = if method == 2 {
            lz::optimal(&both, level)
        } else {
            lz::encode_level::<false>(&both, level)
        };
        if enc.len() > both.len() {
            hdr.push(0);
            hdr.extend(both);
        } else {
            hdr.extend(enc);
        }
    }
    hdr
}
pub fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let method = take(&mut p, 1)?[0];
    let count = u16::from_le_bytes(take(&mut p, 2)?.try_into().unwrap()) as usize;
    let nt = u32in(&mut p)?;
    if count == 0 || count > LIMIT || nt > dst.len() || method > 2 {
        return Err(bad());
    }
    let def = ans::get(&mut p, count * 9)?;
    let mut defs = &*def;
    let mut words = vec![[0u8; 8]; count];
    let mut lens = vec![0; count];
    for (w, l) in words.iter_mut().zip(&mut lens) {
        let n = take(&mut defs, 1)?[0];
        if !(1..=8).contains(&n) {
            return Err(bad());
        }
        w[..n as usize].copy_from_slice(take(&mut defs, n as usize)?);
        *l = n;
    }
    if !defs.is_empty() {
        return Err(bad());
    }
    let mut at = 0;
    let mut emit = |rank: usize| -> Result<()> {
        let w = words.get(rank).ok_or_else(bad)?;
        let n = lens[rank] as usize;
        if at + 8 <= dst.len() {
            unsafe {
                std::ptr::copy_nonoverlapping(w.as_ptr(), dst.as_mut_ptr().add(at), 8);
            }
        } else {
            dst.get_mut(at..at + n)
                .ok_or_else(bad)?
                .copy_from_slice(&w[..n]);
        }
        at += n;
        Ok(())
    };
    if method == 0 {
        let head = ans::get(&mut p, nt)?;
        let low = ans::get(&mut p, nt)?;
        let mut lo = &*low;
        if head.len() != nt || !p.is_empty() {
            return Err(bad());
        }
        for &h in &*head {
            let id = if (h as usize) < DIRECT {
                h as usize
            } else {
                DIRECT + ((h as usize - DIRECT) << 8) + take(&mut lo, 1)?[0] as usize
            };
            emit(id)?;
        }
        if !lo.is_empty() {
            return Err(bad());
        }
    } else {
        let n = u32in(&mut p)?;
        if n > 2 * nt || n < nt {
            return Err(bad());
        }
        let tag = take(&mut p, 1)?[0];
        let mut storage = vec![];
        let mut data = match tag {
            0 if p.len() == n => p,
            1 | 13 | 16 | 17 => {
                storage.resize(n, 0);
                match tag {
                    13 => lz::decode_impl::<true>(p, &mut storage),
                    16 => lz::decode_min::<false, 3>(p, &mut storage),
                    17 => lz::decode_min::<true, 3>(p, &mut storage),
                    _ => lz::decode(p, &mut storage),
                }?;
                &storage
            }
            _ => return Err(bad()),
        };
        for _ in 0..nt {
            let h = take(&mut data, 1)?[0] as usize;
            let id = if h < DIRECT {
                h
            } else {
                DIRECT + ((h - DIRECT) << 8) + take(&mut data, 1)?[0] as usize
            };
            emit(id)?;
        }
        if !data.is_empty() {
            return Err(bad());
        }
    }
    if at != dst.len() {
        return Err(bad());
    }
    Ok(())
}
