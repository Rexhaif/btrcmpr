// One head specifies both the spelling length and a contiguous range of words
// of that length. It therefore determines the output address and the number of
// index bits before a spelling has been fetched from the vocabulary.
use crate::{Result, ans, bad, take, u32in};
#[derive(Clone, Copy, Default)]
struct Group {
    w: u8,
    lo: usize,
    hi: usize,
    k: u8,
}
fn width(n: usize) -> u8 {
    usize::BITS as u8 - (n - 1).leading_zeros() as u8
}
#[cfg(feature = "research")]
pub(crate) fn pack<'a>(
    ids: &[u32],
    order: &[usize],
    spelling: &impl Fn(usize) -> &'a [u8],
    n: usize,
) -> Vec<u8> {
    pack_width::<16>(ids, order, spelling, n)
}
pub(crate) fn pack_width<'a, const LIMIT: usize>(
    ids: &[u32],
    order: &[usize],
    spelling: &impl Fn(usize) -> &'a [u8],
    n: usize,
) -> Vec<u8> {
    let mut counts = vec![0u32; order.len()];
    for &id in ids {
        counts[id as usize] += 1;
    }
    let mut sorted = Vec::with_capacity(order.len());
    let mut groups = vec![];
    for w in 1..=LIMIT {
        let start = sorted.len();
        sorted
            .extend((0..order.len()).filter(|&j| counts[j] != 0 && spelling(order[j]).len() == w));
        sorted[start..].sort_unstable_by_key(|&v| (std::cmp::Reverse(counts[v]), v));
        let end = sorted.len();
        let mut base = start;
        let mut span = 1;
        while base < end {
            let hi = (base + span).min(end);
            groups.push(Group {
                w: w as u8,
                lo: base,
                hi,
                k: width(hi - base),
            });
            base = hi;
            span *= 2;
        }
    }
    if groups.len() > 256 {
        // With a large, diverse block some lengths can require more than one
        // head per geometric tier. Start from length only; the split loop
        // below spends the available heads on the most useful subdivisions.
        let mut merged: Vec<Group> = vec![];
        for g in groups {
            if let Some(old) = merged.last_mut()
                && old.w == g.w
            {
                old.hi = g.hi;
                old.k = width(old.hi - old.lo);
            } else {
                merged.push(g);
            }
        }
        groups = merged;
    }
    let mut sum = vec![0u32];
    for &v in &sorted {
        sum.push(sum.last().unwrap() + counts[v]);
    }
    let price = |lo: usize, hi: usize| {
        let f = (sum[hi] - sum[lo]) as f64;
        f * (width(hi - lo) as f64 - f.log2())
    };
    while groups.len() < 256 {
        let mut best = None;
        let mut gain = 0.0;
        for (i, g) in groups.iter().enumerate() {
            if g.k == 0 {
                continue;
            }
            let mid = g.lo + (1 << (g.k - 1));
            let score = price(g.lo, g.hi) - price(g.lo, mid) - price(mid, g.hi);
            if score > gain {
                gain = score;
                best = Some((i, mid));
            }
        }
        let Some((i, mid)) = best else {
            break;
        };
        let g = groups[i];
        groups[i].hi = mid;
        groups[i].k = width(mid - g.lo);
        groups.push(Group {
            lo: mid,
            k: width(g.hi - mid),
            ..g
        });
    }
    assert!(!groups.is_empty() && groups.len() <= 256);
    groups.sort_unstable_by_key(|g| (g.w, g.lo));
    let mut out = Vec::new();
    out.extend((n as u32).to_le_bytes());
    out.push(29);
    out.extend((ids.len() as u32).to_le_bytes());
    out.push((groups.len() - 1) as u8);
    let mut map = vec![(0u8, 0u32); order.len()];
    let mut same = vec![];
    let mut dna = vec![];
    for (gi, g) in groups.iter().enumerate() {
        let count = g.hi - g.lo;
        out.push(g.w);
        out.extend((count as u32).to_le_bytes());
        sorted[g.lo..g.hi].sort_unstable_by(|&a, &b| spelling(order[a]).cmp(spelling(order[b])));
        let mut last = &[][..];
        for (i, &id) in sorted[g.lo..g.hi].iter().enumerate() {
            let raw = spelling(order[id]);
            let keep = raw.iter().zip(last).take_while(|(a, b)| a == b).count();
            same.push(keep as u8);
            dna.extend(&raw[keep..]);
            last = raw;
            map[id] = (gi as u8, i as u32);
        }
    }
    ans::put_tight(&same, &mut out);
    ans::put_tight(&dna, &mut out);
    let mut h = Vec::with_capacity(ids.len());
    let mut bits = Vec::new();
    let mut acc = 0u64;
    let mut nb = 0u32;
    for &id in ids {
        let (g, j) = map[id as usize];
        h.push(g);
        acc |= (j as u64) << nb;
        nb += groups[g as usize].k as u32;
        while nb >= 8 {
            bits.push(acc as u8);
            acc >>= 8;
            nb -= 8;
        }
    }
    if nb != 0 {
        bits.push(acc as u8);
    }
    ans::put_tight(&h, &mut out);
    out.extend((bits.len() as u32).to_le_bytes());
    out.extend(bits);
    out
}
#[derive(Clone, Copy, Default)]
struct Meta {
    start: u32,
    count: u32,
    width: u8,
    len: u8,
}
#[cfg(feature = "research")]
pub(crate) fn get(p: &mut &[u8], n: usize) -> Result<Vec<u8>> {
    Ok(expand::<false>(p, n)?.0)
}
#[cfg(feature = "research")]
pub(crate) fn expand<const RECORD: bool>(p: &mut &[u8], n: usize) -> Result<(Vec<u8>, Vec<u32>)> {
    let Rows {
        meta,
        spell,
        heads: h,
        bits,
    } = rows::<16>(p, n)?;
    let nt = h.len();
    let count = bits.len();
    let mut padded = Vec::with_capacity(bits.len() + 8);
    padded.extend(bits);
    padded.extend([0u8; 8]);
    let mut out = vec![0; n + 16];
    let mut bit = 0usize;
    let mut at = 0usize;
    let mut positions = [0u32; 64];
    let mut cursor = [0u32; 64];
    let mut groups = [Meta::default(); 64];
    let mut sources = [0u32; 64];
    let mut boundaries = if RECORD {
        Vec::with_capacity(nt + 1)
    } else {
        vec![]
    };
    for tile in h.chunks(64) {
        for (i, &v) in tile.iter().enumerate() {
            let m = meta[v as usize];
            groups[i] = m;
            positions[i] = at as u32;
            cursor[i] = bit as u32;
            at += m.len as usize;
            bit += m.width as usize;
        }
        if RECORD {
            boundaries.extend(&positions[..tile.len()]);
        }
        if at > n || bit > count * 8 {
            return Err(bad());
        }
        let mut invalid = 0u32;
        for i in 0..tile.len() {
            let m = groups[i];
            let b = cursor[i] as usize;
            let raw = unsafe { padded.as_ptr().add(b / 8).cast::<u32>().read_unaligned() }.to_le();
            let val = (raw >> (b & 7)) & ((1 << m.width) - 1);
            invalid |= u32::from(val >= m.count);
            sources[i] = m.start + val * m.len as u32;
            #[cfg(target_arch = "aarch64")]
            unsafe {
                core::arch::asm!("prfm pldl1keep, [{p}]",p=in(reg)spell.as_ptr().wrapping_add(sources[i]as usize),options(nostack,readonly,preserves_flags));
            }
        }
        if invalid != 0 {
            return Err(bad());
        }
        for i in 0..tile.len() {
            unsafe {
                std::ptr::copy_nonoverlapping(
                    spell.as_ptr().add(sources[i] as usize),
                    out.as_mut_ptr().add(positions[i] as usize),
                    16,
                );
            }
        }
    }
    if at != n
        || count != bit.div_ceil(8)
        || (!bit.is_multiple_of(8) && bits[bit / 8] >> (bit & 7) != 0)
    {
        return Err(bad());
    }
    out.truncate(n);
    if RECORD {
        boundaries.push(at as u32);
    }
    Ok((out, boundaries))
}

struct Rows<'a> {
    meta: [Meta; 256],
    spell: Vec<u8>,
    heads: std::borrow::Cow<'a, [u8]>,
    bits: &'a [u8],
}
fn rows<'a, const LIMIT: usize>(p: &mut &'a [u8], n: usize) -> Result<Rows<'a>> {
    let nt = u32in(p)?;
    let ng = take(p, 1)?[0] as usize + 1;
    if nt == 0 || nt > n {
        return Err(bad());
    }
    let mut meta = [Meta::default(); 256];
    let mut dict = 0;
    let mut bytes = 0;
    for g in &mut meta[..ng] {
        let len = take(p, 1)?[0];
        let count = u32in(p)?;
        if !(1..=LIMIT as u8).contains(&len)
            || count == 0
            || count > nt - dict
            || count * len as usize > n - bytes
        {
            return Err(bad());
        }
        *g = Meta {
            count: count as u32,
            start: bytes as u32,
            width: width(count),
            len,
        };
        dict += count;
        bytes += count * len as usize;
    }
    let same = crate::wordbase::plain(p, dict)?;
    let dna = crate::wordbase::plain(p, bytes)?;
    let mut chars = &*dna;
    if same.len() != dict {
        return Err(bad());
    }
    let mut spell = vec![0u8; bytes + LIMIT];
    let mut ix = 0;
    let mut at = 0;
    for g in &meta[..ng] {
        let w = g.len as usize;
        let mut row = [0u8; LIMIT];
        for j in 0..g.count {
            let keep = same[ix] as usize;
            ix += 1;
            if keep > w || (j == 0 && keep != 0) {
                return Err(bad());
            }
            row[keep..w].copy_from_slice(take(&mut chars, w - keep)?);
            spell[at..at + LIMIT].copy_from_slice(&row);
            at += w;
        }
    }
    if !chars.is_empty() {
        return Err(bad());
    }
    let h = crate::wordbase::plain(p, nt)?;
    let count = u32in(p)?;
    let bits = take(p, count)?;
    if h.len() != nt {
        return Err(bad());
    }
    Ok(Rows {
        meta,
        spell,
        heads: h,
        bits,
    })
}

// Each compact head identifies a range of equal-length spellings. Compute
// the descriptor arithmetically, without an indexed load from a large table.
pub(crate) fn word_descriptors(p: &mut &[u8], n: usize) -> Result<(Vec<u8>, Vec<u32>)> {
    let Rows {
        meta,
        spell,
        heads,
        bits,
    } = rows::<64>(p, n)?;
    let mut src = Vec::from(bits);
    src.extend([0; 8]);
    let mut offsets = [0u32; 32];
    let mut buckets = [Meta::default(); 32];
    let mut at = 0usize;
    let mut result = vec![0u32; heads.len()];
    for (hh, dd) in heads.chunks(32).zip(result.chunks_mut(32)) {
        for (j, &head) in hh.iter().enumerate() {
            let m = meta[head as usize];
            offsets[j] = at as u32;
            buckets[j] = m;
            at += usize::from(m.width);
        }
        if at > bits.len() * 8 {
            return Err(bad());
        }
        let mut invalid = 0;
        for (j, v) in dd.iter_mut().enumerate() {
            let m = buckets[j];
            let b = offsets[j] as usize;
            let raw = unsafe { src.as_ptr().add(b / 8).cast::<u32>().read_unaligned() }.to_le();
            let index = (raw >> (b & 7)) & ((1 << m.width) - 1);
            invalid |= u32::from(index >= m.count);
            // Unused heads are reported below; wrapping arithmetic also works
            // for their zero length and does not address the spelling arena.
            *v = (m.start + index * u32::from(m.len)) << 6 | u32::from(m.len).wrapping_sub(1);
        }
        if invalid != 0 {
            return Err(bad());
        }
    }
    if bits.len() != at.div_ceil(8) || (!at.is_multiple_of(8) && bits[at / 8] >> (at & 7) != 0) {
        return Err(bad());
    }
    Ok((spell, result))
}
