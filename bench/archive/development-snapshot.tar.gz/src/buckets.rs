// Set-associative prefix index. Each bucket is contiguous; unlike a chain,
// following a collision never requires a second load to find the next slot.
use crate::lz::{Streams, common, word};
const MASK: usize = (1 << 21) - 1;
#[derive(Clone, Copy)]
struct Choice {
    len: usize,
    pos: usize,
    gain: i32,
}
struct Table<const W: usize> {
    b: Vec<[u32; W]>,
    bits: u32,
    shift: u32,
}
impl<const W: usize> Table<W> {
    fn new(bits: u32, prefix: u32) -> Self {
        Self {
            b: vec![[u32::MAX; W]; 1 << bits],
            bits,
            shift: 64 - prefix * 8,
        }
    }
    #[inline(always)]
    fn key(&self, w: u64) -> (usize, u32) {
        let a = (w << self.shift).wrapping_mul(0x9e3779b97f4a7c15);
        ((a >> (64 - self.bits)) as usize, ((a >> 25) as u32) << 21)
    }
    #[inline(always)]
    fn add(&mut self, w: u64, i: usize) {
        let (k, sig) = self.key(w);
        let b = &mut self.b[k];
        b.copy_within(0..W - 1, 1);
        b[0] = i as u32 | sig;
    }
    #[inline(always)]
    fn find(&self, s: &[u8], i: usize, w: u64, rep: usize, best: &mut Choice) {
        let (k, sig) = self.key(w);
        for &e in &self.b[k] {
            let p = e as usize & MASK;
            if (e ^ sig) > MASK as u32 || p >= i {
                continue;
            }
            let off = i - p;
            let x = word(s, p) ^ w;
            let len = if x == 0 {
                8 + common(s, p + 8, i + 8)
            } else {
                x.trailing_zeros() as usize / 8
            };
            if len < 4 {
                continue;
            }
            let gain = len.min(1 << 24) as i32 * 6
                - if off == rep {
                    1
                } else {
                    4 + off.ilog2() as i32
                };
            if gain > best.gain {
                *best = Choice { len, pos: p, gain };
                if len >= 80 {
                    return;
                }
            }
        }
    }
}
pub(crate) fn encode<const W: usize, const LONG: usize, const B: u32, const A: usize>(
    s: &[u8],
) -> Vec<u8> {
    let mut short = Table::<W>::new(B, 4);
    let mut long = Table::<LONG>::new(B, 8);
    let mut st = Streams::sized(s.len());
    let (mut anchor, mut i, mut indexed) = (0, 0, 0);
    while i + 8 <= s.len() {
        let w = word(s, i);
        let rep = st.rep[0];
        let mut best = Choice {
            len: 0,
            pos: 0,
            gain: 0,
        };
        long.find(s, i, w, rep, &mut best);
        if best.len < 64 {
            short.find(s, i, w, rep, &mut best);
        }
        if i >= rep {
            let p = i - rep;
            let x = word(s, p) ^ w;
            let l = if x == 0 {
                8 + common(s, p + 8, i + 8)
            } else {
                x.trailing_zeros() as usize / 8
            };
            let gain = l.min(1 << 24) as i32 * 6 - 1;
            if l >= 4 && gain > best.gain {
                best = Choice {
                    len: l,
                    pos: p,
                    gain,
                };
            }
        }
        if indexed <= i {
            short.add(w, i);
            long.add(w, i);
            indexed = i + 1;
        }
        if best.len < 4 {
            i += 1;
            continue;
        }
        let base = i;
        let mut chosen = i;
        if best.len < 48 {
            for k in 1..=A {
                let at = base + k;
                if at + 8 > s.len() {
                    break;
                }
                let z = word(s, at);
                let mut c = Choice {
                    len: 0,
                    pos: 0,
                    gain: 0,
                };
                long.find(s, at, z, rep, &mut c);
                if c.len < 48 {
                    short.find(s, at, z, rep, &mut c);
                }
                if indexed <= at {
                    short.add(z, at);
                    long.add(z, at);
                    indexed = at + 1;
                }
                c.gain -= k as i32 * 5;
                if c.len >= 4 && c.gain > best.gain {
                    best = c;
                    chosen = at;
                }
            }
        }
        i = chosen;
        let off = i - best.pos;
        while i > anchor && best.pos > 0 && s[i - 1] == s[best.pos - 1] {
            i -= 1;
            best.pos -= 1;
            best.len += 1;
        }
        st.emit(s, anchor, i, best.len, off);
        i += best.len;
        anchor = i;
        let end = i.min(s.len().saturating_sub(7));
        while indexed < end {
            let z = word(s, indexed);
            short.add(z, indexed);
            long.add(z, indexed);
            indexed += 1;
        }
    }
    st.finish(s, anchor, false)
}
