// For possibly raw distance bytes and literals, sample disjoint stripes.
// Pair collisions estimate the sum of squared byte probabilities; a nearly
// uniform stream is unlikely to pay for an entropy header. A wrong decision
// only affects size: a raw field always carries all of its original bytes.
fn dispersed<const SAMPLES: usize>(s: &[u8], effective: usize) -> bool {
    const STRIPES: usize = 16;
    let width = SAMPLES / STRIPES;
    let mut hist = [0u16; 256];
    let mut count = 0usize;
    let limit = SAMPLES * (SAMPLES - 1) / (2 * effective);
    for j in 0..STRIPES {
        let start = (s.len() - width) * j / (STRIPES - 1);
        for &b in &s[start..start + width] {
            let h = &mut hist[b as usize];
            count += usize::from(*h);
            *h += 1;
        }
        if count > limit {
            return false;
        }
    }
    true
}
pub(super) fn wants(s: &[u8], field: usize, archive: bool, mode: usize) -> bool {
    if s.len() < 2048 || !(field == 4 || field == 5 || (field == 3 && archive && mode >= 5)) {
        return false;
    }
    // Plain distance suffixes are most often raw; modes 1-2 measure the
    // cost and byte tradeoff of omitting their statistical test altogether.
    if mode <= 2 && !archive {
        return true;
    }
    if mode == 1 && archive {
        return false;
    }
    let cutoff = if archive {
        match mode {
            2 | 3 | 5 => 192,
            4 | 6 => 166,
            7 => 145,
            _ => 210,
        }
    } else {
        match mode {
            3 | 5 => 245,
            4 | 6 => 232,
            7 => 219,
            _ => 251,
        }
    };
    if mode == 5 || mode == 6 {
        dispersed::<256>(s, cutoff)
    } else if mode == 8 {
        dispersed::<1024>(s, cutoff)
    } else {
        dispersed::<512>(s, cutoff)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn raw_detector_distinguishes_local_runs_from_balanced_samples() {
        let fixed = vec![19; 16384];
        let mut x = 39133013u32;
        let balanced: Vec<_> = (0..32_768)
            .map(|_| {
                x = x.wrapping_mul(1664525).wrapping_add(1013904223);
                (x >> 24) as u8
            })
            .collect();
        assert!(!wants(&fixed, 4, true, 7));
        assert!(wants(&balanced, 4, true, 7));
        assert!(!wants(&balanced, 0, true, 7));
        assert!(!wants(&balanced[..50], 5, false, 1));
        assert!(wants(&fixed, 4, false, 1));
    }
}
