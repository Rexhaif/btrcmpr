// Index short tiles before parsing them. At each four-position batch the old
// slots are read before new ones are written. A bitmap lists viable prefixes;
// consuming a match discards all bitmap bits covered by that copy at once.
use super::{MASK, common, word};

#[inline(always)]
fn index<const P: usize, const B: usize, const MIX: bool>(w: u64) -> (usize, u32) {
    let v = (w << (64 - 8 * P)).wrapping_mul(0x9e3779b97f4a7c15);
    let h = (v >> (64 - B)) as usize;
    let tag = if MIX {
        (v >> (64 - B - 11)) as u32
    } else {
        w as u32
    };
    (h, tag << 21)
}
#[inline(always)]
fn collect<
    const P: usize,
    const B: usize,
    const MIX: bool,
    const STORE: usize,
    const PROBE: usize,
>(
    s: &[u8],
    base: usize,
    old: &mut [u32],
    table: &mut [u32],
) -> u64 {
    debug_assert!(base + old.len() + 7 <= s.len());
    let mut mask = 0u64;
    for (chunk, dst) in old.chunks_mut(4).enumerate() {
        let start = base + chunk * 4;
        let mut keys = [0; 4];
        let mut slots = [0; 4];
        // Four unrestricted source loads fit inside the caller's readable
        // tile. Reading an index before updating it never introduces a future
        // candidate, even when several prefix hashes collide in this group.
        for (j, pos) in dst.iter_mut().enumerate() {
            let i = start + j;
            let w = unsafe { s.as_ptr().add(i).cast::<u64>().read_unaligned() }.to_le();
            let (k, sig) = index::<P, B, MIX>(w);
            keys[j] = k;
            slots[j] = sig | i as u32;
            if PROBE == 1 || j % PROBE == 0 {
                let v = table[k];
                *pos = v & MASK as u32;
                mask |= u64::from((v ^ sig) <= MASK as u32) << (chunk * 4 + j);
            }
        }
        for j in 0..dst.len() {
            if STORE == 1 || STORE == 2 && j % 2 == 0 || STORE == 3 && j != 3 {
                table[keys[j]] = slots[j];
            }
        }
    }
    mask
}
fn scan<
    const TILE: usize,
    const P: usize,
    const B: usize,
    const MIX: bool,
    const STORE: usize,
    const PROBE: usize,
>(
    s: &[u8],
    mut emit: impl FnMut(usize, usize, usize, usize),
) -> usize {
    const {
        assert!(TILE >= 4 && TILE <= 64 && TILE.is_multiple_of(4));
    }
    let mut table = vec![0u32; 1 << B];
    let mut prior = [0u32; TILE];
    let mut base = 0;
    let mut anchor = 0;
    let stop = s.len().saturating_sub(7);
    while base < stop {
        let live = TILE.min(stop - base);
        let mut mask = collect::<P, B, MIX, STORE, PROBE>(s, base, &mut prior[..live], &mut table);
        while mask != 0 {
            let j = mask.trailing_zeros() as usize;
            mask &= mask - 1;
            let i = base + j;
            let q = prior[j] as usize;
            if q >= i {
                continue;
            }
            let d = word(s, i) ^ word(s, q);
            if d as u32 != 0 || (d >> 32) as u8 != 0 && i - q > 12000 {
                continue;
            }
            let n = if d == 0 {
                8 + common(s, q + 8, i + 8)
            } else {
                d.trailing_zeros() as usize / 8
            };
            let mut back = 0;
            while back < i - anchor && back < q && s[i - back - 1] == s[q - back - 1] {
                back += 1
            }
            emit(anchor, i - back, n + back, i - q);
            anchor = i + n;
            let skip = anchor - base;
            if skip >= live {
                break;
            }
            mask &= u64::MAX << skip;
        }
        // Rebase after a long copy instead of paying for intervening tiles.
        base = (base + live).max(anchor);
    }
    anchor
}
pub(super) fn walk(s: &[u8], mode: usize, emit: impl FnMut(usize, usize, usize, usize)) -> usize {
    macro_rules! m {
        ($t:literal,$p:literal,$b:literal,$mix:literal,$st:literal,$pr:literal) => {
            scan::<$t, $p, $b, $mix, $st, $pr>(s, emit)
        };
    }
    match mode {
        1 => m!(8, 6, 15, true, 1, 1),
        2 => m!(16, 6, 15, true, 1, 1),
        3 => m!(32, 6, 15, true, 1, 1),
        4 => m!(64, 6, 15, true, 1, 1),
        5 => m!(8, 6, 15, true, 2, 1),
        6 => m!(16, 6, 15, true, 2, 1),
        7 => m!(32, 6, 15, true, 2, 1),
        8 => m!(64, 6, 15, true, 2, 1),
        9 => m!(16, 6, 15, false, 2, 1),
        10 => m!(32, 6, 15, false, 1, 1),
        11 => m!(16, 6, 15, true, 3, 1),
        12 => m!(32, 6, 15, true, 3, 1),
        13 => m!(8, 5, 15, true, 1, 2),
        14 => m!(16, 5, 15, true, 1, 2),
        15 => m!(32, 6, 15, true, 1, 2),
        16 => m!(64, 6, 15, true, 1, 2),
        17 => m!(16, 7, 14, true, 2, 1),
        18 => m!(32, 7, 14, true, 1, 2),
        19 => m!(16, 6, 16, true, 2, 1),
        _ => m!(32, 6, 16, true, 1, 2),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn tile_masks_skip_consumed_starts_and_preserve_all_bytes() {
        let mut s = Vec::new();
        let mut v = 514331u32;
        for i in 0..6500 {
            v = v.wrapping_mul(1664525).wrapping_add(1013904223);
            s.push((v >> 24) as u8);
            if i % 7 == 0 {
                s.extend_from_slice(b"bytes in tiles with copies and padding ");
            }
            if i % 11 == 0 && s.len() > 280 {
                let j = (v as usize) % (s.len() - 137);
                s.extend_from_within(j..j + 137);
            }
        }
        s.extend_from_within(..);
        s.extend([0; 167]);
        for m in 1..=20 {
            for n in (0..83).chain([1001, s.len()]) {
                let mut dst = Vec::new();
                let end = walk(&s[..n], m, |a, i, len, d| {
                    assert_eq!(dst.len(), a);
                    assert!(a <= i && i + len <= n && len >= 4 && d > 0 && d <= i);
                    dst.extend_from_slice(&s[a..i]);
                    for _ in 0..len {
                        dst.push(dst[dst.len() - d]);
                    }
                });
                assert_eq!(dst.len(), end);
                dst.extend_from_slice(&s[end..n]);
                assert_eq!(dst, s[..n]);
            }
        }
    }
}
