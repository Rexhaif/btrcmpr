// A block-local phrase alphabet. Every dictionary entry is literally present
// in this input; the stream carries the dictionary and needs no corpus model.
use crate::{Result, ans, bad, lz, take, u32in};
const DIRECT: usize = 64;
const LIMIT: usize = DIRECT + 64 * 256;
#[inline]
fn letter(c: u8) -> bool {
    (c | 32).wrapping_sub(b'a') < 26
}
pub fn detect(s: &[u8]) -> bool {
    if s.len() < 16384 {
        return false;
    }
    let mut alpha = 0;
    let mut printable = 0;
    for j in 0..512 {
        let c = s[(s.len() - 1) * j / 511];
        alpha += letter(c) as usize;
        printable += (c == 10 || c == 13 || (32..127).contains(&c)) as usize;
    }
    alpha > 240 && printable > 470
}
#[cfg(feature = "research")]
#[derive(Clone, Copy, Default)]
struct Entry {
    key: u64,
    at: u32,
    count: u32,
    id: u16,
    len: u8,
}
#[cfg(feature = "research")]
#[inline]
fn key(s: &[u8]) -> u64 {
    let mut a = 0x243f6a8885a308d3u64 ^ s.len() as u64;
    for w in s.chunks_exact(8) {
        a = (a ^ u64::from_le_bytes(w.try_into().unwrap())).wrapping_mul(0xa177c9d8f0a158ad);
    }
    let mut end = 0;
    for &c in s.chunks_exact(8).remainder() {
        end = (end << 8) | c as u64;
    }
    a = (a ^ end).wrapping_mul(0x9e3779b97f4a7c15);
    a ^ (a >> 32)
}
#[cfg(feature = "research")]
#[inline]
fn find(s: &[u8], lo: usize, end: usize, tab: &[Entry]) -> (usize, u64) {
    let v = &s[lo..end];
    let k = key(v);
    let mut h = k as usize & (tab.len() - 1);
    loop {
        let e = tab[h];
        if e.len == 0
            || (e.key == k
                && e.len as usize == v.len()
                && &s[e.at as usize..e.at as usize + v.len()] == v)
        {
            return (h, k);
        }
        h = (h + 1) & (tab.len() - 1);
    }
}
#[cfg(feature = "research")]
#[inline]
fn end(s: &[u8], mut i: usize) -> usize {
    while i < s.len() && letter(s[i]) {
        i += 1;
    }
    i + usize::from(s.get(i) == Some(&b' '))
}
#[cfg(feature = "research")]
pub fn encode(s: &[u8], level: u8, method: u8) -> Option<Vec<u8>> {
    if !detect(s) {
        return None;
    }
    let cap = (s.len() / 9).next_power_of_two().clamp(8192, 1 << 19);
    let mut tab = vec![Entry::default(); cap];
    let mut used = 0;
    let mut i = 0;
    while i < s.len() {
        if !letter(s[i]) {
            i += 1;
            continue;
        }
        let j = end(s, i + 1);
        let n = j - i;
        if (3..=32).contains(&n) {
            let (h, k) = find(s, i, j, &tab);
            if tab[h].len == 0 {
                if used * 4 < cap * 3 {
                    tab[h] = Entry {
                        key: k,
                        at: i as u32,
                        count: 1,
                        id: u16::MAX,
                        len: n as u8,
                    };
                    used += 1;
                }
            } else {
                tab[h].count += 1;
            }
        }
        i = j;
    }
    let mut ids: Vec<_> = (0..cap)
        .filter(|&h| {
            tab[h].count >= 3
                && (tab[h].count - 1) * (tab[h].len as u32 - 2) > tab[h].len as u32 + 2
        })
        .collect();
    ids.sort_unstable_by_key(|&h| {
        (
            std::cmp::Reverse((tab[h].count - 1) * (tab[h].len as u32 - 2)),
            h,
        )
    });
    ids.truncate(LIMIT);
    if ids.len() < DIRECT {
        return None;
    }
    // A one-byte rank saves one extra byte per occurrence. Give those
    // positions to the most frequent retained words.
    ids.select_nth_unstable_by_key(DIRECT - 1, |&h| (std::cmp::Reverse(tab[h].count), h));
    let raw = |h: usize| {
        let e = tab[h];
        &s[e.at as usize..e.at as usize + e.len as usize]
    };
    ids[..DIRECT].sort_unstable_by_key(|&h| raw(h));
    ids[DIRECT..].sort_unstable_by_key(|&h| raw(h));
    let mut dict = vec![];
    let mut last: &[u8] = &[];
    for (id, &h) in ids.iter().enumerate() {
        let e = tab[h];
        let w = &s[e.at as usize..e.at as usize + e.len as usize];
        let shared = last.iter().zip(w).take_while(|(a, b)| a == b).count();
        dict.push(shared as u8);
        dict.push((w.len() - shared) as u8);
        dict.extend(&w[shared..]);
        last = w;
        tab[h].id = id as u16;
    }
    let mut tokens = Vec::with_capacity(s.len() / 2);
    i = 0;
    while i < s.len() {
        if letter(s[i]) {
            let j = end(s, i + 1);
            let n = j - i;
            if (3..=32).contains(&n) {
                let (h, _) = find(s, i, j, &tab);
                let e = tab[h];
                if e.len != 0 && e.id != u16::MAX {
                    let id = e.id as usize;
                    if id < DIRECT {
                        tokens.push(128 + id as u8);
                    } else {
                        let v = id - DIRECT;
                        tokens.extend([192 + (v >> 8) as u8, v as u8]);
                    }
                    i = j;
                    continue;
                }
            }
            tokens.extend(&s[i..j]);
            i = j;
        } else {
            let b = s[i];
            if b >= 127 {
                tokens.push(127);
            }
            tokens.push(b);
            i += 1;
        }
    }
    if tokens.len() >= s.len() {
        return None;
    }
    let mut out = vec![7];
    out.extend((ids.len() as u16).to_le_bytes());
    out.extend((tokens.len() as u32).to_le_bytes());
    ans::put_policy(&dict, &mut out, 0.99);
    let enc = if method == 1 {
        crate::sorted::encode(&tokens, level)
    } else if method == 2 {
        lz::optimal(&tokens, level)
    } else {
        lz::encode_level::<false>(&tokens, level)
    };
    if enc.len() >= tokens.len() {
        out.push(0);
        out.extend(tokens);
    } else {
        out.extend(enc);
    }
    Some(out)
}
pub fn decode(mut p: &[u8], dst: &mut [u8]) -> Result<()> {
    let count = u16::from_le_bytes(take(&mut p, 2)?.try_into().unwrap()) as usize;
    if !(DIRECT..=LIMIT).contains(&count) {
        return Err(bad());
    }
    let n = u32in(&mut p)?;
    if n > dst.len() {
        return Err(bad());
    }
    let def = ans::get(&mut p, count * 34)?;
    let mut defs = &*def;
    let mut words = vec![[0u8; 32]; count];
    let mut sizes = vec![0u8; count];
    let mut prev = [0u8; 32];
    let mut len = 0;
    for (w, sz) in words.iter_mut().zip(&mut sizes) {
        let h = take(&mut defs, 2)?;
        let keep = h[0] as usize;
        let add = h[1] as usize;
        if keep > len || keep + add > 32 || keep + add == 0 {
            return Err(bad());
        }
        len = keep + add;
        prev[keep..len].copy_from_slice(take(&mut defs, add)?);
        *w = prev;
        *sz = len as u8;
    }
    if !defs.is_empty() {
        return Err(bad());
    }
    let mut storage = vec![];
    let kind = take(&mut p, 1)?[0];
    let t = match kind {
        0 if p.len() == n => p,
        1 | 13 | 16 | 17 => {
            storage.resize(n, 0);
            match kind {
                13 => lz::decode_impl::<true>(p, &mut storage),
                16 => lz::decode_min::<false, 3>(p, &mut storage),
                17 => lz::decode_min::<true, 3>(p, &mut storage),
                _ => lz::decode(p, &mut storage),
            }?;
            &storage
        }
        11 => {
            storage.resize(n, 0);
            crate::sorted::decode(p, &mut storage)?;
            &storage
        }
        _ => return Err(bad()),
    };
    let mut i = 0;
    let mut at = 0;
    while i < t.len() {
        let b = t[i];
        i += 1;
        if b < 128 {
            let byte = if b == 127 {
                let v = *t.get(i).ok_or_else(bad)?;
                i += 1;
                v
            } else {
                b
            };
            *dst.get_mut(at).ok_or_else(bad)? = byte;
            at += 1;
        } else {
            let id = if b < 192 {
                (b - 128) as usize
            } else {
                let v = *t.get(i).ok_or_else(bad)?;
                i += 1;
                DIRECT + ((b - 192) as usize) * 256 + v as usize
            };
            let w = words.get(id).ok_or_else(bad)?;
            let l = sizes[id] as usize;
            if at + 32 <= dst.len() {
                unsafe {
                    std::ptr::copy_nonoverlapping(w.as_ptr(), dst.as_mut_ptr().add(at), 32);
                }
            } else {
                dst.get_mut(at..at + l)
                    .ok_or_else(bad)?
                    .copy_from_slice(&w[..l]);
            }
            at += l;
        }
    }
    if at != dst.len() {
        return Err(bad());
    }
    Ok(())
}
