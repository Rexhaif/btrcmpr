// Length-limited prefix codes and a multi-symbol decode table.
use crate::{Result, bad, take, u32in};
use std::{cmp::Reverse, collections::BinaryHeap};
const K: usize = 11;
const SIZE: usize = 1 << K;
fn lengths(counts: &[u32; 256]) -> [u8; 256] {
    let mut heap = BinaryHeap::new();
    let mut parents = [0u16; 512];
    let mut sorted = Vec::new();
    for (i, &c) in counts.iter().enumerate() {
        if c != 0 {
            heap.push(Reverse((c, i)));
            sorted.push(i)
        }
    }
    let mut next = 256;
    while heap.len() > 1 {
        let Reverse((a, x)) = heap.pop().unwrap();
        let Reverse((b, y)) = heap.pop().unwrap();
        parents[x] = next as u16;
        parents[y] = next as u16;
        heap.push(Reverse((a + b, next)));
        next += 1
    }
    let mut depths = [0usize; 512];
    let mut buckets = [0; K + 1];
    let mut units = 0;
    for i in (0..next - 1).rev() {
        depths[i] = depths[parents[i] as usize] + 1;
        if i < 256 && counts[i] != 0 {
            let l = depths[i].min(K);
            buckets[l] += 1;
            units += 1 << (K - l)
        }
    }
    while units > SIZE {
        let j = (1..K).rev().find(|&j| buckets[j] > 0).unwrap();
        buckets[j] -= 1;
        buckets[j + 1] += 2;
        buckets[K] -= 1;
        units -= 1
    }
    sorted.sort_unstable_by_key(|&i| Reverse(counts[i]));
    let mut lens = [0u8; 256];
    let mut at = 0;
    for (l, &n) in buckets.iter().enumerate().skip(1) {
        for &i in &sorted[at..at + n] {
            lens[i] = l as u8
        }
        at += n
    }
    lens
}
fn codes(lens: &[u8; 256]) -> Result<[u16; 256]> {
    let mut count = [0u32; K + 1];
    for &l in lens {
        if l as usize > K {
            return Err(bad());
        }
        count[l as usize] += 1
    }
    count[0] = 0;
    let mut next = [0u32; K + 1];
    for i in 1..=K {
        next[i] = (next[i - 1] + count[i - 1]) * 2
    }
    if next[K] + count[K] != SIZE as u32 {
        return Err(bad());
    }
    let mut table = [0; 256];
    for i in 0..256 {
        let l = lens[i] as usize;
        if l != 0 {
            let val = next[l];
            next[l] += 1;
            table[i] = (val.reverse_bits() >> (32 - l)) as u16
        }
    }
    Ok(table)
}
pub fn put(data: &[u8], counts: &[u32; 256], out: &mut Vec<u8>, ideal: f64) -> bool {
    let lens = lengths(counts);
    let nbits: usize = lens
        .iter()
        .zip(counts)
        .map(|(&l, &c)| l as usize * c as usize)
        .sum();
    // rANS wins decisively for sharply skewed streams.
    if nbits as f64 > ideal * 1.06 + 1200. || nbits / 8 + 176 >= data.len() {
        return false;
    }
    let tab = codes(&lens).unwrap();
    out.push(4);
    for a in lens.chunks_exact(2) {
        out.push(a[0] | (a[1] << 4))
    }
    let step = data.len().div_ceil(4);
    #[cfg(feature = "research")]
    if crate::tuning("BTR_HUFF_PACK", 0, 0, 1) != 0 {
        let map = std::array::from_fn(|i| u32::from(tab[i]) | (u32::from(lens[i]) << 16));
        for lane in data.chunks(step) {
            packed_lane(lane, &map, out)
        }
        return true;
    }
    for lane in data.chunks(step) {
        let mark = out.len();
        out.extend([0; 4]);
        let mut bits = 0u64;
        let mut k = 0;
        let mut nb = 0;
        for &c in lane {
            let len = lens[c as usize] as u32;
            bits |= (tab[c as usize] as u64) << k;
            k += len;
            nb += len;
            if k >= 32 {
                out.extend((bits as u32).to_le_bytes());
                bits >>= 32;
                k -= 32
            }
        }
        out.extend_from_slice(&bits.to_le_bytes()[..k.div_ceil(8) as usize]);
        out.extend([0; 4]);
        out[mark..mark + 4].copy_from_slice(&nb.to_le_bytes());
    }
    true
}
#[cfg(feature = "research")]
fn packed_lane(data: &[u8], table: &[u32; 256], out: &mut Vec<u8>) {
    let start = out.len();
    out.extend([0; 4]);
    // A group contributes at most 44 bits, plus the previous partial byte.
    // Spare capacity covers an unaligned 64-bit store at every position.
    out.reserve((data.len() * K).div_ceil(8) + 8);
    let dst = unsafe { out.as_mut_ptr().add(start + 4) };
    let mut bits = 0usize;
    let mut carry = 0u64;
    let mut chunks = data.chunks_exact(4);
    for c in &mut chunks {
        let mut entries = [0; 4];
        for j in 0..4 {
            entries[j] = table[c[j] as usize]
        }
        let [a, b, c, d] = entries;
        let wa = a >> 16;
        let wb = b >> 16;
        let wc = c >> 16;
        let left = u64::from(a as u16) | (u64::from(b as u16) << wa);
        let right = u64::from(c as u16) | (u64::from(d as u16) << wc);
        let x = carry | ((left | (right << (wa + wb))) << (bits & 7));
        let n = (wa + wb + wc + (d >> 16)) as usize;
        unsafe { std::ptr::write_unaligned(dst.add(bits / 8).cast::<u64>(), x.to_le()) }
        carry = x >> (((bits & 7) + n) & !7);
        bits += n;
    }
    for &c in chunks.remainder() {
        let a = table[c as usize];
        let n = (a >> 16) as usize;
        let x = carry | (u64::from(a as u16) << (bits & 7));
        unsafe { std::ptr::write_unaligned(dst.add(bits / 8).cast::<u64>(), x.to_le()) }
        carry = x >> (((bits & 7) + n) & !7);
        bits += n;
    }
    // All bytes before the rounded-up bit count were initialized by the
    // overlapping stores. The format's four padding bytes are zero.
    unsafe { out.set_len(start + 4 + bits.div_ceil(8)) };
    out.extend([0; 4]);
    out[start..start + 4].copy_from_slice(&(bits as u32).to_le_bytes());
}
#[derive(Clone, Copy, Default)]
#[repr(C, align(8))]
struct E {
    word: u32,
    bits: u8,
    n: u8,
}
#[derive(Clone, Copy)]
struct Lane<'a> {
    src: &'a [u8],
    end: usize,
    nb: usize,
    pos: usize,
    bit: usize,
}
pub fn get(p: &mut &[u8], n: usize) -> Result<Vec<u8>> {
    if n < 16 {
        return Err(bad());
    }
    let mut lens = [0u8; 256];
    for (c, &b) in lens.chunks_exact_mut(2).zip(take(p, 128)?) {
        c[0] = b & 15;
        c[1] = b >> 4
    }
    let codes = codes(&lens)?;
    let mut single = [0u16; SIZE];
    for c in 0..256 {
        let l = lens[c];
        if l != 0 {
            for x in (codes[c] as usize..SIZE).step_by(1 << l) {
                single[x] = ((l as u16) << 8) | c as u16
            }
        }
    }
    #[cfg(feature = "research")]
    if crate::tuning("BTR_HUFF_SINGLE", 0, 0, 1) != 0 {
        return single_lanes(p, n, &single);
    }
    let mut tab = [E::default(); SIZE];
    for (x, e) in tab.iter_mut().enumerate() {
        let mut key = x;
        while e.n < 4 {
            let v = single[key];
            let b = (v >> 8) as u8;
            if e.bits + b > K as u8 {
                break;
            }
            e.word |= ((v & 255) as u32) << (e.n * 8);
            e.bits += b;
            e.n += 1;
            key >>= b
        }
    }
    let mut out = vec![0u8; n];
    let mut lanes = [Lane {
        src: &[],
        end: 0,
        nb: 0,
        pos: 0,
        bit: 0,
    }; 4];
    let step = n.div_ceil(4);
    for (j, l) in lanes.iter_mut().enumerate() {
        let nb = u32in(p)?;
        let src = take(p, nb.div_ceil(8) + 4)?;
        *l = Lane {
            src,
            end: ((j + 1) * step).min(n),
            nb,
            pos: j * step,
            bit: 0,
        }
    }
    while lanes
        .iter()
        .all(|l| l.pos + 32 <= l.end && l.bit + 8 * K <= l.nb)
    {
        for _ in 0..8 {
            for l in &mut lanes {
                // At most 32 bytes of output and 88 input bits per eight iterations.
                unsafe {
                    let w = std::ptr::read_unaligned(l.src.as_ptr().add(l.bit / 8).cast::<u32>())
                        .to_le();
                    let e = tab[((w >> (l.bit & 7)) as usize) & (SIZE - 1)];
                    std::ptr::write_unaligned(
                        out.as_mut_ptr().add(l.pos).cast::<u32>(),
                        e.word.to_le(),
                    );
                    l.bit += e.bits as usize;
                    l.pos += e.n as usize
                }
            }
        }
    }
    for l in &mut lanes {
        while l.pos < l.end {
            if l.bit >= l.nb {
                return Err(bad());
            }
            let w = u32::from_le_bytes(l.src[l.bit / 8..l.bit / 8 + 4].try_into().unwrap());
            let v = single[((w >> (l.bit & 7)) as usize) & (SIZE - 1)];
            out[l.pos] = v as u8;
            l.pos += 1;
            l.bit += (v >> 8) as usize;
        }
        if l.bit != l.nb {
            return Err(bad());
        }
    }
    Ok(out)
}
#[cfg(feature = "research")]
fn single_lanes(p: &mut &[u8], n: usize, table: &[u16; SIZE]) -> Result<Vec<u8>> {
    let mut out = vec![0; n];
    let step = n.div_ceil(4);
    let mut src = [&[][..]; 4];
    let mut nb = [0; 4];
    let mut bit = [0usize; 4];
    for j in 0..4 {
        nb[j] = u32in(p)?;
        src[j] = take(p, nb[j].div_ceil(8) + 4)?
    }
    let mut at = 0;
    while at + 8 <= n - 3 * step && (0..4).all(|j| bit[j] + 8 * K <= nb[j]) {
        for i in 0..8 {
            for j in 0..4 {
                // Each of eight single-symbol steps consumes no more than K
                // bits; every lane has four extra readable padding bytes.
                let word = unsafe {
                    std::ptr::read_unaligned(src[j].as_ptr().add(bit[j] / 8).cast::<u32>())
                }
                .to_le();
                let v = table[((word >> (bit[j] & 7)) as usize) & (SIZE - 1)];
                out[j * step + at + i] = v as u8;
                bit[j] += usize::from(v >> 8);
            }
        }
        at += 8;
    }
    for j in 0..4 {
        for v in &mut out[j * step + at..((j + 1) * step).min(n)] {
            if bit[j] >= nb[j] {
                return Err(bad());
            }
            let w = u32::from_le_bytes(src[j][bit[j] / 8..bit[j] / 8 + 4].try_into().unwrap());
            let x = table[((w >> (bit[j] & 7)) as usize) & (SIZE - 1)];
            *v = x as u8;
            bit[j] += usize::from(x >> 8);
        }
        if bit[j] != nb[j] {
            return Err(bad());
        }
    }
    Ok(out)
}
#[cfg(all(test, feature = "research"))]
mod pack_tests {
    use super::*;
    #[test]
    fn packed_lanes_match_scalar_wire_and_decode_partial_groups() {
        let mut state = 319u32;
        let mut raw = vec![];
        for _ in 0..8083 {
            state = state.wrapping_mul(1664525).wrapping_add(1013904223);
            let x = (state >> 24) as u8;
            raw.push(if x < 181 { (x >> 5) + 33 } else { x });
        }
        let mut counts = [0u32; 256];
        for &v in &raw {
            counts[v as usize] += 1
        }
        let lens = lengths(&counts);
        let table = codes(&lens).unwrap();
        let ent = std::array::from_fn(|i| u32::from(table[i]) | (u32::from(lens[i]) << 16));
        let mut singles = [0u16; SIZE];
        for id in 0..256 {
            let l = lens[id];
            if l > 0 {
                for x in (table[id] as usize..SIZE).step_by(1 << l) {
                    singles[x] = (u16::from(l) << 8) | id as u16
                }
            }
        }
        for end in (16..40).chain([1027, raw.len()]) {
            let data = &raw[..end];
            let mut wire = Vec::new();
            for lane in data.chunks(end.div_ceil(4)) {
                let mut expected = vec![0u8; 4];
                let mut bits = 0usize;
                for &b in lane {
                    let l = usize::from(lens[b as usize]);
                    let code = table[b as usize];
                    for k in 0..l {
                        if bits.is_multiple_of(8) {
                            expected.push(0)
                        }
                        if code >> k & 1 != 0 {
                            expected[4 + bits / 8] |= 1 << (bits & 7)
                        }
                        bits += 1;
                    }
                }
                expected[..4].copy_from_slice(&(bits as u32).to_le_bytes());
                expected.extend([0; 4]);
                let mark = wire.len();
                packed_lane(lane, &ent, &mut wire);
                assert_eq!(&wire[mark..], expected);
            }
            assert_eq!(
                single_lanes(&mut wire.as_slice(), end, &singles).unwrap(),
                data
            );
            assert!(single_lanes(&mut &wire[..wire.len() - 1], end, &singles).is_err());
        }
    }
}
