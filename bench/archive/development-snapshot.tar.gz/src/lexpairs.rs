// Learn a small byte-piece alphabet solely from the current block. Each pass
// selects frequent adjacent pairs, then fuses verified pairs left-to-right.
// Collisions affect which pairs are proposed, never which bytes they mean.
use crate::lex::Term;
const SLOTS: usize = 1 << 16;
#[inline(always)]
fn slot(k: u32) -> usize {
    (k.wrapping_mul(0x9e3779b1)
        .rotate_left(11)
        .wrapping_mul(0x85ebca6b)
        >> 16) as usize
}
#[inline(always)]
fn pair(a: u16, b: u16) -> u32 {
    ((a as u32) << 16) | b as u32
}
pub(crate) fn tokenize(s: &[u8], limit: usize, initial: usize) -> (Vec<Term>, Vec<u32>) {
    let mut lengths = vec![1u8; 256];
    let mut ids: Vec<u16> = s.iter().map(|&x| x as u16).collect();
    let mut keys = vec![u32::MAX; SLOTS];
    let mut counts = vec![0u32; SLOTS];
    let mut assigned = vec![0u16; SLOTS];
    let mut round = 0;
    while lengths.len() < limit && ids.len() > 4 {
        keys.fill(u32::MAX);
        counts.fill(0);
        assigned.fill(0);
        let stride = (ids.len() / 400_000).max(1);
        for j in ((round * 7) % stride..ids.len() - 1).step_by(stride) {
            let a = ids[j];
            let b = ids[j + 1];
            if lengths[a as usize] + lengths[b as usize] > 16 {
                continue;
            }
            let k = pair(a, b);
            let h = slot(k);
            if keys[h] == k {
                counts[h] += 1;
            } else if counts[h] == 0 {
                keys[h] = k;
                counts[h] = 1;
            } else {
                counts[h] -= 1;
            }
        }
        let mut winners: Vec<usize> = (0..SLOTS).filter(|&h| counts[h] >= 3).collect();
        let cap = (initial << round.min(4)).min(limit - lengths.len());
        if winners.len() > cap {
            winners.select_nth_unstable_by_key(cap, |&h| (std::cmp::Reverse(counts[h]), h));
            winners.truncate(cap);
        }
        if winners.is_empty() {
            break;
        }
        for h in winners {
            let k = keys[h];
            assigned[h] = lengths.len() as u16;
            lengths.push(lengths[(k >> 16) as usize] + lengths[(k as u16) as usize]);
        }
        let old = ids.len();
        let mut from = 0;
        let mut w = 0;
        while from + 1 < old {
            let a = ids[from];
            let k = pair(a, ids[from + 1]);
            let h = slot(k);
            if assigned[h] != 0 && keys[h] == k {
                ids[w] = assigned[h];
                from += 2;
            } else {
                ids[w] = a;
                from += 1;
            }
            w += 1;
        }
        if from < old {
            ids[w] = ids[from];
            w += 1;
        }
        ids.truncate(w);
        round += 1;
        if old - w < old / 1024 {
            break;
        }
    }
    let mut remap = vec![u32::MAX; lengths.len()];
    let mut used: Vec<Term> = vec![];
    let mut out = Vec::with_capacity(ids.len());
    let mut pos = 0;
    for id in ids {
        let k = id as usize;
        let len = lengths[k];
        if remap[k] == u32::MAX {
            remap[k] = used.len() as u32;
            used.push(Term {
                pos: pos as u32,
                len,
                count: 0,
            });
        }
        let rank = remap[k];
        used[rank as usize].count += 1;
        out.push(rank);
        pos += len as usize;
    }
    debug_assert_eq!(pos, s.len());
    (used, out)
}
